# EXP-008 (nombre DNS, segunda escritura)

- ns_op: {"c_a_mano": 109.901, "rust": 106.564, "go": 185.074}
- ns_op_por_estrato: {"aleatorio": {"c_a_mano": 13.57, "rust": 13.057, "go": 13.687}, "cortos": {"c_a_mano": 102.524, "rust": 99.472, "go": 191.947}, "largos": {"c_a_mano": 216.667, "rust": 209.904, "go": 334.014}}
- especificacion_equivale_exp007: {"obligacion": "equivalente a la semántica", "estado": "desconocido", "segundos": 10099.8, "detalle": "Z3: timeout", "contraejemplo": null}
- esfuerzos_exp007_contadores_f4: {"efch_total": 102, "c_lineas": 34, "dafny_lineas": 49, "dafny_anotaciones": 6}
```json
{
  "D0": {
    "cumple": true,
    "indefinidas": {
      "diferencial_nativo": 0,
      "diferencial_externo": 0
    },
    "especificacion_vectores_fallidos": []
  },
  "D1": {
    "valor": "revisión manual: ver la ficha (estado empaquetado y límite de recursión)",
    "cumple": null
  },
  "D2": {
    "valor": {
      "estado": "desconocido",
      "segundos": 880.05,
      "codigo": 124,
      "detalle": "sin veredicto (código 124); fase no registrada",
      "herramienta": "desconocida"
    },
    "cumple": false
  },
  "D3": {
    "valor": "no comprobado: el C de EFCH no se ejecuta sin «probado» (F1)",
    "cumple": false
  },
  "D4": {
    "rust_kani": {
      "esfuerzo_relativo": 1.067,
      "a": false,
      "b": false,
      "c": false,
      "cumple": false
    },
    "dafny": {
      "esfuerzo_relativo": 1.959,
      "a": false,
      "b": false,
      "c": false,
      "cumple": false
    },
    "cumple": false
  },
  "D5": {
    "aplica": true,
    "valor": "medición ausente",
    "cumple": false
  },
  "decision": "no cumplido"
}
```
