#define _POSIX_C_SOURCE 199309L
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
typedef unsigned __int128 efch_u128;
int efch_ipv4_header__lang(const uint8_t *in_b, size_t in_b_len, uint64_t *out0, uint64_t *out1, uint64_t *out2, uint64_t *out3);
int efch_ipv4_header__lang_b(const uint8_t *in_b, size_t in_b_len, uint64_t *out0, uint64_t *out1, uint64_t *out2, uint64_t *out3);
static uint64_t *in0_n; static uint8_t *in0_b;
static volatile uint64_t sink;
static double now_ns(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1e9 + ts.tv_nsec; }
__attribute__((noinline)) static double win_efch_ipv4_header__lang(size_t count) { uint64_t o0 = 0, o1 = 0, o2 = 0, o3 = 0; uint64_t acc = 0; o0 = 0; o1 = 0; o2 = 0; o3 = 0; double t0 = now_ns(); for (int p = 0; p < 32; p++) for (size_t i = 0; i < count; i++) { acc += (uint64_t)efch_ipv4_header__lang(in0_b + (size_t)i * 60, (size_t)in0_n[i], &o0, &o1, &o2, &o3) + o0; } double t = (now_ns() - t0) / ((double)count * 32); sink += acc; return t; }
__attribute__((noinline)) static double win_efch_ipv4_header__lang_b(size_t count) { uint64_t o0 = 0, o1 = 0, o2 = 0, o3 = 0; uint64_t acc = 0; o0 = 0; o1 = 0; o2 = 0; o3 = 0; double t0 = now_ns(); for (int p = 0; p < 32; p++) for (size_t i = 0; i < count; i++) { acc += (uint64_t)efch_ipv4_header__lang_b(in0_b + (size_t)i * 60, (size_t)in0_n[i], &o0, &o1, &o2, &o3) + o0; } double t = (now_ns() - t0) / ((double)count * 32); sink += acc; return t; }
int main(int argc, char **argv) {
    if (argc != 2) return 2;
    FILE *f = fopen(argv[1], "rb"); if (!f) return 1;
    uint64_t count64; if (fread(&count64, 8, 1, f) != 1) return 1;
    size_t count = (size_t)count64;
    in0_n = malloc(count * 8); in0_b = malloc(count * 60); if (fread(in0_n, 8, count, f) != count || fread(in0_b, 60, count, f) != count) return 1;
    fclose(f);
    for (int w = 0; w < 2; w++) { win_efch_ipv4_header__lang(count); win_efch_ipv4_header__lang_b(count); }
    printf("[");
    for (int b = 0; b < 16; b++) {
        double a1, a2, b1, b2;
        if (b % 2 == 0) { a1 = win_efch_ipv4_header__lang(count); b1 = win_efch_ipv4_header__lang_b(count); b2 = win_efch_ipv4_header__lang_b(count); a2 = win_efch_ipv4_header__lang(count); }
        else { b1 = win_efch_ipv4_header__lang_b(count); a1 = win_efch_ipv4_header__lang(count); a2 = win_efch_ipv4_header__lang(count); b2 = win_efch_ipv4_header__lang_b(count); }
        printf("%s[%.4f, %.4f, %.4f, %.4f]", b ? ", " : "", a1, a2, b1, b2);
    }
    printf("]\n");
    return 0;
}
