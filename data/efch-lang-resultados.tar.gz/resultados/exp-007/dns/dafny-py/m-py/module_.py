import sys
from typing import Callable, Any, TypeVar, NamedTuple
from math import floor
from itertools import count

import module_ as module_
import _dafny as _dafny
import System_ as System_

# Module: module_

class default__:
    def  __init__(self):
        pass

    @staticmethod
    def IsLdh(c):
        return (((((97) <= (c)) and ((c) <= (122))) or (((65) <= (c)) and ((c) <= (90)))) or (((48) <= (c)) and ((c) <= (57)))) or ((c) == (45))

    @staticmethod
    def ValidLabel(b, p, l):
        def lambda0_(forall_var_0_):
            d_0_j_: int = forall_var_0_
            return not (((p) < (d_0_j_)) and ((d_0_j_) <= ((p) + (l)))) or (default__.IsLdh((b)[d_0_j_]))

        return ((((b)[(p) + (1)]) != (45)) and (((b)[(p) + (l)]) != (45))) and (_dafny.quantifier(_dafny.IntegerRange((p) + (1), ((p) + (l)) + (1)), True, lambda0_))

    @staticmethod
    def Spec(b, p, labels):
        while True:
            with _dafny.label():
                if (p) >= (len(b)):
                    return Option_None()
                elif ((b)[p]) == (0):
                    return Option_Some(((p) + (1), labels, 65535))
                elif ((b)[p]) >= (192):
                    if ((p) + (1)) < (len(b)):
                        return Option_Some(((p) + (2), labels, ((((b)[p]) - (192)) * (256)) + ((b)[(p) + (1)])))
                    elif True:
                        return Option_None()
                elif ((b)[p]) >= (64):
                    return Option_None()
                elif (((p) + ((b)[p])) < (len(b))) and (default__.ValidLabel(b, p, (b)[p])):
                    in0_ = b
                    in1_ = ((p) + (1)) + ((b)[p])
                    in2_ = (labels) + (1)
                    b = in0_
                    p = in1_
                    labels = in2_
                    raise _dafny.TailCall()
                elif True:
                    return Option_None()
                break

    @staticmethod
    def Parse(b):
        r: Option = Option.default()()
        d_0_pos_: int
        d_1_labels_: int
        rhs0_ = 0
        rhs1_ = 0
        d_0_pos_ = rhs0_
        d_1_labels_ = rhs1_
        while (d_0_pos_) < (len(b)):
            d_2_n_: int
            d_2_n_ = (b)[d_0_pos_]
            if (d_2_n_) == (0):
                r = Option_Some(((d_0_pos_) + (1), d_1_labels_, 65535))
                return r
            if (d_2_n_) >= (192):
                if ((d_0_pos_) + (1)) >= (len(b)):
                    r = Option_None()
                    return r
                r = Option_Some(((d_0_pos_) + (2), d_1_labels_, (((d_2_n_) - (192)) * (256)) + ((b)[(d_0_pos_) + (1)])))
                return r
            if ((((d_2_n_) >= (64)) or (((d_0_pos_) + (d_2_n_)) >= (len(b)))) or (((b)[(d_0_pos_) + (1)]) == (45))) or (((b)[(d_0_pos_) + (d_2_n_)]) == (45)):
                r = Option_None()
                return r
            d_3_j_: int
            d_3_j_ = (d_0_pos_) + (1)
            while (d_3_j_) <= ((d_0_pos_) + (d_2_n_)):
                if not(default__.IsLdh((b)[d_3_j_])):
                    r = Option_None()
                    return r
                d_3_j_ = (d_3_j_) + (1)
            d_1_labels_ = (d_1_labels_) + (1)
            d_0_pos_ = ((d_0_pos_) + (1)) + (d_2_n_)
        r = Option_None()
        return r
        return r


class u8:
    def  __init__(self):
        pass

    @staticmethod
    def default():
        return int(0)
    def _Is(source__):
        return True

class Option:
    @classmethod
    def default(cls, ):
        return lambda: Option_None()
    def __ne__(self, __o: object) -> bool:
        return not self.__eq__(__o)
    @property
    def is_None(self) -> bool:
        return isinstance(self, Option_None)
    @property
    def is_Some(self) -> bool:
        return isinstance(self, Option_Some)

class Option_None(Option, NamedTuple('None_', [])):
    def __dafnystr__(self) -> str:
        return f'Option.None'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, Option_None)
    def __hash__(self) -> int:
        return super().__hash__()

class Option_Some(Option, NamedTuple('Some', [('value', Any)])):
    def __dafnystr__(self) -> str:
        return f'Option.Some({_dafny.string_of(self.value)})'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, Option_Some) and self.value == __o.value
    def __hash__(self) -> int:
        return super().__hash__()

