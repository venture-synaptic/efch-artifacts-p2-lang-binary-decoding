#include <stddef.h>
#include <stdint.h>
#include <string.h>
typedef unsigned __int128 efch_u128;

/* Operaciones con signo sobre valores de w bits guardados sin signo y enmascarados. Solo usan
   aritmética sin signo: no hay comportamiento indefinido ni dependiente de la implementación. */
#define EFCH_SIGNED_OPS(T, SUF)                                                               \
static inline T efch_mask##SUF(unsigned w) { return w >= 8 * sizeof(T) ? (T)~(T)0 : (((T)1 << w) - 1); } \
static inline int efch_slt##SUF(T x, T y, unsigned w) { T s = (T)1 << (w - 1); return (x ^ s) < (y ^ s); } \
static inline T efch_sext##SUF(T x, unsigned w, unsigned n) {                                 \
    return (x & ((T)1 << (w - 1))) ? (x | (efch_mask##SUF(n) & ~efch_mask##SUF(w))) : x; }    \
static inline T efch_ashr##SUF(T x, T k, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int neg = (x >> (w - 1)) & 1;                                    \
    if (k >= w) return neg ? m : 0;                                                           \
    return (x >> k) | (neg ? (m & ~(m >> k)) : 0); }                                          \
static inline T efch_sdiv##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return nx ? 1 : m;                                                            \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, q = ax / ay;                     \
    return (nx != ny) ? ((T)-q & m) : q; }                                                    \
static inline T efch_srem##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return x;                                                                     \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, r = ax % ay;                     \
    return nx ? ((T)-r & m) : r; }
EFCH_SIGNED_OPS(uint64_t, 64)
EFCH_SIGNED_OPS(efch_u128, 128)

int efch_dns_hostname_wire__lang(const uint8_t *in_b, size_t in_b_len, uint64_t *out0, uint64_t *out1, uint64_t *out2)
{
    uint64_t v1 = UINT64_C(0);
    uint64_t v2 = UINT64_C(0);
    uint64_t v3 = UINT64_C(0);
    uint64_t v4 = UINT64_C(0);
    uint64_t v5 = UINT64_C(0);
    uint64_t v6 = UINT64_C(0xffff);
    uint64_t v7 = ((uint64_t)((uint64_t)in_b_len));
    int v8 = (UINT64_C(0) < v7);
    uint64_t t24;
    if (v8) {
        uint64_t v9 = ((uint64_t)in_b[UINT64_C(0)]);
        int v10 = ((v1 == UINT64_C(0)) && (UINT64_C(0) == v2));
        int v11 = (v10 && (v9 == UINT64_C(0)));
        int v12 = ((v10 && ((v9 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(1) < ((uint64_t)((uint64_t)in_b_len))));
        int v13 = (((v10 && (v9 != UINT64_C(0))) && (v9 < UINT64_C(64))) && (((uint64_t)((UINT64_C(0) + v9) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t16 = ((v1 == UINT64_C(0)) && (UINT64_C(0) != v2));
        if (t16) {
                uint64_t v14 = v9;
            int t15 = (!(((((v14 | UINT64_C(32)) >= UINT64_C(97)) && ((v14 | UINT64_C(32)) <= UINT64_C(122))) || ((v14 >= UINT64_C(48)) && (v14 <= UINT64_C(57)))) || (v14 == UINT64_C(45))));
            if (!t15) {
                t15 = ((v9 == UINT64_C(45)) && ((UINT64_C(0) == ((v3 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(1) == v2)));
            }
            t16 = t15;
        }
        int v17 = t16;
        uint64_t v18 = (v11 ? UINT64_C(1) : (v12 ? UINT64_C(2) : v5));
        uint64_t v19 = (v12 ? (((((uint64_t)(v9 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(1)]))) : v6);
        uint64_t v20 = (v13 ? ((v4 + UINT64_C(1)) & UINT64_C(255)) : v4);
        uint64_t v21 = (v13 ? UINT64_C(0) : v3);
        uint64_t v22 = (v13 ? ((uint64_t)((UINT64_C(1) + v9) & UINT64_C(255))) : v2);
        uint64_t v23 = ((v11 || v12) ? UINT64_C(1) : ((v17 || (v10 && (!v13))) ? UINT64_C(2) : v1));
        t24 = v18;
    } else {
        t24 = v5;
    }
    uint64_t v25 = t24;
    uint64_t t41;
    if (v8) {
        uint64_t v26 = ((uint64_t)in_b[UINT64_C(0)]);
        int v27 = ((v1 == UINT64_C(0)) && (UINT64_C(0) == v2));
        int v28 = (v27 && (v26 == UINT64_C(0)));
        int v29 = ((v27 && ((v26 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(1) < ((uint64_t)((uint64_t)in_b_len))));
        int v30 = (((v27 && (v26 != UINT64_C(0))) && (v26 < UINT64_C(64))) && (((uint64_t)((UINT64_C(0) + v26) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t33 = ((v1 == UINT64_C(0)) && (UINT64_C(0) != v2));
        if (t33) {
                uint64_t v31 = v26;
            int t32 = (!(((((v31 | UINT64_C(32)) >= UINT64_C(97)) && ((v31 | UINT64_C(32)) <= UINT64_C(122))) || ((v31 >= UINT64_C(48)) && (v31 <= UINT64_C(57)))) || (v31 == UINT64_C(45))));
            if (!t32) {
                t32 = ((v26 == UINT64_C(45)) && ((UINT64_C(0) == ((v3 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(1) == v2)));
            }
            t33 = t32;
        }
        int v34 = t33;
        uint64_t v35 = (v28 ? UINT64_C(1) : (v29 ? UINT64_C(2) : v5));
        uint64_t v36 = (v29 ? (((((uint64_t)(v26 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(1)]))) : v6);
        uint64_t v37 = (v30 ? ((v4 + UINT64_C(1)) & UINT64_C(255)) : v4);
        uint64_t v38 = (v30 ? UINT64_C(0) : v3);
        uint64_t v39 = (v30 ? ((uint64_t)((UINT64_C(1) + v26) & UINT64_C(255))) : v2);
        uint64_t v40 = ((v28 || v29) ? UINT64_C(1) : ((v34 || (v27 && (!v30))) ? UINT64_C(2) : v1));
        t41 = v37;
    } else {
        t41 = v4;
    }
    uint64_t v42 = t41;
    uint64_t t58;
    if (v8) {
        uint64_t v43 = ((uint64_t)in_b[UINT64_C(0)]);
        int v44 = ((v1 == UINT64_C(0)) && (UINT64_C(0) == v2));
        int v45 = (v44 && (v43 == UINT64_C(0)));
        int v46 = ((v44 && ((v43 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(1) < ((uint64_t)((uint64_t)in_b_len))));
        int v47 = (((v44 && (v43 != UINT64_C(0))) && (v43 < UINT64_C(64))) && (((uint64_t)((UINT64_C(0) + v43) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t50 = ((v1 == UINT64_C(0)) && (UINT64_C(0) != v2));
        if (t50) {
                uint64_t v48 = v43;
            int t49 = (!(((((v48 | UINT64_C(32)) >= UINT64_C(97)) && ((v48 | UINT64_C(32)) <= UINT64_C(122))) || ((v48 >= UINT64_C(48)) && (v48 <= UINT64_C(57)))) || (v48 == UINT64_C(45))));
            if (!t49) {
                t49 = ((v43 == UINT64_C(45)) && ((UINT64_C(0) == ((v3 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(1) == v2)));
            }
            t50 = t49;
        }
        int v51 = t50;
        uint64_t v52 = (v45 ? UINT64_C(1) : (v46 ? UINT64_C(2) : v5));
        uint64_t v53 = (v46 ? (((((uint64_t)(v43 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(1)]))) : v6);
        uint64_t v54 = (v47 ? ((v4 + UINT64_C(1)) & UINT64_C(255)) : v4);
        uint64_t v55 = (v47 ? UINT64_C(0) : v3);
        uint64_t v56 = (v47 ? ((uint64_t)((UINT64_C(1) + v43) & UINT64_C(255))) : v2);
        uint64_t v57 = ((v45 || v46) ? UINT64_C(1) : ((v51 || (v44 && (!v47))) ? UINT64_C(2) : v1));
        t58 = v56;
    } else {
        t58 = v2;
    }
    uint64_t v59 = t58;
    uint64_t t75;
    if (v8) {
        uint64_t v60 = ((uint64_t)in_b[UINT64_C(0)]);
        int v61 = ((v1 == UINT64_C(0)) && (UINT64_C(0) == v2));
        int v62 = (v61 && (v60 == UINT64_C(0)));
        int v63 = ((v61 && ((v60 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(1) < ((uint64_t)((uint64_t)in_b_len))));
        int v64 = (((v61 && (v60 != UINT64_C(0))) && (v60 < UINT64_C(64))) && (((uint64_t)((UINT64_C(0) + v60) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t67 = ((v1 == UINT64_C(0)) && (UINT64_C(0) != v2));
        if (t67) {
                uint64_t v65 = v60;
            int t66 = (!(((((v65 | UINT64_C(32)) >= UINT64_C(97)) && ((v65 | UINT64_C(32)) <= UINT64_C(122))) || ((v65 >= UINT64_C(48)) && (v65 <= UINT64_C(57)))) || (v65 == UINT64_C(45))));
            if (!t66) {
                t66 = ((v60 == UINT64_C(45)) && ((UINT64_C(0) == ((v3 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(1) == v2)));
            }
            t67 = t66;
        }
        int v68 = t67;
        uint64_t v69 = (v62 ? UINT64_C(1) : (v63 ? UINT64_C(2) : v5));
        uint64_t v70 = (v63 ? (((((uint64_t)(v60 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(1)]))) : v6);
        uint64_t v71 = (v64 ? ((v4 + UINT64_C(1)) & UINT64_C(255)) : v4);
        uint64_t v72 = (v64 ? UINT64_C(0) : v3);
        uint64_t v73 = (v64 ? ((uint64_t)((UINT64_C(1) + v60) & UINT64_C(255))) : v2);
        uint64_t v74 = ((v62 || v63) ? UINT64_C(1) : ((v68 || (v61 && (!v64))) ? UINT64_C(2) : v1));
        t75 = v70;
    } else {
        t75 = v6;
    }
    uint64_t v76 = t75;
    uint64_t t92;
    if (v8) {
        uint64_t v77 = ((uint64_t)in_b[UINT64_C(0)]);
        int v78 = ((v1 == UINT64_C(0)) && (UINT64_C(0) == v2));
        int v79 = (v78 && (v77 == UINT64_C(0)));
        int v80 = ((v78 && ((v77 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(1) < ((uint64_t)((uint64_t)in_b_len))));
        int v81 = (((v78 && (v77 != UINT64_C(0))) && (v77 < UINT64_C(64))) && (((uint64_t)((UINT64_C(0) + v77) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t84 = ((v1 == UINT64_C(0)) && (UINT64_C(0) != v2));
        if (t84) {
                uint64_t v82 = v77;
            int t83 = (!(((((v82 | UINT64_C(32)) >= UINT64_C(97)) && ((v82 | UINT64_C(32)) <= UINT64_C(122))) || ((v82 >= UINT64_C(48)) && (v82 <= UINT64_C(57)))) || (v82 == UINT64_C(45))));
            if (!t83) {
                t83 = ((v77 == UINT64_C(45)) && ((UINT64_C(0) == ((v3 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(1) == v2)));
            }
            t84 = t83;
        }
        int v85 = t84;
        uint64_t v86 = (v79 ? UINT64_C(1) : (v80 ? UINT64_C(2) : v5));
        uint64_t v87 = (v80 ? (((((uint64_t)(v77 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(1)]))) : v6);
        uint64_t v88 = (v81 ? ((v4 + UINT64_C(1)) & UINT64_C(255)) : v4);
        uint64_t v89 = (v81 ? UINT64_C(0) : v3);
        uint64_t v90 = (v81 ? ((uint64_t)((UINT64_C(1) + v77) & UINT64_C(255))) : v2);
        uint64_t v91 = ((v79 || v80) ? UINT64_C(1) : ((v85 || (v78 && (!v81))) ? UINT64_C(2) : v1));
        t92 = v89;
    } else {
        t92 = v3;
    }
    uint64_t v93 = t92;
    uint64_t t109;
    if (v8) {
        uint64_t v94 = ((uint64_t)in_b[UINT64_C(0)]);
        int v95 = ((v1 == UINT64_C(0)) && (UINT64_C(0) == v2));
        int v96 = (v95 && (v94 == UINT64_C(0)));
        int v97 = ((v95 && ((v94 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(1) < ((uint64_t)((uint64_t)in_b_len))));
        int v98 = (((v95 && (v94 != UINT64_C(0))) && (v94 < UINT64_C(64))) && (((uint64_t)((UINT64_C(0) + v94) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t101 = ((v1 == UINT64_C(0)) && (UINT64_C(0) != v2));
        if (t101) {
                uint64_t v99 = v94;
            int t100 = (!(((((v99 | UINT64_C(32)) >= UINT64_C(97)) && ((v99 | UINT64_C(32)) <= UINT64_C(122))) || ((v99 >= UINT64_C(48)) && (v99 <= UINT64_C(57)))) || (v99 == UINT64_C(45))));
            if (!t100) {
                t100 = ((v94 == UINT64_C(45)) && ((UINT64_C(0) == ((v3 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(1) == v2)));
            }
            t101 = t100;
        }
        int v102 = t101;
        uint64_t v103 = (v96 ? UINT64_C(1) : (v97 ? UINT64_C(2) : v5));
        uint64_t v104 = (v97 ? (((((uint64_t)(v94 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(1)]))) : v6);
        uint64_t v105 = (v98 ? ((v4 + UINT64_C(1)) & UINT64_C(255)) : v4);
        uint64_t v106 = (v98 ? UINT64_C(0) : v3);
        uint64_t v107 = (v98 ? ((uint64_t)((UINT64_C(1) + v94) & UINT64_C(255))) : v2);
        uint64_t v108 = ((v96 || v97) ? UINT64_C(1) : ((v102 || (v95 && (!v98))) ? UINT64_C(2) : v1));
        t109 = v108;
    } else {
        t109 = v1;
    }
    uint64_t v110 = t109;
    int v111 = (UINT64_C(1) < v7);
    uint64_t t127;
    if (v111) {
        uint64_t v112 = ((uint64_t)in_b[UINT64_C(1)]);
        int v113 = ((v110 == UINT64_C(0)) && (UINT64_C(1) == v59));
        int v114 = (v113 && (v112 == UINT64_C(0)));
        int v115 = ((v113 && ((v112 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(2) < ((uint64_t)((uint64_t)in_b_len))));
        int v116 = (((v113 && (v112 != UINT64_C(0))) && (v112 < UINT64_C(64))) && (((uint64_t)((UINT64_C(1) + v112) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t119 = ((v110 == UINT64_C(0)) && (UINT64_C(1) != v59));
        if (t119) {
                uint64_t v117 = v112;
            int t118 = (!(((((v117 | UINT64_C(32)) >= UINT64_C(97)) && ((v117 | UINT64_C(32)) <= UINT64_C(122))) || ((v117 >= UINT64_C(48)) && (v117 <= UINT64_C(57)))) || (v117 == UINT64_C(45))));
            if (!t118) {
                t118 = ((v112 == UINT64_C(45)) && ((UINT64_C(1) == ((v93 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(2) == v59)));
            }
            t119 = t118;
        }
        int v120 = t119;
        uint64_t v121 = (v114 ? UINT64_C(2) : (v115 ? UINT64_C(3) : v25));
        uint64_t v122 = (v115 ? (((((uint64_t)(v112 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(2)]))) : v76);
        uint64_t v123 = (v116 ? ((v42 + UINT64_C(1)) & UINT64_C(255)) : v42);
        uint64_t v124 = (v116 ? UINT64_C(1) : v93);
        uint64_t v125 = (v116 ? ((uint64_t)((UINT64_C(2) + v112) & UINT64_C(255))) : v59);
        uint64_t v126 = ((v114 || v115) ? UINT64_C(1) : ((v120 || (v113 && (!v116))) ? UINT64_C(2) : v110));
        t127 = v121;
    } else {
        t127 = v25;
    }
    uint64_t v128 = t127;
    uint64_t t144;
    if (v111) {
        uint64_t v129 = ((uint64_t)in_b[UINT64_C(1)]);
        int v130 = ((v110 == UINT64_C(0)) && (UINT64_C(1) == v59));
        int v131 = (v130 && (v129 == UINT64_C(0)));
        int v132 = ((v130 && ((v129 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(2) < ((uint64_t)((uint64_t)in_b_len))));
        int v133 = (((v130 && (v129 != UINT64_C(0))) && (v129 < UINT64_C(64))) && (((uint64_t)((UINT64_C(1) + v129) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t136 = ((v110 == UINT64_C(0)) && (UINT64_C(1) != v59));
        if (t136) {
                uint64_t v134 = v129;
            int t135 = (!(((((v134 | UINT64_C(32)) >= UINT64_C(97)) && ((v134 | UINT64_C(32)) <= UINT64_C(122))) || ((v134 >= UINT64_C(48)) && (v134 <= UINT64_C(57)))) || (v134 == UINT64_C(45))));
            if (!t135) {
                t135 = ((v129 == UINT64_C(45)) && ((UINT64_C(1) == ((v93 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(2) == v59)));
            }
            t136 = t135;
        }
        int v137 = t136;
        uint64_t v138 = (v131 ? UINT64_C(2) : (v132 ? UINT64_C(3) : v25));
        uint64_t v139 = (v132 ? (((((uint64_t)(v129 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(2)]))) : v76);
        uint64_t v140 = (v133 ? ((v42 + UINT64_C(1)) & UINT64_C(255)) : v42);
        uint64_t v141 = (v133 ? UINT64_C(1) : v93);
        uint64_t v142 = (v133 ? ((uint64_t)((UINT64_C(2) + v129) & UINT64_C(255))) : v59);
        uint64_t v143 = ((v131 || v132) ? UINT64_C(1) : ((v137 || (v130 && (!v133))) ? UINT64_C(2) : v110));
        t144 = v140;
    } else {
        t144 = v42;
    }
    uint64_t v145 = t144;
    uint64_t t161;
    if (v111) {
        uint64_t v146 = ((uint64_t)in_b[UINT64_C(1)]);
        int v147 = ((v110 == UINT64_C(0)) && (UINT64_C(1) == v59));
        int v148 = (v147 && (v146 == UINT64_C(0)));
        int v149 = ((v147 && ((v146 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(2) < ((uint64_t)((uint64_t)in_b_len))));
        int v150 = (((v147 && (v146 != UINT64_C(0))) && (v146 < UINT64_C(64))) && (((uint64_t)((UINT64_C(1) + v146) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t153 = ((v110 == UINT64_C(0)) && (UINT64_C(1) != v59));
        if (t153) {
                uint64_t v151 = v146;
            int t152 = (!(((((v151 | UINT64_C(32)) >= UINT64_C(97)) && ((v151 | UINT64_C(32)) <= UINT64_C(122))) || ((v151 >= UINT64_C(48)) && (v151 <= UINT64_C(57)))) || (v151 == UINT64_C(45))));
            if (!t152) {
                t152 = ((v146 == UINT64_C(45)) && ((UINT64_C(1) == ((v93 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(2) == v59)));
            }
            t153 = t152;
        }
        int v154 = t153;
        uint64_t v155 = (v148 ? UINT64_C(2) : (v149 ? UINT64_C(3) : v25));
        uint64_t v156 = (v149 ? (((((uint64_t)(v146 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(2)]))) : v76);
        uint64_t v157 = (v150 ? ((v42 + UINT64_C(1)) & UINT64_C(255)) : v42);
        uint64_t v158 = (v150 ? UINT64_C(1) : v93);
        uint64_t v159 = (v150 ? ((uint64_t)((UINT64_C(2) + v146) & UINT64_C(255))) : v59);
        uint64_t v160 = ((v148 || v149) ? UINT64_C(1) : ((v154 || (v147 && (!v150))) ? UINT64_C(2) : v110));
        t161 = v159;
    } else {
        t161 = v59;
    }
    uint64_t v162 = t161;
    uint64_t t178;
    if (v111) {
        uint64_t v163 = ((uint64_t)in_b[UINT64_C(1)]);
        int v164 = ((v110 == UINT64_C(0)) && (UINT64_C(1) == v59));
        int v165 = (v164 && (v163 == UINT64_C(0)));
        int v166 = ((v164 && ((v163 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(2) < ((uint64_t)((uint64_t)in_b_len))));
        int v167 = (((v164 && (v163 != UINT64_C(0))) && (v163 < UINT64_C(64))) && (((uint64_t)((UINT64_C(1) + v163) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t170 = ((v110 == UINT64_C(0)) && (UINT64_C(1) != v59));
        if (t170) {
                uint64_t v168 = v163;
            int t169 = (!(((((v168 | UINT64_C(32)) >= UINT64_C(97)) && ((v168 | UINT64_C(32)) <= UINT64_C(122))) || ((v168 >= UINT64_C(48)) && (v168 <= UINT64_C(57)))) || (v168 == UINT64_C(45))));
            if (!t169) {
                t169 = ((v163 == UINT64_C(45)) && ((UINT64_C(1) == ((v93 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(2) == v59)));
            }
            t170 = t169;
        }
        int v171 = t170;
        uint64_t v172 = (v165 ? UINT64_C(2) : (v166 ? UINT64_C(3) : v25));
        uint64_t v173 = (v166 ? (((((uint64_t)(v163 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(2)]))) : v76);
        uint64_t v174 = (v167 ? ((v42 + UINT64_C(1)) & UINT64_C(255)) : v42);
        uint64_t v175 = (v167 ? UINT64_C(1) : v93);
        uint64_t v176 = (v167 ? ((uint64_t)((UINT64_C(2) + v163) & UINT64_C(255))) : v59);
        uint64_t v177 = ((v165 || v166) ? UINT64_C(1) : ((v171 || (v164 && (!v167))) ? UINT64_C(2) : v110));
        t178 = v173;
    } else {
        t178 = v76;
    }
    uint64_t v179 = t178;
    uint64_t t195;
    if (v111) {
        uint64_t v180 = ((uint64_t)in_b[UINT64_C(1)]);
        int v181 = ((v110 == UINT64_C(0)) && (UINT64_C(1) == v59));
        int v182 = (v181 && (v180 == UINT64_C(0)));
        int v183 = ((v181 && ((v180 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(2) < ((uint64_t)((uint64_t)in_b_len))));
        int v184 = (((v181 && (v180 != UINT64_C(0))) && (v180 < UINT64_C(64))) && (((uint64_t)((UINT64_C(1) + v180) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t187 = ((v110 == UINT64_C(0)) && (UINT64_C(1) != v59));
        if (t187) {
                uint64_t v185 = v180;
            int t186 = (!(((((v185 | UINT64_C(32)) >= UINT64_C(97)) && ((v185 | UINT64_C(32)) <= UINT64_C(122))) || ((v185 >= UINT64_C(48)) && (v185 <= UINT64_C(57)))) || (v185 == UINT64_C(45))));
            if (!t186) {
                t186 = ((v180 == UINT64_C(45)) && ((UINT64_C(1) == ((v93 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(2) == v59)));
            }
            t187 = t186;
        }
        int v188 = t187;
        uint64_t v189 = (v182 ? UINT64_C(2) : (v183 ? UINT64_C(3) : v25));
        uint64_t v190 = (v183 ? (((((uint64_t)(v180 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(2)]))) : v76);
        uint64_t v191 = (v184 ? ((v42 + UINT64_C(1)) & UINT64_C(255)) : v42);
        uint64_t v192 = (v184 ? UINT64_C(1) : v93);
        uint64_t v193 = (v184 ? ((uint64_t)((UINT64_C(2) + v180) & UINT64_C(255))) : v59);
        uint64_t v194 = ((v182 || v183) ? UINT64_C(1) : ((v188 || (v181 && (!v184))) ? UINT64_C(2) : v110));
        t195 = v192;
    } else {
        t195 = v93;
    }
    uint64_t v196 = t195;
    uint64_t t212;
    if (v111) {
        uint64_t v197 = ((uint64_t)in_b[UINT64_C(1)]);
        int v198 = ((v110 == UINT64_C(0)) && (UINT64_C(1) == v59));
        int v199 = (v198 && (v197 == UINT64_C(0)));
        int v200 = ((v198 && ((v197 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(2) < ((uint64_t)((uint64_t)in_b_len))));
        int v201 = (((v198 && (v197 != UINT64_C(0))) && (v197 < UINT64_C(64))) && (((uint64_t)((UINT64_C(1) + v197) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t204 = ((v110 == UINT64_C(0)) && (UINT64_C(1) != v59));
        if (t204) {
                uint64_t v202 = v197;
            int t203 = (!(((((v202 | UINT64_C(32)) >= UINT64_C(97)) && ((v202 | UINT64_C(32)) <= UINT64_C(122))) || ((v202 >= UINT64_C(48)) && (v202 <= UINT64_C(57)))) || (v202 == UINT64_C(45))));
            if (!t203) {
                t203 = ((v197 == UINT64_C(45)) && ((UINT64_C(1) == ((v93 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(2) == v59)));
            }
            t204 = t203;
        }
        int v205 = t204;
        uint64_t v206 = (v199 ? UINT64_C(2) : (v200 ? UINT64_C(3) : v25));
        uint64_t v207 = (v200 ? (((((uint64_t)(v197 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(2)]))) : v76);
        uint64_t v208 = (v201 ? ((v42 + UINT64_C(1)) & UINT64_C(255)) : v42);
        uint64_t v209 = (v201 ? UINT64_C(1) : v93);
        uint64_t v210 = (v201 ? ((uint64_t)((UINT64_C(2) + v197) & UINT64_C(255))) : v59);
        uint64_t v211 = ((v199 || v200) ? UINT64_C(1) : ((v205 || (v198 && (!v201))) ? UINT64_C(2) : v110));
        t212 = v211;
    } else {
        t212 = v110;
    }
    uint64_t v213 = t212;
    int v214 = (UINT64_C(2) < v7);
    uint64_t t230;
    if (v214) {
        uint64_t v215 = ((uint64_t)in_b[UINT64_C(2)]);
        int v216 = ((v213 == UINT64_C(0)) && (UINT64_C(2) == v162));
        int v217 = (v216 && (v215 == UINT64_C(0)));
        int v218 = ((v216 && ((v215 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(3) < ((uint64_t)((uint64_t)in_b_len))));
        int v219 = (((v216 && (v215 != UINT64_C(0))) && (v215 < UINT64_C(64))) && (((uint64_t)((UINT64_C(2) + v215) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t222 = ((v213 == UINT64_C(0)) && (UINT64_C(2) != v162));
        if (t222) {
                uint64_t v220 = v215;
            int t221 = (!(((((v220 | UINT64_C(32)) >= UINT64_C(97)) && ((v220 | UINT64_C(32)) <= UINT64_C(122))) || ((v220 >= UINT64_C(48)) && (v220 <= UINT64_C(57)))) || (v220 == UINT64_C(45))));
            if (!t221) {
                t221 = ((v215 == UINT64_C(45)) && ((UINT64_C(2) == ((v196 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(3) == v162)));
            }
            t222 = t221;
        }
        int v223 = t222;
        uint64_t v224 = (v217 ? UINT64_C(3) : (v218 ? UINT64_C(4) : v128));
        uint64_t v225 = (v218 ? (((((uint64_t)(v215 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(3)]))) : v179);
        uint64_t v226 = (v219 ? ((v145 + UINT64_C(1)) & UINT64_C(255)) : v145);
        uint64_t v227 = (v219 ? UINT64_C(2) : v196);
        uint64_t v228 = (v219 ? ((uint64_t)((UINT64_C(3) + v215) & UINT64_C(255))) : v162);
        uint64_t v229 = ((v217 || v218) ? UINT64_C(1) : ((v223 || (v216 && (!v219))) ? UINT64_C(2) : v213));
        t230 = v224;
    } else {
        t230 = v128;
    }
    uint64_t v231 = t230;
    uint64_t t247;
    if (v214) {
        uint64_t v232 = ((uint64_t)in_b[UINT64_C(2)]);
        int v233 = ((v213 == UINT64_C(0)) && (UINT64_C(2) == v162));
        int v234 = (v233 && (v232 == UINT64_C(0)));
        int v235 = ((v233 && ((v232 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(3) < ((uint64_t)((uint64_t)in_b_len))));
        int v236 = (((v233 && (v232 != UINT64_C(0))) && (v232 < UINT64_C(64))) && (((uint64_t)((UINT64_C(2) + v232) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t239 = ((v213 == UINT64_C(0)) && (UINT64_C(2) != v162));
        if (t239) {
                uint64_t v237 = v232;
            int t238 = (!(((((v237 | UINT64_C(32)) >= UINT64_C(97)) && ((v237 | UINT64_C(32)) <= UINT64_C(122))) || ((v237 >= UINT64_C(48)) && (v237 <= UINT64_C(57)))) || (v237 == UINT64_C(45))));
            if (!t238) {
                t238 = ((v232 == UINT64_C(45)) && ((UINT64_C(2) == ((v196 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(3) == v162)));
            }
            t239 = t238;
        }
        int v240 = t239;
        uint64_t v241 = (v234 ? UINT64_C(3) : (v235 ? UINT64_C(4) : v128));
        uint64_t v242 = (v235 ? (((((uint64_t)(v232 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(3)]))) : v179);
        uint64_t v243 = (v236 ? ((v145 + UINT64_C(1)) & UINT64_C(255)) : v145);
        uint64_t v244 = (v236 ? UINT64_C(2) : v196);
        uint64_t v245 = (v236 ? ((uint64_t)((UINT64_C(3) + v232) & UINT64_C(255))) : v162);
        uint64_t v246 = ((v234 || v235) ? UINT64_C(1) : ((v240 || (v233 && (!v236))) ? UINT64_C(2) : v213));
        t247 = v243;
    } else {
        t247 = v145;
    }
    uint64_t v248 = t247;
    uint64_t t264;
    if (v214) {
        uint64_t v249 = ((uint64_t)in_b[UINT64_C(2)]);
        int v250 = ((v213 == UINT64_C(0)) && (UINT64_C(2) == v162));
        int v251 = (v250 && (v249 == UINT64_C(0)));
        int v252 = ((v250 && ((v249 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(3) < ((uint64_t)((uint64_t)in_b_len))));
        int v253 = (((v250 && (v249 != UINT64_C(0))) && (v249 < UINT64_C(64))) && (((uint64_t)((UINT64_C(2) + v249) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t256 = ((v213 == UINT64_C(0)) && (UINT64_C(2) != v162));
        if (t256) {
                uint64_t v254 = v249;
            int t255 = (!(((((v254 | UINT64_C(32)) >= UINT64_C(97)) && ((v254 | UINT64_C(32)) <= UINT64_C(122))) || ((v254 >= UINT64_C(48)) && (v254 <= UINT64_C(57)))) || (v254 == UINT64_C(45))));
            if (!t255) {
                t255 = ((v249 == UINT64_C(45)) && ((UINT64_C(2) == ((v196 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(3) == v162)));
            }
            t256 = t255;
        }
        int v257 = t256;
        uint64_t v258 = (v251 ? UINT64_C(3) : (v252 ? UINT64_C(4) : v128));
        uint64_t v259 = (v252 ? (((((uint64_t)(v249 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(3)]))) : v179);
        uint64_t v260 = (v253 ? ((v145 + UINT64_C(1)) & UINT64_C(255)) : v145);
        uint64_t v261 = (v253 ? UINT64_C(2) : v196);
        uint64_t v262 = (v253 ? ((uint64_t)((UINT64_C(3) + v249) & UINT64_C(255))) : v162);
        uint64_t v263 = ((v251 || v252) ? UINT64_C(1) : ((v257 || (v250 && (!v253))) ? UINT64_C(2) : v213));
        t264 = v262;
    } else {
        t264 = v162;
    }
    uint64_t v265 = t264;
    uint64_t t281;
    if (v214) {
        uint64_t v266 = ((uint64_t)in_b[UINT64_C(2)]);
        int v267 = ((v213 == UINT64_C(0)) && (UINT64_C(2) == v162));
        int v268 = (v267 && (v266 == UINT64_C(0)));
        int v269 = ((v267 && ((v266 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(3) < ((uint64_t)((uint64_t)in_b_len))));
        int v270 = (((v267 && (v266 != UINT64_C(0))) && (v266 < UINT64_C(64))) && (((uint64_t)((UINT64_C(2) + v266) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t273 = ((v213 == UINT64_C(0)) && (UINT64_C(2) != v162));
        if (t273) {
                uint64_t v271 = v266;
            int t272 = (!(((((v271 | UINT64_C(32)) >= UINT64_C(97)) && ((v271 | UINT64_C(32)) <= UINT64_C(122))) || ((v271 >= UINT64_C(48)) && (v271 <= UINT64_C(57)))) || (v271 == UINT64_C(45))));
            if (!t272) {
                t272 = ((v266 == UINT64_C(45)) && ((UINT64_C(2) == ((v196 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(3) == v162)));
            }
            t273 = t272;
        }
        int v274 = t273;
        uint64_t v275 = (v268 ? UINT64_C(3) : (v269 ? UINT64_C(4) : v128));
        uint64_t v276 = (v269 ? (((((uint64_t)(v266 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(3)]))) : v179);
        uint64_t v277 = (v270 ? ((v145 + UINT64_C(1)) & UINT64_C(255)) : v145);
        uint64_t v278 = (v270 ? UINT64_C(2) : v196);
        uint64_t v279 = (v270 ? ((uint64_t)((UINT64_C(3) + v266) & UINT64_C(255))) : v162);
        uint64_t v280 = ((v268 || v269) ? UINT64_C(1) : ((v274 || (v267 && (!v270))) ? UINT64_C(2) : v213));
        t281 = v276;
    } else {
        t281 = v179;
    }
    uint64_t v282 = t281;
    uint64_t t298;
    if (v214) {
        uint64_t v283 = ((uint64_t)in_b[UINT64_C(2)]);
        int v284 = ((v213 == UINT64_C(0)) && (UINT64_C(2) == v162));
        int v285 = (v284 && (v283 == UINT64_C(0)));
        int v286 = ((v284 && ((v283 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(3) < ((uint64_t)((uint64_t)in_b_len))));
        int v287 = (((v284 && (v283 != UINT64_C(0))) && (v283 < UINT64_C(64))) && (((uint64_t)((UINT64_C(2) + v283) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t290 = ((v213 == UINT64_C(0)) && (UINT64_C(2) != v162));
        if (t290) {
                uint64_t v288 = v283;
            int t289 = (!(((((v288 | UINT64_C(32)) >= UINT64_C(97)) && ((v288 | UINT64_C(32)) <= UINT64_C(122))) || ((v288 >= UINT64_C(48)) && (v288 <= UINT64_C(57)))) || (v288 == UINT64_C(45))));
            if (!t289) {
                t289 = ((v283 == UINT64_C(45)) && ((UINT64_C(2) == ((v196 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(3) == v162)));
            }
            t290 = t289;
        }
        int v291 = t290;
        uint64_t v292 = (v285 ? UINT64_C(3) : (v286 ? UINT64_C(4) : v128));
        uint64_t v293 = (v286 ? (((((uint64_t)(v283 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(3)]))) : v179);
        uint64_t v294 = (v287 ? ((v145 + UINT64_C(1)) & UINT64_C(255)) : v145);
        uint64_t v295 = (v287 ? UINT64_C(2) : v196);
        uint64_t v296 = (v287 ? ((uint64_t)((UINT64_C(3) + v283) & UINT64_C(255))) : v162);
        uint64_t v297 = ((v285 || v286) ? UINT64_C(1) : ((v291 || (v284 && (!v287))) ? UINT64_C(2) : v213));
        t298 = v295;
    } else {
        t298 = v196;
    }
    uint64_t v299 = t298;
    uint64_t t315;
    if (v214) {
        uint64_t v300 = ((uint64_t)in_b[UINT64_C(2)]);
        int v301 = ((v213 == UINT64_C(0)) && (UINT64_C(2) == v162));
        int v302 = (v301 && (v300 == UINT64_C(0)));
        int v303 = ((v301 && ((v300 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(3) < ((uint64_t)((uint64_t)in_b_len))));
        int v304 = (((v301 && (v300 != UINT64_C(0))) && (v300 < UINT64_C(64))) && (((uint64_t)((UINT64_C(2) + v300) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t307 = ((v213 == UINT64_C(0)) && (UINT64_C(2) != v162));
        if (t307) {
                uint64_t v305 = v300;
            int t306 = (!(((((v305 | UINT64_C(32)) >= UINT64_C(97)) && ((v305 | UINT64_C(32)) <= UINT64_C(122))) || ((v305 >= UINT64_C(48)) && (v305 <= UINT64_C(57)))) || (v305 == UINT64_C(45))));
            if (!t306) {
                t306 = ((v300 == UINT64_C(45)) && ((UINT64_C(2) == ((v196 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(3) == v162)));
            }
            t307 = t306;
        }
        int v308 = t307;
        uint64_t v309 = (v302 ? UINT64_C(3) : (v303 ? UINT64_C(4) : v128));
        uint64_t v310 = (v303 ? (((((uint64_t)(v300 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(3)]))) : v179);
        uint64_t v311 = (v304 ? ((v145 + UINT64_C(1)) & UINT64_C(255)) : v145);
        uint64_t v312 = (v304 ? UINT64_C(2) : v196);
        uint64_t v313 = (v304 ? ((uint64_t)((UINT64_C(3) + v300) & UINT64_C(255))) : v162);
        uint64_t v314 = ((v302 || v303) ? UINT64_C(1) : ((v308 || (v301 && (!v304))) ? UINT64_C(2) : v213));
        t315 = v314;
    } else {
        t315 = v213;
    }
    uint64_t v316 = t315;
    int v317 = (UINT64_C(3) < v7);
    uint64_t t333;
    if (v317) {
        uint64_t v318 = ((uint64_t)in_b[UINT64_C(3)]);
        int v319 = ((v316 == UINT64_C(0)) && (UINT64_C(3) == v265));
        int v320 = (v319 && (v318 == UINT64_C(0)));
        int v321 = ((v319 && ((v318 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(4) < ((uint64_t)((uint64_t)in_b_len))));
        int v322 = (((v319 && (v318 != UINT64_C(0))) && (v318 < UINT64_C(64))) && (((uint64_t)((UINT64_C(3) + v318) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t325 = ((v316 == UINT64_C(0)) && (UINT64_C(3) != v265));
        if (t325) {
                uint64_t v323 = v318;
            int t324 = (!(((((v323 | UINT64_C(32)) >= UINT64_C(97)) && ((v323 | UINT64_C(32)) <= UINT64_C(122))) || ((v323 >= UINT64_C(48)) && (v323 <= UINT64_C(57)))) || (v323 == UINT64_C(45))));
            if (!t324) {
                t324 = ((v318 == UINT64_C(45)) && ((UINT64_C(3) == ((v299 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(4) == v265)));
            }
            t325 = t324;
        }
        int v326 = t325;
        uint64_t v327 = (v320 ? UINT64_C(4) : (v321 ? UINT64_C(5) : v231));
        uint64_t v328 = (v321 ? (((((uint64_t)(v318 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(4)]))) : v282);
        uint64_t v329 = (v322 ? ((v248 + UINT64_C(1)) & UINT64_C(255)) : v248);
        uint64_t v330 = (v322 ? UINT64_C(3) : v299);
        uint64_t v331 = (v322 ? ((uint64_t)((UINT64_C(4) + v318) & UINT64_C(255))) : v265);
        uint64_t v332 = ((v320 || v321) ? UINT64_C(1) : ((v326 || (v319 && (!v322))) ? UINT64_C(2) : v316));
        t333 = v327;
    } else {
        t333 = v231;
    }
    uint64_t v334 = t333;
    uint64_t t350;
    if (v317) {
        uint64_t v335 = ((uint64_t)in_b[UINT64_C(3)]);
        int v336 = ((v316 == UINT64_C(0)) && (UINT64_C(3) == v265));
        int v337 = (v336 && (v335 == UINT64_C(0)));
        int v338 = ((v336 && ((v335 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(4) < ((uint64_t)((uint64_t)in_b_len))));
        int v339 = (((v336 && (v335 != UINT64_C(0))) && (v335 < UINT64_C(64))) && (((uint64_t)((UINT64_C(3) + v335) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t342 = ((v316 == UINT64_C(0)) && (UINT64_C(3) != v265));
        if (t342) {
                uint64_t v340 = v335;
            int t341 = (!(((((v340 | UINT64_C(32)) >= UINT64_C(97)) && ((v340 | UINT64_C(32)) <= UINT64_C(122))) || ((v340 >= UINT64_C(48)) && (v340 <= UINT64_C(57)))) || (v340 == UINT64_C(45))));
            if (!t341) {
                t341 = ((v335 == UINT64_C(45)) && ((UINT64_C(3) == ((v299 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(4) == v265)));
            }
            t342 = t341;
        }
        int v343 = t342;
        uint64_t v344 = (v337 ? UINT64_C(4) : (v338 ? UINT64_C(5) : v231));
        uint64_t v345 = (v338 ? (((((uint64_t)(v335 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(4)]))) : v282);
        uint64_t v346 = (v339 ? ((v248 + UINT64_C(1)) & UINT64_C(255)) : v248);
        uint64_t v347 = (v339 ? UINT64_C(3) : v299);
        uint64_t v348 = (v339 ? ((uint64_t)((UINT64_C(4) + v335) & UINT64_C(255))) : v265);
        uint64_t v349 = ((v337 || v338) ? UINT64_C(1) : ((v343 || (v336 && (!v339))) ? UINT64_C(2) : v316));
        t350 = v346;
    } else {
        t350 = v248;
    }
    uint64_t v351 = t350;
    uint64_t t367;
    if (v317) {
        uint64_t v352 = ((uint64_t)in_b[UINT64_C(3)]);
        int v353 = ((v316 == UINT64_C(0)) && (UINT64_C(3) == v265));
        int v354 = (v353 && (v352 == UINT64_C(0)));
        int v355 = ((v353 && ((v352 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(4) < ((uint64_t)((uint64_t)in_b_len))));
        int v356 = (((v353 && (v352 != UINT64_C(0))) && (v352 < UINT64_C(64))) && (((uint64_t)((UINT64_C(3) + v352) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t359 = ((v316 == UINT64_C(0)) && (UINT64_C(3) != v265));
        if (t359) {
                uint64_t v357 = v352;
            int t358 = (!(((((v357 | UINT64_C(32)) >= UINT64_C(97)) && ((v357 | UINT64_C(32)) <= UINT64_C(122))) || ((v357 >= UINT64_C(48)) && (v357 <= UINT64_C(57)))) || (v357 == UINT64_C(45))));
            if (!t358) {
                t358 = ((v352 == UINT64_C(45)) && ((UINT64_C(3) == ((v299 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(4) == v265)));
            }
            t359 = t358;
        }
        int v360 = t359;
        uint64_t v361 = (v354 ? UINT64_C(4) : (v355 ? UINT64_C(5) : v231));
        uint64_t v362 = (v355 ? (((((uint64_t)(v352 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(4)]))) : v282);
        uint64_t v363 = (v356 ? ((v248 + UINT64_C(1)) & UINT64_C(255)) : v248);
        uint64_t v364 = (v356 ? UINT64_C(3) : v299);
        uint64_t v365 = (v356 ? ((uint64_t)((UINT64_C(4) + v352) & UINT64_C(255))) : v265);
        uint64_t v366 = ((v354 || v355) ? UINT64_C(1) : ((v360 || (v353 && (!v356))) ? UINT64_C(2) : v316));
        t367 = v365;
    } else {
        t367 = v265;
    }
    uint64_t v368 = t367;
    uint64_t t384;
    if (v317) {
        uint64_t v369 = ((uint64_t)in_b[UINT64_C(3)]);
        int v370 = ((v316 == UINT64_C(0)) && (UINT64_C(3) == v265));
        int v371 = (v370 && (v369 == UINT64_C(0)));
        int v372 = ((v370 && ((v369 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(4) < ((uint64_t)((uint64_t)in_b_len))));
        int v373 = (((v370 && (v369 != UINT64_C(0))) && (v369 < UINT64_C(64))) && (((uint64_t)((UINT64_C(3) + v369) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t376 = ((v316 == UINT64_C(0)) && (UINT64_C(3) != v265));
        if (t376) {
                uint64_t v374 = v369;
            int t375 = (!(((((v374 | UINT64_C(32)) >= UINT64_C(97)) && ((v374 | UINT64_C(32)) <= UINT64_C(122))) || ((v374 >= UINT64_C(48)) && (v374 <= UINT64_C(57)))) || (v374 == UINT64_C(45))));
            if (!t375) {
                t375 = ((v369 == UINT64_C(45)) && ((UINT64_C(3) == ((v299 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(4) == v265)));
            }
            t376 = t375;
        }
        int v377 = t376;
        uint64_t v378 = (v371 ? UINT64_C(4) : (v372 ? UINT64_C(5) : v231));
        uint64_t v379 = (v372 ? (((((uint64_t)(v369 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(4)]))) : v282);
        uint64_t v380 = (v373 ? ((v248 + UINT64_C(1)) & UINT64_C(255)) : v248);
        uint64_t v381 = (v373 ? UINT64_C(3) : v299);
        uint64_t v382 = (v373 ? ((uint64_t)((UINT64_C(4) + v369) & UINT64_C(255))) : v265);
        uint64_t v383 = ((v371 || v372) ? UINT64_C(1) : ((v377 || (v370 && (!v373))) ? UINT64_C(2) : v316));
        t384 = v379;
    } else {
        t384 = v282;
    }
    uint64_t v385 = t384;
    uint64_t t401;
    if (v317) {
        uint64_t v386 = ((uint64_t)in_b[UINT64_C(3)]);
        int v387 = ((v316 == UINT64_C(0)) && (UINT64_C(3) == v265));
        int v388 = (v387 && (v386 == UINT64_C(0)));
        int v389 = ((v387 && ((v386 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(4) < ((uint64_t)((uint64_t)in_b_len))));
        int v390 = (((v387 && (v386 != UINT64_C(0))) && (v386 < UINT64_C(64))) && (((uint64_t)((UINT64_C(3) + v386) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t393 = ((v316 == UINT64_C(0)) && (UINT64_C(3) != v265));
        if (t393) {
                uint64_t v391 = v386;
            int t392 = (!(((((v391 | UINT64_C(32)) >= UINT64_C(97)) && ((v391 | UINT64_C(32)) <= UINT64_C(122))) || ((v391 >= UINT64_C(48)) && (v391 <= UINT64_C(57)))) || (v391 == UINT64_C(45))));
            if (!t392) {
                t392 = ((v386 == UINT64_C(45)) && ((UINT64_C(3) == ((v299 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(4) == v265)));
            }
            t393 = t392;
        }
        int v394 = t393;
        uint64_t v395 = (v388 ? UINT64_C(4) : (v389 ? UINT64_C(5) : v231));
        uint64_t v396 = (v389 ? (((((uint64_t)(v386 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(4)]))) : v282);
        uint64_t v397 = (v390 ? ((v248 + UINT64_C(1)) & UINT64_C(255)) : v248);
        uint64_t v398 = (v390 ? UINT64_C(3) : v299);
        uint64_t v399 = (v390 ? ((uint64_t)((UINT64_C(4) + v386) & UINT64_C(255))) : v265);
        uint64_t v400 = ((v388 || v389) ? UINT64_C(1) : ((v394 || (v387 && (!v390))) ? UINT64_C(2) : v316));
        t401 = v398;
    } else {
        t401 = v299;
    }
    uint64_t v402 = t401;
    uint64_t t418;
    if (v317) {
        uint64_t v403 = ((uint64_t)in_b[UINT64_C(3)]);
        int v404 = ((v316 == UINT64_C(0)) && (UINT64_C(3) == v265));
        int v405 = (v404 && (v403 == UINT64_C(0)));
        int v406 = ((v404 && ((v403 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(4) < ((uint64_t)((uint64_t)in_b_len))));
        int v407 = (((v404 && (v403 != UINT64_C(0))) && (v403 < UINT64_C(64))) && (((uint64_t)((UINT64_C(3) + v403) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t410 = ((v316 == UINT64_C(0)) && (UINT64_C(3) != v265));
        if (t410) {
                uint64_t v408 = v403;
            int t409 = (!(((((v408 | UINT64_C(32)) >= UINT64_C(97)) && ((v408 | UINT64_C(32)) <= UINT64_C(122))) || ((v408 >= UINT64_C(48)) && (v408 <= UINT64_C(57)))) || (v408 == UINT64_C(45))));
            if (!t409) {
                t409 = ((v403 == UINT64_C(45)) && ((UINT64_C(3) == ((v299 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(4) == v265)));
            }
            t410 = t409;
        }
        int v411 = t410;
        uint64_t v412 = (v405 ? UINT64_C(4) : (v406 ? UINT64_C(5) : v231));
        uint64_t v413 = (v406 ? (((((uint64_t)(v403 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(4)]))) : v282);
        uint64_t v414 = (v407 ? ((v248 + UINT64_C(1)) & UINT64_C(255)) : v248);
        uint64_t v415 = (v407 ? UINT64_C(3) : v299);
        uint64_t v416 = (v407 ? ((uint64_t)((UINT64_C(4) + v403) & UINT64_C(255))) : v265);
        uint64_t v417 = ((v405 || v406) ? UINT64_C(1) : ((v411 || (v404 && (!v407))) ? UINT64_C(2) : v316));
        t418 = v417;
    } else {
        t418 = v316;
    }
    uint64_t v419 = t418;
    int v420 = (UINT64_C(4) < v7);
    uint64_t t436;
    if (v420) {
        uint64_t v421 = ((uint64_t)in_b[UINT64_C(4)]);
        int v422 = ((v419 == UINT64_C(0)) && (UINT64_C(4) == v368));
        int v423 = (v422 && (v421 == UINT64_C(0)));
        int v424 = ((v422 && ((v421 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(5) < ((uint64_t)((uint64_t)in_b_len))));
        int v425 = (((v422 && (v421 != UINT64_C(0))) && (v421 < UINT64_C(64))) && (((uint64_t)((UINT64_C(4) + v421) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t428 = ((v419 == UINT64_C(0)) && (UINT64_C(4) != v368));
        if (t428) {
                uint64_t v426 = v421;
            int t427 = (!(((((v426 | UINT64_C(32)) >= UINT64_C(97)) && ((v426 | UINT64_C(32)) <= UINT64_C(122))) || ((v426 >= UINT64_C(48)) && (v426 <= UINT64_C(57)))) || (v426 == UINT64_C(45))));
            if (!t427) {
                t427 = ((v421 == UINT64_C(45)) && ((UINT64_C(4) == ((v402 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(5) == v368)));
            }
            t428 = t427;
        }
        int v429 = t428;
        uint64_t v430 = (v423 ? UINT64_C(5) : (v424 ? UINT64_C(6) : v334));
        uint64_t v431 = (v424 ? (((((uint64_t)(v421 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(5)]))) : v385);
        uint64_t v432 = (v425 ? ((v351 + UINT64_C(1)) & UINT64_C(255)) : v351);
        uint64_t v433 = (v425 ? UINT64_C(4) : v402);
        uint64_t v434 = (v425 ? ((uint64_t)((UINT64_C(5) + v421) & UINT64_C(255))) : v368);
        uint64_t v435 = ((v423 || v424) ? UINT64_C(1) : ((v429 || (v422 && (!v425))) ? UINT64_C(2) : v419));
        t436 = v430;
    } else {
        t436 = v334;
    }
    uint64_t v437 = t436;
    uint64_t t453;
    if (v420) {
        uint64_t v438 = ((uint64_t)in_b[UINT64_C(4)]);
        int v439 = ((v419 == UINT64_C(0)) && (UINT64_C(4) == v368));
        int v440 = (v439 && (v438 == UINT64_C(0)));
        int v441 = ((v439 && ((v438 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(5) < ((uint64_t)((uint64_t)in_b_len))));
        int v442 = (((v439 && (v438 != UINT64_C(0))) && (v438 < UINT64_C(64))) && (((uint64_t)((UINT64_C(4) + v438) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t445 = ((v419 == UINT64_C(0)) && (UINT64_C(4) != v368));
        if (t445) {
                uint64_t v443 = v438;
            int t444 = (!(((((v443 | UINT64_C(32)) >= UINT64_C(97)) && ((v443 | UINT64_C(32)) <= UINT64_C(122))) || ((v443 >= UINT64_C(48)) && (v443 <= UINT64_C(57)))) || (v443 == UINT64_C(45))));
            if (!t444) {
                t444 = ((v438 == UINT64_C(45)) && ((UINT64_C(4) == ((v402 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(5) == v368)));
            }
            t445 = t444;
        }
        int v446 = t445;
        uint64_t v447 = (v440 ? UINT64_C(5) : (v441 ? UINT64_C(6) : v334));
        uint64_t v448 = (v441 ? (((((uint64_t)(v438 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(5)]))) : v385);
        uint64_t v449 = (v442 ? ((v351 + UINT64_C(1)) & UINT64_C(255)) : v351);
        uint64_t v450 = (v442 ? UINT64_C(4) : v402);
        uint64_t v451 = (v442 ? ((uint64_t)((UINT64_C(5) + v438) & UINT64_C(255))) : v368);
        uint64_t v452 = ((v440 || v441) ? UINT64_C(1) : ((v446 || (v439 && (!v442))) ? UINT64_C(2) : v419));
        t453 = v449;
    } else {
        t453 = v351;
    }
    uint64_t v454 = t453;
    uint64_t t470;
    if (v420) {
        uint64_t v455 = ((uint64_t)in_b[UINT64_C(4)]);
        int v456 = ((v419 == UINT64_C(0)) && (UINT64_C(4) == v368));
        int v457 = (v456 && (v455 == UINT64_C(0)));
        int v458 = ((v456 && ((v455 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(5) < ((uint64_t)((uint64_t)in_b_len))));
        int v459 = (((v456 && (v455 != UINT64_C(0))) && (v455 < UINT64_C(64))) && (((uint64_t)((UINT64_C(4) + v455) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t462 = ((v419 == UINT64_C(0)) && (UINT64_C(4) != v368));
        if (t462) {
                uint64_t v460 = v455;
            int t461 = (!(((((v460 | UINT64_C(32)) >= UINT64_C(97)) && ((v460 | UINT64_C(32)) <= UINT64_C(122))) || ((v460 >= UINT64_C(48)) && (v460 <= UINT64_C(57)))) || (v460 == UINT64_C(45))));
            if (!t461) {
                t461 = ((v455 == UINT64_C(45)) && ((UINT64_C(4) == ((v402 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(5) == v368)));
            }
            t462 = t461;
        }
        int v463 = t462;
        uint64_t v464 = (v457 ? UINT64_C(5) : (v458 ? UINT64_C(6) : v334));
        uint64_t v465 = (v458 ? (((((uint64_t)(v455 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(5)]))) : v385);
        uint64_t v466 = (v459 ? ((v351 + UINT64_C(1)) & UINT64_C(255)) : v351);
        uint64_t v467 = (v459 ? UINT64_C(4) : v402);
        uint64_t v468 = (v459 ? ((uint64_t)((UINT64_C(5) + v455) & UINT64_C(255))) : v368);
        uint64_t v469 = ((v457 || v458) ? UINT64_C(1) : ((v463 || (v456 && (!v459))) ? UINT64_C(2) : v419));
        t470 = v468;
    } else {
        t470 = v368;
    }
    uint64_t v471 = t470;
    uint64_t t487;
    if (v420) {
        uint64_t v472 = ((uint64_t)in_b[UINT64_C(4)]);
        int v473 = ((v419 == UINT64_C(0)) && (UINT64_C(4) == v368));
        int v474 = (v473 && (v472 == UINT64_C(0)));
        int v475 = ((v473 && ((v472 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(5) < ((uint64_t)((uint64_t)in_b_len))));
        int v476 = (((v473 && (v472 != UINT64_C(0))) && (v472 < UINT64_C(64))) && (((uint64_t)((UINT64_C(4) + v472) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t479 = ((v419 == UINT64_C(0)) && (UINT64_C(4) != v368));
        if (t479) {
                uint64_t v477 = v472;
            int t478 = (!(((((v477 | UINT64_C(32)) >= UINT64_C(97)) && ((v477 | UINT64_C(32)) <= UINT64_C(122))) || ((v477 >= UINT64_C(48)) && (v477 <= UINT64_C(57)))) || (v477 == UINT64_C(45))));
            if (!t478) {
                t478 = ((v472 == UINT64_C(45)) && ((UINT64_C(4) == ((v402 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(5) == v368)));
            }
            t479 = t478;
        }
        int v480 = t479;
        uint64_t v481 = (v474 ? UINT64_C(5) : (v475 ? UINT64_C(6) : v334));
        uint64_t v482 = (v475 ? (((((uint64_t)(v472 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(5)]))) : v385);
        uint64_t v483 = (v476 ? ((v351 + UINT64_C(1)) & UINT64_C(255)) : v351);
        uint64_t v484 = (v476 ? UINT64_C(4) : v402);
        uint64_t v485 = (v476 ? ((uint64_t)((UINT64_C(5) + v472) & UINT64_C(255))) : v368);
        uint64_t v486 = ((v474 || v475) ? UINT64_C(1) : ((v480 || (v473 && (!v476))) ? UINT64_C(2) : v419));
        t487 = v482;
    } else {
        t487 = v385;
    }
    uint64_t v488 = t487;
    uint64_t t504;
    if (v420) {
        uint64_t v489 = ((uint64_t)in_b[UINT64_C(4)]);
        int v490 = ((v419 == UINT64_C(0)) && (UINT64_C(4) == v368));
        int v491 = (v490 && (v489 == UINT64_C(0)));
        int v492 = ((v490 && ((v489 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(5) < ((uint64_t)((uint64_t)in_b_len))));
        int v493 = (((v490 && (v489 != UINT64_C(0))) && (v489 < UINT64_C(64))) && (((uint64_t)((UINT64_C(4) + v489) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t496 = ((v419 == UINT64_C(0)) && (UINT64_C(4) != v368));
        if (t496) {
                uint64_t v494 = v489;
            int t495 = (!(((((v494 | UINT64_C(32)) >= UINT64_C(97)) && ((v494 | UINT64_C(32)) <= UINT64_C(122))) || ((v494 >= UINT64_C(48)) && (v494 <= UINT64_C(57)))) || (v494 == UINT64_C(45))));
            if (!t495) {
                t495 = ((v489 == UINT64_C(45)) && ((UINT64_C(4) == ((v402 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(5) == v368)));
            }
            t496 = t495;
        }
        int v497 = t496;
        uint64_t v498 = (v491 ? UINT64_C(5) : (v492 ? UINT64_C(6) : v334));
        uint64_t v499 = (v492 ? (((((uint64_t)(v489 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(5)]))) : v385);
        uint64_t v500 = (v493 ? ((v351 + UINT64_C(1)) & UINT64_C(255)) : v351);
        uint64_t v501 = (v493 ? UINT64_C(4) : v402);
        uint64_t v502 = (v493 ? ((uint64_t)((UINT64_C(5) + v489) & UINT64_C(255))) : v368);
        uint64_t v503 = ((v491 || v492) ? UINT64_C(1) : ((v497 || (v490 && (!v493))) ? UINT64_C(2) : v419));
        t504 = v501;
    } else {
        t504 = v402;
    }
    uint64_t v505 = t504;
    uint64_t t521;
    if (v420) {
        uint64_t v506 = ((uint64_t)in_b[UINT64_C(4)]);
        int v507 = ((v419 == UINT64_C(0)) && (UINT64_C(4) == v368));
        int v508 = (v507 && (v506 == UINT64_C(0)));
        int v509 = ((v507 && ((v506 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(5) < ((uint64_t)((uint64_t)in_b_len))));
        int v510 = (((v507 && (v506 != UINT64_C(0))) && (v506 < UINT64_C(64))) && (((uint64_t)((UINT64_C(4) + v506) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t513 = ((v419 == UINT64_C(0)) && (UINT64_C(4) != v368));
        if (t513) {
                uint64_t v511 = v506;
            int t512 = (!(((((v511 | UINT64_C(32)) >= UINT64_C(97)) && ((v511 | UINT64_C(32)) <= UINT64_C(122))) || ((v511 >= UINT64_C(48)) && (v511 <= UINT64_C(57)))) || (v511 == UINT64_C(45))));
            if (!t512) {
                t512 = ((v506 == UINT64_C(45)) && ((UINT64_C(4) == ((v402 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(5) == v368)));
            }
            t513 = t512;
        }
        int v514 = t513;
        uint64_t v515 = (v508 ? UINT64_C(5) : (v509 ? UINT64_C(6) : v334));
        uint64_t v516 = (v509 ? (((((uint64_t)(v506 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(5)]))) : v385);
        uint64_t v517 = (v510 ? ((v351 + UINT64_C(1)) & UINT64_C(255)) : v351);
        uint64_t v518 = (v510 ? UINT64_C(4) : v402);
        uint64_t v519 = (v510 ? ((uint64_t)((UINT64_C(5) + v506) & UINT64_C(255))) : v368);
        uint64_t v520 = ((v508 || v509) ? UINT64_C(1) : ((v514 || (v507 && (!v510))) ? UINT64_C(2) : v419));
        t521 = v520;
    } else {
        t521 = v419;
    }
    uint64_t v522 = t521;
    int v523 = (UINT64_C(5) < v7);
    uint64_t t539;
    if (v523) {
        uint64_t v524 = ((uint64_t)in_b[UINT64_C(5)]);
        int v525 = ((v522 == UINT64_C(0)) && (UINT64_C(5) == v471));
        int v526 = (v525 && (v524 == UINT64_C(0)));
        int v527 = ((v525 && ((v524 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(6) < ((uint64_t)((uint64_t)in_b_len))));
        int v528 = (((v525 && (v524 != UINT64_C(0))) && (v524 < UINT64_C(64))) && (((uint64_t)((UINT64_C(5) + v524) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t531 = ((v522 == UINT64_C(0)) && (UINT64_C(5) != v471));
        if (t531) {
                uint64_t v529 = v524;
            int t530 = (!(((((v529 | UINT64_C(32)) >= UINT64_C(97)) && ((v529 | UINT64_C(32)) <= UINT64_C(122))) || ((v529 >= UINT64_C(48)) && (v529 <= UINT64_C(57)))) || (v529 == UINT64_C(45))));
            if (!t530) {
                t530 = ((v524 == UINT64_C(45)) && ((UINT64_C(5) == ((v505 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(6) == v471)));
            }
            t531 = t530;
        }
        int v532 = t531;
        uint64_t v533 = (v526 ? UINT64_C(6) : (v527 ? UINT64_C(7) : v437));
        uint64_t v534 = (v527 ? (((((uint64_t)(v524 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(6)]))) : v488);
        uint64_t v535 = (v528 ? ((v454 + UINT64_C(1)) & UINT64_C(255)) : v454);
        uint64_t v536 = (v528 ? UINT64_C(5) : v505);
        uint64_t v537 = (v528 ? ((uint64_t)((UINT64_C(6) + v524) & UINT64_C(255))) : v471);
        uint64_t v538 = ((v526 || v527) ? UINT64_C(1) : ((v532 || (v525 && (!v528))) ? UINT64_C(2) : v522));
        t539 = v533;
    } else {
        t539 = v437;
    }
    uint64_t v540 = t539;
    uint64_t t556;
    if (v523) {
        uint64_t v541 = ((uint64_t)in_b[UINT64_C(5)]);
        int v542 = ((v522 == UINT64_C(0)) && (UINT64_C(5) == v471));
        int v543 = (v542 && (v541 == UINT64_C(0)));
        int v544 = ((v542 && ((v541 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(6) < ((uint64_t)((uint64_t)in_b_len))));
        int v545 = (((v542 && (v541 != UINT64_C(0))) && (v541 < UINT64_C(64))) && (((uint64_t)((UINT64_C(5) + v541) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t548 = ((v522 == UINT64_C(0)) && (UINT64_C(5) != v471));
        if (t548) {
                uint64_t v546 = v541;
            int t547 = (!(((((v546 | UINT64_C(32)) >= UINT64_C(97)) && ((v546 | UINT64_C(32)) <= UINT64_C(122))) || ((v546 >= UINT64_C(48)) && (v546 <= UINT64_C(57)))) || (v546 == UINT64_C(45))));
            if (!t547) {
                t547 = ((v541 == UINT64_C(45)) && ((UINT64_C(5) == ((v505 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(6) == v471)));
            }
            t548 = t547;
        }
        int v549 = t548;
        uint64_t v550 = (v543 ? UINT64_C(6) : (v544 ? UINT64_C(7) : v437));
        uint64_t v551 = (v544 ? (((((uint64_t)(v541 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(6)]))) : v488);
        uint64_t v552 = (v545 ? ((v454 + UINT64_C(1)) & UINT64_C(255)) : v454);
        uint64_t v553 = (v545 ? UINT64_C(5) : v505);
        uint64_t v554 = (v545 ? ((uint64_t)((UINT64_C(6) + v541) & UINT64_C(255))) : v471);
        uint64_t v555 = ((v543 || v544) ? UINT64_C(1) : ((v549 || (v542 && (!v545))) ? UINT64_C(2) : v522));
        t556 = v552;
    } else {
        t556 = v454;
    }
    uint64_t v557 = t556;
    uint64_t t573;
    if (v523) {
        uint64_t v558 = ((uint64_t)in_b[UINT64_C(5)]);
        int v559 = ((v522 == UINT64_C(0)) && (UINT64_C(5) == v471));
        int v560 = (v559 && (v558 == UINT64_C(0)));
        int v561 = ((v559 && ((v558 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(6) < ((uint64_t)((uint64_t)in_b_len))));
        int v562 = (((v559 && (v558 != UINT64_C(0))) && (v558 < UINT64_C(64))) && (((uint64_t)((UINT64_C(5) + v558) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t565 = ((v522 == UINT64_C(0)) && (UINT64_C(5) != v471));
        if (t565) {
                uint64_t v563 = v558;
            int t564 = (!(((((v563 | UINT64_C(32)) >= UINT64_C(97)) && ((v563 | UINT64_C(32)) <= UINT64_C(122))) || ((v563 >= UINT64_C(48)) && (v563 <= UINT64_C(57)))) || (v563 == UINT64_C(45))));
            if (!t564) {
                t564 = ((v558 == UINT64_C(45)) && ((UINT64_C(5) == ((v505 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(6) == v471)));
            }
            t565 = t564;
        }
        int v566 = t565;
        uint64_t v567 = (v560 ? UINT64_C(6) : (v561 ? UINT64_C(7) : v437));
        uint64_t v568 = (v561 ? (((((uint64_t)(v558 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(6)]))) : v488);
        uint64_t v569 = (v562 ? ((v454 + UINT64_C(1)) & UINT64_C(255)) : v454);
        uint64_t v570 = (v562 ? UINT64_C(5) : v505);
        uint64_t v571 = (v562 ? ((uint64_t)((UINT64_C(6) + v558) & UINT64_C(255))) : v471);
        uint64_t v572 = ((v560 || v561) ? UINT64_C(1) : ((v566 || (v559 && (!v562))) ? UINT64_C(2) : v522));
        t573 = v571;
    } else {
        t573 = v471;
    }
    uint64_t v574 = t573;
    uint64_t t590;
    if (v523) {
        uint64_t v575 = ((uint64_t)in_b[UINT64_C(5)]);
        int v576 = ((v522 == UINT64_C(0)) && (UINT64_C(5) == v471));
        int v577 = (v576 && (v575 == UINT64_C(0)));
        int v578 = ((v576 && ((v575 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(6) < ((uint64_t)((uint64_t)in_b_len))));
        int v579 = (((v576 && (v575 != UINT64_C(0))) && (v575 < UINT64_C(64))) && (((uint64_t)((UINT64_C(5) + v575) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t582 = ((v522 == UINT64_C(0)) && (UINT64_C(5) != v471));
        if (t582) {
                uint64_t v580 = v575;
            int t581 = (!(((((v580 | UINT64_C(32)) >= UINT64_C(97)) && ((v580 | UINT64_C(32)) <= UINT64_C(122))) || ((v580 >= UINT64_C(48)) && (v580 <= UINT64_C(57)))) || (v580 == UINT64_C(45))));
            if (!t581) {
                t581 = ((v575 == UINT64_C(45)) && ((UINT64_C(5) == ((v505 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(6) == v471)));
            }
            t582 = t581;
        }
        int v583 = t582;
        uint64_t v584 = (v577 ? UINT64_C(6) : (v578 ? UINT64_C(7) : v437));
        uint64_t v585 = (v578 ? (((((uint64_t)(v575 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(6)]))) : v488);
        uint64_t v586 = (v579 ? ((v454 + UINT64_C(1)) & UINT64_C(255)) : v454);
        uint64_t v587 = (v579 ? UINT64_C(5) : v505);
        uint64_t v588 = (v579 ? ((uint64_t)((UINT64_C(6) + v575) & UINT64_C(255))) : v471);
        uint64_t v589 = ((v577 || v578) ? UINT64_C(1) : ((v583 || (v576 && (!v579))) ? UINT64_C(2) : v522));
        t590 = v585;
    } else {
        t590 = v488;
    }
    uint64_t v591 = t590;
    uint64_t t607;
    if (v523) {
        uint64_t v592 = ((uint64_t)in_b[UINT64_C(5)]);
        int v593 = ((v522 == UINT64_C(0)) && (UINT64_C(5) == v471));
        int v594 = (v593 && (v592 == UINT64_C(0)));
        int v595 = ((v593 && ((v592 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(6) < ((uint64_t)((uint64_t)in_b_len))));
        int v596 = (((v593 && (v592 != UINT64_C(0))) && (v592 < UINT64_C(64))) && (((uint64_t)((UINT64_C(5) + v592) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t599 = ((v522 == UINT64_C(0)) && (UINT64_C(5) != v471));
        if (t599) {
                uint64_t v597 = v592;
            int t598 = (!(((((v597 | UINT64_C(32)) >= UINT64_C(97)) && ((v597 | UINT64_C(32)) <= UINT64_C(122))) || ((v597 >= UINT64_C(48)) && (v597 <= UINT64_C(57)))) || (v597 == UINT64_C(45))));
            if (!t598) {
                t598 = ((v592 == UINT64_C(45)) && ((UINT64_C(5) == ((v505 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(6) == v471)));
            }
            t599 = t598;
        }
        int v600 = t599;
        uint64_t v601 = (v594 ? UINT64_C(6) : (v595 ? UINT64_C(7) : v437));
        uint64_t v602 = (v595 ? (((((uint64_t)(v592 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(6)]))) : v488);
        uint64_t v603 = (v596 ? ((v454 + UINT64_C(1)) & UINT64_C(255)) : v454);
        uint64_t v604 = (v596 ? UINT64_C(5) : v505);
        uint64_t v605 = (v596 ? ((uint64_t)((UINT64_C(6) + v592) & UINT64_C(255))) : v471);
        uint64_t v606 = ((v594 || v595) ? UINT64_C(1) : ((v600 || (v593 && (!v596))) ? UINT64_C(2) : v522));
        t607 = v604;
    } else {
        t607 = v505;
    }
    uint64_t v608 = t607;
    uint64_t t624;
    if (v523) {
        uint64_t v609 = ((uint64_t)in_b[UINT64_C(5)]);
        int v610 = ((v522 == UINT64_C(0)) && (UINT64_C(5) == v471));
        int v611 = (v610 && (v609 == UINT64_C(0)));
        int v612 = ((v610 && ((v609 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(6) < ((uint64_t)((uint64_t)in_b_len))));
        int v613 = (((v610 && (v609 != UINT64_C(0))) && (v609 < UINT64_C(64))) && (((uint64_t)((UINT64_C(5) + v609) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t616 = ((v522 == UINT64_C(0)) && (UINT64_C(5) != v471));
        if (t616) {
                uint64_t v614 = v609;
            int t615 = (!(((((v614 | UINT64_C(32)) >= UINT64_C(97)) && ((v614 | UINT64_C(32)) <= UINT64_C(122))) || ((v614 >= UINT64_C(48)) && (v614 <= UINT64_C(57)))) || (v614 == UINT64_C(45))));
            if (!t615) {
                t615 = ((v609 == UINT64_C(45)) && ((UINT64_C(5) == ((v505 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(6) == v471)));
            }
            t616 = t615;
        }
        int v617 = t616;
        uint64_t v618 = (v611 ? UINT64_C(6) : (v612 ? UINT64_C(7) : v437));
        uint64_t v619 = (v612 ? (((((uint64_t)(v609 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(6)]))) : v488);
        uint64_t v620 = (v613 ? ((v454 + UINT64_C(1)) & UINT64_C(255)) : v454);
        uint64_t v621 = (v613 ? UINT64_C(5) : v505);
        uint64_t v622 = (v613 ? ((uint64_t)((UINT64_C(6) + v609) & UINT64_C(255))) : v471);
        uint64_t v623 = ((v611 || v612) ? UINT64_C(1) : ((v617 || (v610 && (!v613))) ? UINT64_C(2) : v522));
        t624 = v623;
    } else {
        t624 = v522;
    }
    uint64_t v625 = t624;
    int v626 = (UINT64_C(6) < v7);
    uint64_t t642;
    if (v626) {
        uint64_t v627 = ((uint64_t)in_b[UINT64_C(6)]);
        int v628 = ((v625 == UINT64_C(0)) && (UINT64_C(6) == v574));
        int v629 = (v628 && (v627 == UINT64_C(0)));
        int v630 = ((v628 && ((v627 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(7) < ((uint64_t)((uint64_t)in_b_len))));
        int v631 = (((v628 && (v627 != UINT64_C(0))) && (v627 < UINT64_C(64))) && (((uint64_t)((UINT64_C(6) + v627) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t634 = ((v625 == UINT64_C(0)) && (UINT64_C(6) != v574));
        if (t634) {
                uint64_t v632 = v627;
            int t633 = (!(((((v632 | UINT64_C(32)) >= UINT64_C(97)) && ((v632 | UINT64_C(32)) <= UINT64_C(122))) || ((v632 >= UINT64_C(48)) && (v632 <= UINT64_C(57)))) || (v632 == UINT64_C(45))));
            if (!t633) {
                t633 = ((v627 == UINT64_C(45)) && ((UINT64_C(6) == ((v608 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(7) == v574)));
            }
            t634 = t633;
        }
        int v635 = t634;
        uint64_t v636 = (v629 ? UINT64_C(7) : (v630 ? UINT64_C(8) : v540));
        uint64_t v637 = (v630 ? (((((uint64_t)(v627 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(7)]))) : v591);
        uint64_t v638 = (v631 ? ((v557 + UINT64_C(1)) & UINT64_C(255)) : v557);
        uint64_t v639 = (v631 ? UINT64_C(6) : v608);
        uint64_t v640 = (v631 ? ((uint64_t)((UINT64_C(7) + v627) & UINT64_C(255))) : v574);
        uint64_t v641 = ((v629 || v630) ? UINT64_C(1) : ((v635 || (v628 && (!v631))) ? UINT64_C(2) : v625));
        t642 = v636;
    } else {
        t642 = v540;
    }
    uint64_t v643 = t642;
    uint64_t t659;
    if (v626) {
        uint64_t v644 = ((uint64_t)in_b[UINT64_C(6)]);
        int v645 = ((v625 == UINT64_C(0)) && (UINT64_C(6) == v574));
        int v646 = (v645 && (v644 == UINT64_C(0)));
        int v647 = ((v645 && ((v644 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(7) < ((uint64_t)((uint64_t)in_b_len))));
        int v648 = (((v645 && (v644 != UINT64_C(0))) && (v644 < UINT64_C(64))) && (((uint64_t)((UINT64_C(6) + v644) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t651 = ((v625 == UINT64_C(0)) && (UINT64_C(6) != v574));
        if (t651) {
                uint64_t v649 = v644;
            int t650 = (!(((((v649 | UINT64_C(32)) >= UINT64_C(97)) && ((v649 | UINT64_C(32)) <= UINT64_C(122))) || ((v649 >= UINT64_C(48)) && (v649 <= UINT64_C(57)))) || (v649 == UINT64_C(45))));
            if (!t650) {
                t650 = ((v644 == UINT64_C(45)) && ((UINT64_C(6) == ((v608 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(7) == v574)));
            }
            t651 = t650;
        }
        int v652 = t651;
        uint64_t v653 = (v646 ? UINT64_C(7) : (v647 ? UINT64_C(8) : v540));
        uint64_t v654 = (v647 ? (((((uint64_t)(v644 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(7)]))) : v591);
        uint64_t v655 = (v648 ? ((v557 + UINT64_C(1)) & UINT64_C(255)) : v557);
        uint64_t v656 = (v648 ? UINT64_C(6) : v608);
        uint64_t v657 = (v648 ? ((uint64_t)((UINT64_C(7) + v644) & UINT64_C(255))) : v574);
        uint64_t v658 = ((v646 || v647) ? UINT64_C(1) : ((v652 || (v645 && (!v648))) ? UINT64_C(2) : v625));
        t659 = v655;
    } else {
        t659 = v557;
    }
    uint64_t v660 = t659;
    uint64_t t676;
    if (v626) {
        uint64_t v661 = ((uint64_t)in_b[UINT64_C(6)]);
        int v662 = ((v625 == UINT64_C(0)) && (UINT64_C(6) == v574));
        int v663 = (v662 && (v661 == UINT64_C(0)));
        int v664 = ((v662 && ((v661 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(7) < ((uint64_t)((uint64_t)in_b_len))));
        int v665 = (((v662 && (v661 != UINT64_C(0))) && (v661 < UINT64_C(64))) && (((uint64_t)((UINT64_C(6) + v661) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t668 = ((v625 == UINT64_C(0)) && (UINT64_C(6) != v574));
        if (t668) {
                uint64_t v666 = v661;
            int t667 = (!(((((v666 | UINT64_C(32)) >= UINT64_C(97)) && ((v666 | UINT64_C(32)) <= UINT64_C(122))) || ((v666 >= UINT64_C(48)) && (v666 <= UINT64_C(57)))) || (v666 == UINT64_C(45))));
            if (!t667) {
                t667 = ((v661 == UINT64_C(45)) && ((UINT64_C(6) == ((v608 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(7) == v574)));
            }
            t668 = t667;
        }
        int v669 = t668;
        uint64_t v670 = (v663 ? UINT64_C(7) : (v664 ? UINT64_C(8) : v540));
        uint64_t v671 = (v664 ? (((((uint64_t)(v661 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(7)]))) : v591);
        uint64_t v672 = (v665 ? ((v557 + UINT64_C(1)) & UINT64_C(255)) : v557);
        uint64_t v673 = (v665 ? UINT64_C(6) : v608);
        uint64_t v674 = (v665 ? ((uint64_t)((UINT64_C(7) + v661) & UINT64_C(255))) : v574);
        uint64_t v675 = ((v663 || v664) ? UINT64_C(1) : ((v669 || (v662 && (!v665))) ? UINT64_C(2) : v625));
        t676 = v674;
    } else {
        t676 = v574;
    }
    uint64_t v677 = t676;
    uint64_t t693;
    if (v626) {
        uint64_t v678 = ((uint64_t)in_b[UINT64_C(6)]);
        int v679 = ((v625 == UINT64_C(0)) && (UINT64_C(6) == v574));
        int v680 = (v679 && (v678 == UINT64_C(0)));
        int v681 = ((v679 && ((v678 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(7) < ((uint64_t)((uint64_t)in_b_len))));
        int v682 = (((v679 && (v678 != UINT64_C(0))) && (v678 < UINT64_C(64))) && (((uint64_t)((UINT64_C(6) + v678) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t685 = ((v625 == UINT64_C(0)) && (UINT64_C(6) != v574));
        if (t685) {
                uint64_t v683 = v678;
            int t684 = (!(((((v683 | UINT64_C(32)) >= UINT64_C(97)) && ((v683 | UINT64_C(32)) <= UINT64_C(122))) || ((v683 >= UINT64_C(48)) && (v683 <= UINT64_C(57)))) || (v683 == UINT64_C(45))));
            if (!t684) {
                t684 = ((v678 == UINT64_C(45)) && ((UINT64_C(6) == ((v608 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(7) == v574)));
            }
            t685 = t684;
        }
        int v686 = t685;
        uint64_t v687 = (v680 ? UINT64_C(7) : (v681 ? UINT64_C(8) : v540));
        uint64_t v688 = (v681 ? (((((uint64_t)(v678 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(7)]))) : v591);
        uint64_t v689 = (v682 ? ((v557 + UINT64_C(1)) & UINT64_C(255)) : v557);
        uint64_t v690 = (v682 ? UINT64_C(6) : v608);
        uint64_t v691 = (v682 ? ((uint64_t)((UINT64_C(7) + v678) & UINT64_C(255))) : v574);
        uint64_t v692 = ((v680 || v681) ? UINT64_C(1) : ((v686 || (v679 && (!v682))) ? UINT64_C(2) : v625));
        t693 = v688;
    } else {
        t693 = v591;
    }
    uint64_t v694 = t693;
    uint64_t t710;
    if (v626) {
        uint64_t v695 = ((uint64_t)in_b[UINT64_C(6)]);
        int v696 = ((v625 == UINT64_C(0)) && (UINT64_C(6) == v574));
        int v697 = (v696 && (v695 == UINT64_C(0)));
        int v698 = ((v696 && ((v695 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(7) < ((uint64_t)((uint64_t)in_b_len))));
        int v699 = (((v696 && (v695 != UINT64_C(0))) && (v695 < UINT64_C(64))) && (((uint64_t)((UINT64_C(6) + v695) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t702 = ((v625 == UINT64_C(0)) && (UINT64_C(6) != v574));
        if (t702) {
                uint64_t v700 = v695;
            int t701 = (!(((((v700 | UINT64_C(32)) >= UINT64_C(97)) && ((v700 | UINT64_C(32)) <= UINT64_C(122))) || ((v700 >= UINT64_C(48)) && (v700 <= UINT64_C(57)))) || (v700 == UINT64_C(45))));
            if (!t701) {
                t701 = ((v695 == UINT64_C(45)) && ((UINT64_C(6) == ((v608 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(7) == v574)));
            }
            t702 = t701;
        }
        int v703 = t702;
        uint64_t v704 = (v697 ? UINT64_C(7) : (v698 ? UINT64_C(8) : v540));
        uint64_t v705 = (v698 ? (((((uint64_t)(v695 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(7)]))) : v591);
        uint64_t v706 = (v699 ? ((v557 + UINT64_C(1)) & UINT64_C(255)) : v557);
        uint64_t v707 = (v699 ? UINT64_C(6) : v608);
        uint64_t v708 = (v699 ? ((uint64_t)((UINT64_C(7) + v695) & UINT64_C(255))) : v574);
        uint64_t v709 = ((v697 || v698) ? UINT64_C(1) : ((v703 || (v696 && (!v699))) ? UINT64_C(2) : v625));
        t710 = v707;
    } else {
        t710 = v608;
    }
    uint64_t v711 = t710;
    uint64_t t727;
    if (v626) {
        uint64_t v712 = ((uint64_t)in_b[UINT64_C(6)]);
        int v713 = ((v625 == UINT64_C(0)) && (UINT64_C(6) == v574));
        int v714 = (v713 && (v712 == UINT64_C(0)));
        int v715 = ((v713 && ((v712 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(7) < ((uint64_t)((uint64_t)in_b_len))));
        int v716 = (((v713 && (v712 != UINT64_C(0))) && (v712 < UINT64_C(64))) && (((uint64_t)((UINT64_C(6) + v712) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t719 = ((v625 == UINT64_C(0)) && (UINT64_C(6) != v574));
        if (t719) {
                uint64_t v717 = v712;
            int t718 = (!(((((v717 | UINT64_C(32)) >= UINT64_C(97)) && ((v717 | UINT64_C(32)) <= UINT64_C(122))) || ((v717 >= UINT64_C(48)) && (v717 <= UINT64_C(57)))) || (v717 == UINT64_C(45))));
            if (!t718) {
                t718 = ((v712 == UINT64_C(45)) && ((UINT64_C(6) == ((v608 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(7) == v574)));
            }
            t719 = t718;
        }
        int v720 = t719;
        uint64_t v721 = (v714 ? UINT64_C(7) : (v715 ? UINT64_C(8) : v540));
        uint64_t v722 = (v715 ? (((((uint64_t)(v712 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(7)]))) : v591);
        uint64_t v723 = (v716 ? ((v557 + UINT64_C(1)) & UINT64_C(255)) : v557);
        uint64_t v724 = (v716 ? UINT64_C(6) : v608);
        uint64_t v725 = (v716 ? ((uint64_t)((UINT64_C(7) + v712) & UINT64_C(255))) : v574);
        uint64_t v726 = ((v714 || v715) ? UINT64_C(1) : ((v720 || (v713 && (!v716))) ? UINT64_C(2) : v625));
        t727 = v726;
    } else {
        t727 = v625;
    }
    uint64_t v728 = t727;
    int v729 = (UINT64_C(7) < v7);
    uint64_t t745;
    if (v729) {
        uint64_t v730 = ((uint64_t)in_b[UINT64_C(7)]);
        int v731 = ((v728 == UINT64_C(0)) && (UINT64_C(7) == v677));
        int v732 = (v731 && (v730 == UINT64_C(0)));
        int v733 = ((v731 && ((v730 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(8) < ((uint64_t)((uint64_t)in_b_len))));
        int v734 = (((v731 && (v730 != UINT64_C(0))) && (v730 < UINT64_C(64))) && (((uint64_t)((UINT64_C(7) + v730) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t737 = ((v728 == UINT64_C(0)) && (UINT64_C(7) != v677));
        if (t737) {
                uint64_t v735 = v730;
            int t736 = (!(((((v735 | UINT64_C(32)) >= UINT64_C(97)) && ((v735 | UINT64_C(32)) <= UINT64_C(122))) || ((v735 >= UINT64_C(48)) && (v735 <= UINT64_C(57)))) || (v735 == UINT64_C(45))));
            if (!t736) {
                t736 = ((v730 == UINT64_C(45)) && ((UINT64_C(7) == ((v711 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(8) == v677)));
            }
            t737 = t736;
        }
        int v738 = t737;
        uint64_t v739 = (v732 ? UINT64_C(8) : (v733 ? UINT64_C(9) : v643));
        uint64_t v740 = (v733 ? (((((uint64_t)(v730 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(8)]))) : v694);
        uint64_t v741 = (v734 ? ((v660 + UINT64_C(1)) & UINT64_C(255)) : v660);
        uint64_t v742 = (v734 ? UINT64_C(7) : v711);
        uint64_t v743 = (v734 ? ((uint64_t)((UINT64_C(8) + v730) & UINT64_C(255))) : v677);
        uint64_t v744 = ((v732 || v733) ? UINT64_C(1) : ((v738 || (v731 && (!v734))) ? UINT64_C(2) : v728));
        t745 = v739;
    } else {
        t745 = v643;
    }
    uint64_t v746 = t745;
    uint64_t t762;
    if (v729) {
        uint64_t v747 = ((uint64_t)in_b[UINT64_C(7)]);
        int v748 = ((v728 == UINT64_C(0)) && (UINT64_C(7) == v677));
        int v749 = (v748 && (v747 == UINT64_C(0)));
        int v750 = ((v748 && ((v747 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(8) < ((uint64_t)((uint64_t)in_b_len))));
        int v751 = (((v748 && (v747 != UINT64_C(0))) && (v747 < UINT64_C(64))) && (((uint64_t)((UINT64_C(7) + v747) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t754 = ((v728 == UINT64_C(0)) && (UINT64_C(7) != v677));
        if (t754) {
                uint64_t v752 = v747;
            int t753 = (!(((((v752 | UINT64_C(32)) >= UINT64_C(97)) && ((v752 | UINT64_C(32)) <= UINT64_C(122))) || ((v752 >= UINT64_C(48)) && (v752 <= UINT64_C(57)))) || (v752 == UINT64_C(45))));
            if (!t753) {
                t753 = ((v747 == UINT64_C(45)) && ((UINT64_C(7) == ((v711 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(8) == v677)));
            }
            t754 = t753;
        }
        int v755 = t754;
        uint64_t v756 = (v749 ? UINT64_C(8) : (v750 ? UINT64_C(9) : v643));
        uint64_t v757 = (v750 ? (((((uint64_t)(v747 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(8)]))) : v694);
        uint64_t v758 = (v751 ? ((v660 + UINT64_C(1)) & UINT64_C(255)) : v660);
        uint64_t v759 = (v751 ? UINT64_C(7) : v711);
        uint64_t v760 = (v751 ? ((uint64_t)((UINT64_C(8) + v747) & UINT64_C(255))) : v677);
        uint64_t v761 = ((v749 || v750) ? UINT64_C(1) : ((v755 || (v748 && (!v751))) ? UINT64_C(2) : v728));
        t762 = v758;
    } else {
        t762 = v660;
    }
    uint64_t v763 = t762;
    uint64_t t779;
    if (v729) {
        uint64_t v764 = ((uint64_t)in_b[UINT64_C(7)]);
        int v765 = ((v728 == UINT64_C(0)) && (UINT64_C(7) == v677));
        int v766 = (v765 && (v764 == UINT64_C(0)));
        int v767 = ((v765 && ((v764 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(8) < ((uint64_t)((uint64_t)in_b_len))));
        int v768 = (((v765 && (v764 != UINT64_C(0))) && (v764 < UINT64_C(64))) && (((uint64_t)((UINT64_C(7) + v764) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t771 = ((v728 == UINT64_C(0)) && (UINT64_C(7) != v677));
        if (t771) {
                uint64_t v769 = v764;
            int t770 = (!(((((v769 | UINT64_C(32)) >= UINT64_C(97)) && ((v769 | UINT64_C(32)) <= UINT64_C(122))) || ((v769 >= UINT64_C(48)) && (v769 <= UINT64_C(57)))) || (v769 == UINT64_C(45))));
            if (!t770) {
                t770 = ((v764 == UINT64_C(45)) && ((UINT64_C(7) == ((v711 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(8) == v677)));
            }
            t771 = t770;
        }
        int v772 = t771;
        uint64_t v773 = (v766 ? UINT64_C(8) : (v767 ? UINT64_C(9) : v643));
        uint64_t v774 = (v767 ? (((((uint64_t)(v764 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(8)]))) : v694);
        uint64_t v775 = (v768 ? ((v660 + UINT64_C(1)) & UINT64_C(255)) : v660);
        uint64_t v776 = (v768 ? UINT64_C(7) : v711);
        uint64_t v777 = (v768 ? ((uint64_t)((UINT64_C(8) + v764) & UINT64_C(255))) : v677);
        uint64_t v778 = ((v766 || v767) ? UINT64_C(1) : ((v772 || (v765 && (!v768))) ? UINT64_C(2) : v728));
        t779 = v777;
    } else {
        t779 = v677;
    }
    uint64_t v780 = t779;
    uint64_t t796;
    if (v729) {
        uint64_t v781 = ((uint64_t)in_b[UINT64_C(7)]);
        int v782 = ((v728 == UINT64_C(0)) && (UINT64_C(7) == v677));
        int v783 = (v782 && (v781 == UINT64_C(0)));
        int v784 = ((v782 && ((v781 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(8) < ((uint64_t)((uint64_t)in_b_len))));
        int v785 = (((v782 && (v781 != UINT64_C(0))) && (v781 < UINT64_C(64))) && (((uint64_t)((UINT64_C(7) + v781) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t788 = ((v728 == UINT64_C(0)) && (UINT64_C(7) != v677));
        if (t788) {
                uint64_t v786 = v781;
            int t787 = (!(((((v786 | UINT64_C(32)) >= UINT64_C(97)) && ((v786 | UINT64_C(32)) <= UINT64_C(122))) || ((v786 >= UINT64_C(48)) && (v786 <= UINT64_C(57)))) || (v786 == UINT64_C(45))));
            if (!t787) {
                t787 = ((v781 == UINT64_C(45)) && ((UINT64_C(7) == ((v711 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(8) == v677)));
            }
            t788 = t787;
        }
        int v789 = t788;
        uint64_t v790 = (v783 ? UINT64_C(8) : (v784 ? UINT64_C(9) : v643));
        uint64_t v791 = (v784 ? (((((uint64_t)(v781 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(8)]))) : v694);
        uint64_t v792 = (v785 ? ((v660 + UINT64_C(1)) & UINT64_C(255)) : v660);
        uint64_t v793 = (v785 ? UINT64_C(7) : v711);
        uint64_t v794 = (v785 ? ((uint64_t)((UINT64_C(8) + v781) & UINT64_C(255))) : v677);
        uint64_t v795 = ((v783 || v784) ? UINT64_C(1) : ((v789 || (v782 && (!v785))) ? UINT64_C(2) : v728));
        t796 = v791;
    } else {
        t796 = v694;
    }
    uint64_t v797 = t796;
    uint64_t t813;
    if (v729) {
        uint64_t v798 = ((uint64_t)in_b[UINT64_C(7)]);
        int v799 = ((v728 == UINT64_C(0)) && (UINT64_C(7) == v677));
        int v800 = (v799 && (v798 == UINT64_C(0)));
        int v801 = ((v799 && ((v798 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(8) < ((uint64_t)((uint64_t)in_b_len))));
        int v802 = (((v799 && (v798 != UINT64_C(0))) && (v798 < UINT64_C(64))) && (((uint64_t)((UINT64_C(7) + v798) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t805 = ((v728 == UINT64_C(0)) && (UINT64_C(7) != v677));
        if (t805) {
                uint64_t v803 = v798;
            int t804 = (!(((((v803 | UINT64_C(32)) >= UINT64_C(97)) && ((v803 | UINT64_C(32)) <= UINT64_C(122))) || ((v803 >= UINT64_C(48)) && (v803 <= UINT64_C(57)))) || (v803 == UINT64_C(45))));
            if (!t804) {
                t804 = ((v798 == UINT64_C(45)) && ((UINT64_C(7) == ((v711 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(8) == v677)));
            }
            t805 = t804;
        }
        int v806 = t805;
        uint64_t v807 = (v800 ? UINT64_C(8) : (v801 ? UINT64_C(9) : v643));
        uint64_t v808 = (v801 ? (((((uint64_t)(v798 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(8)]))) : v694);
        uint64_t v809 = (v802 ? ((v660 + UINT64_C(1)) & UINT64_C(255)) : v660);
        uint64_t v810 = (v802 ? UINT64_C(7) : v711);
        uint64_t v811 = (v802 ? ((uint64_t)((UINT64_C(8) + v798) & UINT64_C(255))) : v677);
        uint64_t v812 = ((v800 || v801) ? UINT64_C(1) : ((v806 || (v799 && (!v802))) ? UINT64_C(2) : v728));
        t813 = v810;
    } else {
        t813 = v711;
    }
    uint64_t v814 = t813;
    uint64_t t830;
    if (v729) {
        uint64_t v815 = ((uint64_t)in_b[UINT64_C(7)]);
        int v816 = ((v728 == UINT64_C(0)) && (UINT64_C(7) == v677));
        int v817 = (v816 && (v815 == UINT64_C(0)));
        int v818 = ((v816 && ((v815 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(8) < ((uint64_t)((uint64_t)in_b_len))));
        int v819 = (((v816 && (v815 != UINT64_C(0))) && (v815 < UINT64_C(64))) && (((uint64_t)((UINT64_C(7) + v815) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t822 = ((v728 == UINT64_C(0)) && (UINT64_C(7) != v677));
        if (t822) {
                uint64_t v820 = v815;
            int t821 = (!(((((v820 | UINT64_C(32)) >= UINT64_C(97)) && ((v820 | UINT64_C(32)) <= UINT64_C(122))) || ((v820 >= UINT64_C(48)) && (v820 <= UINT64_C(57)))) || (v820 == UINT64_C(45))));
            if (!t821) {
                t821 = ((v815 == UINT64_C(45)) && ((UINT64_C(7) == ((v711 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(8) == v677)));
            }
            t822 = t821;
        }
        int v823 = t822;
        uint64_t v824 = (v817 ? UINT64_C(8) : (v818 ? UINT64_C(9) : v643));
        uint64_t v825 = (v818 ? (((((uint64_t)(v815 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(8)]))) : v694);
        uint64_t v826 = (v819 ? ((v660 + UINT64_C(1)) & UINT64_C(255)) : v660);
        uint64_t v827 = (v819 ? UINT64_C(7) : v711);
        uint64_t v828 = (v819 ? ((uint64_t)((UINT64_C(8) + v815) & UINT64_C(255))) : v677);
        uint64_t v829 = ((v817 || v818) ? UINT64_C(1) : ((v823 || (v816 && (!v819))) ? UINT64_C(2) : v728));
        t830 = v829;
    } else {
        t830 = v728;
    }
    uint64_t v831 = t830;
    int v832 = (UINT64_C(8) < v7);
    uint64_t t848;
    if (v832) {
        uint64_t v833 = ((uint64_t)in_b[UINT64_C(8)]);
        int v834 = ((v831 == UINT64_C(0)) && (UINT64_C(8) == v780));
        int v835 = (v834 && (v833 == UINT64_C(0)));
        int v836 = ((v834 && ((v833 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(9) < ((uint64_t)((uint64_t)in_b_len))));
        int v837 = (((v834 && (v833 != UINT64_C(0))) && (v833 < UINT64_C(64))) && (((uint64_t)((UINT64_C(8) + v833) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t840 = ((v831 == UINT64_C(0)) && (UINT64_C(8) != v780));
        if (t840) {
                uint64_t v838 = v833;
            int t839 = (!(((((v838 | UINT64_C(32)) >= UINT64_C(97)) && ((v838 | UINT64_C(32)) <= UINT64_C(122))) || ((v838 >= UINT64_C(48)) && (v838 <= UINT64_C(57)))) || (v838 == UINT64_C(45))));
            if (!t839) {
                t839 = ((v833 == UINT64_C(45)) && ((UINT64_C(8) == ((v814 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(9) == v780)));
            }
            t840 = t839;
        }
        int v841 = t840;
        uint64_t v842 = (v835 ? UINT64_C(9) : (v836 ? UINT64_C(10) : v746));
        uint64_t v843 = (v836 ? (((((uint64_t)(v833 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(9)]))) : v797);
        uint64_t v844 = (v837 ? ((v763 + UINT64_C(1)) & UINT64_C(255)) : v763);
        uint64_t v845 = (v837 ? UINT64_C(8) : v814);
        uint64_t v846 = (v837 ? ((uint64_t)((UINT64_C(9) + v833) & UINT64_C(255))) : v780);
        uint64_t v847 = ((v835 || v836) ? UINT64_C(1) : ((v841 || (v834 && (!v837))) ? UINT64_C(2) : v831));
        t848 = v842;
    } else {
        t848 = v746;
    }
    uint64_t v849 = t848;
    uint64_t t865;
    if (v832) {
        uint64_t v850 = ((uint64_t)in_b[UINT64_C(8)]);
        int v851 = ((v831 == UINT64_C(0)) && (UINT64_C(8) == v780));
        int v852 = (v851 && (v850 == UINT64_C(0)));
        int v853 = ((v851 && ((v850 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(9) < ((uint64_t)((uint64_t)in_b_len))));
        int v854 = (((v851 && (v850 != UINT64_C(0))) && (v850 < UINT64_C(64))) && (((uint64_t)((UINT64_C(8) + v850) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t857 = ((v831 == UINT64_C(0)) && (UINT64_C(8) != v780));
        if (t857) {
                uint64_t v855 = v850;
            int t856 = (!(((((v855 | UINT64_C(32)) >= UINT64_C(97)) && ((v855 | UINT64_C(32)) <= UINT64_C(122))) || ((v855 >= UINT64_C(48)) && (v855 <= UINT64_C(57)))) || (v855 == UINT64_C(45))));
            if (!t856) {
                t856 = ((v850 == UINT64_C(45)) && ((UINT64_C(8) == ((v814 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(9) == v780)));
            }
            t857 = t856;
        }
        int v858 = t857;
        uint64_t v859 = (v852 ? UINT64_C(9) : (v853 ? UINT64_C(10) : v746));
        uint64_t v860 = (v853 ? (((((uint64_t)(v850 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(9)]))) : v797);
        uint64_t v861 = (v854 ? ((v763 + UINT64_C(1)) & UINT64_C(255)) : v763);
        uint64_t v862 = (v854 ? UINT64_C(8) : v814);
        uint64_t v863 = (v854 ? ((uint64_t)((UINT64_C(9) + v850) & UINT64_C(255))) : v780);
        uint64_t v864 = ((v852 || v853) ? UINT64_C(1) : ((v858 || (v851 && (!v854))) ? UINT64_C(2) : v831));
        t865 = v861;
    } else {
        t865 = v763;
    }
    uint64_t v866 = t865;
    uint64_t t882;
    if (v832) {
        uint64_t v867 = ((uint64_t)in_b[UINT64_C(8)]);
        int v868 = ((v831 == UINT64_C(0)) && (UINT64_C(8) == v780));
        int v869 = (v868 && (v867 == UINT64_C(0)));
        int v870 = ((v868 && ((v867 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(9) < ((uint64_t)((uint64_t)in_b_len))));
        int v871 = (((v868 && (v867 != UINT64_C(0))) && (v867 < UINT64_C(64))) && (((uint64_t)((UINT64_C(8) + v867) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t874 = ((v831 == UINT64_C(0)) && (UINT64_C(8) != v780));
        if (t874) {
                uint64_t v872 = v867;
            int t873 = (!(((((v872 | UINT64_C(32)) >= UINT64_C(97)) && ((v872 | UINT64_C(32)) <= UINT64_C(122))) || ((v872 >= UINT64_C(48)) && (v872 <= UINT64_C(57)))) || (v872 == UINT64_C(45))));
            if (!t873) {
                t873 = ((v867 == UINT64_C(45)) && ((UINT64_C(8) == ((v814 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(9) == v780)));
            }
            t874 = t873;
        }
        int v875 = t874;
        uint64_t v876 = (v869 ? UINT64_C(9) : (v870 ? UINT64_C(10) : v746));
        uint64_t v877 = (v870 ? (((((uint64_t)(v867 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(9)]))) : v797);
        uint64_t v878 = (v871 ? ((v763 + UINT64_C(1)) & UINT64_C(255)) : v763);
        uint64_t v879 = (v871 ? UINT64_C(8) : v814);
        uint64_t v880 = (v871 ? ((uint64_t)((UINT64_C(9) + v867) & UINT64_C(255))) : v780);
        uint64_t v881 = ((v869 || v870) ? UINT64_C(1) : ((v875 || (v868 && (!v871))) ? UINT64_C(2) : v831));
        t882 = v880;
    } else {
        t882 = v780;
    }
    uint64_t v883 = t882;
    uint64_t t899;
    if (v832) {
        uint64_t v884 = ((uint64_t)in_b[UINT64_C(8)]);
        int v885 = ((v831 == UINT64_C(0)) && (UINT64_C(8) == v780));
        int v886 = (v885 && (v884 == UINT64_C(0)));
        int v887 = ((v885 && ((v884 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(9) < ((uint64_t)((uint64_t)in_b_len))));
        int v888 = (((v885 && (v884 != UINT64_C(0))) && (v884 < UINT64_C(64))) && (((uint64_t)((UINT64_C(8) + v884) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t891 = ((v831 == UINT64_C(0)) && (UINT64_C(8) != v780));
        if (t891) {
                uint64_t v889 = v884;
            int t890 = (!(((((v889 | UINT64_C(32)) >= UINT64_C(97)) && ((v889 | UINT64_C(32)) <= UINT64_C(122))) || ((v889 >= UINT64_C(48)) && (v889 <= UINT64_C(57)))) || (v889 == UINT64_C(45))));
            if (!t890) {
                t890 = ((v884 == UINT64_C(45)) && ((UINT64_C(8) == ((v814 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(9) == v780)));
            }
            t891 = t890;
        }
        int v892 = t891;
        uint64_t v893 = (v886 ? UINT64_C(9) : (v887 ? UINT64_C(10) : v746));
        uint64_t v894 = (v887 ? (((((uint64_t)(v884 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(9)]))) : v797);
        uint64_t v895 = (v888 ? ((v763 + UINT64_C(1)) & UINT64_C(255)) : v763);
        uint64_t v896 = (v888 ? UINT64_C(8) : v814);
        uint64_t v897 = (v888 ? ((uint64_t)((UINT64_C(9) + v884) & UINT64_C(255))) : v780);
        uint64_t v898 = ((v886 || v887) ? UINT64_C(1) : ((v892 || (v885 && (!v888))) ? UINT64_C(2) : v831));
        t899 = v894;
    } else {
        t899 = v797;
    }
    uint64_t v900 = t899;
    uint64_t t916;
    if (v832) {
        uint64_t v901 = ((uint64_t)in_b[UINT64_C(8)]);
        int v902 = ((v831 == UINT64_C(0)) && (UINT64_C(8) == v780));
        int v903 = (v902 && (v901 == UINT64_C(0)));
        int v904 = ((v902 && ((v901 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(9) < ((uint64_t)((uint64_t)in_b_len))));
        int v905 = (((v902 && (v901 != UINT64_C(0))) && (v901 < UINT64_C(64))) && (((uint64_t)((UINT64_C(8) + v901) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t908 = ((v831 == UINT64_C(0)) && (UINT64_C(8) != v780));
        if (t908) {
                uint64_t v906 = v901;
            int t907 = (!(((((v906 | UINT64_C(32)) >= UINT64_C(97)) && ((v906 | UINT64_C(32)) <= UINT64_C(122))) || ((v906 >= UINT64_C(48)) && (v906 <= UINT64_C(57)))) || (v906 == UINT64_C(45))));
            if (!t907) {
                t907 = ((v901 == UINT64_C(45)) && ((UINT64_C(8) == ((v814 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(9) == v780)));
            }
            t908 = t907;
        }
        int v909 = t908;
        uint64_t v910 = (v903 ? UINT64_C(9) : (v904 ? UINT64_C(10) : v746));
        uint64_t v911 = (v904 ? (((((uint64_t)(v901 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(9)]))) : v797);
        uint64_t v912 = (v905 ? ((v763 + UINT64_C(1)) & UINT64_C(255)) : v763);
        uint64_t v913 = (v905 ? UINT64_C(8) : v814);
        uint64_t v914 = (v905 ? ((uint64_t)((UINT64_C(9) + v901) & UINT64_C(255))) : v780);
        uint64_t v915 = ((v903 || v904) ? UINT64_C(1) : ((v909 || (v902 && (!v905))) ? UINT64_C(2) : v831));
        t916 = v913;
    } else {
        t916 = v814;
    }
    uint64_t v917 = t916;
    uint64_t t933;
    if (v832) {
        uint64_t v918 = ((uint64_t)in_b[UINT64_C(8)]);
        int v919 = ((v831 == UINT64_C(0)) && (UINT64_C(8) == v780));
        int v920 = (v919 && (v918 == UINT64_C(0)));
        int v921 = ((v919 && ((v918 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(9) < ((uint64_t)((uint64_t)in_b_len))));
        int v922 = (((v919 && (v918 != UINT64_C(0))) && (v918 < UINT64_C(64))) && (((uint64_t)((UINT64_C(8) + v918) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t925 = ((v831 == UINT64_C(0)) && (UINT64_C(8) != v780));
        if (t925) {
                uint64_t v923 = v918;
            int t924 = (!(((((v923 | UINT64_C(32)) >= UINT64_C(97)) && ((v923 | UINT64_C(32)) <= UINT64_C(122))) || ((v923 >= UINT64_C(48)) && (v923 <= UINT64_C(57)))) || (v923 == UINT64_C(45))));
            if (!t924) {
                t924 = ((v918 == UINT64_C(45)) && ((UINT64_C(8) == ((v814 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(9) == v780)));
            }
            t925 = t924;
        }
        int v926 = t925;
        uint64_t v927 = (v920 ? UINT64_C(9) : (v921 ? UINT64_C(10) : v746));
        uint64_t v928 = (v921 ? (((((uint64_t)(v918 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(9)]))) : v797);
        uint64_t v929 = (v922 ? ((v763 + UINT64_C(1)) & UINT64_C(255)) : v763);
        uint64_t v930 = (v922 ? UINT64_C(8) : v814);
        uint64_t v931 = (v922 ? ((uint64_t)((UINT64_C(9) + v918) & UINT64_C(255))) : v780);
        uint64_t v932 = ((v920 || v921) ? UINT64_C(1) : ((v926 || (v919 && (!v922))) ? UINT64_C(2) : v831));
        t933 = v932;
    } else {
        t933 = v831;
    }
    uint64_t v934 = t933;
    int v935 = (UINT64_C(9) < v7);
    uint64_t t951;
    if (v935) {
        uint64_t v936 = ((uint64_t)in_b[UINT64_C(9)]);
        int v937 = ((v934 == UINT64_C(0)) && (UINT64_C(9) == v883));
        int v938 = (v937 && (v936 == UINT64_C(0)));
        int v939 = ((v937 && ((v936 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(10) < ((uint64_t)((uint64_t)in_b_len))));
        int v940 = (((v937 && (v936 != UINT64_C(0))) && (v936 < UINT64_C(64))) && (((uint64_t)((UINT64_C(9) + v936) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t943 = ((v934 == UINT64_C(0)) && (UINT64_C(9) != v883));
        if (t943) {
                uint64_t v941 = v936;
            int t942 = (!(((((v941 | UINT64_C(32)) >= UINT64_C(97)) && ((v941 | UINT64_C(32)) <= UINT64_C(122))) || ((v941 >= UINT64_C(48)) && (v941 <= UINT64_C(57)))) || (v941 == UINT64_C(45))));
            if (!t942) {
                t942 = ((v936 == UINT64_C(45)) && ((UINT64_C(9) == ((v917 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(10) == v883)));
            }
            t943 = t942;
        }
        int v944 = t943;
        uint64_t v945 = (v938 ? UINT64_C(10) : (v939 ? UINT64_C(11) : v849));
        uint64_t v946 = (v939 ? (((((uint64_t)(v936 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(10)]))) : v900);
        uint64_t v947 = (v940 ? ((v866 + UINT64_C(1)) & UINT64_C(255)) : v866);
        uint64_t v948 = (v940 ? UINT64_C(9) : v917);
        uint64_t v949 = (v940 ? ((uint64_t)((UINT64_C(10) + v936) & UINT64_C(255))) : v883);
        uint64_t v950 = ((v938 || v939) ? UINT64_C(1) : ((v944 || (v937 && (!v940))) ? UINT64_C(2) : v934));
        t951 = v945;
    } else {
        t951 = v849;
    }
    uint64_t v952 = t951;
    uint64_t t968;
    if (v935) {
        uint64_t v953 = ((uint64_t)in_b[UINT64_C(9)]);
        int v954 = ((v934 == UINT64_C(0)) && (UINT64_C(9) == v883));
        int v955 = (v954 && (v953 == UINT64_C(0)));
        int v956 = ((v954 && ((v953 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(10) < ((uint64_t)((uint64_t)in_b_len))));
        int v957 = (((v954 && (v953 != UINT64_C(0))) && (v953 < UINT64_C(64))) && (((uint64_t)((UINT64_C(9) + v953) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t960 = ((v934 == UINT64_C(0)) && (UINT64_C(9) != v883));
        if (t960) {
                uint64_t v958 = v953;
            int t959 = (!(((((v958 | UINT64_C(32)) >= UINT64_C(97)) && ((v958 | UINT64_C(32)) <= UINT64_C(122))) || ((v958 >= UINT64_C(48)) && (v958 <= UINT64_C(57)))) || (v958 == UINT64_C(45))));
            if (!t959) {
                t959 = ((v953 == UINT64_C(45)) && ((UINT64_C(9) == ((v917 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(10) == v883)));
            }
            t960 = t959;
        }
        int v961 = t960;
        uint64_t v962 = (v955 ? UINT64_C(10) : (v956 ? UINT64_C(11) : v849));
        uint64_t v963 = (v956 ? (((((uint64_t)(v953 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(10)]))) : v900);
        uint64_t v964 = (v957 ? ((v866 + UINT64_C(1)) & UINT64_C(255)) : v866);
        uint64_t v965 = (v957 ? UINT64_C(9) : v917);
        uint64_t v966 = (v957 ? ((uint64_t)((UINT64_C(10) + v953) & UINT64_C(255))) : v883);
        uint64_t v967 = ((v955 || v956) ? UINT64_C(1) : ((v961 || (v954 && (!v957))) ? UINT64_C(2) : v934));
        t968 = v964;
    } else {
        t968 = v866;
    }
    uint64_t v969 = t968;
    uint64_t t985;
    if (v935) {
        uint64_t v970 = ((uint64_t)in_b[UINT64_C(9)]);
        int v971 = ((v934 == UINT64_C(0)) && (UINT64_C(9) == v883));
        int v972 = (v971 && (v970 == UINT64_C(0)));
        int v973 = ((v971 && ((v970 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(10) < ((uint64_t)((uint64_t)in_b_len))));
        int v974 = (((v971 && (v970 != UINT64_C(0))) && (v970 < UINT64_C(64))) && (((uint64_t)((UINT64_C(9) + v970) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t977 = ((v934 == UINT64_C(0)) && (UINT64_C(9) != v883));
        if (t977) {
                uint64_t v975 = v970;
            int t976 = (!(((((v975 | UINT64_C(32)) >= UINT64_C(97)) && ((v975 | UINT64_C(32)) <= UINT64_C(122))) || ((v975 >= UINT64_C(48)) && (v975 <= UINT64_C(57)))) || (v975 == UINT64_C(45))));
            if (!t976) {
                t976 = ((v970 == UINT64_C(45)) && ((UINT64_C(9) == ((v917 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(10) == v883)));
            }
            t977 = t976;
        }
        int v978 = t977;
        uint64_t v979 = (v972 ? UINT64_C(10) : (v973 ? UINT64_C(11) : v849));
        uint64_t v980 = (v973 ? (((((uint64_t)(v970 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(10)]))) : v900);
        uint64_t v981 = (v974 ? ((v866 + UINT64_C(1)) & UINT64_C(255)) : v866);
        uint64_t v982 = (v974 ? UINT64_C(9) : v917);
        uint64_t v983 = (v974 ? ((uint64_t)((UINT64_C(10) + v970) & UINT64_C(255))) : v883);
        uint64_t v984 = ((v972 || v973) ? UINT64_C(1) : ((v978 || (v971 && (!v974))) ? UINT64_C(2) : v934));
        t985 = v983;
    } else {
        t985 = v883;
    }
    uint64_t v986 = t985;
    uint64_t t1002;
    if (v935) {
        uint64_t v987 = ((uint64_t)in_b[UINT64_C(9)]);
        int v988 = ((v934 == UINT64_C(0)) && (UINT64_C(9) == v883));
        int v989 = (v988 && (v987 == UINT64_C(0)));
        int v990 = ((v988 && ((v987 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(10) < ((uint64_t)((uint64_t)in_b_len))));
        int v991 = (((v988 && (v987 != UINT64_C(0))) && (v987 < UINT64_C(64))) && (((uint64_t)((UINT64_C(9) + v987) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t994 = ((v934 == UINT64_C(0)) && (UINT64_C(9) != v883));
        if (t994) {
                uint64_t v992 = v987;
            int t993 = (!(((((v992 | UINT64_C(32)) >= UINT64_C(97)) && ((v992 | UINT64_C(32)) <= UINT64_C(122))) || ((v992 >= UINT64_C(48)) && (v992 <= UINT64_C(57)))) || (v992 == UINT64_C(45))));
            if (!t993) {
                t993 = ((v987 == UINT64_C(45)) && ((UINT64_C(9) == ((v917 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(10) == v883)));
            }
            t994 = t993;
        }
        int v995 = t994;
        uint64_t v996 = (v989 ? UINT64_C(10) : (v990 ? UINT64_C(11) : v849));
        uint64_t v997 = (v990 ? (((((uint64_t)(v987 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(10)]))) : v900);
        uint64_t v998 = (v991 ? ((v866 + UINT64_C(1)) & UINT64_C(255)) : v866);
        uint64_t v999 = (v991 ? UINT64_C(9) : v917);
        uint64_t v1000 = (v991 ? ((uint64_t)((UINT64_C(10) + v987) & UINT64_C(255))) : v883);
        uint64_t v1001 = ((v989 || v990) ? UINT64_C(1) : ((v995 || (v988 && (!v991))) ? UINT64_C(2) : v934));
        t1002 = v997;
    } else {
        t1002 = v900;
    }
    uint64_t v1003 = t1002;
    uint64_t t1019;
    if (v935) {
        uint64_t v1004 = ((uint64_t)in_b[UINT64_C(9)]);
        int v1005 = ((v934 == UINT64_C(0)) && (UINT64_C(9) == v883));
        int v1006 = (v1005 && (v1004 == UINT64_C(0)));
        int v1007 = ((v1005 && ((v1004 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(10) < ((uint64_t)((uint64_t)in_b_len))));
        int v1008 = (((v1005 && (v1004 != UINT64_C(0))) && (v1004 < UINT64_C(64))) && (((uint64_t)((UINT64_C(9) + v1004) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1011 = ((v934 == UINT64_C(0)) && (UINT64_C(9) != v883));
        if (t1011) {
                uint64_t v1009 = v1004;
            int t1010 = (!(((((v1009 | UINT64_C(32)) >= UINT64_C(97)) && ((v1009 | UINT64_C(32)) <= UINT64_C(122))) || ((v1009 >= UINT64_C(48)) && (v1009 <= UINT64_C(57)))) || (v1009 == UINT64_C(45))));
            if (!t1010) {
                t1010 = ((v1004 == UINT64_C(45)) && ((UINT64_C(9) == ((v917 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(10) == v883)));
            }
            t1011 = t1010;
        }
        int v1012 = t1011;
        uint64_t v1013 = (v1006 ? UINT64_C(10) : (v1007 ? UINT64_C(11) : v849));
        uint64_t v1014 = (v1007 ? (((((uint64_t)(v1004 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(10)]))) : v900);
        uint64_t v1015 = (v1008 ? ((v866 + UINT64_C(1)) & UINT64_C(255)) : v866);
        uint64_t v1016 = (v1008 ? UINT64_C(9) : v917);
        uint64_t v1017 = (v1008 ? ((uint64_t)((UINT64_C(10) + v1004) & UINT64_C(255))) : v883);
        uint64_t v1018 = ((v1006 || v1007) ? UINT64_C(1) : ((v1012 || (v1005 && (!v1008))) ? UINT64_C(2) : v934));
        t1019 = v1016;
    } else {
        t1019 = v917;
    }
    uint64_t v1020 = t1019;
    uint64_t t1036;
    if (v935) {
        uint64_t v1021 = ((uint64_t)in_b[UINT64_C(9)]);
        int v1022 = ((v934 == UINT64_C(0)) && (UINT64_C(9) == v883));
        int v1023 = (v1022 && (v1021 == UINT64_C(0)));
        int v1024 = ((v1022 && ((v1021 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(10) < ((uint64_t)((uint64_t)in_b_len))));
        int v1025 = (((v1022 && (v1021 != UINT64_C(0))) && (v1021 < UINT64_C(64))) && (((uint64_t)((UINT64_C(9) + v1021) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1028 = ((v934 == UINT64_C(0)) && (UINT64_C(9) != v883));
        if (t1028) {
                uint64_t v1026 = v1021;
            int t1027 = (!(((((v1026 | UINT64_C(32)) >= UINT64_C(97)) && ((v1026 | UINT64_C(32)) <= UINT64_C(122))) || ((v1026 >= UINT64_C(48)) && (v1026 <= UINT64_C(57)))) || (v1026 == UINT64_C(45))));
            if (!t1027) {
                t1027 = ((v1021 == UINT64_C(45)) && ((UINT64_C(9) == ((v917 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(10) == v883)));
            }
            t1028 = t1027;
        }
        int v1029 = t1028;
        uint64_t v1030 = (v1023 ? UINT64_C(10) : (v1024 ? UINT64_C(11) : v849));
        uint64_t v1031 = (v1024 ? (((((uint64_t)(v1021 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(10)]))) : v900);
        uint64_t v1032 = (v1025 ? ((v866 + UINT64_C(1)) & UINT64_C(255)) : v866);
        uint64_t v1033 = (v1025 ? UINT64_C(9) : v917);
        uint64_t v1034 = (v1025 ? ((uint64_t)((UINT64_C(10) + v1021) & UINT64_C(255))) : v883);
        uint64_t v1035 = ((v1023 || v1024) ? UINT64_C(1) : ((v1029 || (v1022 && (!v1025))) ? UINT64_C(2) : v934));
        t1036 = v1035;
    } else {
        t1036 = v934;
    }
    uint64_t v1037 = t1036;
    int v1038 = (UINT64_C(10) < v7);
    uint64_t t1054;
    if (v1038) {
        uint64_t v1039 = ((uint64_t)in_b[UINT64_C(10)]);
        int v1040 = ((v1037 == UINT64_C(0)) && (UINT64_C(10) == v986));
        int v1041 = (v1040 && (v1039 == UINT64_C(0)));
        int v1042 = ((v1040 && ((v1039 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(11) < ((uint64_t)((uint64_t)in_b_len))));
        int v1043 = (((v1040 && (v1039 != UINT64_C(0))) && (v1039 < UINT64_C(64))) && (((uint64_t)((UINT64_C(10) + v1039) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1046 = ((v1037 == UINT64_C(0)) && (UINT64_C(10) != v986));
        if (t1046) {
                uint64_t v1044 = v1039;
            int t1045 = (!(((((v1044 | UINT64_C(32)) >= UINT64_C(97)) && ((v1044 | UINT64_C(32)) <= UINT64_C(122))) || ((v1044 >= UINT64_C(48)) && (v1044 <= UINT64_C(57)))) || (v1044 == UINT64_C(45))));
            if (!t1045) {
                t1045 = ((v1039 == UINT64_C(45)) && ((UINT64_C(10) == ((v1020 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(11) == v986)));
            }
            t1046 = t1045;
        }
        int v1047 = t1046;
        uint64_t v1048 = (v1041 ? UINT64_C(11) : (v1042 ? UINT64_C(12) : v952));
        uint64_t v1049 = (v1042 ? (((((uint64_t)(v1039 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(11)]))) : v1003);
        uint64_t v1050 = (v1043 ? ((v969 + UINT64_C(1)) & UINT64_C(255)) : v969);
        uint64_t v1051 = (v1043 ? UINT64_C(10) : v1020);
        uint64_t v1052 = (v1043 ? ((uint64_t)((UINT64_C(11) + v1039) & UINT64_C(255))) : v986);
        uint64_t v1053 = ((v1041 || v1042) ? UINT64_C(1) : ((v1047 || (v1040 && (!v1043))) ? UINT64_C(2) : v1037));
        t1054 = v1048;
    } else {
        t1054 = v952;
    }
    uint64_t v1055 = t1054;
    uint64_t t1071;
    if (v1038) {
        uint64_t v1056 = ((uint64_t)in_b[UINT64_C(10)]);
        int v1057 = ((v1037 == UINT64_C(0)) && (UINT64_C(10) == v986));
        int v1058 = (v1057 && (v1056 == UINT64_C(0)));
        int v1059 = ((v1057 && ((v1056 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(11) < ((uint64_t)((uint64_t)in_b_len))));
        int v1060 = (((v1057 && (v1056 != UINT64_C(0))) && (v1056 < UINT64_C(64))) && (((uint64_t)((UINT64_C(10) + v1056) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1063 = ((v1037 == UINT64_C(0)) && (UINT64_C(10) != v986));
        if (t1063) {
                uint64_t v1061 = v1056;
            int t1062 = (!(((((v1061 | UINT64_C(32)) >= UINT64_C(97)) && ((v1061 | UINT64_C(32)) <= UINT64_C(122))) || ((v1061 >= UINT64_C(48)) && (v1061 <= UINT64_C(57)))) || (v1061 == UINT64_C(45))));
            if (!t1062) {
                t1062 = ((v1056 == UINT64_C(45)) && ((UINT64_C(10) == ((v1020 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(11) == v986)));
            }
            t1063 = t1062;
        }
        int v1064 = t1063;
        uint64_t v1065 = (v1058 ? UINT64_C(11) : (v1059 ? UINT64_C(12) : v952));
        uint64_t v1066 = (v1059 ? (((((uint64_t)(v1056 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(11)]))) : v1003);
        uint64_t v1067 = (v1060 ? ((v969 + UINT64_C(1)) & UINT64_C(255)) : v969);
        uint64_t v1068 = (v1060 ? UINT64_C(10) : v1020);
        uint64_t v1069 = (v1060 ? ((uint64_t)((UINT64_C(11) + v1056) & UINT64_C(255))) : v986);
        uint64_t v1070 = ((v1058 || v1059) ? UINT64_C(1) : ((v1064 || (v1057 && (!v1060))) ? UINT64_C(2) : v1037));
        t1071 = v1067;
    } else {
        t1071 = v969;
    }
    uint64_t v1072 = t1071;
    uint64_t t1088;
    if (v1038) {
        uint64_t v1073 = ((uint64_t)in_b[UINT64_C(10)]);
        int v1074 = ((v1037 == UINT64_C(0)) && (UINT64_C(10) == v986));
        int v1075 = (v1074 && (v1073 == UINT64_C(0)));
        int v1076 = ((v1074 && ((v1073 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(11) < ((uint64_t)((uint64_t)in_b_len))));
        int v1077 = (((v1074 && (v1073 != UINT64_C(0))) && (v1073 < UINT64_C(64))) && (((uint64_t)((UINT64_C(10) + v1073) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1080 = ((v1037 == UINT64_C(0)) && (UINT64_C(10) != v986));
        if (t1080) {
                uint64_t v1078 = v1073;
            int t1079 = (!(((((v1078 | UINT64_C(32)) >= UINT64_C(97)) && ((v1078 | UINT64_C(32)) <= UINT64_C(122))) || ((v1078 >= UINT64_C(48)) && (v1078 <= UINT64_C(57)))) || (v1078 == UINT64_C(45))));
            if (!t1079) {
                t1079 = ((v1073 == UINT64_C(45)) && ((UINT64_C(10) == ((v1020 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(11) == v986)));
            }
            t1080 = t1079;
        }
        int v1081 = t1080;
        uint64_t v1082 = (v1075 ? UINT64_C(11) : (v1076 ? UINT64_C(12) : v952));
        uint64_t v1083 = (v1076 ? (((((uint64_t)(v1073 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(11)]))) : v1003);
        uint64_t v1084 = (v1077 ? ((v969 + UINT64_C(1)) & UINT64_C(255)) : v969);
        uint64_t v1085 = (v1077 ? UINT64_C(10) : v1020);
        uint64_t v1086 = (v1077 ? ((uint64_t)((UINT64_C(11) + v1073) & UINT64_C(255))) : v986);
        uint64_t v1087 = ((v1075 || v1076) ? UINT64_C(1) : ((v1081 || (v1074 && (!v1077))) ? UINT64_C(2) : v1037));
        t1088 = v1086;
    } else {
        t1088 = v986;
    }
    uint64_t v1089 = t1088;
    uint64_t t1105;
    if (v1038) {
        uint64_t v1090 = ((uint64_t)in_b[UINT64_C(10)]);
        int v1091 = ((v1037 == UINT64_C(0)) && (UINT64_C(10) == v986));
        int v1092 = (v1091 && (v1090 == UINT64_C(0)));
        int v1093 = ((v1091 && ((v1090 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(11) < ((uint64_t)((uint64_t)in_b_len))));
        int v1094 = (((v1091 && (v1090 != UINT64_C(0))) && (v1090 < UINT64_C(64))) && (((uint64_t)((UINT64_C(10) + v1090) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1097 = ((v1037 == UINT64_C(0)) && (UINT64_C(10) != v986));
        if (t1097) {
                uint64_t v1095 = v1090;
            int t1096 = (!(((((v1095 | UINT64_C(32)) >= UINT64_C(97)) && ((v1095 | UINT64_C(32)) <= UINT64_C(122))) || ((v1095 >= UINT64_C(48)) && (v1095 <= UINT64_C(57)))) || (v1095 == UINT64_C(45))));
            if (!t1096) {
                t1096 = ((v1090 == UINT64_C(45)) && ((UINT64_C(10) == ((v1020 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(11) == v986)));
            }
            t1097 = t1096;
        }
        int v1098 = t1097;
        uint64_t v1099 = (v1092 ? UINT64_C(11) : (v1093 ? UINT64_C(12) : v952));
        uint64_t v1100 = (v1093 ? (((((uint64_t)(v1090 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(11)]))) : v1003);
        uint64_t v1101 = (v1094 ? ((v969 + UINT64_C(1)) & UINT64_C(255)) : v969);
        uint64_t v1102 = (v1094 ? UINT64_C(10) : v1020);
        uint64_t v1103 = (v1094 ? ((uint64_t)((UINT64_C(11) + v1090) & UINT64_C(255))) : v986);
        uint64_t v1104 = ((v1092 || v1093) ? UINT64_C(1) : ((v1098 || (v1091 && (!v1094))) ? UINT64_C(2) : v1037));
        t1105 = v1100;
    } else {
        t1105 = v1003;
    }
    uint64_t v1106 = t1105;
    uint64_t t1122;
    if (v1038) {
        uint64_t v1107 = ((uint64_t)in_b[UINT64_C(10)]);
        int v1108 = ((v1037 == UINT64_C(0)) && (UINT64_C(10) == v986));
        int v1109 = (v1108 && (v1107 == UINT64_C(0)));
        int v1110 = ((v1108 && ((v1107 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(11) < ((uint64_t)((uint64_t)in_b_len))));
        int v1111 = (((v1108 && (v1107 != UINT64_C(0))) && (v1107 < UINT64_C(64))) && (((uint64_t)((UINT64_C(10) + v1107) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1114 = ((v1037 == UINT64_C(0)) && (UINT64_C(10) != v986));
        if (t1114) {
                uint64_t v1112 = v1107;
            int t1113 = (!(((((v1112 | UINT64_C(32)) >= UINT64_C(97)) && ((v1112 | UINT64_C(32)) <= UINT64_C(122))) || ((v1112 >= UINT64_C(48)) && (v1112 <= UINT64_C(57)))) || (v1112 == UINT64_C(45))));
            if (!t1113) {
                t1113 = ((v1107 == UINT64_C(45)) && ((UINT64_C(10) == ((v1020 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(11) == v986)));
            }
            t1114 = t1113;
        }
        int v1115 = t1114;
        uint64_t v1116 = (v1109 ? UINT64_C(11) : (v1110 ? UINT64_C(12) : v952));
        uint64_t v1117 = (v1110 ? (((((uint64_t)(v1107 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(11)]))) : v1003);
        uint64_t v1118 = (v1111 ? ((v969 + UINT64_C(1)) & UINT64_C(255)) : v969);
        uint64_t v1119 = (v1111 ? UINT64_C(10) : v1020);
        uint64_t v1120 = (v1111 ? ((uint64_t)((UINT64_C(11) + v1107) & UINT64_C(255))) : v986);
        uint64_t v1121 = ((v1109 || v1110) ? UINT64_C(1) : ((v1115 || (v1108 && (!v1111))) ? UINT64_C(2) : v1037));
        t1122 = v1119;
    } else {
        t1122 = v1020;
    }
    uint64_t v1123 = t1122;
    uint64_t t1139;
    if (v1038) {
        uint64_t v1124 = ((uint64_t)in_b[UINT64_C(10)]);
        int v1125 = ((v1037 == UINT64_C(0)) && (UINT64_C(10) == v986));
        int v1126 = (v1125 && (v1124 == UINT64_C(0)));
        int v1127 = ((v1125 && ((v1124 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(11) < ((uint64_t)((uint64_t)in_b_len))));
        int v1128 = (((v1125 && (v1124 != UINT64_C(0))) && (v1124 < UINT64_C(64))) && (((uint64_t)((UINT64_C(10) + v1124) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1131 = ((v1037 == UINT64_C(0)) && (UINT64_C(10) != v986));
        if (t1131) {
                uint64_t v1129 = v1124;
            int t1130 = (!(((((v1129 | UINT64_C(32)) >= UINT64_C(97)) && ((v1129 | UINT64_C(32)) <= UINT64_C(122))) || ((v1129 >= UINT64_C(48)) && (v1129 <= UINT64_C(57)))) || (v1129 == UINT64_C(45))));
            if (!t1130) {
                t1130 = ((v1124 == UINT64_C(45)) && ((UINT64_C(10) == ((v1020 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(11) == v986)));
            }
            t1131 = t1130;
        }
        int v1132 = t1131;
        uint64_t v1133 = (v1126 ? UINT64_C(11) : (v1127 ? UINT64_C(12) : v952));
        uint64_t v1134 = (v1127 ? (((((uint64_t)(v1124 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(11)]))) : v1003);
        uint64_t v1135 = (v1128 ? ((v969 + UINT64_C(1)) & UINT64_C(255)) : v969);
        uint64_t v1136 = (v1128 ? UINT64_C(10) : v1020);
        uint64_t v1137 = (v1128 ? ((uint64_t)((UINT64_C(11) + v1124) & UINT64_C(255))) : v986);
        uint64_t v1138 = ((v1126 || v1127) ? UINT64_C(1) : ((v1132 || (v1125 && (!v1128))) ? UINT64_C(2) : v1037));
        t1139 = v1138;
    } else {
        t1139 = v1037;
    }
    uint64_t v1140 = t1139;
    int v1141 = (UINT64_C(11) < v7);
    uint64_t t1157;
    if (v1141) {
        uint64_t v1142 = ((uint64_t)in_b[UINT64_C(11)]);
        int v1143 = ((v1140 == UINT64_C(0)) && (UINT64_C(11) == v1089));
        int v1144 = (v1143 && (v1142 == UINT64_C(0)));
        int v1145 = ((v1143 && ((v1142 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(12) < ((uint64_t)((uint64_t)in_b_len))));
        int v1146 = (((v1143 && (v1142 != UINT64_C(0))) && (v1142 < UINT64_C(64))) && (((uint64_t)((UINT64_C(11) + v1142) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1149 = ((v1140 == UINT64_C(0)) && (UINT64_C(11) != v1089));
        if (t1149) {
                uint64_t v1147 = v1142;
            int t1148 = (!(((((v1147 | UINT64_C(32)) >= UINT64_C(97)) && ((v1147 | UINT64_C(32)) <= UINT64_C(122))) || ((v1147 >= UINT64_C(48)) && (v1147 <= UINT64_C(57)))) || (v1147 == UINT64_C(45))));
            if (!t1148) {
                t1148 = ((v1142 == UINT64_C(45)) && ((UINT64_C(11) == ((v1123 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(12) == v1089)));
            }
            t1149 = t1148;
        }
        int v1150 = t1149;
        uint64_t v1151 = (v1144 ? UINT64_C(12) : (v1145 ? UINT64_C(13) : v1055));
        uint64_t v1152 = (v1145 ? (((((uint64_t)(v1142 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(12)]))) : v1106);
        uint64_t v1153 = (v1146 ? ((v1072 + UINT64_C(1)) & UINT64_C(255)) : v1072);
        uint64_t v1154 = (v1146 ? UINT64_C(11) : v1123);
        uint64_t v1155 = (v1146 ? ((uint64_t)((UINT64_C(12) + v1142) & UINT64_C(255))) : v1089);
        uint64_t v1156 = ((v1144 || v1145) ? UINT64_C(1) : ((v1150 || (v1143 && (!v1146))) ? UINT64_C(2) : v1140));
        t1157 = v1151;
    } else {
        t1157 = v1055;
    }
    uint64_t v1158 = t1157;
    uint64_t t1174;
    if (v1141) {
        uint64_t v1159 = ((uint64_t)in_b[UINT64_C(11)]);
        int v1160 = ((v1140 == UINT64_C(0)) && (UINT64_C(11) == v1089));
        int v1161 = (v1160 && (v1159 == UINT64_C(0)));
        int v1162 = ((v1160 && ((v1159 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(12) < ((uint64_t)((uint64_t)in_b_len))));
        int v1163 = (((v1160 && (v1159 != UINT64_C(0))) && (v1159 < UINT64_C(64))) && (((uint64_t)((UINT64_C(11) + v1159) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1166 = ((v1140 == UINT64_C(0)) && (UINT64_C(11) != v1089));
        if (t1166) {
                uint64_t v1164 = v1159;
            int t1165 = (!(((((v1164 | UINT64_C(32)) >= UINT64_C(97)) && ((v1164 | UINT64_C(32)) <= UINT64_C(122))) || ((v1164 >= UINT64_C(48)) && (v1164 <= UINT64_C(57)))) || (v1164 == UINT64_C(45))));
            if (!t1165) {
                t1165 = ((v1159 == UINT64_C(45)) && ((UINT64_C(11) == ((v1123 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(12) == v1089)));
            }
            t1166 = t1165;
        }
        int v1167 = t1166;
        uint64_t v1168 = (v1161 ? UINT64_C(12) : (v1162 ? UINT64_C(13) : v1055));
        uint64_t v1169 = (v1162 ? (((((uint64_t)(v1159 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(12)]))) : v1106);
        uint64_t v1170 = (v1163 ? ((v1072 + UINT64_C(1)) & UINT64_C(255)) : v1072);
        uint64_t v1171 = (v1163 ? UINT64_C(11) : v1123);
        uint64_t v1172 = (v1163 ? ((uint64_t)((UINT64_C(12) + v1159) & UINT64_C(255))) : v1089);
        uint64_t v1173 = ((v1161 || v1162) ? UINT64_C(1) : ((v1167 || (v1160 && (!v1163))) ? UINT64_C(2) : v1140));
        t1174 = v1170;
    } else {
        t1174 = v1072;
    }
    uint64_t v1175 = t1174;
    uint64_t t1191;
    if (v1141) {
        uint64_t v1176 = ((uint64_t)in_b[UINT64_C(11)]);
        int v1177 = ((v1140 == UINT64_C(0)) && (UINT64_C(11) == v1089));
        int v1178 = (v1177 && (v1176 == UINT64_C(0)));
        int v1179 = ((v1177 && ((v1176 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(12) < ((uint64_t)((uint64_t)in_b_len))));
        int v1180 = (((v1177 && (v1176 != UINT64_C(0))) && (v1176 < UINT64_C(64))) && (((uint64_t)((UINT64_C(11) + v1176) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1183 = ((v1140 == UINT64_C(0)) && (UINT64_C(11) != v1089));
        if (t1183) {
                uint64_t v1181 = v1176;
            int t1182 = (!(((((v1181 | UINT64_C(32)) >= UINT64_C(97)) && ((v1181 | UINT64_C(32)) <= UINT64_C(122))) || ((v1181 >= UINT64_C(48)) && (v1181 <= UINT64_C(57)))) || (v1181 == UINT64_C(45))));
            if (!t1182) {
                t1182 = ((v1176 == UINT64_C(45)) && ((UINT64_C(11) == ((v1123 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(12) == v1089)));
            }
            t1183 = t1182;
        }
        int v1184 = t1183;
        uint64_t v1185 = (v1178 ? UINT64_C(12) : (v1179 ? UINT64_C(13) : v1055));
        uint64_t v1186 = (v1179 ? (((((uint64_t)(v1176 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(12)]))) : v1106);
        uint64_t v1187 = (v1180 ? ((v1072 + UINT64_C(1)) & UINT64_C(255)) : v1072);
        uint64_t v1188 = (v1180 ? UINT64_C(11) : v1123);
        uint64_t v1189 = (v1180 ? ((uint64_t)((UINT64_C(12) + v1176) & UINT64_C(255))) : v1089);
        uint64_t v1190 = ((v1178 || v1179) ? UINT64_C(1) : ((v1184 || (v1177 && (!v1180))) ? UINT64_C(2) : v1140));
        t1191 = v1189;
    } else {
        t1191 = v1089;
    }
    uint64_t v1192 = t1191;
    uint64_t t1208;
    if (v1141) {
        uint64_t v1193 = ((uint64_t)in_b[UINT64_C(11)]);
        int v1194 = ((v1140 == UINT64_C(0)) && (UINT64_C(11) == v1089));
        int v1195 = (v1194 && (v1193 == UINT64_C(0)));
        int v1196 = ((v1194 && ((v1193 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(12) < ((uint64_t)((uint64_t)in_b_len))));
        int v1197 = (((v1194 && (v1193 != UINT64_C(0))) && (v1193 < UINT64_C(64))) && (((uint64_t)((UINT64_C(11) + v1193) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1200 = ((v1140 == UINT64_C(0)) && (UINT64_C(11) != v1089));
        if (t1200) {
                uint64_t v1198 = v1193;
            int t1199 = (!(((((v1198 | UINT64_C(32)) >= UINT64_C(97)) && ((v1198 | UINT64_C(32)) <= UINT64_C(122))) || ((v1198 >= UINT64_C(48)) && (v1198 <= UINT64_C(57)))) || (v1198 == UINT64_C(45))));
            if (!t1199) {
                t1199 = ((v1193 == UINT64_C(45)) && ((UINT64_C(11) == ((v1123 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(12) == v1089)));
            }
            t1200 = t1199;
        }
        int v1201 = t1200;
        uint64_t v1202 = (v1195 ? UINT64_C(12) : (v1196 ? UINT64_C(13) : v1055));
        uint64_t v1203 = (v1196 ? (((((uint64_t)(v1193 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(12)]))) : v1106);
        uint64_t v1204 = (v1197 ? ((v1072 + UINT64_C(1)) & UINT64_C(255)) : v1072);
        uint64_t v1205 = (v1197 ? UINT64_C(11) : v1123);
        uint64_t v1206 = (v1197 ? ((uint64_t)((UINT64_C(12) + v1193) & UINT64_C(255))) : v1089);
        uint64_t v1207 = ((v1195 || v1196) ? UINT64_C(1) : ((v1201 || (v1194 && (!v1197))) ? UINT64_C(2) : v1140));
        t1208 = v1203;
    } else {
        t1208 = v1106;
    }
    uint64_t v1209 = t1208;
    uint64_t t1225;
    if (v1141) {
        uint64_t v1210 = ((uint64_t)in_b[UINT64_C(11)]);
        int v1211 = ((v1140 == UINT64_C(0)) && (UINT64_C(11) == v1089));
        int v1212 = (v1211 && (v1210 == UINT64_C(0)));
        int v1213 = ((v1211 && ((v1210 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(12) < ((uint64_t)((uint64_t)in_b_len))));
        int v1214 = (((v1211 && (v1210 != UINT64_C(0))) && (v1210 < UINT64_C(64))) && (((uint64_t)((UINT64_C(11) + v1210) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1217 = ((v1140 == UINT64_C(0)) && (UINT64_C(11) != v1089));
        if (t1217) {
                uint64_t v1215 = v1210;
            int t1216 = (!(((((v1215 | UINT64_C(32)) >= UINT64_C(97)) && ((v1215 | UINT64_C(32)) <= UINT64_C(122))) || ((v1215 >= UINT64_C(48)) && (v1215 <= UINT64_C(57)))) || (v1215 == UINT64_C(45))));
            if (!t1216) {
                t1216 = ((v1210 == UINT64_C(45)) && ((UINT64_C(11) == ((v1123 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(12) == v1089)));
            }
            t1217 = t1216;
        }
        int v1218 = t1217;
        uint64_t v1219 = (v1212 ? UINT64_C(12) : (v1213 ? UINT64_C(13) : v1055));
        uint64_t v1220 = (v1213 ? (((((uint64_t)(v1210 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(12)]))) : v1106);
        uint64_t v1221 = (v1214 ? ((v1072 + UINT64_C(1)) & UINT64_C(255)) : v1072);
        uint64_t v1222 = (v1214 ? UINT64_C(11) : v1123);
        uint64_t v1223 = (v1214 ? ((uint64_t)((UINT64_C(12) + v1210) & UINT64_C(255))) : v1089);
        uint64_t v1224 = ((v1212 || v1213) ? UINT64_C(1) : ((v1218 || (v1211 && (!v1214))) ? UINT64_C(2) : v1140));
        t1225 = v1222;
    } else {
        t1225 = v1123;
    }
    uint64_t v1226 = t1225;
    uint64_t t1242;
    if (v1141) {
        uint64_t v1227 = ((uint64_t)in_b[UINT64_C(11)]);
        int v1228 = ((v1140 == UINT64_C(0)) && (UINT64_C(11) == v1089));
        int v1229 = (v1228 && (v1227 == UINT64_C(0)));
        int v1230 = ((v1228 && ((v1227 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(12) < ((uint64_t)((uint64_t)in_b_len))));
        int v1231 = (((v1228 && (v1227 != UINT64_C(0))) && (v1227 < UINT64_C(64))) && (((uint64_t)((UINT64_C(11) + v1227) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1234 = ((v1140 == UINT64_C(0)) && (UINT64_C(11) != v1089));
        if (t1234) {
                uint64_t v1232 = v1227;
            int t1233 = (!(((((v1232 | UINT64_C(32)) >= UINT64_C(97)) && ((v1232 | UINT64_C(32)) <= UINT64_C(122))) || ((v1232 >= UINT64_C(48)) && (v1232 <= UINT64_C(57)))) || (v1232 == UINT64_C(45))));
            if (!t1233) {
                t1233 = ((v1227 == UINT64_C(45)) && ((UINT64_C(11) == ((v1123 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(12) == v1089)));
            }
            t1234 = t1233;
        }
        int v1235 = t1234;
        uint64_t v1236 = (v1229 ? UINT64_C(12) : (v1230 ? UINT64_C(13) : v1055));
        uint64_t v1237 = (v1230 ? (((((uint64_t)(v1227 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(12)]))) : v1106);
        uint64_t v1238 = (v1231 ? ((v1072 + UINT64_C(1)) & UINT64_C(255)) : v1072);
        uint64_t v1239 = (v1231 ? UINT64_C(11) : v1123);
        uint64_t v1240 = (v1231 ? ((uint64_t)((UINT64_C(12) + v1227) & UINT64_C(255))) : v1089);
        uint64_t v1241 = ((v1229 || v1230) ? UINT64_C(1) : ((v1235 || (v1228 && (!v1231))) ? UINT64_C(2) : v1140));
        t1242 = v1241;
    } else {
        t1242 = v1140;
    }
    uint64_t v1243 = t1242;
    int v1244 = (UINT64_C(12) < v7);
    uint64_t t1260;
    if (v1244) {
        uint64_t v1245 = ((uint64_t)in_b[UINT64_C(12)]);
        int v1246 = ((v1243 == UINT64_C(0)) && (UINT64_C(12) == v1192));
        int v1247 = (v1246 && (v1245 == UINT64_C(0)));
        int v1248 = ((v1246 && ((v1245 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(13) < ((uint64_t)((uint64_t)in_b_len))));
        int v1249 = (((v1246 && (v1245 != UINT64_C(0))) && (v1245 < UINT64_C(64))) && (((uint64_t)((UINT64_C(12) + v1245) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1252 = ((v1243 == UINT64_C(0)) && (UINT64_C(12) != v1192));
        if (t1252) {
                uint64_t v1250 = v1245;
            int t1251 = (!(((((v1250 | UINT64_C(32)) >= UINT64_C(97)) && ((v1250 | UINT64_C(32)) <= UINT64_C(122))) || ((v1250 >= UINT64_C(48)) && (v1250 <= UINT64_C(57)))) || (v1250 == UINT64_C(45))));
            if (!t1251) {
                t1251 = ((v1245 == UINT64_C(45)) && ((UINT64_C(12) == ((v1226 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(13) == v1192)));
            }
            t1252 = t1251;
        }
        int v1253 = t1252;
        uint64_t v1254 = (v1247 ? UINT64_C(13) : (v1248 ? UINT64_C(14) : v1158));
        uint64_t v1255 = (v1248 ? (((((uint64_t)(v1245 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(13)]))) : v1209);
        uint64_t v1256 = (v1249 ? ((v1175 + UINT64_C(1)) & UINT64_C(255)) : v1175);
        uint64_t v1257 = (v1249 ? UINT64_C(12) : v1226);
        uint64_t v1258 = (v1249 ? ((uint64_t)((UINT64_C(13) + v1245) & UINT64_C(255))) : v1192);
        uint64_t v1259 = ((v1247 || v1248) ? UINT64_C(1) : ((v1253 || (v1246 && (!v1249))) ? UINT64_C(2) : v1243));
        t1260 = v1254;
    } else {
        t1260 = v1158;
    }
    uint64_t v1261 = t1260;
    uint64_t t1277;
    if (v1244) {
        uint64_t v1262 = ((uint64_t)in_b[UINT64_C(12)]);
        int v1263 = ((v1243 == UINT64_C(0)) && (UINT64_C(12) == v1192));
        int v1264 = (v1263 && (v1262 == UINT64_C(0)));
        int v1265 = ((v1263 && ((v1262 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(13) < ((uint64_t)((uint64_t)in_b_len))));
        int v1266 = (((v1263 && (v1262 != UINT64_C(0))) && (v1262 < UINT64_C(64))) && (((uint64_t)((UINT64_C(12) + v1262) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1269 = ((v1243 == UINT64_C(0)) && (UINT64_C(12) != v1192));
        if (t1269) {
                uint64_t v1267 = v1262;
            int t1268 = (!(((((v1267 | UINT64_C(32)) >= UINT64_C(97)) && ((v1267 | UINT64_C(32)) <= UINT64_C(122))) || ((v1267 >= UINT64_C(48)) && (v1267 <= UINT64_C(57)))) || (v1267 == UINT64_C(45))));
            if (!t1268) {
                t1268 = ((v1262 == UINT64_C(45)) && ((UINT64_C(12) == ((v1226 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(13) == v1192)));
            }
            t1269 = t1268;
        }
        int v1270 = t1269;
        uint64_t v1271 = (v1264 ? UINT64_C(13) : (v1265 ? UINT64_C(14) : v1158));
        uint64_t v1272 = (v1265 ? (((((uint64_t)(v1262 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(13)]))) : v1209);
        uint64_t v1273 = (v1266 ? ((v1175 + UINT64_C(1)) & UINT64_C(255)) : v1175);
        uint64_t v1274 = (v1266 ? UINT64_C(12) : v1226);
        uint64_t v1275 = (v1266 ? ((uint64_t)((UINT64_C(13) + v1262) & UINT64_C(255))) : v1192);
        uint64_t v1276 = ((v1264 || v1265) ? UINT64_C(1) : ((v1270 || (v1263 && (!v1266))) ? UINT64_C(2) : v1243));
        t1277 = v1273;
    } else {
        t1277 = v1175;
    }
    uint64_t v1278 = t1277;
    uint64_t t1294;
    if (v1244) {
        uint64_t v1279 = ((uint64_t)in_b[UINT64_C(12)]);
        int v1280 = ((v1243 == UINT64_C(0)) && (UINT64_C(12) == v1192));
        int v1281 = (v1280 && (v1279 == UINT64_C(0)));
        int v1282 = ((v1280 && ((v1279 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(13) < ((uint64_t)((uint64_t)in_b_len))));
        int v1283 = (((v1280 && (v1279 != UINT64_C(0))) && (v1279 < UINT64_C(64))) && (((uint64_t)((UINT64_C(12) + v1279) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1286 = ((v1243 == UINT64_C(0)) && (UINT64_C(12) != v1192));
        if (t1286) {
                uint64_t v1284 = v1279;
            int t1285 = (!(((((v1284 | UINT64_C(32)) >= UINT64_C(97)) && ((v1284 | UINT64_C(32)) <= UINT64_C(122))) || ((v1284 >= UINT64_C(48)) && (v1284 <= UINT64_C(57)))) || (v1284 == UINT64_C(45))));
            if (!t1285) {
                t1285 = ((v1279 == UINT64_C(45)) && ((UINT64_C(12) == ((v1226 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(13) == v1192)));
            }
            t1286 = t1285;
        }
        int v1287 = t1286;
        uint64_t v1288 = (v1281 ? UINT64_C(13) : (v1282 ? UINT64_C(14) : v1158));
        uint64_t v1289 = (v1282 ? (((((uint64_t)(v1279 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(13)]))) : v1209);
        uint64_t v1290 = (v1283 ? ((v1175 + UINT64_C(1)) & UINT64_C(255)) : v1175);
        uint64_t v1291 = (v1283 ? UINT64_C(12) : v1226);
        uint64_t v1292 = (v1283 ? ((uint64_t)((UINT64_C(13) + v1279) & UINT64_C(255))) : v1192);
        uint64_t v1293 = ((v1281 || v1282) ? UINT64_C(1) : ((v1287 || (v1280 && (!v1283))) ? UINT64_C(2) : v1243));
        t1294 = v1292;
    } else {
        t1294 = v1192;
    }
    uint64_t v1295 = t1294;
    uint64_t t1311;
    if (v1244) {
        uint64_t v1296 = ((uint64_t)in_b[UINT64_C(12)]);
        int v1297 = ((v1243 == UINT64_C(0)) && (UINT64_C(12) == v1192));
        int v1298 = (v1297 && (v1296 == UINT64_C(0)));
        int v1299 = ((v1297 && ((v1296 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(13) < ((uint64_t)((uint64_t)in_b_len))));
        int v1300 = (((v1297 && (v1296 != UINT64_C(0))) && (v1296 < UINT64_C(64))) && (((uint64_t)((UINT64_C(12) + v1296) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1303 = ((v1243 == UINT64_C(0)) && (UINT64_C(12) != v1192));
        if (t1303) {
                uint64_t v1301 = v1296;
            int t1302 = (!(((((v1301 | UINT64_C(32)) >= UINT64_C(97)) && ((v1301 | UINT64_C(32)) <= UINT64_C(122))) || ((v1301 >= UINT64_C(48)) && (v1301 <= UINT64_C(57)))) || (v1301 == UINT64_C(45))));
            if (!t1302) {
                t1302 = ((v1296 == UINT64_C(45)) && ((UINT64_C(12) == ((v1226 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(13) == v1192)));
            }
            t1303 = t1302;
        }
        int v1304 = t1303;
        uint64_t v1305 = (v1298 ? UINT64_C(13) : (v1299 ? UINT64_C(14) : v1158));
        uint64_t v1306 = (v1299 ? (((((uint64_t)(v1296 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(13)]))) : v1209);
        uint64_t v1307 = (v1300 ? ((v1175 + UINT64_C(1)) & UINT64_C(255)) : v1175);
        uint64_t v1308 = (v1300 ? UINT64_C(12) : v1226);
        uint64_t v1309 = (v1300 ? ((uint64_t)((UINT64_C(13) + v1296) & UINT64_C(255))) : v1192);
        uint64_t v1310 = ((v1298 || v1299) ? UINT64_C(1) : ((v1304 || (v1297 && (!v1300))) ? UINT64_C(2) : v1243));
        t1311 = v1306;
    } else {
        t1311 = v1209;
    }
    uint64_t v1312 = t1311;
    uint64_t t1328;
    if (v1244) {
        uint64_t v1313 = ((uint64_t)in_b[UINT64_C(12)]);
        int v1314 = ((v1243 == UINT64_C(0)) && (UINT64_C(12) == v1192));
        int v1315 = (v1314 && (v1313 == UINT64_C(0)));
        int v1316 = ((v1314 && ((v1313 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(13) < ((uint64_t)((uint64_t)in_b_len))));
        int v1317 = (((v1314 && (v1313 != UINT64_C(0))) && (v1313 < UINT64_C(64))) && (((uint64_t)((UINT64_C(12) + v1313) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1320 = ((v1243 == UINT64_C(0)) && (UINT64_C(12) != v1192));
        if (t1320) {
                uint64_t v1318 = v1313;
            int t1319 = (!(((((v1318 | UINT64_C(32)) >= UINT64_C(97)) && ((v1318 | UINT64_C(32)) <= UINT64_C(122))) || ((v1318 >= UINT64_C(48)) && (v1318 <= UINT64_C(57)))) || (v1318 == UINT64_C(45))));
            if (!t1319) {
                t1319 = ((v1313 == UINT64_C(45)) && ((UINT64_C(12) == ((v1226 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(13) == v1192)));
            }
            t1320 = t1319;
        }
        int v1321 = t1320;
        uint64_t v1322 = (v1315 ? UINT64_C(13) : (v1316 ? UINT64_C(14) : v1158));
        uint64_t v1323 = (v1316 ? (((((uint64_t)(v1313 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(13)]))) : v1209);
        uint64_t v1324 = (v1317 ? ((v1175 + UINT64_C(1)) & UINT64_C(255)) : v1175);
        uint64_t v1325 = (v1317 ? UINT64_C(12) : v1226);
        uint64_t v1326 = (v1317 ? ((uint64_t)((UINT64_C(13) + v1313) & UINT64_C(255))) : v1192);
        uint64_t v1327 = ((v1315 || v1316) ? UINT64_C(1) : ((v1321 || (v1314 && (!v1317))) ? UINT64_C(2) : v1243));
        t1328 = v1325;
    } else {
        t1328 = v1226;
    }
    uint64_t v1329 = t1328;
    uint64_t t1345;
    if (v1244) {
        uint64_t v1330 = ((uint64_t)in_b[UINT64_C(12)]);
        int v1331 = ((v1243 == UINT64_C(0)) && (UINT64_C(12) == v1192));
        int v1332 = (v1331 && (v1330 == UINT64_C(0)));
        int v1333 = ((v1331 && ((v1330 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(13) < ((uint64_t)((uint64_t)in_b_len))));
        int v1334 = (((v1331 && (v1330 != UINT64_C(0))) && (v1330 < UINT64_C(64))) && (((uint64_t)((UINT64_C(12) + v1330) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1337 = ((v1243 == UINT64_C(0)) && (UINT64_C(12) != v1192));
        if (t1337) {
                uint64_t v1335 = v1330;
            int t1336 = (!(((((v1335 | UINT64_C(32)) >= UINT64_C(97)) && ((v1335 | UINT64_C(32)) <= UINT64_C(122))) || ((v1335 >= UINT64_C(48)) && (v1335 <= UINT64_C(57)))) || (v1335 == UINT64_C(45))));
            if (!t1336) {
                t1336 = ((v1330 == UINT64_C(45)) && ((UINT64_C(12) == ((v1226 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(13) == v1192)));
            }
            t1337 = t1336;
        }
        int v1338 = t1337;
        uint64_t v1339 = (v1332 ? UINT64_C(13) : (v1333 ? UINT64_C(14) : v1158));
        uint64_t v1340 = (v1333 ? (((((uint64_t)(v1330 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(13)]))) : v1209);
        uint64_t v1341 = (v1334 ? ((v1175 + UINT64_C(1)) & UINT64_C(255)) : v1175);
        uint64_t v1342 = (v1334 ? UINT64_C(12) : v1226);
        uint64_t v1343 = (v1334 ? ((uint64_t)((UINT64_C(13) + v1330) & UINT64_C(255))) : v1192);
        uint64_t v1344 = ((v1332 || v1333) ? UINT64_C(1) : ((v1338 || (v1331 && (!v1334))) ? UINT64_C(2) : v1243));
        t1345 = v1344;
    } else {
        t1345 = v1243;
    }
    uint64_t v1346 = t1345;
    int v1347 = (UINT64_C(13) < v7);
    uint64_t t1363;
    if (v1347) {
        uint64_t v1348 = ((uint64_t)in_b[UINT64_C(13)]);
        int v1349 = ((v1346 == UINT64_C(0)) && (UINT64_C(13) == v1295));
        int v1350 = (v1349 && (v1348 == UINT64_C(0)));
        int v1351 = ((v1349 && ((v1348 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(14) < ((uint64_t)((uint64_t)in_b_len))));
        int v1352 = (((v1349 && (v1348 != UINT64_C(0))) && (v1348 < UINT64_C(64))) && (((uint64_t)((UINT64_C(13) + v1348) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1355 = ((v1346 == UINT64_C(0)) && (UINT64_C(13) != v1295));
        if (t1355) {
                uint64_t v1353 = v1348;
            int t1354 = (!(((((v1353 | UINT64_C(32)) >= UINT64_C(97)) && ((v1353 | UINT64_C(32)) <= UINT64_C(122))) || ((v1353 >= UINT64_C(48)) && (v1353 <= UINT64_C(57)))) || (v1353 == UINT64_C(45))));
            if (!t1354) {
                t1354 = ((v1348 == UINT64_C(45)) && ((UINT64_C(13) == ((v1329 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(14) == v1295)));
            }
            t1355 = t1354;
        }
        int v1356 = t1355;
        uint64_t v1357 = (v1350 ? UINT64_C(14) : (v1351 ? UINT64_C(15) : v1261));
        uint64_t v1358 = (v1351 ? (((((uint64_t)(v1348 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(14)]))) : v1312);
        uint64_t v1359 = (v1352 ? ((v1278 + UINT64_C(1)) & UINT64_C(255)) : v1278);
        uint64_t v1360 = (v1352 ? UINT64_C(13) : v1329);
        uint64_t v1361 = (v1352 ? ((uint64_t)((UINT64_C(14) + v1348) & UINT64_C(255))) : v1295);
        uint64_t v1362 = ((v1350 || v1351) ? UINT64_C(1) : ((v1356 || (v1349 && (!v1352))) ? UINT64_C(2) : v1346));
        t1363 = v1357;
    } else {
        t1363 = v1261;
    }
    uint64_t v1364 = t1363;
    uint64_t t1380;
    if (v1347) {
        uint64_t v1365 = ((uint64_t)in_b[UINT64_C(13)]);
        int v1366 = ((v1346 == UINT64_C(0)) && (UINT64_C(13) == v1295));
        int v1367 = (v1366 && (v1365 == UINT64_C(0)));
        int v1368 = ((v1366 && ((v1365 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(14) < ((uint64_t)((uint64_t)in_b_len))));
        int v1369 = (((v1366 && (v1365 != UINT64_C(0))) && (v1365 < UINT64_C(64))) && (((uint64_t)((UINT64_C(13) + v1365) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1372 = ((v1346 == UINT64_C(0)) && (UINT64_C(13) != v1295));
        if (t1372) {
                uint64_t v1370 = v1365;
            int t1371 = (!(((((v1370 | UINT64_C(32)) >= UINT64_C(97)) && ((v1370 | UINT64_C(32)) <= UINT64_C(122))) || ((v1370 >= UINT64_C(48)) && (v1370 <= UINT64_C(57)))) || (v1370 == UINT64_C(45))));
            if (!t1371) {
                t1371 = ((v1365 == UINT64_C(45)) && ((UINT64_C(13) == ((v1329 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(14) == v1295)));
            }
            t1372 = t1371;
        }
        int v1373 = t1372;
        uint64_t v1374 = (v1367 ? UINT64_C(14) : (v1368 ? UINT64_C(15) : v1261));
        uint64_t v1375 = (v1368 ? (((((uint64_t)(v1365 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(14)]))) : v1312);
        uint64_t v1376 = (v1369 ? ((v1278 + UINT64_C(1)) & UINT64_C(255)) : v1278);
        uint64_t v1377 = (v1369 ? UINT64_C(13) : v1329);
        uint64_t v1378 = (v1369 ? ((uint64_t)((UINT64_C(14) + v1365) & UINT64_C(255))) : v1295);
        uint64_t v1379 = ((v1367 || v1368) ? UINT64_C(1) : ((v1373 || (v1366 && (!v1369))) ? UINT64_C(2) : v1346));
        t1380 = v1376;
    } else {
        t1380 = v1278;
    }
    uint64_t v1381 = t1380;
    uint64_t t1397;
    if (v1347) {
        uint64_t v1382 = ((uint64_t)in_b[UINT64_C(13)]);
        int v1383 = ((v1346 == UINT64_C(0)) && (UINT64_C(13) == v1295));
        int v1384 = (v1383 && (v1382 == UINT64_C(0)));
        int v1385 = ((v1383 && ((v1382 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(14) < ((uint64_t)((uint64_t)in_b_len))));
        int v1386 = (((v1383 && (v1382 != UINT64_C(0))) && (v1382 < UINT64_C(64))) && (((uint64_t)((UINT64_C(13) + v1382) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1389 = ((v1346 == UINT64_C(0)) && (UINT64_C(13) != v1295));
        if (t1389) {
                uint64_t v1387 = v1382;
            int t1388 = (!(((((v1387 | UINT64_C(32)) >= UINT64_C(97)) && ((v1387 | UINT64_C(32)) <= UINT64_C(122))) || ((v1387 >= UINT64_C(48)) && (v1387 <= UINT64_C(57)))) || (v1387 == UINT64_C(45))));
            if (!t1388) {
                t1388 = ((v1382 == UINT64_C(45)) && ((UINT64_C(13) == ((v1329 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(14) == v1295)));
            }
            t1389 = t1388;
        }
        int v1390 = t1389;
        uint64_t v1391 = (v1384 ? UINT64_C(14) : (v1385 ? UINT64_C(15) : v1261));
        uint64_t v1392 = (v1385 ? (((((uint64_t)(v1382 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(14)]))) : v1312);
        uint64_t v1393 = (v1386 ? ((v1278 + UINT64_C(1)) & UINT64_C(255)) : v1278);
        uint64_t v1394 = (v1386 ? UINT64_C(13) : v1329);
        uint64_t v1395 = (v1386 ? ((uint64_t)((UINT64_C(14) + v1382) & UINT64_C(255))) : v1295);
        uint64_t v1396 = ((v1384 || v1385) ? UINT64_C(1) : ((v1390 || (v1383 && (!v1386))) ? UINT64_C(2) : v1346));
        t1397 = v1395;
    } else {
        t1397 = v1295;
    }
    uint64_t v1398 = t1397;
    uint64_t t1414;
    if (v1347) {
        uint64_t v1399 = ((uint64_t)in_b[UINT64_C(13)]);
        int v1400 = ((v1346 == UINT64_C(0)) && (UINT64_C(13) == v1295));
        int v1401 = (v1400 && (v1399 == UINT64_C(0)));
        int v1402 = ((v1400 && ((v1399 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(14) < ((uint64_t)((uint64_t)in_b_len))));
        int v1403 = (((v1400 && (v1399 != UINT64_C(0))) && (v1399 < UINT64_C(64))) && (((uint64_t)((UINT64_C(13) + v1399) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1406 = ((v1346 == UINT64_C(0)) && (UINT64_C(13) != v1295));
        if (t1406) {
                uint64_t v1404 = v1399;
            int t1405 = (!(((((v1404 | UINT64_C(32)) >= UINT64_C(97)) && ((v1404 | UINT64_C(32)) <= UINT64_C(122))) || ((v1404 >= UINT64_C(48)) && (v1404 <= UINT64_C(57)))) || (v1404 == UINT64_C(45))));
            if (!t1405) {
                t1405 = ((v1399 == UINT64_C(45)) && ((UINT64_C(13) == ((v1329 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(14) == v1295)));
            }
            t1406 = t1405;
        }
        int v1407 = t1406;
        uint64_t v1408 = (v1401 ? UINT64_C(14) : (v1402 ? UINT64_C(15) : v1261));
        uint64_t v1409 = (v1402 ? (((((uint64_t)(v1399 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(14)]))) : v1312);
        uint64_t v1410 = (v1403 ? ((v1278 + UINT64_C(1)) & UINT64_C(255)) : v1278);
        uint64_t v1411 = (v1403 ? UINT64_C(13) : v1329);
        uint64_t v1412 = (v1403 ? ((uint64_t)((UINT64_C(14) + v1399) & UINT64_C(255))) : v1295);
        uint64_t v1413 = ((v1401 || v1402) ? UINT64_C(1) : ((v1407 || (v1400 && (!v1403))) ? UINT64_C(2) : v1346));
        t1414 = v1409;
    } else {
        t1414 = v1312;
    }
    uint64_t v1415 = t1414;
    uint64_t t1431;
    if (v1347) {
        uint64_t v1416 = ((uint64_t)in_b[UINT64_C(13)]);
        int v1417 = ((v1346 == UINT64_C(0)) && (UINT64_C(13) == v1295));
        int v1418 = (v1417 && (v1416 == UINT64_C(0)));
        int v1419 = ((v1417 && ((v1416 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(14) < ((uint64_t)((uint64_t)in_b_len))));
        int v1420 = (((v1417 && (v1416 != UINT64_C(0))) && (v1416 < UINT64_C(64))) && (((uint64_t)((UINT64_C(13) + v1416) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1423 = ((v1346 == UINT64_C(0)) && (UINT64_C(13) != v1295));
        if (t1423) {
                uint64_t v1421 = v1416;
            int t1422 = (!(((((v1421 | UINT64_C(32)) >= UINT64_C(97)) && ((v1421 | UINT64_C(32)) <= UINT64_C(122))) || ((v1421 >= UINT64_C(48)) && (v1421 <= UINT64_C(57)))) || (v1421 == UINT64_C(45))));
            if (!t1422) {
                t1422 = ((v1416 == UINT64_C(45)) && ((UINT64_C(13) == ((v1329 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(14) == v1295)));
            }
            t1423 = t1422;
        }
        int v1424 = t1423;
        uint64_t v1425 = (v1418 ? UINT64_C(14) : (v1419 ? UINT64_C(15) : v1261));
        uint64_t v1426 = (v1419 ? (((((uint64_t)(v1416 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(14)]))) : v1312);
        uint64_t v1427 = (v1420 ? ((v1278 + UINT64_C(1)) & UINT64_C(255)) : v1278);
        uint64_t v1428 = (v1420 ? UINT64_C(13) : v1329);
        uint64_t v1429 = (v1420 ? ((uint64_t)((UINT64_C(14) + v1416) & UINT64_C(255))) : v1295);
        uint64_t v1430 = ((v1418 || v1419) ? UINT64_C(1) : ((v1424 || (v1417 && (!v1420))) ? UINT64_C(2) : v1346));
        t1431 = v1428;
    } else {
        t1431 = v1329;
    }
    uint64_t v1432 = t1431;
    uint64_t t1448;
    if (v1347) {
        uint64_t v1433 = ((uint64_t)in_b[UINT64_C(13)]);
        int v1434 = ((v1346 == UINT64_C(0)) && (UINT64_C(13) == v1295));
        int v1435 = (v1434 && (v1433 == UINT64_C(0)));
        int v1436 = ((v1434 && ((v1433 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(14) < ((uint64_t)((uint64_t)in_b_len))));
        int v1437 = (((v1434 && (v1433 != UINT64_C(0))) && (v1433 < UINT64_C(64))) && (((uint64_t)((UINT64_C(13) + v1433) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1440 = ((v1346 == UINT64_C(0)) && (UINT64_C(13) != v1295));
        if (t1440) {
                uint64_t v1438 = v1433;
            int t1439 = (!(((((v1438 | UINT64_C(32)) >= UINT64_C(97)) && ((v1438 | UINT64_C(32)) <= UINT64_C(122))) || ((v1438 >= UINT64_C(48)) && (v1438 <= UINT64_C(57)))) || (v1438 == UINT64_C(45))));
            if (!t1439) {
                t1439 = ((v1433 == UINT64_C(45)) && ((UINT64_C(13) == ((v1329 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(14) == v1295)));
            }
            t1440 = t1439;
        }
        int v1441 = t1440;
        uint64_t v1442 = (v1435 ? UINT64_C(14) : (v1436 ? UINT64_C(15) : v1261));
        uint64_t v1443 = (v1436 ? (((((uint64_t)(v1433 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(14)]))) : v1312);
        uint64_t v1444 = (v1437 ? ((v1278 + UINT64_C(1)) & UINT64_C(255)) : v1278);
        uint64_t v1445 = (v1437 ? UINT64_C(13) : v1329);
        uint64_t v1446 = (v1437 ? ((uint64_t)((UINT64_C(14) + v1433) & UINT64_C(255))) : v1295);
        uint64_t v1447 = ((v1435 || v1436) ? UINT64_C(1) : ((v1441 || (v1434 && (!v1437))) ? UINT64_C(2) : v1346));
        t1448 = v1447;
    } else {
        t1448 = v1346;
    }
    uint64_t v1449 = t1448;
    int v1450 = (UINT64_C(14) < v7);
    uint64_t t1466;
    if (v1450) {
        uint64_t v1451 = ((uint64_t)in_b[UINT64_C(14)]);
        int v1452 = ((v1449 == UINT64_C(0)) && (UINT64_C(14) == v1398));
        int v1453 = (v1452 && (v1451 == UINT64_C(0)));
        int v1454 = ((v1452 && ((v1451 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(15) < ((uint64_t)((uint64_t)in_b_len))));
        int v1455 = (((v1452 && (v1451 != UINT64_C(0))) && (v1451 < UINT64_C(64))) && (((uint64_t)((UINT64_C(14) + v1451) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1458 = ((v1449 == UINT64_C(0)) && (UINT64_C(14) != v1398));
        if (t1458) {
                uint64_t v1456 = v1451;
            int t1457 = (!(((((v1456 | UINT64_C(32)) >= UINT64_C(97)) && ((v1456 | UINT64_C(32)) <= UINT64_C(122))) || ((v1456 >= UINT64_C(48)) && (v1456 <= UINT64_C(57)))) || (v1456 == UINT64_C(45))));
            if (!t1457) {
                t1457 = ((v1451 == UINT64_C(45)) && ((UINT64_C(14) == ((v1432 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(15) == v1398)));
            }
            t1458 = t1457;
        }
        int v1459 = t1458;
        uint64_t v1460 = (v1453 ? UINT64_C(15) : (v1454 ? UINT64_C(16) : v1364));
        uint64_t v1461 = (v1454 ? (((((uint64_t)(v1451 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(15)]))) : v1415);
        uint64_t v1462 = (v1455 ? ((v1381 + UINT64_C(1)) & UINT64_C(255)) : v1381);
        uint64_t v1463 = (v1455 ? UINT64_C(14) : v1432);
        uint64_t v1464 = (v1455 ? ((uint64_t)((UINT64_C(15) + v1451) & UINT64_C(255))) : v1398);
        uint64_t v1465 = ((v1453 || v1454) ? UINT64_C(1) : ((v1459 || (v1452 && (!v1455))) ? UINT64_C(2) : v1449));
        t1466 = v1460;
    } else {
        t1466 = v1364;
    }
    uint64_t v1467 = t1466;
    uint64_t t1483;
    if (v1450) {
        uint64_t v1468 = ((uint64_t)in_b[UINT64_C(14)]);
        int v1469 = ((v1449 == UINT64_C(0)) && (UINT64_C(14) == v1398));
        int v1470 = (v1469 && (v1468 == UINT64_C(0)));
        int v1471 = ((v1469 && ((v1468 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(15) < ((uint64_t)((uint64_t)in_b_len))));
        int v1472 = (((v1469 && (v1468 != UINT64_C(0))) && (v1468 < UINT64_C(64))) && (((uint64_t)((UINT64_C(14) + v1468) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1475 = ((v1449 == UINT64_C(0)) && (UINT64_C(14) != v1398));
        if (t1475) {
                uint64_t v1473 = v1468;
            int t1474 = (!(((((v1473 | UINT64_C(32)) >= UINT64_C(97)) && ((v1473 | UINT64_C(32)) <= UINT64_C(122))) || ((v1473 >= UINT64_C(48)) && (v1473 <= UINT64_C(57)))) || (v1473 == UINT64_C(45))));
            if (!t1474) {
                t1474 = ((v1468 == UINT64_C(45)) && ((UINT64_C(14) == ((v1432 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(15) == v1398)));
            }
            t1475 = t1474;
        }
        int v1476 = t1475;
        uint64_t v1477 = (v1470 ? UINT64_C(15) : (v1471 ? UINT64_C(16) : v1364));
        uint64_t v1478 = (v1471 ? (((((uint64_t)(v1468 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(15)]))) : v1415);
        uint64_t v1479 = (v1472 ? ((v1381 + UINT64_C(1)) & UINT64_C(255)) : v1381);
        uint64_t v1480 = (v1472 ? UINT64_C(14) : v1432);
        uint64_t v1481 = (v1472 ? ((uint64_t)((UINT64_C(15) + v1468) & UINT64_C(255))) : v1398);
        uint64_t v1482 = ((v1470 || v1471) ? UINT64_C(1) : ((v1476 || (v1469 && (!v1472))) ? UINT64_C(2) : v1449));
        t1483 = v1479;
    } else {
        t1483 = v1381;
    }
    uint64_t v1484 = t1483;
    uint64_t t1500;
    if (v1450) {
        uint64_t v1485 = ((uint64_t)in_b[UINT64_C(14)]);
        int v1486 = ((v1449 == UINT64_C(0)) && (UINT64_C(14) == v1398));
        int v1487 = (v1486 && (v1485 == UINT64_C(0)));
        int v1488 = ((v1486 && ((v1485 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(15) < ((uint64_t)((uint64_t)in_b_len))));
        int v1489 = (((v1486 && (v1485 != UINT64_C(0))) && (v1485 < UINT64_C(64))) && (((uint64_t)((UINT64_C(14) + v1485) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1492 = ((v1449 == UINT64_C(0)) && (UINT64_C(14) != v1398));
        if (t1492) {
                uint64_t v1490 = v1485;
            int t1491 = (!(((((v1490 | UINT64_C(32)) >= UINT64_C(97)) && ((v1490 | UINT64_C(32)) <= UINT64_C(122))) || ((v1490 >= UINT64_C(48)) && (v1490 <= UINT64_C(57)))) || (v1490 == UINT64_C(45))));
            if (!t1491) {
                t1491 = ((v1485 == UINT64_C(45)) && ((UINT64_C(14) == ((v1432 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(15) == v1398)));
            }
            t1492 = t1491;
        }
        int v1493 = t1492;
        uint64_t v1494 = (v1487 ? UINT64_C(15) : (v1488 ? UINT64_C(16) : v1364));
        uint64_t v1495 = (v1488 ? (((((uint64_t)(v1485 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(15)]))) : v1415);
        uint64_t v1496 = (v1489 ? ((v1381 + UINT64_C(1)) & UINT64_C(255)) : v1381);
        uint64_t v1497 = (v1489 ? UINT64_C(14) : v1432);
        uint64_t v1498 = (v1489 ? ((uint64_t)((UINT64_C(15) + v1485) & UINT64_C(255))) : v1398);
        uint64_t v1499 = ((v1487 || v1488) ? UINT64_C(1) : ((v1493 || (v1486 && (!v1489))) ? UINT64_C(2) : v1449));
        t1500 = v1498;
    } else {
        t1500 = v1398;
    }
    uint64_t v1501 = t1500;
    uint64_t t1517;
    if (v1450) {
        uint64_t v1502 = ((uint64_t)in_b[UINT64_C(14)]);
        int v1503 = ((v1449 == UINT64_C(0)) && (UINT64_C(14) == v1398));
        int v1504 = (v1503 && (v1502 == UINT64_C(0)));
        int v1505 = ((v1503 && ((v1502 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(15) < ((uint64_t)((uint64_t)in_b_len))));
        int v1506 = (((v1503 && (v1502 != UINT64_C(0))) && (v1502 < UINT64_C(64))) && (((uint64_t)((UINT64_C(14) + v1502) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1509 = ((v1449 == UINT64_C(0)) && (UINT64_C(14) != v1398));
        if (t1509) {
                uint64_t v1507 = v1502;
            int t1508 = (!(((((v1507 | UINT64_C(32)) >= UINT64_C(97)) && ((v1507 | UINT64_C(32)) <= UINT64_C(122))) || ((v1507 >= UINT64_C(48)) && (v1507 <= UINT64_C(57)))) || (v1507 == UINT64_C(45))));
            if (!t1508) {
                t1508 = ((v1502 == UINT64_C(45)) && ((UINT64_C(14) == ((v1432 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(15) == v1398)));
            }
            t1509 = t1508;
        }
        int v1510 = t1509;
        uint64_t v1511 = (v1504 ? UINT64_C(15) : (v1505 ? UINT64_C(16) : v1364));
        uint64_t v1512 = (v1505 ? (((((uint64_t)(v1502 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(15)]))) : v1415);
        uint64_t v1513 = (v1506 ? ((v1381 + UINT64_C(1)) & UINT64_C(255)) : v1381);
        uint64_t v1514 = (v1506 ? UINT64_C(14) : v1432);
        uint64_t v1515 = (v1506 ? ((uint64_t)((UINT64_C(15) + v1502) & UINT64_C(255))) : v1398);
        uint64_t v1516 = ((v1504 || v1505) ? UINT64_C(1) : ((v1510 || (v1503 && (!v1506))) ? UINT64_C(2) : v1449));
        t1517 = v1512;
    } else {
        t1517 = v1415;
    }
    uint64_t v1518 = t1517;
    uint64_t t1534;
    if (v1450) {
        uint64_t v1519 = ((uint64_t)in_b[UINT64_C(14)]);
        int v1520 = ((v1449 == UINT64_C(0)) && (UINT64_C(14) == v1398));
        int v1521 = (v1520 && (v1519 == UINT64_C(0)));
        int v1522 = ((v1520 && ((v1519 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(15) < ((uint64_t)((uint64_t)in_b_len))));
        int v1523 = (((v1520 && (v1519 != UINT64_C(0))) && (v1519 < UINT64_C(64))) && (((uint64_t)((UINT64_C(14) + v1519) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1526 = ((v1449 == UINT64_C(0)) && (UINT64_C(14) != v1398));
        if (t1526) {
                uint64_t v1524 = v1519;
            int t1525 = (!(((((v1524 | UINT64_C(32)) >= UINT64_C(97)) && ((v1524 | UINT64_C(32)) <= UINT64_C(122))) || ((v1524 >= UINT64_C(48)) && (v1524 <= UINT64_C(57)))) || (v1524 == UINT64_C(45))));
            if (!t1525) {
                t1525 = ((v1519 == UINT64_C(45)) && ((UINT64_C(14) == ((v1432 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(15) == v1398)));
            }
            t1526 = t1525;
        }
        int v1527 = t1526;
        uint64_t v1528 = (v1521 ? UINT64_C(15) : (v1522 ? UINT64_C(16) : v1364));
        uint64_t v1529 = (v1522 ? (((((uint64_t)(v1519 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(15)]))) : v1415);
        uint64_t v1530 = (v1523 ? ((v1381 + UINT64_C(1)) & UINT64_C(255)) : v1381);
        uint64_t v1531 = (v1523 ? UINT64_C(14) : v1432);
        uint64_t v1532 = (v1523 ? ((uint64_t)((UINT64_C(15) + v1519) & UINT64_C(255))) : v1398);
        uint64_t v1533 = ((v1521 || v1522) ? UINT64_C(1) : ((v1527 || (v1520 && (!v1523))) ? UINT64_C(2) : v1449));
        t1534 = v1531;
    } else {
        t1534 = v1432;
    }
    uint64_t v1535 = t1534;
    uint64_t t1551;
    if (v1450) {
        uint64_t v1536 = ((uint64_t)in_b[UINT64_C(14)]);
        int v1537 = ((v1449 == UINT64_C(0)) && (UINT64_C(14) == v1398));
        int v1538 = (v1537 && (v1536 == UINT64_C(0)));
        int v1539 = ((v1537 && ((v1536 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(15) < ((uint64_t)((uint64_t)in_b_len))));
        int v1540 = (((v1537 && (v1536 != UINT64_C(0))) && (v1536 < UINT64_C(64))) && (((uint64_t)((UINT64_C(14) + v1536) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1543 = ((v1449 == UINT64_C(0)) && (UINT64_C(14) != v1398));
        if (t1543) {
                uint64_t v1541 = v1536;
            int t1542 = (!(((((v1541 | UINT64_C(32)) >= UINT64_C(97)) && ((v1541 | UINT64_C(32)) <= UINT64_C(122))) || ((v1541 >= UINT64_C(48)) && (v1541 <= UINT64_C(57)))) || (v1541 == UINT64_C(45))));
            if (!t1542) {
                t1542 = ((v1536 == UINT64_C(45)) && ((UINT64_C(14) == ((v1432 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(15) == v1398)));
            }
            t1543 = t1542;
        }
        int v1544 = t1543;
        uint64_t v1545 = (v1538 ? UINT64_C(15) : (v1539 ? UINT64_C(16) : v1364));
        uint64_t v1546 = (v1539 ? (((((uint64_t)(v1536 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(15)]))) : v1415);
        uint64_t v1547 = (v1540 ? ((v1381 + UINT64_C(1)) & UINT64_C(255)) : v1381);
        uint64_t v1548 = (v1540 ? UINT64_C(14) : v1432);
        uint64_t v1549 = (v1540 ? ((uint64_t)((UINT64_C(15) + v1536) & UINT64_C(255))) : v1398);
        uint64_t v1550 = ((v1538 || v1539) ? UINT64_C(1) : ((v1544 || (v1537 && (!v1540))) ? UINT64_C(2) : v1449));
        t1551 = v1550;
    } else {
        t1551 = v1449;
    }
    uint64_t v1552 = t1551;
    int v1553 = (UINT64_C(15) < v7);
    uint64_t t1569;
    if (v1553) {
        uint64_t v1554 = ((uint64_t)in_b[UINT64_C(15)]);
        int v1555 = ((v1552 == UINT64_C(0)) && (UINT64_C(15) == v1501));
        int v1556 = (v1555 && (v1554 == UINT64_C(0)));
        int v1557 = ((v1555 && ((v1554 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(16) < ((uint64_t)((uint64_t)in_b_len))));
        int v1558 = (((v1555 && (v1554 != UINT64_C(0))) && (v1554 < UINT64_C(64))) && (((uint64_t)((UINT64_C(15) + v1554) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1561 = ((v1552 == UINT64_C(0)) && (UINT64_C(15) != v1501));
        if (t1561) {
                uint64_t v1559 = v1554;
            int t1560 = (!(((((v1559 | UINT64_C(32)) >= UINT64_C(97)) && ((v1559 | UINT64_C(32)) <= UINT64_C(122))) || ((v1559 >= UINT64_C(48)) && (v1559 <= UINT64_C(57)))) || (v1559 == UINT64_C(45))));
            if (!t1560) {
                t1560 = ((v1554 == UINT64_C(45)) && ((UINT64_C(15) == ((v1535 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(16) == v1501)));
            }
            t1561 = t1560;
        }
        int v1562 = t1561;
        uint64_t v1563 = (v1556 ? UINT64_C(16) : (v1557 ? UINT64_C(17) : v1467));
        uint64_t v1564 = (v1557 ? (((((uint64_t)(v1554 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(16)]))) : v1518);
        uint64_t v1565 = (v1558 ? ((v1484 + UINT64_C(1)) & UINT64_C(255)) : v1484);
        uint64_t v1566 = (v1558 ? UINT64_C(15) : v1535);
        uint64_t v1567 = (v1558 ? ((uint64_t)((UINT64_C(16) + v1554) & UINT64_C(255))) : v1501);
        uint64_t v1568 = ((v1556 || v1557) ? UINT64_C(1) : ((v1562 || (v1555 && (!v1558))) ? UINT64_C(2) : v1552));
        t1569 = v1563;
    } else {
        t1569 = v1467;
    }
    uint64_t v1570 = t1569;
    uint64_t t1586;
    if (v1553) {
        uint64_t v1571 = ((uint64_t)in_b[UINT64_C(15)]);
        int v1572 = ((v1552 == UINT64_C(0)) && (UINT64_C(15) == v1501));
        int v1573 = (v1572 && (v1571 == UINT64_C(0)));
        int v1574 = ((v1572 && ((v1571 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(16) < ((uint64_t)((uint64_t)in_b_len))));
        int v1575 = (((v1572 && (v1571 != UINT64_C(0))) && (v1571 < UINT64_C(64))) && (((uint64_t)((UINT64_C(15) + v1571) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1578 = ((v1552 == UINT64_C(0)) && (UINT64_C(15) != v1501));
        if (t1578) {
                uint64_t v1576 = v1571;
            int t1577 = (!(((((v1576 | UINT64_C(32)) >= UINT64_C(97)) && ((v1576 | UINT64_C(32)) <= UINT64_C(122))) || ((v1576 >= UINT64_C(48)) && (v1576 <= UINT64_C(57)))) || (v1576 == UINT64_C(45))));
            if (!t1577) {
                t1577 = ((v1571 == UINT64_C(45)) && ((UINT64_C(15) == ((v1535 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(16) == v1501)));
            }
            t1578 = t1577;
        }
        int v1579 = t1578;
        uint64_t v1580 = (v1573 ? UINT64_C(16) : (v1574 ? UINT64_C(17) : v1467));
        uint64_t v1581 = (v1574 ? (((((uint64_t)(v1571 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(16)]))) : v1518);
        uint64_t v1582 = (v1575 ? ((v1484 + UINT64_C(1)) & UINT64_C(255)) : v1484);
        uint64_t v1583 = (v1575 ? UINT64_C(15) : v1535);
        uint64_t v1584 = (v1575 ? ((uint64_t)((UINT64_C(16) + v1571) & UINT64_C(255))) : v1501);
        uint64_t v1585 = ((v1573 || v1574) ? UINT64_C(1) : ((v1579 || (v1572 && (!v1575))) ? UINT64_C(2) : v1552));
        t1586 = v1582;
    } else {
        t1586 = v1484;
    }
    uint64_t v1587 = t1586;
    uint64_t t1603;
    if (v1553) {
        uint64_t v1588 = ((uint64_t)in_b[UINT64_C(15)]);
        int v1589 = ((v1552 == UINT64_C(0)) && (UINT64_C(15) == v1501));
        int v1590 = (v1589 && (v1588 == UINT64_C(0)));
        int v1591 = ((v1589 && ((v1588 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(16) < ((uint64_t)((uint64_t)in_b_len))));
        int v1592 = (((v1589 && (v1588 != UINT64_C(0))) && (v1588 < UINT64_C(64))) && (((uint64_t)((UINT64_C(15) + v1588) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1595 = ((v1552 == UINT64_C(0)) && (UINT64_C(15) != v1501));
        if (t1595) {
                uint64_t v1593 = v1588;
            int t1594 = (!(((((v1593 | UINT64_C(32)) >= UINT64_C(97)) && ((v1593 | UINT64_C(32)) <= UINT64_C(122))) || ((v1593 >= UINT64_C(48)) && (v1593 <= UINT64_C(57)))) || (v1593 == UINT64_C(45))));
            if (!t1594) {
                t1594 = ((v1588 == UINT64_C(45)) && ((UINT64_C(15) == ((v1535 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(16) == v1501)));
            }
            t1595 = t1594;
        }
        int v1596 = t1595;
        uint64_t v1597 = (v1590 ? UINT64_C(16) : (v1591 ? UINT64_C(17) : v1467));
        uint64_t v1598 = (v1591 ? (((((uint64_t)(v1588 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(16)]))) : v1518);
        uint64_t v1599 = (v1592 ? ((v1484 + UINT64_C(1)) & UINT64_C(255)) : v1484);
        uint64_t v1600 = (v1592 ? UINT64_C(15) : v1535);
        uint64_t v1601 = (v1592 ? ((uint64_t)((UINT64_C(16) + v1588) & UINT64_C(255))) : v1501);
        uint64_t v1602 = ((v1590 || v1591) ? UINT64_C(1) : ((v1596 || (v1589 && (!v1592))) ? UINT64_C(2) : v1552));
        t1603 = v1601;
    } else {
        t1603 = v1501;
    }
    uint64_t v1604 = t1603;
    uint64_t t1620;
    if (v1553) {
        uint64_t v1605 = ((uint64_t)in_b[UINT64_C(15)]);
        int v1606 = ((v1552 == UINT64_C(0)) && (UINT64_C(15) == v1501));
        int v1607 = (v1606 && (v1605 == UINT64_C(0)));
        int v1608 = ((v1606 && ((v1605 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(16) < ((uint64_t)((uint64_t)in_b_len))));
        int v1609 = (((v1606 && (v1605 != UINT64_C(0))) && (v1605 < UINT64_C(64))) && (((uint64_t)((UINT64_C(15) + v1605) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1612 = ((v1552 == UINT64_C(0)) && (UINT64_C(15) != v1501));
        if (t1612) {
                uint64_t v1610 = v1605;
            int t1611 = (!(((((v1610 | UINT64_C(32)) >= UINT64_C(97)) && ((v1610 | UINT64_C(32)) <= UINT64_C(122))) || ((v1610 >= UINT64_C(48)) && (v1610 <= UINT64_C(57)))) || (v1610 == UINT64_C(45))));
            if (!t1611) {
                t1611 = ((v1605 == UINT64_C(45)) && ((UINT64_C(15) == ((v1535 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(16) == v1501)));
            }
            t1612 = t1611;
        }
        int v1613 = t1612;
        uint64_t v1614 = (v1607 ? UINT64_C(16) : (v1608 ? UINT64_C(17) : v1467));
        uint64_t v1615 = (v1608 ? (((((uint64_t)(v1605 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(16)]))) : v1518);
        uint64_t v1616 = (v1609 ? ((v1484 + UINT64_C(1)) & UINT64_C(255)) : v1484);
        uint64_t v1617 = (v1609 ? UINT64_C(15) : v1535);
        uint64_t v1618 = (v1609 ? ((uint64_t)((UINT64_C(16) + v1605) & UINT64_C(255))) : v1501);
        uint64_t v1619 = ((v1607 || v1608) ? UINT64_C(1) : ((v1613 || (v1606 && (!v1609))) ? UINT64_C(2) : v1552));
        t1620 = v1615;
    } else {
        t1620 = v1518;
    }
    uint64_t v1621 = t1620;
    uint64_t t1637;
    if (v1553) {
        uint64_t v1622 = ((uint64_t)in_b[UINT64_C(15)]);
        int v1623 = ((v1552 == UINT64_C(0)) && (UINT64_C(15) == v1501));
        int v1624 = (v1623 && (v1622 == UINT64_C(0)));
        int v1625 = ((v1623 && ((v1622 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(16) < ((uint64_t)((uint64_t)in_b_len))));
        int v1626 = (((v1623 && (v1622 != UINT64_C(0))) && (v1622 < UINT64_C(64))) && (((uint64_t)((UINT64_C(15) + v1622) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1629 = ((v1552 == UINT64_C(0)) && (UINT64_C(15) != v1501));
        if (t1629) {
                uint64_t v1627 = v1622;
            int t1628 = (!(((((v1627 | UINT64_C(32)) >= UINT64_C(97)) && ((v1627 | UINT64_C(32)) <= UINT64_C(122))) || ((v1627 >= UINT64_C(48)) && (v1627 <= UINT64_C(57)))) || (v1627 == UINT64_C(45))));
            if (!t1628) {
                t1628 = ((v1622 == UINT64_C(45)) && ((UINT64_C(15) == ((v1535 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(16) == v1501)));
            }
            t1629 = t1628;
        }
        int v1630 = t1629;
        uint64_t v1631 = (v1624 ? UINT64_C(16) : (v1625 ? UINT64_C(17) : v1467));
        uint64_t v1632 = (v1625 ? (((((uint64_t)(v1622 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(16)]))) : v1518);
        uint64_t v1633 = (v1626 ? ((v1484 + UINT64_C(1)) & UINT64_C(255)) : v1484);
        uint64_t v1634 = (v1626 ? UINT64_C(15) : v1535);
        uint64_t v1635 = (v1626 ? ((uint64_t)((UINT64_C(16) + v1622) & UINT64_C(255))) : v1501);
        uint64_t v1636 = ((v1624 || v1625) ? UINT64_C(1) : ((v1630 || (v1623 && (!v1626))) ? UINT64_C(2) : v1552));
        t1637 = v1634;
    } else {
        t1637 = v1535;
    }
    uint64_t v1638 = t1637;
    uint64_t t1654;
    if (v1553) {
        uint64_t v1639 = ((uint64_t)in_b[UINT64_C(15)]);
        int v1640 = ((v1552 == UINT64_C(0)) && (UINT64_C(15) == v1501));
        int v1641 = (v1640 && (v1639 == UINT64_C(0)));
        int v1642 = ((v1640 && ((v1639 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(16) < ((uint64_t)((uint64_t)in_b_len))));
        int v1643 = (((v1640 && (v1639 != UINT64_C(0))) && (v1639 < UINT64_C(64))) && (((uint64_t)((UINT64_C(15) + v1639) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1646 = ((v1552 == UINT64_C(0)) && (UINT64_C(15) != v1501));
        if (t1646) {
                uint64_t v1644 = v1639;
            int t1645 = (!(((((v1644 | UINT64_C(32)) >= UINT64_C(97)) && ((v1644 | UINT64_C(32)) <= UINT64_C(122))) || ((v1644 >= UINT64_C(48)) && (v1644 <= UINT64_C(57)))) || (v1644 == UINT64_C(45))));
            if (!t1645) {
                t1645 = ((v1639 == UINT64_C(45)) && ((UINT64_C(15) == ((v1535 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(16) == v1501)));
            }
            t1646 = t1645;
        }
        int v1647 = t1646;
        uint64_t v1648 = (v1641 ? UINT64_C(16) : (v1642 ? UINT64_C(17) : v1467));
        uint64_t v1649 = (v1642 ? (((((uint64_t)(v1639 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(16)]))) : v1518);
        uint64_t v1650 = (v1643 ? ((v1484 + UINT64_C(1)) & UINT64_C(255)) : v1484);
        uint64_t v1651 = (v1643 ? UINT64_C(15) : v1535);
        uint64_t v1652 = (v1643 ? ((uint64_t)((UINT64_C(16) + v1639) & UINT64_C(255))) : v1501);
        uint64_t v1653 = ((v1641 || v1642) ? UINT64_C(1) : ((v1647 || (v1640 && (!v1643))) ? UINT64_C(2) : v1552));
        t1654 = v1653;
    } else {
        t1654 = v1552;
    }
    uint64_t v1655 = t1654;
    int v1656 = (UINT64_C(16) < v7);
    uint64_t t1672;
    if (v1656) {
        uint64_t v1657 = ((uint64_t)in_b[UINT64_C(16)]);
        int v1658 = ((v1655 == UINT64_C(0)) && (UINT64_C(16) == v1604));
        int v1659 = (v1658 && (v1657 == UINT64_C(0)));
        int v1660 = ((v1658 && ((v1657 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(17) < ((uint64_t)((uint64_t)in_b_len))));
        int v1661 = (((v1658 && (v1657 != UINT64_C(0))) && (v1657 < UINT64_C(64))) && (((uint64_t)((UINT64_C(16) + v1657) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1664 = ((v1655 == UINT64_C(0)) && (UINT64_C(16) != v1604));
        if (t1664) {
                uint64_t v1662 = v1657;
            int t1663 = (!(((((v1662 | UINT64_C(32)) >= UINT64_C(97)) && ((v1662 | UINT64_C(32)) <= UINT64_C(122))) || ((v1662 >= UINT64_C(48)) && (v1662 <= UINT64_C(57)))) || (v1662 == UINT64_C(45))));
            if (!t1663) {
                t1663 = ((v1657 == UINT64_C(45)) && ((UINT64_C(16) == ((v1638 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(17) == v1604)));
            }
            t1664 = t1663;
        }
        int v1665 = t1664;
        uint64_t v1666 = (v1659 ? UINT64_C(17) : (v1660 ? UINT64_C(18) : v1570));
        uint64_t v1667 = (v1660 ? (((((uint64_t)(v1657 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(17)]))) : v1621);
        uint64_t v1668 = (v1661 ? ((v1587 + UINT64_C(1)) & UINT64_C(255)) : v1587);
        uint64_t v1669 = (v1661 ? UINT64_C(16) : v1638);
        uint64_t v1670 = (v1661 ? ((uint64_t)((UINT64_C(17) + v1657) & UINT64_C(255))) : v1604);
        uint64_t v1671 = ((v1659 || v1660) ? UINT64_C(1) : ((v1665 || (v1658 && (!v1661))) ? UINT64_C(2) : v1655));
        t1672 = v1666;
    } else {
        t1672 = v1570;
    }
    uint64_t v1673 = t1672;
    uint64_t t1689;
    if (v1656) {
        uint64_t v1674 = ((uint64_t)in_b[UINT64_C(16)]);
        int v1675 = ((v1655 == UINT64_C(0)) && (UINT64_C(16) == v1604));
        int v1676 = (v1675 && (v1674 == UINT64_C(0)));
        int v1677 = ((v1675 && ((v1674 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(17) < ((uint64_t)((uint64_t)in_b_len))));
        int v1678 = (((v1675 && (v1674 != UINT64_C(0))) && (v1674 < UINT64_C(64))) && (((uint64_t)((UINT64_C(16) + v1674) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1681 = ((v1655 == UINT64_C(0)) && (UINT64_C(16) != v1604));
        if (t1681) {
                uint64_t v1679 = v1674;
            int t1680 = (!(((((v1679 | UINT64_C(32)) >= UINT64_C(97)) && ((v1679 | UINT64_C(32)) <= UINT64_C(122))) || ((v1679 >= UINT64_C(48)) && (v1679 <= UINT64_C(57)))) || (v1679 == UINT64_C(45))));
            if (!t1680) {
                t1680 = ((v1674 == UINT64_C(45)) && ((UINT64_C(16) == ((v1638 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(17) == v1604)));
            }
            t1681 = t1680;
        }
        int v1682 = t1681;
        uint64_t v1683 = (v1676 ? UINT64_C(17) : (v1677 ? UINT64_C(18) : v1570));
        uint64_t v1684 = (v1677 ? (((((uint64_t)(v1674 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(17)]))) : v1621);
        uint64_t v1685 = (v1678 ? ((v1587 + UINT64_C(1)) & UINT64_C(255)) : v1587);
        uint64_t v1686 = (v1678 ? UINT64_C(16) : v1638);
        uint64_t v1687 = (v1678 ? ((uint64_t)((UINT64_C(17) + v1674) & UINT64_C(255))) : v1604);
        uint64_t v1688 = ((v1676 || v1677) ? UINT64_C(1) : ((v1682 || (v1675 && (!v1678))) ? UINT64_C(2) : v1655));
        t1689 = v1685;
    } else {
        t1689 = v1587;
    }
    uint64_t v1690 = t1689;
    uint64_t t1706;
    if (v1656) {
        uint64_t v1691 = ((uint64_t)in_b[UINT64_C(16)]);
        int v1692 = ((v1655 == UINT64_C(0)) && (UINT64_C(16) == v1604));
        int v1693 = (v1692 && (v1691 == UINT64_C(0)));
        int v1694 = ((v1692 && ((v1691 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(17) < ((uint64_t)((uint64_t)in_b_len))));
        int v1695 = (((v1692 && (v1691 != UINT64_C(0))) && (v1691 < UINT64_C(64))) && (((uint64_t)((UINT64_C(16) + v1691) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1698 = ((v1655 == UINT64_C(0)) && (UINT64_C(16) != v1604));
        if (t1698) {
                uint64_t v1696 = v1691;
            int t1697 = (!(((((v1696 | UINT64_C(32)) >= UINT64_C(97)) && ((v1696 | UINT64_C(32)) <= UINT64_C(122))) || ((v1696 >= UINT64_C(48)) && (v1696 <= UINT64_C(57)))) || (v1696 == UINT64_C(45))));
            if (!t1697) {
                t1697 = ((v1691 == UINT64_C(45)) && ((UINT64_C(16) == ((v1638 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(17) == v1604)));
            }
            t1698 = t1697;
        }
        int v1699 = t1698;
        uint64_t v1700 = (v1693 ? UINT64_C(17) : (v1694 ? UINT64_C(18) : v1570));
        uint64_t v1701 = (v1694 ? (((((uint64_t)(v1691 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(17)]))) : v1621);
        uint64_t v1702 = (v1695 ? ((v1587 + UINT64_C(1)) & UINT64_C(255)) : v1587);
        uint64_t v1703 = (v1695 ? UINT64_C(16) : v1638);
        uint64_t v1704 = (v1695 ? ((uint64_t)((UINT64_C(17) + v1691) & UINT64_C(255))) : v1604);
        uint64_t v1705 = ((v1693 || v1694) ? UINT64_C(1) : ((v1699 || (v1692 && (!v1695))) ? UINT64_C(2) : v1655));
        t1706 = v1704;
    } else {
        t1706 = v1604;
    }
    uint64_t v1707 = t1706;
    uint64_t t1723;
    if (v1656) {
        uint64_t v1708 = ((uint64_t)in_b[UINT64_C(16)]);
        int v1709 = ((v1655 == UINT64_C(0)) && (UINT64_C(16) == v1604));
        int v1710 = (v1709 && (v1708 == UINT64_C(0)));
        int v1711 = ((v1709 && ((v1708 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(17) < ((uint64_t)((uint64_t)in_b_len))));
        int v1712 = (((v1709 && (v1708 != UINT64_C(0))) && (v1708 < UINT64_C(64))) && (((uint64_t)((UINT64_C(16) + v1708) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1715 = ((v1655 == UINT64_C(0)) && (UINT64_C(16) != v1604));
        if (t1715) {
                uint64_t v1713 = v1708;
            int t1714 = (!(((((v1713 | UINT64_C(32)) >= UINT64_C(97)) && ((v1713 | UINT64_C(32)) <= UINT64_C(122))) || ((v1713 >= UINT64_C(48)) && (v1713 <= UINT64_C(57)))) || (v1713 == UINT64_C(45))));
            if (!t1714) {
                t1714 = ((v1708 == UINT64_C(45)) && ((UINT64_C(16) == ((v1638 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(17) == v1604)));
            }
            t1715 = t1714;
        }
        int v1716 = t1715;
        uint64_t v1717 = (v1710 ? UINT64_C(17) : (v1711 ? UINT64_C(18) : v1570));
        uint64_t v1718 = (v1711 ? (((((uint64_t)(v1708 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(17)]))) : v1621);
        uint64_t v1719 = (v1712 ? ((v1587 + UINT64_C(1)) & UINT64_C(255)) : v1587);
        uint64_t v1720 = (v1712 ? UINT64_C(16) : v1638);
        uint64_t v1721 = (v1712 ? ((uint64_t)((UINT64_C(17) + v1708) & UINT64_C(255))) : v1604);
        uint64_t v1722 = ((v1710 || v1711) ? UINT64_C(1) : ((v1716 || (v1709 && (!v1712))) ? UINT64_C(2) : v1655));
        t1723 = v1718;
    } else {
        t1723 = v1621;
    }
    uint64_t v1724 = t1723;
    uint64_t t1740;
    if (v1656) {
        uint64_t v1725 = ((uint64_t)in_b[UINT64_C(16)]);
        int v1726 = ((v1655 == UINT64_C(0)) && (UINT64_C(16) == v1604));
        int v1727 = (v1726 && (v1725 == UINT64_C(0)));
        int v1728 = ((v1726 && ((v1725 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(17) < ((uint64_t)((uint64_t)in_b_len))));
        int v1729 = (((v1726 && (v1725 != UINT64_C(0))) && (v1725 < UINT64_C(64))) && (((uint64_t)((UINT64_C(16) + v1725) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1732 = ((v1655 == UINT64_C(0)) && (UINT64_C(16) != v1604));
        if (t1732) {
                uint64_t v1730 = v1725;
            int t1731 = (!(((((v1730 | UINT64_C(32)) >= UINT64_C(97)) && ((v1730 | UINT64_C(32)) <= UINT64_C(122))) || ((v1730 >= UINT64_C(48)) && (v1730 <= UINT64_C(57)))) || (v1730 == UINT64_C(45))));
            if (!t1731) {
                t1731 = ((v1725 == UINT64_C(45)) && ((UINT64_C(16) == ((v1638 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(17) == v1604)));
            }
            t1732 = t1731;
        }
        int v1733 = t1732;
        uint64_t v1734 = (v1727 ? UINT64_C(17) : (v1728 ? UINT64_C(18) : v1570));
        uint64_t v1735 = (v1728 ? (((((uint64_t)(v1725 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(17)]))) : v1621);
        uint64_t v1736 = (v1729 ? ((v1587 + UINT64_C(1)) & UINT64_C(255)) : v1587);
        uint64_t v1737 = (v1729 ? UINT64_C(16) : v1638);
        uint64_t v1738 = (v1729 ? ((uint64_t)((UINT64_C(17) + v1725) & UINT64_C(255))) : v1604);
        uint64_t v1739 = ((v1727 || v1728) ? UINT64_C(1) : ((v1733 || (v1726 && (!v1729))) ? UINT64_C(2) : v1655));
        t1740 = v1737;
    } else {
        t1740 = v1638;
    }
    uint64_t v1741 = t1740;
    uint64_t t1757;
    if (v1656) {
        uint64_t v1742 = ((uint64_t)in_b[UINT64_C(16)]);
        int v1743 = ((v1655 == UINT64_C(0)) && (UINT64_C(16) == v1604));
        int v1744 = (v1743 && (v1742 == UINT64_C(0)));
        int v1745 = ((v1743 && ((v1742 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(17) < ((uint64_t)((uint64_t)in_b_len))));
        int v1746 = (((v1743 && (v1742 != UINT64_C(0))) && (v1742 < UINT64_C(64))) && (((uint64_t)((UINT64_C(16) + v1742) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1749 = ((v1655 == UINT64_C(0)) && (UINT64_C(16) != v1604));
        if (t1749) {
                uint64_t v1747 = v1742;
            int t1748 = (!(((((v1747 | UINT64_C(32)) >= UINT64_C(97)) && ((v1747 | UINT64_C(32)) <= UINT64_C(122))) || ((v1747 >= UINT64_C(48)) && (v1747 <= UINT64_C(57)))) || (v1747 == UINT64_C(45))));
            if (!t1748) {
                t1748 = ((v1742 == UINT64_C(45)) && ((UINT64_C(16) == ((v1638 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(17) == v1604)));
            }
            t1749 = t1748;
        }
        int v1750 = t1749;
        uint64_t v1751 = (v1744 ? UINT64_C(17) : (v1745 ? UINT64_C(18) : v1570));
        uint64_t v1752 = (v1745 ? (((((uint64_t)(v1742 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(17)]))) : v1621);
        uint64_t v1753 = (v1746 ? ((v1587 + UINT64_C(1)) & UINT64_C(255)) : v1587);
        uint64_t v1754 = (v1746 ? UINT64_C(16) : v1638);
        uint64_t v1755 = (v1746 ? ((uint64_t)((UINT64_C(17) + v1742) & UINT64_C(255))) : v1604);
        uint64_t v1756 = ((v1744 || v1745) ? UINT64_C(1) : ((v1750 || (v1743 && (!v1746))) ? UINT64_C(2) : v1655));
        t1757 = v1756;
    } else {
        t1757 = v1655;
    }
    uint64_t v1758 = t1757;
    int v1759 = (UINT64_C(17) < v7);
    uint64_t t1775;
    if (v1759) {
        uint64_t v1760 = ((uint64_t)in_b[UINT64_C(17)]);
        int v1761 = ((v1758 == UINT64_C(0)) && (UINT64_C(17) == v1707));
        int v1762 = (v1761 && (v1760 == UINT64_C(0)));
        int v1763 = ((v1761 && ((v1760 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(18) < ((uint64_t)((uint64_t)in_b_len))));
        int v1764 = (((v1761 && (v1760 != UINT64_C(0))) && (v1760 < UINT64_C(64))) && (((uint64_t)((UINT64_C(17) + v1760) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1767 = ((v1758 == UINT64_C(0)) && (UINT64_C(17) != v1707));
        if (t1767) {
                uint64_t v1765 = v1760;
            int t1766 = (!(((((v1765 | UINT64_C(32)) >= UINT64_C(97)) && ((v1765 | UINT64_C(32)) <= UINT64_C(122))) || ((v1765 >= UINT64_C(48)) && (v1765 <= UINT64_C(57)))) || (v1765 == UINT64_C(45))));
            if (!t1766) {
                t1766 = ((v1760 == UINT64_C(45)) && ((UINT64_C(17) == ((v1741 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(18) == v1707)));
            }
            t1767 = t1766;
        }
        int v1768 = t1767;
        uint64_t v1769 = (v1762 ? UINT64_C(18) : (v1763 ? UINT64_C(19) : v1673));
        uint64_t v1770 = (v1763 ? (((((uint64_t)(v1760 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(18)]))) : v1724);
        uint64_t v1771 = (v1764 ? ((v1690 + UINT64_C(1)) & UINT64_C(255)) : v1690);
        uint64_t v1772 = (v1764 ? UINT64_C(17) : v1741);
        uint64_t v1773 = (v1764 ? ((uint64_t)((UINT64_C(18) + v1760) & UINT64_C(255))) : v1707);
        uint64_t v1774 = ((v1762 || v1763) ? UINT64_C(1) : ((v1768 || (v1761 && (!v1764))) ? UINT64_C(2) : v1758));
        t1775 = v1769;
    } else {
        t1775 = v1673;
    }
    uint64_t v1776 = t1775;
    uint64_t t1792;
    if (v1759) {
        uint64_t v1777 = ((uint64_t)in_b[UINT64_C(17)]);
        int v1778 = ((v1758 == UINT64_C(0)) && (UINT64_C(17) == v1707));
        int v1779 = (v1778 && (v1777 == UINT64_C(0)));
        int v1780 = ((v1778 && ((v1777 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(18) < ((uint64_t)((uint64_t)in_b_len))));
        int v1781 = (((v1778 && (v1777 != UINT64_C(0))) && (v1777 < UINT64_C(64))) && (((uint64_t)((UINT64_C(17) + v1777) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1784 = ((v1758 == UINT64_C(0)) && (UINT64_C(17) != v1707));
        if (t1784) {
                uint64_t v1782 = v1777;
            int t1783 = (!(((((v1782 | UINT64_C(32)) >= UINT64_C(97)) && ((v1782 | UINT64_C(32)) <= UINT64_C(122))) || ((v1782 >= UINT64_C(48)) && (v1782 <= UINT64_C(57)))) || (v1782 == UINT64_C(45))));
            if (!t1783) {
                t1783 = ((v1777 == UINT64_C(45)) && ((UINT64_C(17) == ((v1741 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(18) == v1707)));
            }
            t1784 = t1783;
        }
        int v1785 = t1784;
        uint64_t v1786 = (v1779 ? UINT64_C(18) : (v1780 ? UINT64_C(19) : v1673));
        uint64_t v1787 = (v1780 ? (((((uint64_t)(v1777 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(18)]))) : v1724);
        uint64_t v1788 = (v1781 ? ((v1690 + UINT64_C(1)) & UINT64_C(255)) : v1690);
        uint64_t v1789 = (v1781 ? UINT64_C(17) : v1741);
        uint64_t v1790 = (v1781 ? ((uint64_t)((UINT64_C(18) + v1777) & UINT64_C(255))) : v1707);
        uint64_t v1791 = ((v1779 || v1780) ? UINT64_C(1) : ((v1785 || (v1778 && (!v1781))) ? UINT64_C(2) : v1758));
        t1792 = v1788;
    } else {
        t1792 = v1690;
    }
    uint64_t v1793 = t1792;
    uint64_t t1809;
    if (v1759) {
        uint64_t v1794 = ((uint64_t)in_b[UINT64_C(17)]);
        int v1795 = ((v1758 == UINT64_C(0)) && (UINT64_C(17) == v1707));
        int v1796 = (v1795 && (v1794 == UINT64_C(0)));
        int v1797 = ((v1795 && ((v1794 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(18) < ((uint64_t)((uint64_t)in_b_len))));
        int v1798 = (((v1795 && (v1794 != UINT64_C(0))) && (v1794 < UINT64_C(64))) && (((uint64_t)((UINT64_C(17) + v1794) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1801 = ((v1758 == UINT64_C(0)) && (UINT64_C(17) != v1707));
        if (t1801) {
                uint64_t v1799 = v1794;
            int t1800 = (!(((((v1799 | UINT64_C(32)) >= UINT64_C(97)) && ((v1799 | UINT64_C(32)) <= UINT64_C(122))) || ((v1799 >= UINT64_C(48)) && (v1799 <= UINT64_C(57)))) || (v1799 == UINT64_C(45))));
            if (!t1800) {
                t1800 = ((v1794 == UINT64_C(45)) && ((UINT64_C(17) == ((v1741 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(18) == v1707)));
            }
            t1801 = t1800;
        }
        int v1802 = t1801;
        uint64_t v1803 = (v1796 ? UINT64_C(18) : (v1797 ? UINT64_C(19) : v1673));
        uint64_t v1804 = (v1797 ? (((((uint64_t)(v1794 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(18)]))) : v1724);
        uint64_t v1805 = (v1798 ? ((v1690 + UINT64_C(1)) & UINT64_C(255)) : v1690);
        uint64_t v1806 = (v1798 ? UINT64_C(17) : v1741);
        uint64_t v1807 = (v1798 ? ((uint64_t)((UINT64_C(18) + v1794) & UINT64_C(255))) : v1707);
        uint64_t v1808 = ((v1796 || v1797) ? UINT64_C(1) : ((v1802 || (v1795 && (!v1798))) ? UINT64_C(2) : v1758));
        t1809 = v1807;
    } else {
        t1809 = v1707;
    }
    uint64_t v1810 = t1809;
    uint64_t t1826;
    if (v1759) {
        uint64_t v1811 = ((uint64_t)in_b[UINT64_C(17)]);
        int v1812 = ((v1758 == UINT64_C(0)) && (UINT64_C(17) == v1707));
        int v1813 = (v1812 && (v1811 == UINT64_C(0)));
        int v1814 = ((v1812 && ((v1811 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(18) < ((uint64_t)((uint64_t)in_b_len))));
        int v1815 = (((v1812 && (v1811 != UINT64_C(0))) && (v1811 < UINT64_C(64))) && (((uint64_t)((UINT64_C(17) + v1811) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1818 = ((v1758 == UINT64_C(0)) && (UINT64_C(17) != v1707));
        if (t1818) {
                uint64_t v1816 = v1811;
            int t1817 = (!(((((v1816 | UINT64_C(32)) >= UINT64_C(97)) && ((v1816 | UINT64_C(32)) <= UINT64_C(122))) || ((v1816 >= UINT64_C(48)) && (v1816 <= UINT64_C(57)))) || (v1816 == UINT64_C(45))));
            if (!t1817) {
                t1817 = ((v1811 == UINT64_C(45)) && ((UINT64_C(17) == ((v1741 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(18) == v1707)));
            }
            t1818 = t1817;
        }
        int v1819 = t1818;
        uint64_t v1820 = (v1813 ? UINT64_C(18) : (v1814 ? UINT64_C(19) : v1673));
        uint64_t v1821 = (v1814 ? (((((uint64_t)(v1811 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(18)]))) : v1724);
        uint64_t v1822 = (v1815 ? ((v1690 + UINT64_C(1)) & UINT64_C(255)) : v1690);
        uint64_t v1823 = (v1815 ? UINT64_C(17) : v1741);
        uint64_t v1824 = (v1815 ? ((uint64_t)((UINT64_C(18) + v1811) & UINT64_C(255))) : v1707);
        uint64_t v1825 = ((v1813 || v1814) ? UINT64_C(1) : ((v1819 || (v1812 && (!v1815))) ? UINT64_C(2) : v1758));
        t1826 = v1821;
    } else {
        t1826 = v1724;
    }
    uint64_t v1827 = t1826;
    uint64_t t1843;
    if (v1759) {
        uint64_t v1828 = ((uint64_t)in_b[UINT64_C(17)]);
        int v1829 = ((v1758 == UINT64_C(0)) && (UINT64_C(17) == v1707));
        int v1830 = (v1829 && (v1828 == UINT64_C(0)));
        int v1831 = ((v1829 && ((v1828 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(18) < ((uint64_t)((uint64_t)in_b_len))));
        int v1832 = (((v1829 && (v1828 != UINT64_C(0))) && (v1828 < UINT64_C(64))) && (((uint64_t)((UINT64_C(17) + v1828) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1835 = ((v1758 == UINT64_C(0)) && (UINT64_C(17) != v1707));
        if (t1835) {
                uint64_t v1833 = v1828;
            int t1834 = (!(((((v1833 | UINT64_C(32)) >= UINT64_C(97)) && ((v1833 | UINT64_C(32)) <= UINT64_C(122))) || ((v1833 >= UINT64_C(48)) && (v1833 <= UINT64_C(57)))) || (v1833 == UINT64_C(45))));
            if (!t1834) {
                t1834 = ((v1828 == UINT64_C(45)) && ((UINT64_C(17) == ((v1741 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(18) == v1707)));
            }
            t1835 = t1834;
        }
        int v1836 = t1835;
        uint64_t v1837 = (v1830 ? UINT64_C(18) : (v1831 ? UINT64_C(19) : v1673));
        uint64_t v1838 = (v1831 ? (((((uint64_t)(v1828 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(18)]))) : v1724);
        uint64_t v1839 = (v1832 ? ((v1690 + UINT64_C(1)) & UINT64_C(255)) : v1690);
        uint64_t v1840 = (v1832 ? UINT64_C(17) : v1741);
        uint64_t v1841 = (v1832 ? ((uint64_t)((UINT64_C(18) + v1828) & UINT64_C(255))) : v1707);
        uint64_t v1842 = ((v1830 || v1831) ? UINT64_C(1) : ((v1836 || (v1829 && (!v1832))) ? UINT64_C(2) : v1758));
        t1843 = v1840;
    } else {
        t1843 = v1741;
    }
    uint64_t v1844 = t1843;
    uint64_t t1860;
    if (v1759) {
        uint64_t v1845 = ((uint64_t)in_b[UINT64_C(17)]);
        int v1846 = ((v1758 == UINT64_C(0)) && (UINT64_C(17) == v1707));
        int v1847 = (v1846 && (v1845 == UINT64_C(0)));
        int v1848 = ((v1846 && ((v1845 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(18) < ((uint64_t)((uint64_t)in_b_len))));
        int v1849 = (((v1846 && (v1845 != UINT64_C(0))) && (v1845 < UINT64_C(64))) && (((uint64_t)((UINT64_C(17) + v1845) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1852 = ((v1758 == UINT64_C(0)) && (UINT64_C(17) != v1707));
        if (t1852) {
                uint64_t v1850 = v1845;
            int t1851 = (!(((((v1850 | UINT64_C(32)) >= UINT64_C(97)) && ((v1850 | UINT64_C(32)) <= UINT64_C(122))) || ((v1850 >= UINT64_C(48)) && (v1850 <= UINT64_C(57)))) || (v1850 == UINT64_C(45))));
            if (!t1851) {
                t1851 = ((v1845 == UINT64_C(45)) && ((UINT64_C(17) == ((v1741 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(18) == v1707)));
            }
            t1852 = t1851;
        }
        int v1853 = t1852;
        uint64_t v1854 = (v1847 ? UINT64_C(18) : (v1848 ? UINT64_C(19) : v1673));
        uint64_t v1855 = (v1848 ? (((((uint64_t)(v1845 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(18)]))) : v1724);
        uint64_t v1856 = (v1849 ? ((v1690 + UINT64_C(1)) & UINT64_C(255)) : v1690);
        uint64_t v1857 = (v1849 ? UINT64_C(17) : v1741);
        uint64_t v1858 = (v1849 ? ((uint64_t)((UINT64_C(18) + v1845) & UINT64_C(255))) : v1707);
        uint64_t v1859 = ((v1847 || v1848) ? UINT64_C(1) : ((v1853 || (v1846 && (!v1849))) ? UINT64_C(2) : v1758));
        t1860 = v1859;
    } else {
        t1860 = v1758;
    }
    uint64_t v1861 = t1860;
    int v1862 = (UINT64_C(18) < v7);
    uint64_t t1878;
    if (v1862) {
        uint64_t v1863 = ((uint64_t)in_b[UINT64_C(18)]);
        int v1864 = ((v1861 == UINT64_C(0)) && (UINT64_C(18) == v1810));
        int v1865 = (v1864 && (v1863 == UINT64_C(0)));
        int v1866 = ((v1864 && ((v1863 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(19) < ((uint64_t)((uint64_t)in_b_len))));
        int v1867 = (((v1864 && (v1863 != UINT64_C(0))) && (v1863 < UINT64_C(64))) && (((uint64_t)((UINT64_C(18) + v1863) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1870 = ((v1861 == UINT64_C(0)) && (UINT64_C(18) != v1810));
        if (t1870) {
                uint64_t v1868 = v1863;
            int t1869 = (!(((((v1868 | UINT64_C(32)) >= UINT64_C(97)) && ((v1868 | UINT64_C(32)) <= UINT64_C(122))) || ((v1868 >= UINT64_C(48)) && (v1868 <= UINT64_C(57)))) || (v1868 == UINT64_C(45))));
            if (!t1869) {
                t1869 = ((v1863 == UINT64_C(45)) && ((UINT64_C(18) == ((v1844 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(19) == v1810)));
            }
            t1870 = t1869;
        }
        int v1871 = t1870;
        uint64_t v1872 = (v1865 ? UINT64_C(19) : (v1866 ? UINT64_C(20) : v1776));
        uint64_t v1873 = (v1866 ? (((((uint64_t)(v1863 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(19)]))) : v1827);
        uint64_t v1874 = (v1867 ? ((v1793 + UINT64_C(1)) & UINT64_C(255)) : v1793);
        uint64_t v1875 = (v1867 ? UINT64_C(18) : v1844);
        uint64_t v1876 = (v1867 ? ((uint64_t)((UINT64_C(19) + v1863) & UINT64_C(255))) : v1810);
        uint64_t v1877 = ((v1865 || v1866) ? UINT64_C(1) : ((v1871 || (v1864 && (!v1867))) ? UINT64_C(2) : v1861));
        t1878 = v1872;
    } else {
        t1878 = v1776;
    }
    uint64_t v1879 = t1878;
    uint64_t t1895;
    if (v1862) {
        uint64_t v1880 = ((uint64_t)in_b[UINT64_C(18)]);
        int v1881 = ((v1861 == UINT64_C(0)) && (UINT64_C(18) == v1810));
        int v1882 = (v1881 && (v1880 == UINT64_C(0)));
        int v1883 = ((v1881 && ((v1880 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(19) < ((uint64_t)((uint64_t)in_b_len))));
        int v1884 = (((v1881 && (v1880 != UINT64_C(0))) && (v1880 < UINT64_C(64))) && (((uint64_t)((UINT64_C(18) + v1880) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1887 = ((v1861 == UINT64_C(0)) && (UINT64_C(18) != v1810));
        if (t1887) {
                uint64_t v1885 = v1880;
            int t1886 = (!(((((v1885 | UINT64_C(32)) >= UINT64_C(97)) && ((v1885 | UINT64_C(32)) <= UINT64_C(122))) || ((v1885 >= UINT64_C(48)) && (v1885 <= UINT64_C(57)))) || (v1885 == UINT64_C(45))));
            if (!t1886) {
                t1886 = ((v1880 == UINT64_C(45)) && ((UINT64_C(18) == ((v1844 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(19) == v1810)));
            }
            t1887 = t1886;
        }
        int v1888 = t1887;
        uint64_t v1889 = (v1882 ? UINT64_C(19) : (v1883 ? UINT64_C(20) : v1776));
        uint64_t v1890 = (v1883 ? (((((uint64_t)(v1880 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(19)]))) : v1827);
        uint64_t v1891 = (v1884 ? ((v1793 + UINT64_C(1)) & UINT64_C(255)) : v1793);
        uint64_t v1892 = (v1884 ? UINT64_C(18) : v1844);
        uint64_t v1893 = (v1884 ? ((uint64_t)((UINT64_C(19) + v1880) & UINT64_C(255))) : v1810);
        uint64_t v1894 = ((v1882 || v1883) ? UINT64_C(1) : ((v1888 || (v1881 && (!v1884))) ? UINT64_C(2) : v1861));
        t1895 = v1891;
    } else {
        t1895 = v1793;
    }
    uint64_t v1896 = t1895;
    uint64_t t1912;
    if (v1862) {
        uint64_t v1897 = ((uint64_t)in_b[UINT64_C(18)]);
        int v1898 = ((v1861 == UINT64_C(0)) && (UINT64_C(18) == v1810));
        int v1899 = (v1898 && (v1897 == UINT64_C(0)));
        int v1900 = ((v1898 && ((v1897 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(19) < ((uint64_t)((uint64_t)in_b_len))));
        int v1901 = (((v1898 && (v1897 != UINT64_C(0))) && (v1897 < UINT64_C(64))) && (((uint64_t)((UINT64_C(18) + v1897) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1904 = ((v1861 == UINT64_C(0)) && (UINT64_C(18) != v1810));
        if (t1904) {
                uint64_t v1902 = v1897;
            int t1903 = (!(((((v1902 | UINT64_C(32)) >= UINT64_C(97)) && ((v1902 | UINT64_C(32)) <= UINT64_C(122))) || ((v1902 >= UINT64_C(48)) && (v1902 <= UINT64_C(57)))) || (v1902 == UINT64_C(45))));
            if (!t1903) {
                t1903 = ((v1897 == UINT64_C(45)) && ((UINT64_C(18) == ((v1844 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(19) == v1810)));
            }
            t1904 = t1903;
        }
        int v1905 = t1904;
        uint64_t v1906 = (v1899 ? UINT64_C(19) : (v1900 ? UINT64_C(20) : v1776));
        uint64_t v1907 = (v1900 ? (((((uint64_t)(v1897 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(19)]))) : v1827);
        uint64_t v1908 = (v1901 ? ((v1793 + UINT64_C(1)) & UINT64_C(255)) : v1793);
        uint64_t v1909 = (v1901 ? UINT64_C(18) : v1844);
        uint64_t v1910 = (v1901 ? ((uint64_t)((UINT64_C(19) + v1897) & UINT64_C(255))) : v1810);
        uint64_t v1911 = ((v1899 || v1900) ? UINT64_C(1) : ((v1905 || (v1898 && (!v1901))) ? UINT64_C(2) : v1861));
        t1912 = v1910;
    } else {
        t1912 = v1810;
    }
    uint64_t v1913 = t1912;
    uint64_t t1929;
    if (v1862) {
        uint64_t v1914 = ((uint64_t)in_b[UINT64_C(18)]);
        int v1915 = ((v1861 == UINT64_C(0)) && (UINT64_C(18) == v1810));
        int v1916 = (v1915 && (v1914 == UINT64_C(0)));
        int v1917 = ((v1915 && ((v1914 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(19) < ((uint64_t)((uint64_t)in_b_len))));
        int v1918 = (((v1915 && (v1914 != UINT64_C(0))) && (v1914 < UINT64_C(64))) && (((uint64_t)((UINT64_C(18) + v1914) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1921 = ((v1861 == UINT64_C(0)) && (UINT64_C(18) != v1810));
        if (t1921) {
                uint64_t v1919 = v1914;
            int t1920 = (!(((((v1919 | UINT64_C(32)) >= UINT64_C(97)) && ((v1919 | UINT64_C(32)) <= UINT64_C(122))) || ((v1919 >= UINT64_C(48)) && (v1919 <= UINT64_C(57)))) || (v1919 == UINT64_C(45))));
            if (!t1920) {
                t1920 = ((v1914 == UINT64_C(45)) && ((UINT64_C(18) == ((v1844 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(19) == v1810)));
            }
            t1921 = t1920;
        }
        int v1922 = t1921;
        uint64_t v1923 = (v1916 ? UINT64_C(19) : (v1917 ? UINT64_C(20) : v1776));
        uint64_t v1924 = (v1917 ? (((((uint64_t)(v1914 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(19)]))) : v1827);
        uint64_t v1925 = (v1918 ? ((v1793 + UINT64_C(1)) & UINT64_C(255)) : v1793);
        uint64_t v1926 = (v1918 ? UINT64_C(18) : v1844);
        uint64_t v1927 = (v1918 ? ((uint64_t)((UINT64_C(19) + v1914) & UINT64_C(255))) : v1810);
        uint64_t v1928 = ((v1916 || v1917) ? UINT64_C(1) : ((v1922 || (v1915 && (!v1918))) ? UINT64_C(2) : v1861));
        t1929 = v1924;
    } else {
        t1929 = v1827;
    }
    uint64_t v1930 = t1929;
    uint64_t t1946;
    if (v1862) {
        uint64_t v1931 = ((uint64_t)in_b[UINT64_C(18)]);
        int v1932 = ((v1861 == UINT64_C(0)) && (UINT64_C(18) == v1810));
        int v1933 = (v1932 && (v1931 == UINT64_C(0)));
        int v1934 = ((v1932 && ((v1931 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(19) < ((uint64_t)((uint64_t)in_b_len))));
        int v1935 = (((v1932 && (v1931 != UINT64_C(0))) && (v1931 < UINT64_C(64))) && (((uint64_t)((UINT64_C(18) + v1931) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1938 = ((v1861 == UINT64_C(0)) && (UINT64_C(18) != v1810));
        if (t1938) {
                uint64_t v1936 = v1931;
            int t1937 = (!(((((v1936 | UINT64_C(32)) >= UINT64_C(97)) && ((v1936 | UINT64_C(32)) <= UINT64_C(122))) || ((v1936 >= UINT64_C(48)) && (v1936 <= UINT64_C(57)))) || (v1936 == UINT64_C(45))));
            if (!t1937) {
                t1937 = ((v1931 == UINT64_C(45)) && ((UINT64_C(18) == ((v1844 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(19) == v1810)));
            }
            t1938 = t1937;
        }
        int v1939 = t1938;
        uint64_t v1940 = (v1933 ? UINT64_C(19) : (v1934 ? UINT64_C(20) : v1776));
        uint64_t v1941 = (v1934 ? (((((uint64_t)(v1931 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(19)]))) : v1827);
        uint64_t v1942 = (v1935 ? ((v1793 + UINT64_C(1)) & UINT64_C(255)) : v1793);
        uint64_t v1943 = (v1935 ? UINT64_C(18) : v1844);
        uint64_t v1944 = (v1935 ? ((uint64_t)((UINT64_C(19) + v1931) & UINT64_C(255))) : v1810);
        uint64_t v1945 = ((v1933 || v1934) ? UINT64_C(1) : ((v1939 || (v1932 && (!v1935))) ? UINT64_C(2) : v1861));
        t1946 = v1943;
    } else {
        t1946 = v1844;
    }
    uint64_t v1947 = t1946;
    uint64_t t1963;
    if (v1862) {
        uint64_t v1948 = ((uint64_t)in_b[UINT64_C(18)]);
        int v1949 = ((v1861 == UINT64_C(0)) && (UINT64_C(18) == v1810));
        int v1950 = (v1949 && (v1948 == UINT64_C(0)));
        int v1951 = ((v1949 && ((v1948 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(19) < ((uint64_t)((uint64_t)in_b_len))));
        int v1952 = (((v1949 && (v1948 != UINT64_C(0))) && (v1948 < UINT64_C(64))) && (((uint64_t)((UINT64_C(18) + v1948) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1955 = ((v1861 == UINT64_C(0)) && (UINT64_C(18) != v1810));
        if (t1955) {
                uint64_t v1953 = v1948;
            int t1954 = (!(((((v1953 | UINT64_C(32)) >= UINT64_C(97)) && ((v1953 | UINT64_C(32)) <= UINT64_C(122))) || ((v1953 >= UINT64_C(48)) && (v1953 <= UINT64_C(57)))) || (v1953 == UINT64_C(45))));
            if (!t1954) {
                t1954 = ((v1948 == UINT64_C(45)) && ((UINT64_C(18) == ((v1844 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(19) == v1810)));
            }
            t1955 = t1954;
        }
        int v1956 = t1955;
        uint64_t v1957 = (v1950 ? UINT64_C(19) : (v1951 ? UINT64_C(20) : v1776));
        uint64_t v1958 = (v1951 ? (((((uint64_t)(v1948 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(19)]))) : v1827);
        uint64_t v1959 = (v1952 ? ((v1793 + UINT64_C(1)) & UINT64_C(255)) : v1793);
        uint64_t v1960 = (v1952 ? UINT64_C(18) : v1844);
        uint64_t v1961 = (v1952 ? ((uint64_t)((UINT64_C(19) + v1948) & UINT64_C(255))) : v1810);
        uint64_t v1962 = ((v1950 || v1951) ? UINT64_C(1) : ((v1956 || (v1949 && (!v1952))) ? UINT64_C(2) : v1861));
        t1963 = v1962;
    } else {
        t1963 = v1861;
    }
    uint64_t v1964 = t1963;
    int v1965 = (UINT64_C(19) < v7);
    uint64_t t1981;
    if (v1965) {
        uint64_t v1966 = ((uint64_t)in_b[UINT64_C(19)]);
        int v1967 = ((v1964 == UINT64_C(0)) && (UINT64_C(19) == v1913));
        int v1968 = (v1967 && (v1966 == UINT64_C(0)));
        int v1969 = ((v1967 && ((v1966 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(20) < ((uint64_t)((uint64_t)in_b_len))));
        int v1970 = (((v1967 && (v1966 != UINT64_C(0))) && (v1966 < UINT64_C(64))) && (((uint64_t)((UINT64_C(19) + v1966) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1973 = ((v1964 == UINT64_C(0)) && (UINT64_C(19) != v1913));
        if (t1973) {
                uint64_t v1971 = v1966;
            int t1972 = (!(((((v1971 | UINT64_C(32)) >= UINT64_C(97)) && ((v1971 | UINT64_C(32)) <= UINT64_C(122))) || ((v1971 >= UINT64_C(48)) && (v1971 <= UINT64_C(57)))) || (v1971 == UINT64_C(45))));
            if (!t1972) {
                t1972 = ((v1966 == UINT64_C(45)) && ((UINT64_C(19) == ((v1947 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(20) == v1913)));
            }
            t1973 = t1972;
        }
        int v1974 = t1973;
        uint64_t v1975 = (v1968 ? UINT64_C(20) : (v1969 ? UINT64_C(21) : v1879));
        uint64_t v1976 = (v1969 ? (((((uint64_t)(v1966 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(20)]))) : v1930);
        uint64_t v1977 = (v1970 ? ((v1896 + UINT64_C(1)) & UINT64_C(255)) : v1896);
        uint64_t v1978 = (v1970 ? UINT64_C(19) : v1947);
        uint64_t v1979 = (v1970 ? ((uint64_t)((UINT64_C(20) + v1966) & UINT64_C(255))) : v1913);
        uint64_t v1980 = ((v1968 || v1969) ? UINT64_C(1) : ((v1974 || (v1967 && (!v1970))) ? UINT64_C(2) : v1964));
        t1981 = v1975;
    } else {
        t1981 = v1879;
    }
    uint64_t v1982 = t1981;
    uint64_t t1998;
    if (v1965) {
        uint64_t v1983 = ((uint64_t)in_b[UINT64_C(19)]);
        int v1984 = ((v1964 == UINT64_C(0)) && (UINT64_C(19) == v1913));
        int v1985 = (v1984 && (v1983 == UINT64_C(0)));
        int v1986 = ((v1984 && ((v1983 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(20) < ((uint64_t)((uint64_t)in_b_len))));
        int v1987 = (((v1984 && (v1983 != UINT64_C(0))) && (v1983 < UINT64_C(64))) && (((uint64_t)((UINT64_C(19) + v1983) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t1990 = ((v1964 == UINT64_C(0)) && (UINT64_C(19) != v1913));
        if (t1990) {
                uint64_t v1988 = v1983;
            int t1989 = (!(((((v1988 | UINT64_C(32)) >= UINT64_C(97)) && ((v1988 | UINT64_C(32)) <= UINT64_C(122))) || ((v1988 >= UINT64_C(48)) && (v1988 <= UINT64_C(57)))) || (v1988 == UINT64_C(45))));
            if (!t1989) {
                t1989 = ((v1983 == UINT64_C(45)) && ((UINT64_C(19) == ((v1947 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(20) == v1913)));
            }
            t1990 = t1989;
        }
        int v1991 = t1990;
        uint64_t v1992 = (v1985 ? UINT64_C(20) : (v1986 ? UINT64_C(21) : v1879));
        uint64_t v1993 = (v1986 ? (((((uint64_t)(v1983 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(20)]))) : v1930);
        uint64_t v1994 = (v1987 ? ((v1896 + UINT64_C(1)) & UINT64_C(255)) : v1896);
        uint64_t v1995 = (v1987 ? UINT64_C(19) : v1947);
        uint64_t v1996 = (v1987 ? ((uint64_t)((UINT64_C(20) + v1983) & UINT64_C(255))) : v1913);
        uint64_t v1997 = ((v1985 || v1986) ? UINT64_C(1) : ((v1991 || (v1984 && (!v1987))) ? UINT64_C(2) : v1964));
        t1998 = v1994;
    } else {
        t1998 = v1896;
    }
    uint64_t v1999 = t1998;
    uint64_t t2015;
    if (v1965) {
        uint64_t v2000 = ((uint64_t)in_b[UINT64_C(19)]);
        int v2001 = ((v1964 == UINT64_C(0)) && (UINT64_C(19) == v1913));
        int v2002 = (v2001 && (v2000 == UINT64_C(0)));
        int v2003 = ((v2001 && ((v2000 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(20) < ((uint64_t)((uint64_t)in_b_len))));
        int v2004 = (((v2001 && (v2000 != UINT64_C(0))) && (v2000 < UINT64_C(64))) && (((uint64_t)((UINT64_C(19) + v2000) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2007 = ((v1964 == UINT64_C(0)) && (UINT64_C(19) != v1913));
        if (t2007) {
                uint64_t v2005 = v2000;
            int t2006 = (!(((((v2005 | UINT64_C(32)) >= UINT64_C(97)) && ((v2005 | UINT64_C(32)) <= UINT64_C(122))) || ((v2005 >= UINT64_C(48)) && (v2005 <= UINT64_C(57)))) || (v2005 == UINT64_C(45))));
            if (!t2006) {
                t2006 = ((v2000 == UINT64_C(45)) && ((UINT64_C(19) == ((v1947 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(20) == v1913)));
            }
            t2007 = t2006;
        }
        int v2008 = t2007;
        uint64_t v2009 = (v2002 ? UINT64_C(20) : (v2003 ? UINT64_C(21) : v1879));
        uint64_t v2010 = (v2003 ? (((((uint64_t)(v2000 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(20)]))) : v1930);
        uint64_t v2011 = (v2004 ? ((v1896 + UINT64_C(1)) & UINT64_C(255)) : v1896);
        uint64_t v2012 = (v2004 ? UINT64_C(19) : v1947);
        uint64_t v2013 = (v2004 ? ((uint64_t)((UINT64_C(20) + v2000) & UINT64_C(255))) : v1913);
        uint64_t v2014 = ((v2002 || v2003) ? UINT64_C(1) : ((v2008 || (v2001 && (!v2004))) ? UINT64_C(2) : v1964));
        t2015 = v2013;
    } else {
        t2015 = v1913;
    }
    uint64_t v2016 = t2015;
    uint64_t t2032;
    if (v1965) {
        uint64_t v2017 = ((uint64_t)in_b[UINT64_C(19)]);
        int v2018 = ((v1964 == UINT64_C(0)) && (UINT64_C(19) == v1913));
        int v2019 = (v2018 && (v2017 == UINT64_C(0)));
        int v2020 = ((v2018 && ((v2017 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(20) < ((uint64_t)((uint64_t)in_b_len))));
        int v2021 = (((v2018 && (v2017 != UINT64_C(0))) && (v2017 < UINT64_C(64))) && (((uint64_t)((UINT64_C(19) + v2017) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2024 = ((v1964 == UINT64_C(0)) && (UINT64_C(19) != v1913));
        if (t2024) {
                uint64_t v2022 = v2017;
            int t2023 = (!(((((v2022 | UINT64_C(32)) >= UINT64_C(97)) && ((v2022 | UINT64_C(32)) <= UINT64_C(122))) || ((v2022 >= UINT64_C(48)) && (v2022 <= UINT64_C(57)))) || (v2022 == UINT64_C(45))));
            if (!t2023) {
                t2023 = ((v2017 == UINT64_C(45)) && ((UINT64_C(19) == ((v1947 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(20) == v1913)));
            }
            t2024 = t2023;
        }
        int v2025 = t2024;
        uint64_t v2026 = (v2019 ? UINT64_C(20) : (v2020 ? UINT64_C(21) : v1879));
        uint64_t v2027 = (v2020 ? (((((uint64_t)(v2017 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(20)]))) : v1930);
        uint64_t v2028 = (v2021 ? ((v1896 + UINT64_C(1)) & UINT64_C(255)) : v1896);
        uint64_t v2029 = (v2021 ? UINT64_C(19) : v1947);
        uint64_t v2030 = (v2021 ? ((uint64_t)((UINT64_C(20) + v2017) & UINT64_C(255))) : v1913);
        uint64_t v2031 = ((v2019 || v2020) ? UINT64_C(1) : ((v2025 || (v2018 && (!v2021))) ? UINT64_C(2) : v1964));
        t2032 = v2027;
    } else {
        t2032 = v1930;
    }
    uint64_t v2033 = t2032;
    uint64_t t2049;
    if (v1965) {
        uint64_t v2034 = ((uint64_t)in_b[UINT64_C(19)]);
        int v2035 = ((v1964 == UINT64_C(0)) && (UINT64_C(19) == v1913));
        int v2036 = (v2035 && (v2034 == UINT64_C(0)));
        int v2037 = ((v2035 && ((v2034 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(20) < ((uint64_t)((uint64_t)in_b_len))));
        int v2038 = (((v2035 && (v2034 != UINT64_C(0))) && (v2034 < UINT64_C(64))) && (((uint64_t)((UINT64_C(19) + v2034) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2041 = ((v1964 == UINT64_C(0)) && (UINT64_C(19) != v1913));
        if (t2041) {
                uint64_t v2039 = v2034;
            int t2040 = (!(((((v2039 | UINT64_C(32)) >= UINT64_C(97)) && ((v2039 | UINT64_C(32)) <= UINT64_C(122))) || ((v2039 >= UINT64_C(48)) && (v2039 <= UINT64_C(57)))) || (v2039 == UINT64_C(45))));
            if (!t2040) {
                t2040 = ((v2034 == UINT64_C(45)) && ((UINT64_C(19) == ((v1947 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(20) == v1913)));
            }
            t2041 = t2040;
        }
        int v2042 = t2041;
        uint64_t v2043 = (v2036 ? UINT64_C(20) : (v2037 ? UINT64_C(21) : v1879));
        uint64_t v2044 = (v2037 ? (((((uint64_t)(v2034 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(20)]))) : v1930);
        uint64_t v2045 = (v2038 ? ((v1896 + UINT64_C(1)) & UINT64_C(255)) : v1896);
        uint64_t v2046 = (v2038 ? UINT64_C(19) : v1947);
        uint64_t v2047 = (v2038 ? ((uint64_t)((UINT64_C(20) + v2034) & UINT64_C(255))) : v1913);
        uint64_t v2048 = ((v2036 || v2037) ? UINT64_C(1) : ((v2042 || (v2035 && (!v2038))) ? UINT64_C(2) : v1964));
        t2049 = v2046;
    } else {
        t2049 = v1947;
    }
    uint64_t v2050 = t2049;
    uint64_t t2066;
    if (v1965) {
        uint64_t v2051 = ((uint64_t)in_b[UINT64_C(19)]);
        int v2052 = ((v1964 == UINT64_C(0)) && (UINT64_C(19) == v1913));
        int v2053 = (v2052 && (v2051 == UINT64_C(0)));
        int v2054 = ((v2052 && ((v2051 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(20) < ((uint64_t)((uint64_t)in_b_len))));
        int v2055 = (((v2052 && (v2051 != UINT64_C(0))) && (v2051 < UINT64_C(64))) && (((uint64_t)((UINT64_C(19) + v2051) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2058 = ((v1964 == UINT64_C(0)) && (UINT64_C(19) != v1913));
        if (t2058) {
                uint64_t v2056 = v2051;
            int t2057 = (!(((((v2056 | UINT64_C(32)) >= UINT64_C(97)) && ((v2056 | UINT64_C(32)) <= UINT64_C(122))) || ((v2056 >= UINT64_C(48)) && (v2056 <= UINT64_C(57)))) || (v2056 == UINT64_C(45))));
            if (!t2057) {
                t2057 = ((v2051 == UINT64_C(45)) && ((UINT64_C(19) == ((v1947 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(20) == v1913)));
            }
            t2058 = t2057;
        }
        int v2059 = t2058;
        uint64_t v2060 = (v2053 ? UINT64_C(20) : (v2054 ? UINT64_C(21) : v1879));
        uint64_t v2061 = (v2054 ? (((((uint64_t)(v2051 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(20)]))) : v1930);
        uint64_t v2062 = (v2055 ? ((v1896 + UINT64_C(1)) & UINT64_C(255)) : v1896);
        uint64_t v2063 = (v2055 ? UINT64_C(19) : v1947);
        uint64_t v2064 = (v2055 ? ((uint64_t)((UINT64_C(20) + v2051) & UINT64_C(255))) : v1913);
        uint64_t v2065 = ((v2053 || v2054) ? UINT64_C(1) : ((v2059 || (v2052 && (!v2055))) ? UINT64_C(2) : v1964));
        t2066 = v2065;
    } else {
        t2066 = v1964;
    }
    uint64_t v2067 = t2066;
    int v2068 = (UINT64_C(20) < v7);
    uint64_t t2084;
    if (v2068) {
        uint64_t v2069 = ((uint64_t)in_b[UINT64_C(20)]);
        int v2070 = ((v2067 == UINT64_C(0)) && (UINT64_C(20) == v2016));
        int v2071 = (v2070 && (v2069 == UINT64_C(0)));
        int v2072 = ((v2070 && ((v2069 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(21) < ((uint64_t)((uint64_t)in_b_len))));
        int v2073 = (((v2070 && (v2069 != UINT64_C(0))) && (v2069 < UINT64_C(64))) && (((uint64_t)((UINT64_C(20) + v2069) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2076 = ((v2067 == UINT64_C(0)) && (UINT64_C(20) != v2016));
        if (t2076) {
                uint64_t v2074 = v2069;
            int t2075 = (!(((((v2074 | UINT64_C(32)) >= UINT64_C(97)) && ((v2074 | UINT64_C(32)) <= UINT64_C(122))) || ((v2074 >= UINT64_C(48)) && (v2074 <= UINT64_C(57)))) || (v2074 == UINT64_C(45))));
            if (!t2075) {
                t2075 = ((v2069 == UINT64_C(45)) && ((UINT64_C(20) == ((v2050 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(21) == v2016)));
            }
            t2076 = t2075;
        }
        int v2077 = t2076;
        uint64_t v2078 = (v2071 ? UINT64_C(21) : (v2072 ? UINT64_C(22) : v1982));
        uint64_t v2079 = (v2072 ? (((((uint64_t)(v2069 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(21)]))) : v2033);
        uint64_t v2080 = (v2073 ? ((v1999 + UINT64_C(1)) & UINT64_C(255)) : v1999);
        uint64_t v2081 = (v2073 ? UINT64_C(20) : v2050);
        uint64_t v2082 = (v2073 ? ((uint64_t)((UINT64_C(21) + v2069) & UINT64_C(255))) : v2016);
        uint64_t v2083 = ((v2071 || v2072) ? UINT64_C(1) : ((v2077 || (v2070 && (!v2073))) ? UINT64_C(2) : v2067));
        t2084 = v2078;
    } else {
        t2084 = v1982;
    }
    uint64_t v2085 = t2084;
    uint64_t t2101;
    if (v2068) {
        uint64_t v2086 = ((uint64_t)in_b[UINT64_C(20)]);
        int v2087 = ((v2067 == UINT64_C(0)) && (UINT64_C(20) == v2016));
        int v2088 = (v2087 && (v2086 == UINT64_C(0)));
        int v2089 = ((v2087 && ((v2086 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(21) < ((uint64_t)((uint64_t)in_b_len))));
        int v2090 = (((v2087 && (v2086 != UINT64_C(0))) && (v2086 < UINT64_C(64))) && (((uint64_t)((UINT64_C(20) + v2086) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2093 = ((v2067 == UINT64_C(0)) && (UINT64_C(20) != v2016));
        if (t2093) {
                uint64_t v2091 = v2086;
            int t2092 = (!(((((v2091 | UINT64_C(32)) >= UINT64_C(97)) && ((v2091 | UINT64_C(32)) <= UINT64_C(122))) || ((v2091 >= UINT64_C(48)) && (v2091 <= UINT64_C(57)))) || (v2091 == UINT64_C(45))));
            if (!t2092) {
                t2092 = ((v2086 == UINT64_C(45)) && ((UINT64_C(20) == ((v2050 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(21) == v2016)));
            }
            t2093 = t2092;
        }
        int v2094 = t2093;
        uint64_t v2095 = (v2088 ? UINT64_C(21) : (v2089 ? UINT64_C(22) : v1982));
        uint64_t v2096 = (v2089 ? (((((uint64_t)(v2086 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(21)]))) : v2033);
        uint64_t v2097 = (v2090 ? ((v1999 + UINT64_C(1)) & UINT64_C(255)) : v1999);
        uint64_t v2098 = (v2090 ? UINT64_C(20) : v2050);
        uint64_t v2099 = (v2090 ? ((uint64_t)((UINT64_C(21) + v2086) & UINT64_C(255))) : v2016);
        uint64_t v2100 = ((v2088 || v2089) ? UINT64_C(1) : ((v2094 || (v2087 && (!v2090))) ? UINT64_C(2) : v2067));
        t2101 = v2097;
    } else {
        t2101 = v1999;
    }
    uint64_t v2102 = t2101;
    uint64_t t2118;
    if (v2068) {
        uint64_t v2103 = ((uint64_t)in_b[UINT64_C(20)]);
        int v2104 = ((v2067 == UINT64_C(0)) && (UINT64_C(20) == v2016));
        int v2105 = (v2104 && (v2103 == UINT64_C(0)));
        int v2106 = ((v2104 && ((v2103 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(21) < ((uint64_t)((uint64_t)in_b_len))));
        int v2107 = (((v2104 && (v2103 != UINT64_C(0))) && (v2103 < UINT64_C(64))) && (((uint64_t)((UINT64_C(20) + v2103) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2110 = ((v2067 == UINT64_C(0)) && (UINT64_C(20) != v2016));
        if (t2110) {
                uint64_t v2108 = v2103;
            int t2109 = (!(((((v2108 | UINT64_C(32)) >= UINT64_C(97)) && ((v2108 | UINT64_C(32)) <= UINT64_C(122))) || ((v2108 >= UINT64_C(48)) && (v2108 <= UINT64_C(57)))) || (v2108 == UINT64_C(45))));
            if (!t2109) {
                t2109 = ((v2103 == UINT64_C(45)) && ((UINT64_C(20) == ((v2050 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(21) == v2016)));
            }
            t2110 = t2109;
        }
        int v2111 = t2110;
        uint64_t v2112 = (v2105 ? UINT64_C(21) : (v2106 ? UINT64_C(22) : v1982));
        uint64_t v2113 = (v2106 ? (((((uint64_t)(v2103 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(21)]))) : v2033);
        uint64_t v2114 = (v2107 ? ((v1999 + UINT64_C(1)) & UINT64_C(255)) : v1999);
        uint64_t v2115 = (v2107 ? UINT64_C(20) : v2050);
        uint64_t v2116 = (v2107 ? ((uint64_t)((UINT64_C(21) + v2103) & UINT64_C(255))) : v2016);
        uint64_t v2117 = ((v2105 || v2106) ? UINT64_C(1) : ((v2111 || (v2104 && (!v2107))) ? UINT64_C(2) : v2067));
        t2118 = v2116;
    } else {
        t2118 = v2016;
    }
    uint64_t v2119 = t2118;
    uint64_t t2135;
    if (v2068) {
        uint64_t v2120 = ((uint64_t)in_b[UINT64_C(20)]);
        int v2121 = ((v2067 == UINT64_C(0)) && (UINT64_C(20) == v2016));
        int v2122 = (v2121 && (v2120 == UINT64_C(0)));
        int v2123 = ((v2121 && ((v2120 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(21) < ((uint64_t)((uint64_t)in_b_len))));
        int v2124 = (((v2121 && (v2120 != UINT64_C(0))) && (v2120 < UINT64_C(64))) && (((uint64_t)((UINT64_C(20) + v2120) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2127 = ((v2067 == UINT64_C(0)) && (UINT64_C(20) != v2016));
        if (t2127) {
                uint64_t v2125 = v2120;
            int t2126 = (!(((((v2125 | UINT64_C(32)) >= UINT64_C(97)) && ((v2125 | UINT64_C(32)) <= UINT64_C(122))) || ((v2125 >= UINT64_C(48)) && (v2125 <= UINT64_C(57)))) || (v2125 == UINT64_C(45))));
            if (!t2126) {
                t2126 = ((v2120 == UINT64_C(45)) && ((UINT64_C(20) == ((v2050 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(21) == v2016)));
            }
            t2127 = t2126;
        }
        int v2128 = t2127;
        uint64_t v2129 = (v2122 ? UINT64_C(21) : (v2123 ? UINT64_C(22) : v1982));
        uint64_t v2130 = (v2123 ? (((((uint64_t)(v2120 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(21)]))) : v2033);
        uint64_t v2131 = (v2124 ? ((v1999 + UINT64_C(1)) & UINT64_C(255)) : v1999);
        uint64_t v2132 = (v2124 ? UINT64_C(20) : v2050);
        uint64_t v2133 = (v2124 ? ((uint64_t)((UINT64_C(21) + v2120) & UINT64_C(255))) : v2016);
        uint64_t v2134 = ((v2122 || v2123) ? UINT64_C(1) : ((v2128 || (v2121 && (!v2124))) ? UINT64_C(2) : v2067));
        t2135 = v2130;
    } else {
        t2135 = v2033;
    }
    uint64_t v2136 = t2135;
    uint64_t t2152;
    if (v2068) {
        uint64_t v2137 = ((uint64_t)in_b[UINT64_C(20)]);
        int v2138 = ((v2067 == UINT64_C(0)) && (UINT64_C(20) == v2016));
        int v2139 = (v2138 && (v2137 == UINT64_C(0)));
        int v2140 = ((v2138 && ((v2137 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(21) < ((uint64_t)((uint64_t)in_b_len))));
        int v2141 = (((v2138 && (v2137 != UINT64_C(0))) && (v2137 < UINT64_C(64))) && (((uint64_t)((UINT64_C(20) + v2137) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2144 = ((v2067 == UINT64_C(0)) && (UINT64_C(20) != v2016));
        if (t2144) {
                uint64_t v2142 = v2137;
            int t2143 = (!(((((v2142 | UINT64_C(32)) >= UINT64_C(97)) && ((v2142 | UINT64_C(32)) <= UINT64_C(122))) || ((v2142 >= UINT64_C(48)) && (v2142 <= UINT64_C(57)))) || (v2142 == UINT64_C(45))));
            if (!t2143) {
                t2143 = ((v2137 == UINT64_C(45)) && ((UINT64_C(20) == ((v2050 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(21) == v2016)));
            }
            t2144 = t2143;
        }
        int v2145 = t2144;
        uint64_t v2146 = (v2139 ? UINT64_C(21) : (v2140 ? UINT64_C(22) : v1982));
        uint64_t v2147 = (v2140 ? (((((uint64_t)(v2137 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(21)]))) : v2033);
        uint64_t v2148 = (v2141 ? ((v1999 + UINT64_C(1)) & UINT64_C(255)) : v1999);
        uint64_t v2149 = (v2141 ? UINT64_C(20) : v2050);
        uint64_t v2150 = (v2141 ? ((uint64_t)((UINT64_C(21) + v2137) & UINT64_C(255))) : v2016);
        uint64_t v2151 = ((v2139 || v2140) ? UINT64_C(1) : ((v2145 || (v2138 && (!v2141))) ? UINT64_C(2) : v2067));
        t2152 = v2149;
    } else {
        t2152 = v2050;
    }
    uint64_t v2153 = t2152;
    uint64_t t2169;
    if (v2068) {
        uint64_t v2154 = ((uint64_t)in_b[UINT64_C(20)]);
        int v2155 = ((v2067 == UINT64_C(0)) && (UINT64_C(20) == v2016));
        int v2156 = (v2155 && (v2154 == UINT64_C(0)));
        int v2157 = ((v2155 && ((v2154 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(21) < ((uint64_t)((uint64_t)in_b_len))));
        int v2158 = (((v2155 && (v2154 != UINT64_C(0))) && (v2154 < UINT64_C(64))) && (((uint64_t)((UINT64_C(20) + v2154) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2161 = ((v2067 == UINT64_C(0)) && (UINT64_C(20) != v2016));
        if (t2161) {
                uint64_t v2159 = v2154;
            int t2160 = (!(((((v2159 | UINT64_C(32)) >= UINT64_C(97)) && ((v2159 | UINT64_C(32)) <= UINT64_C(122))) || ((v2159 >= UINT64_C(48)) && (v2159 <= UINT64_C(57)))) || (v2159 == UINT64_C(45))));
            if (!t2160) {
                t2160 = ((v2154 == UINT64_C(45)) && ((UINT64_C(20) == ((v2050 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(21) == v2016)));
            }
            t2161 = t2160;
        }
        int v2162 = t2161;
        uint64_t v2163 = (v2156 ? UINT64_C(21) : (v2157 ? UINT64_C(22) : v1982));
        uint64_t v2164 = (v2157 ? (((((uint64_t)(v2154 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(21)]))) : v2033);
        uint64_t v2165 = (v2158 ? ((v1999 + UINT64_C(1)) & UINT64_C(255)) : v1999);
        uint64_t v2166 = (v2158 ? UINT64_C(20) : v2050);
        uint64_t v2167 = (v2158 ? ((uint64_t)((UINT64_C(21) + v2154) & UINT64_C(255))) : v2016);
        uint64_t v2168 = ((v2156 || v2157) ? UINT64_C(1) : ((v2162 || (v2155 && (!v2158))) ? UINT64_C(2) : v2067));
        t2169 = v2168;
    } else {
        t2169 = v2067;
    }
    uint64_t v2170 = t2169;
    int v2171 = (UINT64_C(21) < v7);
    uint64_t t2187;
    if (v2171) {
        uint64_t v2172 = ((uint64_t)in_b[UINT64_C(21)]);
        int v2173 = ((v2170 == UINT64_C(0)) && (UINT64_C(21) == v2119));
        int v2174 = (v2173 && (v2172 == UINT64_C(0)));
        int v2175 = ((v2173 && ((v2172 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(22) < ((uint64_t)((uint64_t)in_b_len))));
        int v2176 = (((v2173 && (v2172 != UINT64_C(0))) && (v2172 < UINT64_C(64))) && (((uint64_t)((UINT64_C(21) + v2172) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2179 = ((v2170 == UINT64_C(0)) && (UINT64_C(21) != v2119));
        if (t2179) {
                uint64_t v2177 = v2172;
            int t2178 = (!(((((v2177 | UINT64_C(32)) >= UINT64_C(97)) && ((v2177 | UINT64_C(32)) <= UINT64_C(122))) || ((v2177 >= UINT64_C(48)) && (v2177 <= UINT64_C(57)))) || (v2177 == UINT64_C(45))));
            if (!t2178) {
                t2178 = ((v2172 == UINT64_C(45)) && ((UINT64_C(21) == ((v2153 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(22) == v2119)));
            }
            t2179 = t2178;
        }
        int v2180 = t2179;
        uint64_t v2181 = (v2174 ? UINT64_C(22) : (v2175 ? UINT64_C(23) : v2085));
        uint64_t v2182 = (v2175 ? (((((uint64_t)(v2172 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(22)]))) : v2136);
        uint64_t v2183 = (v2176 ? ((v2102 + UINT64_C(1)) & UINT64_C(255)) : v2102);
        uint64_t v2184 = (v2176 ? UINT64_C(21) : v2153);
        uint64_t v2185 = (v2176 ? ((uint64_t)((UINT64_C(22) + v2172) & UINT64_C(255))) : v2119);
        uint64_t v2186 = ((v2174 || v2175) ? UINT64_C(1) : ((v2180 || (v2173 && (!v2176))) ? UINT64_C(2) : v2170));
        t2187 = v2181;
    } else {
        t2187 = v2085;
    }
    uint64_t v2188 = t2187;
    uint64_t t2204;
    if (v2171) {
        uint64_t v2189 = ((uint64_t)in_b[UINT64_C(21)]);
        int v2190 = ((v2170 == UINT64_C(0)) && (UINT64_C(21) == v2119));
        int v2191 = (v2190 && (v2189 == UINT64_C(0)));
        int v2192 = ((v2190 && ((v2189 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(22) < ((uint64_t)((uint64_t)in_b_len))));
        int v2193 = (((v2190 && (v2189 != UINT64_C(0))) && (v2189 < UINT64_C(64))) && (((uint64_t)((UINT64_C(21) + v2189) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2196 = ((v2170 == UINT64_C(0)) && (UINT64_C(21) != v2119));
        if (t2196) {
                uint64_t v2194 = v2189;
            int t2195 = (!(((((v2194 | UINT64_C(32)) >= UINT64_C(97)) && ((v2194 | UINT64_C(32)) <= UINT64_C(122))) || ((v2194 >= UINT64_C(48)) && (v2194 <= UINT64_C(57)))) || (v2194 == UINT64_C(45))));
            if (!t2195) {
                t2195 = ((v2189 == UINT64_C(45)) && ((UINT64_C(21) == ((v2153 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(22) == v2119)));
            }
            t2196 = t2195;
        }
        int v2197 = t2196;
        uint64_t v2198 = (v2191 ? UINT64_C(22) : (v2192 ? UINT64_C(23) : v2085));
        uint64_t v2199 = (v2192 ? (((((uint64_t)(v2189 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(22)]))) : v2136);
        uint64_t v2200 = (v2193 ? ((v2102 + UINT64_C(1)) & UINT64_C(255)) : v2102);
        uint64_t v2201 = (v2193 ? UINT64_C(21) : v2153);
        uint64_t v2202 = (v2193 ? ((uint64_t)((UINT64_C(22) + v2189) & UINT64_C(255))) : v2119);
        uint64_t v2203 = ((v2191 || v2192) ? UINT64_C(1) : ((v2197 || (v2190 && (!v2193))) ? UINT64_C(2) : v2170));
        t2204 = v2200;
    } else {
        t2204 = v2102;
    }
    uint64_t v2205 = t2204;
    uint64_t t2221;
    if (v2171) {
        uint64_t v2206 = ((uint64_t)in_b[UINT64_C(21)]);
        int v2207 = ((v2170 == UINT64_C(0)) && (UINT64_C(21) == v2119));
        int v2208 = (v2207 && (v2206 == UINT64_C(0)));
        int v2209 = ((v2207 && ((v2206 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(22) < ((uint64_t)((uint64_t)in_b_len))));
        int v2210 = (((v2207 && (v2206 != UINT64_C(0))) && (v2206 < UINT64_C(64))) && (((uint64_t)((UINT64_C(21) + v2206) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2213 = ((v2170 == UINT64_C(0)) && (UINT64_C(21) != v2119));
        if (t2213) {
                uint64_t v2211 = v2206;
            int t2212 = (!(((((v2211 | UINT64_C(32)) >= UINT64_C(97)) && ((v2211 | UINT64_C(32)) <= UINT64_C(122))) || ((v2211 >= UINT64_C(48)) && (v2211 <= UINT64_C(57)))) || (v2211 == UINT64_C(45))));
            if (!t2212) {
                t2212 = ((v2206 == UINT64_C(45)) && ((UINT64_C(21) == ((v2153 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(22) == v2119)));
            }
            t2213 = t2212;
        }
        int v2214 = t2213;
        uint64_t v2215 = (v2208 ? UINT64_C(22) : (v2209 ? UINT64_C(23) : v2085));
        uint64_t v2216 = (v2209 ? (((((uint64_t)(v2206 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(22)]))) : v2136);
        uint64_t v2217 = (v2210 ? ((v2102 + UINT64_C(1)) & UINT64_C(255)) : v2102);
        uint64_t v2218 = (v2210 ? UINT64_C(21) : v2153);
        uint64_t v2219 = (v2210 ? ((uint64_t)((UINT64_C(22) + v2206) & UINT64_C(255))) : v2119);
        uint64_t v2220 = ((v2208 || v2209) ? UINT64_C(1) : ((v2214 || (v2207 && (!v2210))) ? UINT64_C(2) : v2170));
        t2221 = v2219;
    } else {
        t2221 = v2119;
    }
    uint64_t v2222 = t2221;
    uint64_t t2238;
    if (v2171) {
        uint64_t v2223 = ((uint64_t)in_b[UINT64_C(21)]);
        int v2224 = ((v2170 == UINT64_C(0)) && (UINT64_C(21) == v2119));
        int v2225 = (v2224 && (v2223 == UINT64_C(0)));
        int v2226 = ((v2224 && ((v2223 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(22) < ((uint64_t)((uint64_t)in_b_len))));
        int v2227 = (((v2224 && (v2223 != UINT64_C(0))) && (v2223 < UINT64_C(64))) && (((uint64_t)((UINT64_C(21) + v2223) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2230 = ((v2170 == UINT64_C(0)) && (UINT64_C(21) != v2119));
        if (t2230) {
                uint64_t v2228 = v2223;
            int t2229 = (!(((((v2228 | UINT64_C(32)) >= UINT64_C(97)) && ((v2228 | UINT64_C(32)) <= UINT64_C(122))) || ((v2228 >= UINT64_C(48)) && (v2228 <= UINT64_C(57)))) || (v2228 == UINT64_C(45))));
            if (!t2229) {
                t2229 = ((v2223 == UINT64_C(45)) && ((UINT64_C(21) == ((v2153 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(22) == v2119)));
            }
            t2230 = t2229;
        }
        int v2231 = t2230;
        uint64_t v2232 = (v2225 ? UINT64_C(22) : (v2226 ? UINT64_C(23) : v2085));
        uint64_t v2233 = (v2226 ? (((((uint64_t)(v2223 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(22)]))) : v2136);
        uint64_t v2234 = (v2227 ? ((v2102 + UINT64_C(1)) & UINT64_C(255)) : v2102);
        uint64_t v2235 = (v2227 ? UINT64_C(21) : v2153);
        uint64_t v2236 = (v2227 ? ((uint64_t)((UINT64_C(22) + v2223) & UINT64_C(255))) : v2119);
        uint64_t v2237 = ((v2225 || v2226) ? UINT64_C(1) : ((v2231 || (v2224 && (!v2227))) ? UINT64_C(2) : v2170));
        t2238 = v2233;
    } else {
        t2238 = v2136;
    }
    uint64_t v2239 = t2238;
    uint64_t t2255;
    if (v2171) {
        uint64_t v2240 = ((uint64_t)in_b[UINT64_C(21)]);
        int v2241 = ((v2170 == UINT64_C(0)) && (UINT64_C(21) == v2119));
        int v2242 = (v2241 && (v2240 == UINT64_C(0)));
        int v2243 = ((v2241 && ((v2240 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(22) < ((uint64_t)((uint64_t)in_b_len))));
        int v2244 = (((v2241 && (v2240 != UINT64_C(0))) && (v2240 < UINT64_C(64))) && (((uint64_t)((UINT64_C(21) + v2240) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2247 = ((v2170 == UINT64_C(0)) && (UINT64_C(21) != v2119));
        if (t2247) {
                uint64_t v2245 = v2240;
            int t2246 = (!(((((v2245 | UINT64_C(32)) >= UINT64_C(97)) && ((v2245 | UINT64_C(32)) <= UINT64_C(122))) || ((v2245 >= UINT64_C(48)) && (v2245 <= UINT64_C(57)))) || (v2245 == UINT64_C(45))));
            if (!t2246) {
                t2246 = ((v2240 == UINT64_C(45)) && ((UINT64_C(21) == ((v2153 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(22) == v2119)));
            }
            t2247 = t2246;
        }
        int v2248 = t2247;
        uint64_t v2249 = (v2242 ? UINT64_C(22) : (v2243 ? UINT64_C(23) : v2085));
        uint64_t v2250 = (v2243 ? (((((uint64_t)(v2240 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(22)]))) : v2136);
        uint64_t v2251 = (v2244 ? ((v2102 + UINT64_C(1)) & UINT64_C(255)) : v2102);
        uint64_t v2252 = (v2244 ? UINT64_C(21) : v2153);
        uint64_t v2253 = (v2244 ? ((uint64_t)((UINT64_C(22) + v2240) & UINT64_C(255))) : v2119);
        uint64_t v2254 = ((v2242 || v2243) ? UINT64_C(1) : ((v2248 || (v2241 && (!v2244))) ? UINT64_C(2) : v2170));
        t2255 = v2252;
    } else {
        t2255 = v2153;
    }
    uint64_t v2256 = t2255;
    uint64_t t2272;
    if (v2171) {
        uint64_t v2257 = ((uint64_t)in_b[UINT64_C(21)]);
        int v2258 = ((v2170 == UINT64_C(0)) && (UINT64_C(21) == v2119));
        int v2259 = (v2258 && (v2257 == UINT64_C(0)));
        int v2260 = ((v2258 && ((v2257 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(22) < ((uint64_t)((uint64_t)in_b_len))));
        int v2261 = (((v2258 && (v2257 != UINT64_C(0))) && (v2257 < UINT64_C(64))) && (((uint64_t)((UINT64_C(21) + v2257) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2264 = ((v2170 == UINT64_C(0)) && (UINT64_C(21) != v2119));
        if (t2264) {
                uint64_t v2262 = v2257;
            int t2263 = (!(((((v2262 | UINT64_C(32)) >= UINT64_C(97)) && ((v2262 | UINT64_C(32)) <= UINT64_C(122))) || ((v2262 >= UINT64_C(48)) && (v2262 <= UINT64_C(57)))) || (v2262 == UINT64_C(45))));
            if (!t2263) {
                t2263 = ((v2257 == UINT64_C(45)) && ((UINT64_C(21) == ((v2153 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(22) == v2119)));
            }
            t2264 = t2263;
        }
        int v2265 = t2264;
        uint64_t v2266 = (v2259 ? UINT64_C(22) : (v2260 ? UINT64_C(23) : v2085));
        uint64_t v2267 = (v2260 ? (((((uint64_t)(v2257 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(22)]))) : v2136);
        uint64_t v2268 = (v2261 ? ((v2102 + UINT64_C(1)) & UINT64_C(255)) : v2102);
        uint64_t v2269 = (v2261 ? UINT64_C(21) : v2153);
        uint64_t v2270 = (v2261 ? ((uint64_t)((UINT64_C(22) + v2257) & UINT64_C(255))) : v2119);
        uint64_t v2271 = ((v2259 || v2260) ? UINT64_C(1) : ((v2265 || (v2258 && (!v2261))) ? UINT64_C(2) : v2170));
        t2272 = v2271;
    } else {
        t2272 = v2170;
    }
    uint64_t v2273 = t2272;
    int v2274 = (UINT64_C(22) < v7);
    uint64_t t2290;
    if (v2274) {
        uint64_t v2275 = ((uint64_t)in_b[UINT64_C(22)]);
        int v2276 = ((v2273 == UINT64_C(0)) && (UINT64_C(22) == v2222));
        int v2277 = (v2276 && (v2275 == UINT64_C(0)));
        int v2278 = ((v2276 && ((v2275 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(23) < ((uint64_t)((uint64_t)in_b_len))));
        int v2279 = (((v2276 && (v2275 != UINT64_C(0))) && (v2275 < UINT64_C(64))) && (((uint64_t)((UINT64_C(22) + v2275) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2282 = ((v2273 == UINT64_C(0)) && (UINT64_C(22) != v2222));
        if (t2282) {
                uint64_t v2280 = v2275;
            int t2281 = (!(((((v2280 | UINT64_C(32)) >= UINT64_C(97)) && ((v2280 | UINT64_C(32)) <= UINT64_C(122))) || ((v2280 >= UINT64_C(48)) && (v2280 <= UINT64_C(57)))) || (v2280 == UINT64_C(45))));
            if (!t2281) {
                t2281 = ((v2275 == UINT64_C(45)) && ((UINT64_C(22) == ((v2256 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(23) == v2222)));
            }
            t2282 = t2281;
        }
        int v2283 = t2282;
        uint64_t v2284 = (v2277 ? UINT64_C(23) : (v2278 ? UINT64_C(24) : v2188));
        uint64_t v2285 = (v2278 ? (((((uint64_t)(v2275 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(23)]))) : v2239);
        uint64_t v2286 = (v2279 ? ((v2205 + UINT64_C(1)) & UINT64_C(255)) : v2205);
        uint64_t v2287 = (v2279 ? UINT64_C(22) : v2256);
        uint64_t v2288 = (v2279 ? ((uint64_t)((UINT64_C(23) + v2275) & UINT64_C(255))) : v2222);
        uint64_t v2289 = ((v2277 || v2278) ? UINT64_C(1) : ((v2283 || (v2276 && (!v2279))) ? UINT64_C(2) : v2273));
        t2290 = v2284;
    } else {
        t2290 = v2188;
    }
    uint64_t v2291 = t2290;
    uint64_t t2307;
    if (v2274) {
        uint64_t v2292 = ((uint64_t)in_b[UINT64_C(22)]);
        int v2293 = ((v2273 == UINT64_C(0)) && (UINT64_C(22) == v2222));
        int v2294 = (v2293 && (v2292 == UINT64_C(0)));
        int v2295 = ((v2293 && ((v2292 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(23) < ((uint64_t)((uint64_t)in_b_len))));
        int v2296 = (((v2293 && (v2292 != UINT64_C(0))) && (v2292 < UINT64_C(64))) && (((uint64_t)((UINT64_C(22) + v2292) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2299 = ((v2273 == UINT64_C(0)) && (UINT64_C(22) != v2222));
        if (t2299) {
                uint64_t v2297 = v2292;
            int t2298 = (!(((((v2297 | UINT64_C(32)) >= UINT64_C(97)) && ((v2297 | UINT64_C(32)) <= UINT64_C(122))) || ((v2297 >= UINT64_C(48)) && (v2297 <= UINT64_C(57)))) || (v2297 == UINT64_C(45))));
            if (!t2298) {
                t2298 = ((v2292 == UINT64_C(45)) && ((UINT64_C(22) == ((v2256 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(23) == v2222)));
            }
            t2299 = t2298;
        }
        int v2300 = t2299;
        uint64_t v2301 = (v2294 ? UINT64_C(23) : (v2295 ? UINT64_C(24) : v2188));
        uint64_t v2302 = (v2295 ? (((((uint64_t)(v2292 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(23)]))) : v2239);
        uint64_t v2303 = (v2296 ? ((v2205 + UINT64_C(1)) & UINT64_C(255)) : v2205);
        uint64_t v2304 = (v2296 ? UINT64_C(22) : v2256);
        uint64_t v2305 = (v2296 ? ((uint64_t)((UINT64_C(23) + v2292) & UINT64_C(255))) : v2222);
        uint64_t v2306 = ((v2294 || v2295) ? UINT64_C(1) : ((v2300 || (v2293 && (!v2296))) ? UINT64_C(2) : v2273));
        t2307 = v2303;
    } else {
        t2307 = v2205;
    }
    uint64_t v2308 = t2307;
    uint64_t t2324;
    if (v2274) {
        uint64_t v2309 = ((uint64_t)in_b[UINT64_C(22)]);
        int v2310 = ((v2273 == UINT64_C(0)) && (UINT64_C(22) == v2222));
        int v2311 = (v2310 && (v2309 == UINT64_C(0)));
        int v2312 = ((v2310 && ((v2309 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(23) < ((uint64_t)((uint64_t)in_b_len))));
        int v2313 = (((v2310 && (v2309 != UINT64_C(0))) && (v2309 < UINT64_C(64))) && (((uint64_t)((UINT64_C(22) + v2309) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2316 = ((v2273 == UINT64_C(0)) && (UINT64_C(22) != v2222));
        if (t2316) {
                uint64_t v2314 = v2309;
            int t2315 = (!(((((v2314 | UINT64_C(32)) >= UINT64_C(97)) && ((v2314 | UINT64_C(32)) <= UINT64_C(122))) || ((v2314 >= UINT64_C(48)) && (v2314 <= UINT64_C(57)))) || (v2314 == UINT64_C(45))));
            if (!t2315) {
                t2315 = ((v2309 == UINT64_C(45)) && ((UINT64_C(22) == ((v2256 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(23) == v2222)));
            }
            t2316 = t2315;
        }
        int v2317 = t2316;
        uint64_t v2318 = (v2311 ? UINT64_C(23) : (v2312 ? UINT64_C(24) : v2188));
        uint64_t v2319 = (v2312 ? (((((uint64_t)(v2309 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(23)]))) : v2239);
        uint64_t v2320 = (v2313 ? ((v2205 + UINT64_C(1)) & UINT64_C(255)) : v2205);
        uint64_t v2321 = (v2313 ? UINT64_C(22) : v2256);
        uint64_t v2322 = (v2313 ? ((uint64_t)((UINT64_C(23) + v2309) & UINT64_C(255))) : v2222);
        uint64_t v2323 = ((v2311 || v2312) ? UINT64_C(1) : ((v2317 || (v2310 && (!v2313))) ? UINT64_C(2) : v2273));
        t2324 = v2322;
    } else {
        t2324 = v2222;
    }
    uint64_t v2325 = t2324;
    uint64_t t2341;
    if (v2274) {
        uint64_t v2326 = ((uint64_t)in_b[UINT64_C(22)]);
        int v2327 = ((v2273 == UINT64_C(0)) && (UINT64_C(22) == v2222));
        int v2328 = (v2327 && (v2326 == UINT64_C(0)));
        int v2329 = ((v2327 && ((v2326 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(23) < ((uint64_t)((uint64_t)in_b_len))));
        int v2330 = (((v2327 && (v2326 != UINT64_C(0))) && (v2326 < UINT64_C(64))) && (((uint64_t)((UINT64_C(22) + v2326) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2333 = ((v2273 == UINT64_C(0)) && (UINT64_C(22) != v2222));
        if (t2333) {
                uint64_t v2331 = v2326;
            int t2332 = (!(((((v2331 | UINT64_C(32)) >= UINT64_C(97)) && ((v2331 | UINT64_C(32)) <= UINT64_C(122))) || ((v2331 >= UINT64_C(48)) && (v2331 <= UINT64_C(57)))) || (v2331 == UINT64_C(45))));
            if (!t2332) {
                t2332 = ((v2326 == UINT64_C(45)) && ((UINT64_C(22) == ((v2256 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(23) == v2222)));
            }
            t2333 = t2332;
        }
        int v2334 = t2333;
        uint64_t v2335 = (v2328 ? UINT64_C(23) : (v2329 ? UINT64_C(24) : v2188));
        uint64_t v2336 = (v2329 ? (((((uint64_t)(v2326 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(23)]))) : v2239);
        uint64_t v2337 = (v2330 ? ((v2205 + UINT64_C(1)) & UINT64_C(255)) : v2205);
        uint64_t v2338 = (v2330 ? UINT64_C(22) : v2256);
        uint64_t v2339 = (v2330 ? ((uint64_t)((UINT64_C(23) + v2326) & UINT64_C(255))) : v2222);
        uint64_t v2340 = ((v2328 || v2329) ? UINT64_C(1) : ((v2334 || (v2327 && (!v2330))) ? UINT64_C(2) : v2273));
        t2341 = v2336;
    } else {
        t2341 = v2239;
    }
    uint64_t v2342 = t2341;
    uint64_t t2358;
    if (v2274) {
        uint64_t v2343 = ((uint64_t)in_b[UINT64_C(22)]);
        int v2344 = ((v2273 == UINT64_C(0)) && (UINT64_C(22) == v2222));
        int v2345 = (v2344 && (v2343 == UINT64_C(0)));
        int v2346 = ((v2344 && ((v2343 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(23) < ((uint64_t)((uint64_t)in_b_len))));
        int v2347 = (((v2344 && (v2343 != UINT64_C(0))) && (v2343 < UINT64_C(64))) && (((uint64_t)((UINT64_C(22) + v2343) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2350 = ((v2273 == UINT64_C(0)) && (UINT64_C(22) != v2222));
        if (t2350) {
                uint64_t v2348 = v2343;
            int t2349 = (!(((((v2348 | UINT64_C(32)) >= UINT64_C(97)) && ((v2348 | UINT64_C(32)) <= UINT64_C(122))) || ((v2348 >= UINT64_C(48)) && (v2348 <= UINT64_C(57)))) || (v2348 == UINT64_C(45))));
            if (!t2349) {
                t2349 = ((v2343 == UINT64_C(45)) && ((UINT64_C(22) == ((v2256 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(23) == v2222)));
            }
            t2350 = t2349;
        }
        int v2351 = t2350;
        uint64_t v2352 = (v2345 ? UINT64_C(23) : (v2346 ? UINT64_C(24) : v2188));
        uint64_t v2353 = (v2346 ? (((((uint64_t)(v2343 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(23)]))) : v2239);
        uint64_t v2354 = (v2347 ? ((v2205 + UINT64_C(1)) & UINT64_C(255)) : v2205);
        uint64_t v2355 = (v2347 ? UINT64_C(22) : v2256);
        uint64_t v2356 = (v2347 ? ((uint64_t)((UINT64_C(23) + v2343) & UINT64_C(255))) : v2222);
        uint64_t v2357 = ((v2345 || v2346) ? UINT64_C(1) : ((v2351 || (v2344 && (!v2347))) ? UINT64_C(2) : v2273));
        t2358 = v2355;
    } else {
        t2358 = v2256;
    }
    uint64_t v2359 = t2358;
    uint64_t t2375;
    if (v2274) {
        uint64_t v2360 = ((uint64_t)in_b[UINT64_C(22)]);
        int v2361 = ((v2273 == UINT64_C(0)) && (UINT64_C(22) == v2222));
        int v2362 = (v2361 && (v2360 == UINT64_C(0)));
        int v2363 = ((v2361 && ((v2360 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(23) < ((uint64_t)((uint64_t)in_b_len))));
        int v2364 = (((v2361 && (v2360 != UINT64_C(0))) && (v2360 < UINT64_C(64))) && (((uint64_t)((UINT64_C(22) + v2360) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2367 = ((v2273 == UINT64_C(0)) && (UINT64_C(22) != v2222));
        if (t2367) {
                uint64_t v2365 = v2360;
            int t2366 = (!(((((v2365 | UINT64_C(32)) >= UINT64_C(97)) && ((v2365 | UINT64_C(32)) <= UINT64_C(122))) || ((v2365 >= UINT64_C(48)) && (v2365 <= UINT64_C(57)))) || (v2365 == UINT64_C(45))));
            if (!t2366) {
                t2366 = ((v2360 == UINT64_C(45)) && ((UINT64_C(22) == ((v2256 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(23) == v2222)));
            }
            t2367 = t2366;
        }
        int v2368 = t2367;
        uint64_t v2369 = (v2362 ? UINT64_C(23) : (v2363 ? UINT64_C(24) : v2188));
        uint64_t v2370 = (v2363 ? (((((uint64_t)(v2360 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(23)]))) : v2239);
        uint64_t v2371 = (v2364 ? ((v2205 + UINT64_C(1)) & UINT64_C(255)) : v2205);
        uint64_t v2372 = (v2364 ? UINT64_C(22) : v2256);
        uint64_t v2373 = (v2364 ? ((uint64_t)((UINT64_C(23) + v2360) & UINT64_C(255))) : v2222);
        uint64_t v2374 = ((v2362 || v2363) ? UINT64_C(1) : ((v2368 || (v2361 && (!v2364))) ? UINT64_C(2) : v2273));
        t2375 = v2374;
    } else {
        t2375 = v2273;
    }
    uint64_t v2376 = t2375;
    int v2377 = (UINT64_C(23) < v7);
    uint64_t t2393;
    if (v2377) {
        uint64_t v2378 = ((uint64_t)in_b[UINT64_C(23)]);
        int v2379 = ((v2376 == UINT64_C(0)) && (UINT64_C(23) == v2325));
        int v2380 = (v2379 && (v2378 == UINT64_C(0)));
        int v2381 = ((v2379 && ((v2378 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(24) < ((uint64_t)((uint64_t)in_b_len))));
        int v2382 = (((v2379 && (v2378 != UINT64_C(0))) && (v2378 < UINT64_C(64))) && (((uint64_t)((UINT64_C(23) + v2378) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2385 = ((v2376 == UINT64_C(0)) && (UINT64_C(23) != v2325));
        if (t2385) {
                uint64_t v2383 = v2378;
            int t2384 = (!(((((v2383 | UINT64_C(32)) >= UINT64_C(97)) && ((v2383 | UINT64_C(32)) <= UINT64_C(122))) || ((v2383 >= UINT64_C(48)) && (v2383 <= UINT64_C(57)))) || (v2383 == UINT64_C(45))));
            if (!t2384) {
                t2384 = ((v2378 == UINT64_C(45)) && ((UINT64_C(23) == ((v2359 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(24) == v2325)));
            }
            t2385 = t2384;
        }
        int v2386 = t2385;
        uint64_t v2387 = (v2380 ? UINT64_C(24) : (v2381 ? UINT64_C(25) : v2291));
        uint64_t v2388 = (v2381 ? (((((uint64_t)(v2378 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(24)]))) : v2342);
        uint64_t v2389 = (v2382 ? ((v2308 + UINT64_C(1)) & UINT64_C(255)) : v2308);
        uint64_t v2390 = (v2382 ? UINT64_C(23) : v2359);
        uint64_t v2391 = (v2382 ? ((uint64_t)((UINT64_C(24) + v2378) & UINT64_C(255))) : v2325);
        uint64_t v2392 = ((v2380 || v2381) ? UINT64_C(1) : ((v2386 || (v2379 && (!v2382))) ? UINT64_C(2) : v2376));
        t2393 = v2387;
    } else {
        t2393 = v2291;
    }
    uint64_t v2394 = t2393;
    uint64_t t2410;
    if (v2377) {
        uint64_t v2395 = ((uint64_t)in_b[UINT64_C(23)]);
        int v2396 = ((v2376 == UINT64_C(0)) && (UINT64_C(23) == v2325));
        int v2397 = (v2396 && (v2395 == UINT64_C(0)));
        int v2398 = ((v2396 && ((v2395 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(24) < ((uint64_t)((uint64_t)in_b_len))));
        int v2399 = (((v2396 && (v2395 != UINT64_C(0))) && (v2395 < UINT64_C(64))) && (((uint64_t)((UINT64_C(23) + v2395) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2402 = ((v2376 == UINT64_C(0)) && (UINT64_C(23) != v2325));
        if (t2402) {
                uint64_t v2400 = v2395;
            int t2401 = (!(((((v2400 | UINT64_C(32)) >= UINT64_C(97)) && ((v2400 | UINT64_C(32)) <= UINT64_C(122))) || ((v2400 >= UINT64_C(48)) && (v2400 <= UINT64_C(57)))) || (v2400 == UINT64_C(45))));
            if (!t2401) {
                t2401 = ((v2395 == UINT64_C(45)) && ((UINT64_C(23) == ((v2359 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(24) == v2325)));
            }
            t2402 = t2401;
        }
        int v2403 = t2402;
        uint64_t v2404 = (v2397 ? UINT64_C(24) : (v2398 ? UINT64_C(25) : v2291));
        uint64_t v2405 = (v2398 ? (((((uint64_t)(v2395 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(24)]))) : v2342);
        uint64_t v2406 = (v2399 ? ((v2308 + UINT64_C(1)) & UINT64_C(255)) : v2308);
        uint64_t v2407 = (v2399 ? UINT64_C(23) : v2359);
        uint64_t v2408 = (v2399 ? ((uint64_t)((UINT64_C(24) + v2395) & UINT64_C(255))) : v2325);
        uint64_t v2409 = ((v2397 || v2398) ? UINT64_C(1) : ((v2403 || (v2396 && (!v2399))) ? UINT64_C(2) : v2376));
        t2410 = v2406;
    } else {
        t2410 = v2308;
    }
    uint64_t v2411 = t2410;
    uint64_t t2427;
    if (v2377) {
        uint64_t v2412 = ((uint64_t)in_b[UINT64_C(23)]);
        int v2413 = ((v2376 == UINT64_C(0)) && (UINT64_C(23) == v2325));
        int v2414 = (v2413 && (v2412 == UINT64_C(0)));
        int v2415 = ((v2413 && ((v2412 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(24) < ((uint64_t)((uint64_t)in_b_len))));
        int v2416 = (((v2413 && (v2412 != UINT64_C(0))) && (v2412 < UINT64_C(64))) && (((uint64_t)((UINT64_C(23) + v2412) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2419 = ((v2376 == UINT64_C(0)) && (UINT64_C(23) != v2325));
        if (t2419) {
                uint64_t v2417 = v2412;
            int t2418 = (!(((((v2417 | UINT64_C(32)) >= UINT64_C(97)) && ((v2417 | UINT64_C(32)) <= UINT64_C(122))) || ((v2417 >= UINT64_C(48)) && (v2417 <= UINT64_C(57)))) || (v2417 == UINT64_C(45))));
            if (!t2418) {
                t2418 = ((v2412 == UINT64_C(45)) && ((UINT64_C(23) == ((v2359 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(24) == v2325)));
            }
            t2419 = t2418;
        }
        int v2420 = t2419;
        uint64_t v2421 = (v2414 ? UINT64_C(24) : (v2415 ? UINT64_C(25) : v2291));
        uint64_t v2422 = (v2415 ? (((((uint64_t)(v2412 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(24)]))) : v2342);
        uint64_t v2423 = (v2416 ? ((v2308 + UINT64_C(1)) & UINT64_C(255)) : v2308);
        uint64_t v2424 = (v2416 ? UINT64_C(23) : v2359);
        uint64_t v2425 = (v2416 ? ((uint64_t)((UINT64_C(24) + v2412) & UINT64_C(255))) : v2325);
        uint64_t v2426 = ((v2414 || v2415) ? UINT64_C(1) : ((v2420 || (v2413 && (!v2416))) ? UINT64_C(2) : v2376));
        t2427 = v2425;
    } else {
        t2427 = v2325;
    }
    uint64_t v2428 = t2427;
    uint64_t t2444;
    if (v2377) {
        uint64_t v2429 = ((uint64_t)in_b[UINT64_C(23)]);
        int v2430 = ((v2376 == UINT64_C(0)) && (UINT64_C(23) == v2325));
        int v2431 = (v2430 && (v2429 == UINT64_C(0)));
        int v2432 = ((v2430 && ((v2429 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(24) < ((uint64_t)((uint64_t)in_b_len))));
        int v2433 = (((v2430 && (v2429 != UINT64_C(0))) && (v2429 < UINT64_C(64))) && (((uint64_t)((UINT64_C(23) + v2429) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2436 = ((v2376 == UINT64_C(0)) && (UINT64_C(23) != v2325));
        if (t2436) {
                uint64_t v2434 = v2429;
            int t2435 = (!(((((v2434 | UINT64_C(32)) >= UINT64_C(97)) && ((v2434 | UINT64_C(32)) <= UINT64_C(122))) || ((v2434 >= UINT64_C(48)) && (v2434 <= UINT64_C(57)))) || (v2434 == UINT64_C(45))));
            if (!t2435) {
                t2435 = ((v2429 == UINT64_C(45)) && ((UINT64_C(23) == ((v2359 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(24) == v2325)));
            }
            t2436 = t2435;
        }
        int v2437 = t2436;
        uint64_t v2438 = (v2431 ? UINT64_C(24) : (v2432 ? UINT64_C(25) : v2291));
        uint64_t v2439 = (v2432 ? (((((uint64_t)(v2429 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(24)]))) : v2342);
        uint64_t v2440 = (v2433 ? ((v2308 + UINT64_C(1)) & UINT64_C(255)) : v2308);
        uint64_t v2441 = (v2433 ? UINT64_C(23) : v2359);
        uint64_t v2442 = (v2433 ? ((uint64_t)((UINT64_C(24) + v2429) & UINT64_C(255))) : v2325);
        uint64_t v2443 = ((v2431 || v2432) ? UINT64_C(1) : ((v2437 || (v2430 && (!v2433))) ? UINT64_C(2) : v2376));
        t2444 = v2439;
    } else {
        t2444 = v2342;
    }
    uint64_t v2445 = t2444;
    uint64_t t2461;
    if (v2377) {
        uint64_t v2446 = ((uint64_t)in_b[UINT64_C(23)]);
        int v2447 = ((v2376 == UINT64_C(0)) && (UINT64_C(23) == v2325));
        int v2448 = (v2447 && (v2446 == UINT64_C(0)));
        int v2449 = ((v2447 && ((v2446 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(24) < ((uint64_t)((uint64_t)in_b_len))));
        int v2450 = (((v2447 && (v2446 != UINT64_C(0))) && (v2446 < UINT64_C(64))) && (((uint64_t)((UINT64_C(23) + v2446) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2453 = ((v2376 == UINT64_C(0)) && (UINT64_C(23) != v2325));
        if (t2453) {
                uint64_t v2451 = v2446;
            int t2452 = (!(((((v2451 | UINT64_C(32)) >= UINT64_C(97)) && ((v2451 | UINT64_C(32)) <= UINT64_C(122))) || ((v2451 >= UINT64_C(48)) && (v2451 <= UINT64_C(57)))) || (v2451 == UINT64_C(45))));
            if (!t2452) {
                t2452 = ((v2446 == UINT64_C(45)) && ((UINT64_C(23) == ((v2359 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(24) == v2325)));
            }
            t2453 = t2452;
        }
        int v2454 = t2453;
        uint64_t v2455 = (v2448 ? UINT64_C(24) : (v2449 ? UINT64_C(25) : v2291));
        uint64_t v2456 = (v2449 ? (((((uint64_t)(v2446 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(24)]))) : v2342);
        uint64_t v2457 = (v2450 ? ((v2308 + UINT64_C(1)) & UINT64_C(255)) : v2308);
        uint64_t v2458 = (v2450 ? UINT64_C(23) : v2359);
        uint64_t v2459 = (v2450 ? ((uint64_t)((UINT64_C(24) + v2446) & UINT64_C(255))) : v2325);
        uint64_t v2460 = ((v2448 || v2449) ? UINT64_C(1) : ((v2454 || (v2447 && (!v2450))) ? UINT64_C(2) : v2376));
        t2461 = v2458;
    } else {
        t2461 = v2359;
    }
    uint64_t v2462 = t2461;
    uint64_t t2478;
    if (v2377) {
        uint64_t v2463 = ((uint64_t)in_b[UINT64_C(23)]);
        int v2464 = ((v2376 == UINT64_C(0)) && (UINT64_C(23) == v2325));
        int v2465 = (v2464 && (v2463 == UINT64_C(0)));
        int v2466 = ((v2464 && ((v2463 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(24) < ((uint64_t)((uint64_t)in_b_len))));
        int v2467 = (((v2464 && (v2463 != UINT64_C(0))) && (v2463 < UINT64_C(64))) && (((uint64_t)((UINT64_C(23) + v2463) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2470 = ((v2376 == UINT64_C(0)) && (UINT64_C(23) != v2325));
        if (t2470) {
                uint64_t v2468 = v2463;
            int t2469 = (!(((((v2468 | UINT64_C(32)) >= UINT64_C(97)) && ((v2468 | UINT64_C(32)) <= UINT64_C(122))) || ((v2468 >= UINT64_C(48)) && (v2468 <= UINT64_C(57)))) || (v2468 == UINT64_C(45))));
            if (!t2469) {
                t2469 = ((v2463 == UINT64_C(45)) && ((UINT64_C(23) == ((v2359 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(24) == v2325)));
            }
            t2470 = t2469;
        }
        int v2471 = t2470;
        uint64_t v2472 = (v2465 ? UINT64_C(24) : (v2466 ? UINT64_C(25) : v2291));
        uint64_t v2473 = (v2466 ? (((((uint64_t)(v2463 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(24)]))) : v2342);
        uint64_t v2474 = (v2467 ? ((v2308 + UINT64_C(1)) & UINT64_C(255)) : v2308);
        uint64_t v2475 = (v2467 ? UINT64_C(23) : v2359);
        uint64_t v2476 = (v2467 ? ((uint64_t)((UINT64_C(24) + v2463) & UINT64_C(255))) : v2325);
        uint64_t v2477 = ((v2465 || v2466) ? UINT64_C(1) : ((v2471 || (v2464 && (!v2467))) ? UINT64_C(2) : v2376));
        t2478 = v2477;
    } else {
        t2478 = v2376;
    }
    uint64_t v2479 = t2478;
    int v2480 = (UINT64_C(24) < v7);
    uint64_t t2496;
    if (v2480) {
        uint64_t v2481 = ((uint64_t)in_b[UINT64_C(24)]);
        int v2482 = ((v2479 == UINT64_C(0)) && (UINT64_C(24) == v2428));
        int v2483 = (v2482 && (v2481 == UINT64_C(0)));
        int v2484 = ((v2482 && ((v2481 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(25) < ((uint64_t)((uint64_t)in_b_len))));
        int v2485 = (((v2482 && (v2481 != UINT64_C(0))) && (v2481 < UINT64_C(64))) && (((uint64_t)((UINT64_C(24) + v2481) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2488 = ((v2479 == UINT64_C(0)) && (UINT64_C(24) != v2428));
        if (t2488) {
                uint64_t v2486 = v2481;
            int t2487 = (!(((((v2486 | UINT64_C(32)) >= UINT64_C(97)) && ((v2486 | UINT64_C(32)) <= UINT64_C(122))) || ((v2486 >= UINT64_C(48)) && (v2486 <= UINT64_C(57)))) || (v2486 == UINT64_C(45))));
            if (!t2487) {
                t2487 = ((v2481 == UINT64_C(45)) && ((UINT64_C(24) == ((v2462 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(25) == v2428)));
            }
            t2488 = t2487;
        }
        int v2489 = t2488;
        uint64_t v2490 = (v2483 ? UINT64_C(25) : (v2484 ? UINT64_C(26) : v2394));
        uint64_t v2491 = (v2484 ? (((((uint64_t)(v2481 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(25)]))) : v2445);
        uint64_t v2492 = (v2485 ? ((v2411 + UINT64_C(1)) & UINT64_C(255)) : v2411);
        uint64_t v2493 = (v2485 ? UINT64_C(24) : v2462);
        uint64_t v2494 = (v2485 ? ((uint64_t)((UINT64_C(25) + v2481) & UINT64_C(255))) : v2428);
        uint64_t v2495 = ((v2483 || v2484) ? UINT64_C(1) : ((v2489 || (v2482 && (!v2485))) ? UINT64_C(2) : v2479));
        t2496 = v2490;
    } else {
        t2496 = v2394;
    }
    uint64_t v2497 = t2496;
    uint64_t t2513;
    if (v2480) {
        uint64_t v2498 = ((uint64_t)in_b[UINT64_C(24)]);
        int v2499 = ((v2479 == UINT64_C(0)) && (UINT64_C(24) == v2428));
        int v2500 = (v2499 && (v2498 == UINT64_C(0)));
        int v2501 = ((v2499 && ((v2498 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(25) < ((uint64_t)((uint64_t)in_b_len))));
        int v2502 = (((v2499 && (v2498 != UINT64_C(0))) && (v2498 < UINT64_C(64))) && (((uint64_t)((UINT64_C(24) + v2498) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2505 = ((v2479 == UINT64_C(0)) && (UINT64_C(24) != v2428));
        if (t2505) {
                uint64_t v2503 = v2498;
            int t2504 = (!(((((v2503 | UINT64_C(32)) >= UINT64_C(97)) && ((v2503 | UINT64_C(32)) <= UINT64_C(122))) || ((v2503 >= UINT64_C(48)) && (v2503 <= UINT64_C(57)))) || (v2503 == UINT64_C(45))));
            if (!t2504) {
                t2504 = ((v2498 == UINT64_C(45)) && ((UINT64_C(24) == ((v2462 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(25) == v2428)));
            }
            t2505 = t2504;
        }
        int v2506 = t2505;
        uint64_t v2507 = (v2500 ? UINT64_C(25) : (v2501 ? UINT64_C(26) : v2394));
        uint64_t v2508 = (v2501 ? (((((uint64_t)(v2498 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(25)]))) : v2445);
        uint64_t v2509 = (v2502 ? ((v2411 + UINT64_C(1)) & UINT64_C(255)) : v2411);
        uint64_t v2510 = (v2502 ? UINT64_C(24) : v2462);
        uint64_t v2511 = (v2502 ? ((uint64_t)((UINT64_C(25) + v2498) & UINT64_C(255))) : v2428);
        uint64_t v2512 = ((v2500 || v2501) ? UINT64_C(1) : ((v2506 || (v2499 && (!v2502))) ? UINT64_C(2) : v2479));
        t2513 = v2509;
    } else {
        t2513 = v2411;
    }
    uint64_t v2514 = t2513;
    uint64_t t2530;
    if (v2480) {
        uint64_t v2515 = ((uint64_t)in_b[UINT64_C(24)]);
        int v2516 = ((v2479 == UINT64_C(0)) && (UINT64_C(24) == v2428));
        int v2517 = (v2516 && (v2515 == UINT64_C(0)));
        int v2518 = ((v2516 && ((v2515 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(25) < ((uint64_t)((uint64_t)in_b_len))));
        int v2519 = (((v2516 && (v2515 != UINT64_C(0))) && (v2515 < UINT64_C(64))) && (((uint64_t)((UINT64_C(24) + v2515) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2522 = ((v2479 == UINT64_C(0)) && (UINT64_C(24) != v2428));
        if (t2522) {
                uint64_t v2520 = v2515;
            int t2521 = (!(((((v2520 | UINT64_C(32)) >= UINT64_C(97)) && ((v2520 | UINT64_C(32)) <= UINT64_C(122))) || ((v2520 >= UINT64_C(48)) && (v2520 <= UINT64_C(57)))) || (v2520 == UINT64_C(45))));
            if (!t2521) {
                t2521 = ((v2515 == UINT64_C(45)) && ((UINT64_C(24) == ((v2462 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(25) == v2428)));
            }
            t2522 = t2521;
        }
        int v2523 = t2522;
        uint64_t v2524 = (v2517 ? UINT64_C(25) : (v2518 ? UINT64_C(26) : v2394));
        uint64_t v2525 = (v2518 ? (((((uint64_t)(v2515 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(25)]))) : v2445);
        uint64_t v2526 = (v2519 ? ((v2411 + UINT64_C(1)) & UINT64_C(255)) : v2411);
        uint64_t v2527 = (v2519 ? UINT64_C(24) : v2462);
        uint64_t v2528 = (v2519 ? ((uint64_t)((UINT64_C(25) + v2515) & UINT64_C(255))) : v2428);
        uint64_t v2529 = ((v2517 || v2518) ? UINT64_C(1) : ((v2523 || (v2516 && (!v2519))) ? UINT64_C(2) : v2479));
        t2530 = v2528;
    } else {
        t2530 = v2428;
    }
    uint64_t v2531 = t2530;
    uint64_t t2547;
    if (v2480) {
        uint64_t v2532 = ((uint64_t)in_b[UINT64_C(24)]);
        int v2533 = ((v2479 == UINT64_C(0)) && (UINT64_C(24) == v2428));
        int v2534 = (v2533 && (v2532 == UINT64_C(0)));
        int v2535 = ((v2533 && ((v2532 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(25) < ((uint64_t)((uint64_t)in_b_len))));
        int v2536 = (((v2533 && (v2532 != UINT64_C(0))) && (v2532 < UINT64_C(64))) && (((uint64_t)((UINT64_C(24) + v2532) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2539 = ((v2479 == UINT64_C(0)) && (UINT64_C(24) != v2428));
        if (t2539) {
                uint64_t v2537 = v2532;
            int t2538 = (!(((((v2537 | UINT64_C(32)) >= UINT64_C(97)) && ((v2537 | UINT64_C(32)) <= UINT64_C(122))) || ((v2537 >= UINT64_C(48)) && (v2537 <= UINT64_C(57)))) || (v2537 == UINT64_C(45))));
            if (!t2538) {
                t2538 = ((v2532 == UINT64_C(45)) && ((UINT64_C(24) == ((v2462 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(25) == v2428)));
            }
            t2539 = t2538;
        }
        int v2540 = t2539;
        uint64_t v2541 = (v2534 ? UINT64_C(25) : (v2535 ? UINT64_C(26) : v2394));
        uint64_t v2542 = (v2535 ? (((((uint64_t)(v2532 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(25)]))) : v2445);
        uint64_t v2543 = (v2536 ? ((v2411 + UINT64_C(1)) & UINT64_C(255)) : v2411);
        uint64_t v2544 = (v2536 ? UINT64_C(24) : v2462);
        uint64_t v2545 = (v2536 ? ((uint64_t)((UINT64_C(25) + v2532) & UINT64_C(255))) : v2428);
        uint64_t v2546 = ((v2534 || v2535) ? UINT64_C(1) : ((v2540 || (v2533 && (!v2536))) ? UINT64_C(2) : v2479));
        t2547 = v2542;
    } else {
        t2547 = v2445;
    }
    uint64_t v2548 = t2547;
    uint64_t t2564;
    if (v2480) {
        uint64_t v2549 = ((uint64_t)in_b[UINT64_C(24)]);
        int v2550 = ((v2479 == UINT64_C(0)) && (UINT64_C(24) == v2428));
        int v2551 = (v2550 && (v2549 == UINT64_C(0)));
        int v2552 = ((v2550 && ((v2549 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(25) < ((uint64_t)((uint64_t)in_b_len))));
        int v2553 = (((v2550 && (v2549 != UINT64_C(0))) && (v2549 < UINT64_C(64))) && (((uint64_t)((UINT64_C(24) + v2549) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2556 = ((v2479 == UINT64_C(0)) && (UINT64_C(24) != v2428));
        if (t2556) {
                uint64_t v2554 = v2549;
            int t2555 = (!(((((v2554 | UINT64_C(32)) >= UINT64_C(97)) && ((v2554 | UINT64_C(32)) <= UINT64_C(122))) || ((v2554 >= UINT64_C(48)) && (v2554 <= UINT64_C(57)))) || (v2554 == UINT64_C(45))));
            if (!t2555) {
                t2555 = ((v2549 == UINT64_C(45)) && ((UINT64_C(24) == ((v2462 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(25) == v2428)));
            }
            t2556 = t2555;
        }
        int v2557 = t2556;
        uint64_t v2558 = (v2551 ? UINT64_C(25) : (v2552 ? UINT64_C(26) : v2394));
        uint64_t v2559 = (v2552 ? (((((uint64_t)(v2549 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(25)]))) : v2445);
        uint64_t v2560 = (v2553 ? ((v2411 + UINT64_C(1)) & UINT64_C(255)) : v2411);
        uint64_t v2561 = (v2553 ? UINT64_C(24) : v2462);
        uint64_t v2562 = (v2553 ? ((uint64_t)((UINT64_C(25) + v2549) & UINT64_C(255))) : v2428);
        uint64_t v2563 = ((v2551 || v2552) ? UINT64_C(1) : ((v2557 || (v2550 && (!v2553))) ? UINT64_C(2) : v2479));
        t2564 = v2561;
    } else {
        t2564 = v2462;
    }
    uint64_t v2565 = t2564;
    uint64_t t2581;
    if (v2480) {
        uint64_t v2566 = ((uint64_t)in_b[UINT64_C(24)]);
        int v2567 = ((v2479 == UINT64_C(0)) && (UINT64_C(24) == v2428));
        int v2568 = (v2567 && (v2566 == UINT64_C(0)));
        int v2569 = ((v2567 && ((v2566 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(25) < ((uint64_t)((uint64_t)in_b_len))));
        int v2570 = (((v2567 && (v2566 != UINT64_C(0))) && (v2566 < UINT64_C(64))) && (((uint64_t)((UINT64_C(24) + v2566) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2573 = ((v2479 == UINT64_C(0)) && (UINT64_C(24) != v2428));
        if (t2573) {
                uint64_t v2571 = v2566;
            int t2572 = (!(((((v2571 | UINT64_C(32)) >= UINT64_C(97)) && ((v2571 | UINT64_C(32)) <= UINT64_C(122))) || ((v2571 >= UINT64_C(48)) && (v2571 <= UINT64_C(57)))) || (v2571 == UINT64_C(45))));
            if (!t2572) {
                t2572 = ((v2566 == UINT64_C(45)) && ((UINT64_C(24) == ((v2462 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(25) == v2428)));
            }
            t2573 = t2572;
        }
        int v2574 = t2573;
        uint64_t v2575 = (v2568 ? UINT64_C(25) : (v2569 ? UINT64_C(26) : v2394));
        uint64_t v2576 = (v2569 ? (((((uint64_t)(v2566 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(25)]))) : v2445);
        uint64_t v2577 = (v2570 ? ((v2411 + UINT64_C(1)) & UINT64_C(255)) : v2411);
        uint64_t v2578 = (v2570 ? UINT64_C(24) : v2462);
        uint64_t v2579 = (v2570 ? ((uint64_t)((UINT64_C(25) + v2566) & UINT64_C(255))) : v2428);
        uint64_t v2580 = ((v2568 || v2569) ? UINT64_C(1) : ((v2574 || (v2567 && (!v2570))) ? UINT64_C(2) : v2479));
        t2581 = v2580;
    } else {
        t2581 = v2479;
    }
    uint64_t v2582 = t2581;
    int v2583 = (UINT64_C(25) < v7);
    uint64_t t2599;
    if (v2583) {
        uint64_t v2584 = ((uint64_t)in_b[UINT64_C(25)]);
        int v2585 = ((v2582 == UINT64_C(0)) && (UINT64_C(25) == v2531));
        int v2586 = (v2585 && (v2584 == UINT64_C(0)));
        int v2587 = ((v2585 && ((v2584 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(26) < ((uint64_t)((uint64_t)in_b_len))));
        int v2588 = (((v2585 && (v2584 != UINT64_C(0))) && (v2584 < UINT64_C(64))) && (((uint64_t)((UINT64_C(25) + v2584) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2591 = ((v2582 == UINT64_C(0)) && (UINT64_C(25) != v2531));
        if (t2591) {
                uint64_t v2589 = v2584;
            int t2590 = (!(((((v2589 | UINT64_C(32)) >= UINT64_C(97)) && ((v2589 | UINT64_C(32)) <= UINT64_C(122))) || ((v2589 >= UINT64_C(48)) && (v2589 <= UINT64_C(57)))) || (v2589 == UINT64_C(45))));
            if (!t2590) {
                t2590 = ((v2584 == UINT64_C(45)) && ((UINT64_C(25) == ((v2565 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(26) == v2531)));
            }
            t2591 = t2590;
        }
        int v2592 = t2591;
        uint64_t v2593 = (v2586 ? UINT64_C(26) : (v2587 ? UINT64_C(27) : v2497));
        uint64_t v2594 = (v2587 ? (((((uint64_t)(v2584 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(26)]))) : v2548);
        uint64_t v2595 = (v2588 ? ((v2514 + UINT64_C(1)) & UINT64_C(255)) : v2514);
        uint64_t v2596 = (v2588 ? UINT64_C(25) : v2565);
        uint64_t v2597 = (v2588 ? ((uint64_t)((UINT64_C(26) + v2584) & UINT64_C(255))) : v2531);
        uint64_t v2598 = ((v2586 || v2587) ? UINT64_C(1) : ((v2592 || (v2585 && (!v2588))) ? UINT64_C(2) : v2582));
        t2599 = v2593;
    } else {
        t2599 = v2497;
    }
    uint64_t v2600 = t2599;
    uint64_t t2616;
    if (v2583) {
        uint64_t v2601 = ((uint64_t)in_b[UINT64_C(25)]);
        int v2602 = ((v2582 == UINT64_C(0)) && (UINT64_C(25) == v2531));
        int v2603 = (v2602 && (v2601 == UINT64_C(0)));
        int v2604 = ((v2602 && ((v2601 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(26) < ((uint64_t)((uint64_t)in_b_len))));
        int v2605 = (((v2602 && (v2601 != UINT64_C(0))) && (v2601 < UINT64_C(64))) && (((uint64_t)((UINT64_C(25) + v2601) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2608 = ((v2582 == UINT64_C(0)) && (UINT64_C(25) != v2531));
        if (t2608) {
                uint64_t v2606 = v2601;
            int t2607 = (!(((((v2606 | UINT64_C(32)) >= UINT64_C(97)) && ((v2606 | UINT64_C(32)) <= UINT64_C(122))) || ((v2606 >= UINT64_C(48)) && (v2606 <= UINT64_C(57)))) || (v2606 == UINT64_C(45))));
            if (!t2607) {
                t2607 = ((v2601 == UINT64_C(45)) && ((UINT64_C(25) == ((v2565 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(26) == v2531)));
            }
            t2608 = t2607;
        }
        int v2609 = t2608;
        uint64_t v2610 = (v2603 ? UINT64_C(26) : (v2604 ? UINT64_C(27) : v2497));
        uint64_t v2611 = (v2604 ? (((((uint64_t)(v2601 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(26)]))) : v2548);
        uint64_t v2612 = (v2605 ? ((v2514 + UINT64_C(1)) & UINT64_C(255)) : v2514);
        uint64_t v2613 = (v2605 ? UINT64_C(25) : v2565);
        uint64_t v2614 = (v2605 ? ((uint64_t)((UINT64_C(26) + v2601) & UINT64_C(255))) : v2531);
        uint64_t v2615 = ((v2603 || v2604) ? UINT64_C(1) : ((v2609 || (v2602 && (!v2605))) ? UINT64_C(2) : v2582));
        t2616 = v2612;
    } else {
        t2616 = v2514;
    }
    uint64_t v2617 = t2616;
    uint64_t t2633;
    if (v2583) {
        uint64_t v2618 = ((uint64_t)in_b[UINT64_C(25)]);
        int v2619 = ((v2582 == UINT64_C(0)) && (UINT64_C(25) == v2531));
        int v2620 = (v2619 && (v2618 == UINT64_C(0)));
        int v2621 = ((v2619 && ((v2618 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(26) < ((uint64_t)((uint64_t)in_b_len))));
        int v2622 = (((v2619 && (v2618 != UINT64_C(0))) && (v2618 < UINT64_C(64))) && (((uint64_t)((UINT64_C(25) + v2618) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2625 = ((v2582 == UINT64_C(0)) && (UINT64_C(25) != v2531));
        if (t2625) {
                uint64_t v2623 = v2618;
            int t2624 = (!(((((v2623 | UINT64_C(32)) >= UINT64_C(97)) && ((v2623 | UINT64_C(32)) <= UINT64_C(122))) || ((v2623 >= UINT64_C(48)) && (v2623 <= UINT64_C(57)))) || (v2623 == UINT64_C(45))));
            if (!t2624) {
                t2624 = ((v2618 == UINT64_C(45)) && ((UINT64_C(25) == ((v2565 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(26) == v2531)));
            }
            t2625 = t2624;
        }
        int v2626 = t2625;
        uint64_t v2627 = (v2620 ? UINT64_C(26) : (v2621 ? UINT64_C(27) : v2497));
        uint64_t v2628 = (v2621 ? (((((uint64_t)(v2618 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(26)]))) : v2548);
        uint64_t v2629 = (v2622 ? ((v2514 + UINT64_C(1)) & UINT64_C(255)) : v2514);
        uint64_t v2630 = (v2622 ? UINT64_C(25) : v2565);
        uint64_t v2631 = (v2622 ? ((uint64_t)((UINT64_C(26) + v2618) & UINT64_C(255))) : v2531);
        uint64_t v2632 = ((v2620 || v2621) ? UINT64_C(1) : ((v2626 || (v2619 && (!v2622))) ? UINT64_C(2) : v2582));
        t2633 = v2631;
    } else {
        t2633 = v2531;
    }
    uint64_t v2634 = t2633;
    uint64_t t2650;
    if (v2583) {
        uint64_t v2635 = ((uint64_t)in_b[UINT64_C(25)]);
        int v2636 = ((v2582 == UINT64_C(0)) && (UINT64_C(25) == v2531));
        int v2637 = (v2636 && (v2635 == UINT64_C(0)));
        int v2638 = ((v2636 && ((v2635 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(26) < ((uint64_t)((uint64_t)in_b_len))));
        int v2639 = (((v2636 && (v2635 != UINT64_C(0))) && (v2635 < UINT64_C(64))) && (((uint64_t)((UINT64_C(25) + v2635) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2642 = ((v2582 == UINT64_C(0)) && (UINT64_C(25) != v2531));
        if (t2642) {
                uint64_t v2640 = v2635;
            int t2641 = (!(((((v2640 | UINT64_C(32)) >= UINT64_C(97)) && ((v2640 | UINT64_C(32)) <= UINT64_C(122))) || ((v2640 >= UINT64_C(48)) && (v2640 <= UINT64_C(57)))) || (v2640 == UINT64_C(45))));
            if (!t2641) {
                t2641 = ((v2635 == UINT64_C(45)) && ((UINT64_C(25) == ((v2565 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(26) == v2531)));
            }
            t2642 = t2641;
        }
        int v2643 = t2642;
        uint64_t v2644 = (v2637 ? UINT64_C(26) : (v2638 ? UINT64_C(27) : v2497));
        uint64_t v2645 = (v2638 ? (((((uint64_t)(v2635 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(26)]))) : v2548);
        uint64_t v2646 = (v2639 ? ((v2514 + UINT64_C(1)) & UINT64_C(255)) : v2514);
        uint64_t v2647 = (v2639 ? UINT64_C(25) : v2565);
        uint64_t v2648 = (v2639 ? ((uint64_t)((UINT64_C(26) + v2635) & UINT64_C(255))) : v2531);
        uint64_t v2649 = ((v2637 || v2638) ? UINT64_C(1) : ((v2643 || (v2636 && (!v2639))) ? UINT64_C(2) : v2582));
        t2650 = v2645;
    } else {
        t2650 = v2548;
    }
    uint64_t v2651 = t2650;
    uint64_t t2667;
    if (v2583) {
        uint64_t v2652 = ((uint64_t)in_b[UINT64_C(25)]);
        int v2653 = ((v2582 == UINT64_C(0)) && (UINT64_C(25) == v2531));
        int v2654 = (v2653 && (v2652 == UINT64_C(0)));
        int v2655 = ((v2653 && ((v2652 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(26) < ((uint64_t)((uint64_t)in_b_len))));
        int v2656 = (((v2653 && (v2652 != UINT64_C(0))) && (v2652 < UINT64_C(64))) && (((uint64_t)((UINT64_C(25) + v2652) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2659 = ((v2582 == UINT64_C(0)) && (UINT64_C(25) != v2531));
        if (t2659) {
                uint64_t v2657 = v2652;
            int t2658 = (!(((((v2657 | UINT64_C(32)) >= UINT64_C(97)) && ((v2657 | UINT64_C(32)) <= UINT64_C(122))) || ((v2657 >= UINT64_C(48)) && (v2657 <= UINT64_C(57)))) || (v2657 == UINT64_C(45))));
            if (!t2658) {
                t2658 = ((v2652 == UINT64_C(45)) && ((UINT64_C(25) == ((v2565 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(26) == v2531)));
            }
            t2659 = t2658;
        }
        int v2660 = t2659;
        uint64_t v2661 = (v2654 ? UINT64_C(26) : (v2655 ? UINT64_C(27) : v2497));
        uint64_t v2662 = (v2655 ? (((((uint64_t)(v2652 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(26)]))) : v2548);
        uint64_t v2663 = (v2656 ? ((v2514 + UINT64_C(1)) & UINT64_C(255)) : v2514);
        uint64_t v2664 = (v2656 ? UINT64_C(25) : v2565);
        uint64_t v2665 = (v2656 ? ((uint64_t)((UINT64_C(26) + v2652) & UINT64_C(255))) : v2531);
        uint64_t v2666 = ((v2654 || v2655) ? UINT64_C(1) : ((v2660 || (v2653 && (!v2656))) ? UINT64_C(2) : v2582));
        t2667 = v2664;
    } else {
        t2667 = v2565;
    }
    uint64_t v2668 = t2667;
    uint64_t t2684;
    if (v2583) {
        uint64_t v2669 = ((uint64_t)in_b[UINT64_C(25)]);
        int v2670 = ((v2582 == UINT64_C(0)) && (UINT64_C(25) == v2531));
        int v2671 = (v2670 && (v2669 == UINT64_C(0)));
        int v2672 = ((v2670 && ((v2669 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(26) < ((uint64_t)((uint64_t)in_b_len))));
        int v2673 = (((v2670 && (v2669 != UINT64_C(0))) && (v2669 < UINT64_C(64))) && (((uint64_t)((UINT64_C(25) + v2669) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2676 = ((v2582 == UINT64_C(0)) && (UINT64_C(25) != v2531));
        if (t2676) {
                uint64_t v2674 = v2669;
            int t2675 = (!(((((v2674 | UINT64_C(32)) >= UINT64_C(97)) && ((v2674 | UINT64_C(32)) <= UINT64_C(122))) || ((v2674 >= UINT64_C(48)) && (v2674 <= UINT64_C(57)))) || (v2674 == UINT64_C(45))));
            if (!t2675) {
                t2675 = ((v2669 == UINT64_C(45)) && ((UINT64_C(25) == ((v2565 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(26) == v2531)));
            }
            t2676 = t2675;
        }
        int v2677 = t2676;
        uint64_t v2678 = (v2671 ? UINT64_C(26) : (v2672 ? UINT64_C(27) : v2497));
        uint64_t v2679 = (v2672 ? (((((uint64_t)(v2669 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(26)]))) : v2548);
        uint64_t v2680 = (v2673 ? ((v2514 + UINT64_C(1)) & UINT64_C(255)) : v2514);
        uint64_t v2681 = (v2673 ? UINT64_C(25) : v2565);
        uint64_t v2682 = (v2673 ? ((uint64_t)((UINT64_C(26) + v2669) & UINT64_C(255))) : v2531);
        uint64_t v2683 = ((v2671 || v2672) ? UINT64_C(1) : ((v2677 || (v2670 && (!v2673))) ? UINT64_C(2) : v2582));
        t2684 = v2683;
    } else {
        t2684 = v2582;
    }
    uint64_t v2685 = t2684;
    int v2686 = (UINT64_C(26) < v7);
    uint64_t t2702;
    if (v2686) {
        uint64_t v2687 = ((uint64_t)in_b[UINT64_C(26)]);
        int v2688 = ((v2685 == UINT64_C(0)) && (UINT64_C(26) == v2634));
        int v2689 = (v2688 && (v2687 == UINT64_C(0)));
        int v2690 = ((v2688 && ((v2687 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(27) < ((uint64_t)((uint64_t)in_b_len))));
        int v2691 = (((v2688 && (v2687 != UINT64_C(0))) && (v2687 < UINT64_C(64))) && (((uint64_t)((UINT64_C(26) + v2687) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2694 = ((v2685 == UINT64_C(0)) && (UINT64_C(26) != v2634));
        if (t2694) {
                uint64_t v2692 = v2687;
            int t2693 = (!(((((v2692 | UINT64_C(32)) >= UINT64_C(97)) && ((v2692 | UINT64_C(32)) <= UINT64_C(122))) || ((v2692 >= UINT64_C(48)) && (v2692 <= UINT64_C(57)))) || (v2692 == UINT64_C(45))));
            if (!t2693) {
                t2693 = ((v2687 == UINT64_C(45)) && ((UINT64_C(26) == ((v2668 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(27) == v2634)));
            }
            t2694 = t2693;
        }
        int v2695 = t2694;
        uint64_t v2696 = (v2689 ? UINT64_C(27) : (v2690 ? UINT64_C(28) : v2600));
        uint64_t v2697 = (v2690 ? (((((uint64_t)(v2687 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(27)]))) : v2651);
        uint64_t v2698 = (v2691 ? ((v2617 + UINT64_C(1)) & UINT64_C(255)) : v2617);
        uint64_t v2699 = (v2691 ? UINT64_C(26) : v2668);
        uint64_t v2700 = (v2691 ? ((uint64_t)((UINT64_C(27) + v2687) & UINT64_C(255))) : v2634);
        uint64_t v2701 = ((v2689 || v2690) ? UINT64_C(1) : ((v2695 || (v2688 && (!v2691))) ? UINT64_C(2) : v2685));
        t2702 = v2696;
    } else {
        t2702 = v2600;
    }
    uint64_t v2703 = t2702;
    uint64_t t2719;
    if (v2686) {
        uint64_t v2704 = ((uint64_t)in_b[UINT64_C(26)]);
        int v2705 = ((v2685 == UINT64_C(0)) && (UINT64_C(26) == v2634));
        int v2706 = (v2705 && (v2704 == UINT64_C(0)));
        int v2707 = ((v2705 && ((v2704 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(27) < ((uint64_t)((uint64_t)in_b_len))));
        int v2708 = (((v2705 && (v2704 != UINT64_C(0))) && (v2704 < UINT64_C(64))) && (((uint64_t)((UINT64_C(26) + v2704) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2711 = ((v2685 == UINT64_C(0)) && (UINT64_C(26) != v2634));
        if (t2711) {
                uint64_t v2709 = v2704;
            int t2710 = (!(((((v2709 | UINT64_C(32)) >= UINT64_C(97)) && ((v2709 | UINT64_C(32)) <= UINT64_C(122))) || ((v2709 >= UINT64_C(48)) && (v2709 <= UINT64_C(57)))) || (v2709 == UINT64_C(45))));
            if (!t2710) {
                t2710 = ((v2704 == UINT64_C(45)) && ((UINT64_C(26) == ((v2668 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(27) == v2634)));
            }
            t2711 = t2710;
        }
        int v2712 = t2711;
        uint64_t v2713 = (v2706 ? UINT64_C(27) : (v2707 ? UINT64_C(28) : v2600));
        uint64_t v2714 = (v2707 ? (((((uint64_t)(v2704 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(27)]))) : v2651);
        uint64_t v2715 = (v2708 ? ((v2617 + UINT64_C(1)) & UINT64_C(255)) : v2617);
        uint64_t v2716 = (v2708 ? UINT64_C(26) : v2668);
        uint64_t v2717 = (v2708 ? ((uint64_t)((UINT64_C(27) + v2704) & UINT64_C(255))) : v2634);
        uint64_t v2718 = ((v2706 || v2707) ? UINT64_C(1) : ((v2712 || (v2705 && (!v2708))) ? UINT64_C(2) : v2685));
        t2719 = v2715;
    } else {
        t2719 = v2617;
    }
    uint64_t v2720 = t2719;
    uint64_t t2736;
    if (v2686) {
        uint64_t v2721 = ((uint64_t)in_b[UINT64_C(26)]);
        int v2722 = ((v2685 == UINT64_C(0)) && (UINT64_C(26) == v2634));
        int v2723 = (v2722 && (v2721 == UINT64_C(0)));
        int v2724 = ((v2722 && ((v2721 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(27) < ((uint64_t)((uint64_t)in_b_len))));
        int v2725 = (((v2722 && (v2721 != UINT64_C(0))) && (v2721 < UINT64_C(64))) && (((uint64_t)((UINT64_C(26) + v2721) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2728 = ((v2685 == UINT64_C(0)) && (UINT64_C(26) != v2634));
        if (t2728) {
                uint64_t v2726 = v2721;
            int t2727 = (!(((((v2726 | UINT64_C(32)) >= UINT64_C(97)) && ((v2726 | UINT64_C(32)) <= UINT64_C(122))) || ((v2726 >= UINT64_C(48)) && (v2726 <= UINT64_C(57)))) || (v2726 == UINT64_C(45))));
            if (!t2727) {
                t2727 = ((v2721 == UINT64_C(45)) && ((UINT64_C(26) == ((v2668 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(27) == v2634)));
            }
            t2728 = t2727;
        }
        int v2729 = t2728;
        uint64_t v2730 = (v2723 ? UINT64_C(27) : (v2724 ? UINT64_C(28) : v2600));
        uint64_t v2731 = (v2724 ? (((((uint64_t)(v2721 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(27)]))) : v2651);
        uint64_t v2732 = (v2725 ? ((v2617 + UINT64_C(1)) & UINT64_C(255)) : v2617);
        uint64_t v2733 = (v2725 ? UINT64_C(26) : v2668);
        uint64_t v2734 = (v2725 ? ((uint64_t)((UINT64_C(27) + v2721) & UINT64_C(255))) : v2634);
        uint64_t v2735 = ((v2723 || v2724) ? UINT64_C(1) : ((v2729 || (v2722 && (!v2725))) ? UINT64_C(2) : v2685));
        t2736 = v2734;
    } else {
        t2736 = v2634;
    }
    uint64_t v2737 = t2736;
    uint64_t t2753;
    if (v2686) {
        uint64_t v2738 = ((uint64_t)in_b[UINT64_C(26)]);
        int v2739 = ((v2685 == UINT64_C(0)) && (UINT64_C(26) == v2634));
        int v2740 = (v2739 && (v2738 == UINT64_C(0)));
        int v2741 = ((v2739 && ((v2738 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(27) < ((uint64_t)((uint64_t)in_b_len))));
        int v2742 = (((v2739 && (v2738 != UINT64_C(0))) && (v2738 < UINT64_C(64))) && (((uint64_t)((UINT64_C(26) + v2738) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2745 = ((v2685 == UINT64_C(0)) && (UINT64_C(26) != v2634));
        if (t2745) {
                uint64_t v2743 = v2738;
            int t2744 = (!(((((v2743 | UINT64_C(32)) >= UINT64_C(97)) && ((v2743 | UINT64_C(32)) <= UINT64_C(122))) || ((v2743 >= UINT64_C(48)) && (v2743 <= UINT64_C(57)))) || (v2743 == UINT64_C(45))));
            if (!t2744) {
                t2744 = ((v2738 == UINT64_C(45)) && ((UINT64_C(26) == ((v2668 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(27) == v2634)));
            }
            t2745 = t2744;
        }
        int v2746 = t2745;
        uint64_t v2747 = (v2740 ? UINT64_C(27) : (v2741 ? UINT64_C(28) : v2600));
        uint64_t v2748 = (v2741 ? (((((uint64_t)(v2738 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(27)]))) : v2651);
        uint64_t v2749 = (v2742 ? ((v2617 + UINT64_C(1)) & UINT64_C(255)) : v2617);
        uint64_t v2750 = (v2742 ? UINT64_C(26) : v2668);
        uint64_t v2751 = (v2742 ? ((uint64_t)((UINT64_C(27) + v2738) & UINT64_C(255))) : v2634);
        uint64_t v2752 = ((v2740 || v2741) ? UINT64_C(1) : ((v2746 || (v2739 && (!v2742))) ? UINT64_C(2) : v2685));
        t2753 = v2748;
    } else {
        t2753 = v2651;
    }
    uint64_t v2754 = t2753;
    uint64_t t2770;
    if (v2686) {
        uint64_t v2755 = ((uint64_t)in_b[UINT64_C(26)]);
        int v2756 = ((v2685 == UINT64_C(0)) && (UINT64_C(26) == v2634));
        int v2757 = (v2756 && (v2755 == UINT64_C(0)));
        int v2758 = ((v2756 && ((v2755 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(27) < ((uint64_t)((uint64_t)in_b_len))));
        int v2759 = (((v2756 && (v2755 != UINT64_C(0))) && (v2755 < UINT64_C(64))) && (((uint64_t)((UINT64_C(26) + v2755) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2762 = ((v2685 == UINT64_C(0)) && (UINT64_C(26) != v2634));
        if (t2762) {
                uint64_t v2760 = v2755;
            int t2761 = (!(((((v2760 | UINT64_C(32)) >= UINT64_C(97)) && ((v2760 | UINT64_C(32)) <= UINT64_C(122))) || ((v2760 >= UINT64_C(48)) && (v2760 <= UINT64_C(57)))) || (v2760 == UINT64_C(45))));
            if (!t2761) {
                t2761 = ((v2755 == UINT64_C(45)) && ((UINT64_C(26) == ((v2668 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(27) == v2634)));
            }
            t2762 = t2761;
        }
        int v2763 = t2762;
        uint64_t v2764 = (v2757 ? UINT64_C(27) : (v2758 ? UINT64_C(28) : v2600));
        uint64_t v2765 = (v2758 ? (((((uint64_t)(v2755 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(27)]))) : v2651);
        uint64_t v2766 = (v2759 ? ((v2617 + UINT64_C(1)) & UINT64_C(255)) : v2617);
        uint64_t v2767 = (v2759 ? UINT64_C(26) : v2668);
        uint64_t v2768 = (v2759 ? ((uint64_t)((UINT64_C(27) + v2755) & UINT64_C(255))) : v2634);
        uint64_t v2769 = ((v2757 || v2758) ? UINT64_C(1) : ((v2763 || (v2756 && (!v2759))) ? UINT64_C(2) : v2685));
        t2770 = v2767;
    } else {
        t2770 = v2668;
    }
    uint64_t v2771 = t2770;
    uint64_t t2787;
    if (v2686) {
        uint64_t v2772 = ((uint64_t)in_b[UINT64_C(26)]);
        int v2773 = ((v2685 == UINT64_C(0)) && (UINT64_C(26) == v2634));
        int v2774 = (v2773 && (v2772 == UINT64_C(0)));
        int v2775 = ((v2773 && ((v2772 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(27) < ((uint64_t)((uint64_t)in_b_len))));
        int v2776 = (((v2773 && (v2772 != UINT64_C(0))) && (v2772 < UINT64_C(64))) && (((uint64_t)((UINT64_C(26) + v2772) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2779 = ((v2685 == UINT64_C(0)) && (UINT64_C(26) != v2634));
        if (t2779) {
                uint64_t v2777 = v2772;
            int t2778 = (!(((((v2777 | UINT64_C(32)) >= UINT64_C(97)) && ((v2777 | UINT64_C(32)) <= UINT64_C(122))) || ((v2777 >= UINT64_C(48)) && (v2777 <= UINT64_C(57)))) || (v2777 == UINT64_C(45))));
            if (!t2778) {
                t2778 = ((v2772 == UINT64_C(45)) && ((UINT64_C(26) == ((v2668 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(27) == v2634)));
            }
            t2779 = t2778;
        }
        int v2780 = t2779;
        uint64_t v2781 = (v2774 ? UINT64_C(27) : (v2775 ? UINT64_C(28) : v2600));
        uint64_t v2782 = (v2775 ? (((((uint64_t)(v2772 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(27)]))) : v2651);
        uint64_t v2783 = (v2776 ? ((v2617 + UINT64_C(1)) & UINT64_C(255)) : v2617);
        uint64_t v2784 = (v2776 ? UINT64_C(26) : v2668);
        uint64_t v2785 = (v2776 ? ((uint64_t)((UINT64_C(27) + v2772) & UINT64_C(255))) : v2634);
        uint64_t v2786 = ((v2774 || v2775) ? UINT64_C(1) : ((v2780 || (v2773 && (!v2776))) ? UINT64_C(2) : v2685));
        t2787 = v2786;
    } else {
        t2787 = v2685;
    }
    uint64_t v2788 = t2787;
    int v2789 = (UINT64_C(27) < v7);
    uint64_t t2805;
    if (v2789) {
        uint64_t v2790 = ((uint64_t)in_b[UINT64_C(27)]);
        int v2791 = ((v2788 == UINT64_C(0)) && (UINT64_C(27) == v2737));
        int v2792 = (v2791 && (v2790 == UINT64_C(0)));
        int v2793 = ((v2791 && ((v2790 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(28) < ((uint64_t)((uint64_t)in_b_len))));
        int v2794 = (((v2791 && (v2790 != UINT64_C(0))) && (v2790 < UINT64_C(64))) && (((uint64_t)((UINT64_C(27) + v2790) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2797 = ((v2788 == UINT64_C(0)) && (UINT64_C(27) != v2737));
        if (t2797) {
                uint64_t v2795 = v2790;
            int t2796 = (!(((((v2795 | UINT64_C(32)) >= UINT64_C(97)) && ((v2795 | UINT64_C(32)) <= UINT64_C(122))) || ((v2795 >= UINT64_C(48)) && (v2795 <= UINT64_C(57)))) || (v2795 == UINT64_C(45))));
            if (!t2796) {
                t2796 = ((v2790 == UINT64_C(45)) && ((UINT64_C(27) == ((v2771 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(28) == v2737)));
            }
            t2797 = t2796;
        }
        int v2798 = t2797;
        uint64_t v2799 = (v2792 ? UINT64_C(28) : (v2793 ? UINT64_C(29) : v2703));
        uint64_t v2800 = (v2793 ? (((((uint64_t)(v2790 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(28)]))) : v2754);
        uint64_t v2801 = (v2794 ? ((v2720 + UINT64_C(1)) & UINT64_C(255)) : v2720);
        uint64_t v2802 = (v2794 ? UINT64_C(27) : v2771);
        uint64_t v2803 = (v2794 ? ((uint64_t)((UINT64_C(28) + v2790) & UINT64_C(255))) : v2737);
        uint64_t v2804 = ((v2792 || v2793) ? UINT64_C(1) : ((v2798 || (v2791 && (!v2794))) ? UINT64_C(2) : v2788));
        t2805 = v2799;
    } else {
        t2805 = v2703;
    }
    uint64_t v2806 = t2805;
    uint64_t t2822;
    if (v2789) {
        uint64_t v2807 = ((uint64_t)in_b[UINT64_C(27)]);
        int v2808 = ((v2788 == UINT64_C(0)) && (UINT64_C(27) == v2737));
        int v2809 = (v2808 && (v2807 == UINT64_C(0)));
        int v2810 = ((v2808 && ((v2807 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(28) < ((uint64_t)((uint64_t)in_b_len))));
        int v2811 = (((v2808 && (v2807 != UINT64_C(0))) && (v2807 < UINT64_C(64))) && (((uint64_t)((UINT64_C(27) + v2807) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2814 = ((v2788 == UINT64_C(0)) && (UINT64_C(27) != v2737));
        if (t2814) {
                uint64_t v2812 = v2807;
            int t2813 = (!(((((v2812 | UINT64_C(32)) >= UINT64_C(97)) && ((v2812 | UINT64_C(32)) <= UINT64_C(122))) || ((v2812 >= UINT64_C(48)) && (v2812 <= UINT64_C(57)))) || (v2812 == UINT64_C(45))));
            if (!t2813) {
                t2813 = ((v2807 == UINT64_C(45)) && ((UINT64_C(27) == ((v2771 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(28) == v2737)));
            }
            t2814 = t2813;
        }
        int v2815 = t2814;
        uint64_t v2816 = (v2809 ? UINT64_C(28) : (v2810 ? UINT64_C(29) : v2703));
        uint64_t v2817 = (v2810 ? (((((uint64_t)(v2807 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(28)]))) : v2754);
        uint64_t v2818 = (v2811 ? ((v2720 + UINT64_C(1)) & UINT64_C(255)) : v2720);
        uint64_t v2819 = (v2811 ? UINT64_C(27) : v2771);
        uint64_t v2820 = (v2811 ? ((uint64_t)((UINT64_C(28) + v2807) & UINT64_C(255))) : v2737);
        uint64_t v2821 = ((v2809 || v2810) ? UINT64_C(1) : ((v2815 || (v2808 && (!v2811))) ? UINT64_C(2) : v2788));
        t2822 = v2818;
    } else {
        t2822 = v2720;
    }
    uint64_t v2823 = t2822;
    uint64_t t2839;
    if (v2789) {
        uint64_t v2824 = ((uint64_t)in_b[UINT64_C(27)]);
        int v2825 = ((v2788 == UINT64_C(0)) && (UINT64_C(27) == v2737));
        int v2826 = (v2825 && (v2824 == UINT64_C(0)));
        int v2827 = ((v2825 && ((v2824 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(28) < ((uint64_t)((uint64_t)in_b_len))));
        int v2828 = (((v2825 && (v2824 != UINT64_C(0))) && (v2824 < UINT64_C(64))) && (((uint64_t)((UINT64_C(27) + v2824) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2831 = ((v2788 == UINT64_C(0)) && (UINT64_C(27) != v2737));
        if (t2831) {
                uint64_t v2829 = v2824;
            int t2830 = (!(((((v2829 | UINT64_C(32)) >= UINT64_C(97)) && ((v2829 | UINT64_C(32)) <= UINT64_C(122))) || ((v2829 >= UINT64_C(48)) && (v2829 <= UINT64_C(57)))) || (v2829 == UINT64_C(45))));
            if (!t2830) {
                t2830 = ((v2824 == UINT64_C(45)) && ((UINT64_C(27) == ((v2771 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(28) == v2737)));
            }
            t2831 = t2830;
        }
        int v2832 = t2831;
        uint64_t v2833 = (v2826 ? UINT64_C(28) : (v2827 ? UINT64_C(29) : v2703));
        uint64_t v2834 = (v2827 ? (((((uint64_t)(v2824 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(28)]))) : v2754);
        uint64_t v2835 = (v2828 ? ((v2720 + UINT64_C(1)) & UINT64_C(255)) : v2720);
        uint64_t v2836 = (v2828 ? UINT64_C(27) : v2771);
        uint64_t v2837 = (v2828 ? ((uint64_t)((UINT64_C(28) + v2824) & UINT64_C(255))) : v2737);
        uint64_t v2838 = ((v2826 || v2827) ? UINT64_C(1) : ((v2832 || (v2825 && (!v2828))) ? UINT64_C(2) : v2788));
        t2839 = v2837;
    } else {
        t2839 = v2737;
    }
    uint64_t v2840 = t2839;
    uint64_t t2856;
    if (v2789) {
        uint64_t v2841 = ((uint64_t)in_b[UINT64_C(27)]);
        int v2842 = ((v2788 == UINT64_C(0)) && (UINT64_C(27) == v2737));
        int v2843 = (v2842 && (v2841 == UINT64_C(0)));
        int v2844 = ((v2842 && ((v2841 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(28) < ((uint64_t)((uint64_t)in_b_len))));
        int v2845 = (((v2842 && (v2841 != UINT64_C(0))) && (v2841 < UINT64_C(64))) && (((uint64_t)((UINT64_C(27) + v2841) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2848 = ((v2788 == UINT64_C(0)) && (UINT64_C(27) != v2737));
        if (t2848) {
                uint64_t v2846 = v2841;
            int t2847 = (!(((((v2846 | UINT64_C(32)) >= UINT64_C(97)) && ((v2846 | UINT64_C(32)) <= UINT64_C(122))) || ((v2846 >= UINT64_C(48)) && (v2846 <= UINT64_C(57)))) || (v2846 == UINT64_C(45))));
            if (!t2847) {
                t2847 = ((v2841 == UINT64_C(45)) && ((UINT64_C(27) == ((v2771 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(28) == v2737)));
            }
            t2848 = t2847;
        }
        int v2849 = t2848;
        uint64_t v2850 = (v2843 ? UINT64_C(28) : (v2844 ? UINT64_C(29) : v2703));
        uint64_t v2851 = (v2844 ? (((((uint64_t)(v2841 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(28)]))) : v2754);
        uint64_t v2852 = (v2845 ? ((v2720 + UINT64_C(1)) & UINT64_C(255)) : v2720);
        uint64_t v2853 = (v2845 ? UINT64_C(27) : v2771);
        uint64_t v2854 = (v2845 ? ((uint64_t)((UINT64_C(28) + v2841) & UINT64_C(255))) : v2737);
        uint64_t v2855 = ((v2843 || v2844) ? UINT64_C(1) : ((v2849 || (v2842 && (!v2845))) ? UINT64_C(2) : v2788));
        t2856 = v2851;
    } else {
        t2856 = v2754;
    }
    uint64_t v2857 = t2856;
    uint64_t t2873;
    if (v2789) {
        uint64_t v2858 = ((uint64_t)in_b[UINT64_C(27)]);
        int v2859 = ((v2788 == UINT64_C(0)) && (UINT64_C(27) == v2737));
        int v2860 = (v2859 && (v2858 == UINT64_C(0)));
        int v2861 = ((v2859 && ((v2858 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(28) < ((uint64_t)((uint64_t)in_b_len))));
        int v2862 = (((v2859 && (v2858 != UINT64_C(0))) && (v2858 < UINT64_C(64))) && (((uint64_t)((UINT64_C(27) + v2858) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2865 = ((v2788 == UINT64_C(0)) && (UINT64_C(27) != v2737));
        if (t2865) {
                uint64_t v2863 = v2858;
            int t2864 = (!(((((v2863 | UINT64_C(32)) >= UINT64_C(97)) && ((v2863 | UINT64_C(32)) <= UINT64_C(122))) || ((v2863 >= UINT64_C(48)) && (v2863 <= UINT64_C(57)))) || (v2863 == UINT64_C(45))));
            if (!t2864) {
                t2864 = ((v2858 == UINT64_C(45)) && ((UINT64_C(27) == ((v2771 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(28) == v2737)));
            }
            t2865 = t2864;
        }
        int v2866 = t2865;
        uint64_t v2867 = (v2860 ? UINT64_C(28) : (v2861 ? UINT64_C(29) : v2703));
        uint64_t v2868 = (v2861 ? (((((uint64_t)(v2858 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(28)]))) : v2754);
        uint64_t v2869 = (v2862 ? ((v2720 + UINT64_C(1)) & UINT64_C(255)) : v2720);
        uint64_t v2870 = (v2862 ? UINT64_C(27) : v2771);
        uint64_t v2871 = (v2862 ? ((uint64_t)((UINT64_C(28) + v2858) & UINT64_C(255))) : v2737);
        uint64_t v2872 = ((v2860 || v2861) ? UINT64_C(1) : ((v2866 || (v2859 && (!v2862))) ? UINT64_C(2) : v2788));
        t2873 = v2870;
    } else {
        t2873 = v2771;
    }
    uint64_t v2874 = t2873;
    uint64_t t2890;
    if (v2789) {
        uint64_t v2875 = ((uint64_t)in_b[UINT64_C(27)]);
        int v2876 = ((v2788 == UINT64_C(0)) && (UINT64_C(27) == v2737));
        int v2877 = (v2876 && (v2875 == UINT64_C(0)));
        int v2878 = ((v2876 && ((v2875 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(28) < ((uint64_t)((uint64_t)in_b_len))));
        int v2879 = (((v2876 && (v2875 != UINT64_C(0))) && (v2875 < UINT64_C(64))) && (((uint64_t)((UINT64_C(27) + v2875) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2882 = ((v2788 == UINT64_C(0)) && (UINT64_C(27) != v2737));
        if (t2882) {
                uint64_t v2880 = v2875;
            int t2881 = (!(((((v2880 | UINT64_C(32)) >= UINT64_C(97)) && ((v2880 | UINT64_C(32)) <= UINT64_C(122))) || ((v2880 >= UINT64_C(48)) && (v2880 <= UINT64_C(57)))) || (v2880 == UINT64_C(45))));
            if (!t2881) {
                t2881 = ((v2875 == UINT64_C(45)) && ((UINT64_C(27) == ((v2771 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(28) == v2737)));
            }
            t2882 = t2881;
        }
        int v2883 = t2882;
        uint64_t v2884 = (v2877 ? UINT64_C(28) : (v2878 ? UINT64_C(29) : v2703));
        uint64_t v2885 = (v2878 ? (((((uint64_t)(v2875 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(28)]))) : v2754);
        uint64_t v2886 = (v2879 ? ((v2720 + UINT64_C(1)) & UINT64_C(255)) : v2720);
        uint64_t v2887 = (v2879 ? UINT64_C(27) : v2771);
        uint64_t v2888 = (v2879 ? ((uint64_t)((UINT64_C(28) + v2875) & UINT64_C(255))) : v2737);
        uint64_t v2889 = ((v2877 || v2878) ? UINT64_C(1) : ((v2883 || (v2876 && (!v2879))) ? UINT64_C(2) : v2788));
        t2890 = v2889;
    } else {
        t2890 = v2788;
    }
    uint64_t v2891 = t2890;
    int v2892 = (UINT64_C(28) < v7);
    uint64_t t2908;
    if (v2892) {
        uint64_t v2893 = ((uint64_t)in_b[UINT64_C(28)]);
        int v2894 = ((v2891 == UINT64_C(0)) && (UINT64_C(28) == v2840));
        int v2895 = (v2894 && (v2893 == UINT64_C(0)));
        int v2896 = ((v2894 && ((v2893 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(29) < ((uint64_t)((uint64_t)in_b_len))));
        int v2897 = (((v2894 && (v2893 != UINT64_C(0))) && (v2893 < UINT64_C(64))) && (((uint64_t)((UINT64_C(28) + v2893) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2900 = ((v2891 == UINT64_C(0)) && (UINT64_C(28) != v2840));
        if (t2900) {
                uint64_t v2898 = v2893;
            int t2899 = (!(((((v2898 | UINT64_C(32)) >= UINT64_C(97)) && ((v2898 | UINT64_C(32)) <= UINT64_C(122))) || ((v2898 >= UINT64_C(48)) && (v2898 <= UINT64_C(57)))) || (v2898 == UINT64_C(45))));
            if (!t2899) {
                t2899 = ((v2893 == UINT64_C(45)) && ((UINT64_C(28) == ((v2874 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(29) == v2840)));
            }
            t2900 = t2899;
        }
        int v2901 = t2900;
        uint64_t v2902 = (v2895 ? UINT64_C(29) : (v2896 ? UINT64_C(30) : v2806));
        uint64_t v2903 = (v2896 ? (((((uint64_t)(v2893 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(29)]))) : v2857);
        uint64_t v2904 = (v2897 ? ((v2823 + UINT64_C(1)) & UINT64_C(255)) : v2823);
        uint64_t v2905 = (v2897 ? UINT64_C(28) : v2874);
        uint64_t v2906 = (v2897 ? ((uint64_t)((UINT64_C(29) + v2893) & UINT64_C(255))) : v2840);
        uint64_t v2907 = ((v2895 || v2896) ? UINT64_C(1) : ((v2901 || (v2894 && (!v2897))) ? UINT64_C(2) : v2891));
        t2908 = v2902;
    } else {
        t2908 = v2806;
    }
    uint64_t v2909 = t2908;
    uint64_t t2925;
    if (v2892) {
        uint64_t v2910 = ((uint64_t)in_b[UINT64_C(28)]);
        int v2911 = ((v2891 == UINT64_C(0)) && (UINT64_C(28) == v2840));
        int v2912 = (v2911 && (v2910 == UINT64_C(0)));
        int v2913 = ((v2911 && ((v2910 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(29) < ((uint64_t)((uint64_t)in_b_len))));
        int v2914 = (((v2911 && (v2910 != UINT64_C(0))) && (v2910 < UINT64_C(64))) && (((uint64_t)((UINT64_C(28) + v2910) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2917 = ((v2891 == UINT64_C(0)) && (UINT64_C(28) != v2840));
        if (t2917) {
                uint64_t v2915 = v2910;
            int t2916 = (!(((((v2915 | UINT64_C(32)) >= UINT64_C(97)) && ((v2915 | UINT64_C(32)) <= UINT64_C(122))) || ((v2915 >= UINT64_C(48)) && (v2915 <= UINT64_C(57)))) || (v2915 == UINT64_C(45))));
            if (!t2916) {
                t2916 = ((v2910 == UINT64_C(45)) && ((UINT64_C(28) == ((v2874 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(29) == v2840)));
            }
            t2917 = t2916;
        }
        int v2918 = t2917;
        uint64_t v2919 = (v2912 ? UINT64_C(29) : (v2913 ? UINT64_C(30) : v2806));
        uint64_t v2920 = (v2913 ? (((((uint64_t)(v2910 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(29)]))) : v2857);
        uint64_t v2921 = (v2914 ? ((v2823 + UINT64_C(1)) & UINT64_C(255)) : v2823);
        uint64_t v2922 = (v2914 ? UINT64_C(28) : v2874);
        uint64_t v2923 = (v2914 ? ((uint64_t)((UINT64_C(29) + v2910) & UINT64_C(255))) : v2840);
        uint64_t v2924 = ((v2912 || v2913) ? UINT64_C(1) : ((v2918 || (v2911 && (!v2914))) ? UINT64_C(2) : v2891));
        t2925 = v2921;
    } else {
        t2925 = v2823;
    }
    uint64_t v2926 = t2925;
    uint64_t t2942;
    if (v2892) {
        uint64_t v2927 = ((uint64_t)in_b[UINT64_C(28)]);
        int v2928 = ((v2891 == UINT64_C(0)) && (UINT64_C(28) == v2840));
        int v2929 = (v2928 && (v2927 == UINT64_C(0)));
        int v2930 = ((v2928 && ((v2927 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(29) < ((uint64_t)((uint64_t)in_b_len))));
        int v2931 = (((v2928 && (v2927 != UINT64_C(0))) && (v2927 < UINT64_C(64))) && (((uint64_t)((UINT64_C(28) + v2927) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2934 = ((v2891 == UINT64_C(0)) && (UINT64_C(28) != v2840));
        if (t2934) {
                uint64_t v2932 = v2927;
            int t2933 = (!(((((v2932 | UINT64_C(32)) >= UINT64_C(97)) && ((v2932 | UINT64_C(32)) <= UINT64_C(122))) || ((v2932 >= UINT64_C(48)) && (v2932 <= UINT64_C(57)))) || (v2932 == UINT64_C(45))));
            if (!t2933) {
                t2933 = ((v2927 == UINT64_C(45)) && ((UINT64_C(28) == ((v2874 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(29) == v2840)));
            }
            t2934 = t2933;
        }
        int v2935 = t2934;
        uint64_t v2936 = (v2929 ? UINT64_C(29) : (v2930 ? UINT64_C(30) : v2806));
        uint64_t v2937 = (v2930 ? (((((uint64_t)(v2927 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(29)]))) : v2857);
        uint64_t v2938 = (v2931 ? ((v2823 + UINT64_C(1)) & UINT64_C(255)) : v2823);
        uint64_t v2939 = (v2931 ? UINT64_C(28) : v2874);
        uint64_t v2940 = (v2931 ? ((uint64_t)((UINT64_C(29) + v2927) & UINT64_C(255))) : v2840);
        uint64_t v2941 = ((v2929 || v2930) ? UINT64_C(1) : ((v2935 || (v2928 && (!v2931))) ? UINT64_C(2) : v2891));
        t2942 = v2940;
    } else {
        t2942 = v2840;
    }
    uint64_t v2943 = t2942;
    uint64_t t2959;
    if (v2892) {
        uint64_t v2944 = ((uint64_t)in_b[UINT64_C(28)]);
        int v2945 = ((v2891 == UINT64_C(0)) && (UINT64_C(28) == v2840));
        int v2946 = (v2945 && (v2944 == UINT64_C(0)));
        int v2947 = ((v2945 && ((v2944 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(29) < ((uint64_t)((uint64_t)in_b_len))));
        int v2948 = (((v2945 && (v2944 != UINT64_C(0))) && (v2944 < UINT64_C(64))) && (((uint64_t)((UINT64_C(28) + v2944) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2951 = ((v2891 == UINT64_C(0)) && (UINT64_C(28) != v2840));
        if (t2951) {
                uint64_t v2949 = v2944;
            int t2950 = (!(((((v2949 | UINT64_C(32)) >= UINT64_C(97)) && ((v2949 | UINT64_C(32)) <= UINT64_C(122))) || ((v2949 >= UINT64_C(48)) && (v2949 <= UINT64_C(57)))) || (v2949 == UINT64_C(45))));
            if (!t2950) {
                t2950 = ((v2944 == UINT64_C(45)) && ((UINT64_C(28) == ((v2874 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(29) == v2840)));
            }
            t2951 = t2950;
        }
        int v2952 = t2951;
        uint64_t v2953 = (v2946 ? UINT64_C(29) : (v2947 ? UINT64_C(30) : v2806));
        uint64_t v2954 = (v2947 ? (((((uint64_t)(v2944 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(29)]))) : v2857);
        uint64_t v2955 = (v2948 ? ((v2823 + UINT64_C(1)) & UINT64_C(255)) : v2823);
        uint64_t v2956 = (v2948 ? UINT64_C(28) : v2874);
        uint64_t v2957 = (v2948 ? ((uint64_t)((UINT64_C(29) + v2944) & UINT64_C(255))) : v2840);
        uint64_t v2958 = ((v2946 || v2947) ? UINT64_C(1) : ((v2952 || (v2945 && (!v2948))) ? UINT64_C(2) : v2891));
        t2959 = v2954;
    } else {
        t2959 = v2857;
    }
    uint64_t v2960 = t2959;
    uint64_t t2976;
    if (v2892) {
        uint64_t v2961 = ((uint64_t)in_b[UINT64_C(28)]);
        int v2962 = ((v2891 == UINT64_C(0)) && (UINT64_C(28) == v2840));
        int v2963 = (v2962 && (v2961 == UINT64_C(0)));
        int v2964 = ((v2962 && ((v2961 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(29) < ((uint64_t)((uint64_t)in_b_len))));
        int v2965 = (((v2962 && (v2961 != UINT64_C(0))) && (v2961 < UINT64_C(64))) && (((uint64_t)((UINT64_C(28) + v2961) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2968 = ((v2891 == UINT64_C(0)) && (UINT64_C(28) != v2840));
        if (t2968) {
                uint64_t v2966 = v2961;
            int t2967 = (!(((((v2966 | UINT64_C(32)) >= UINT64_C(97)) && ((v2966 | UINT64_C(32)) <= UINT64_C(122))) || ((v2966 >= UINT64_C(48)) && (v2966 <= UINT64_C(57)))) || (v2966 == UINT64_C(45))));
            if (!t2967) {
                t2967 = ((v2961 == UINT64_C(45)) && ((UINT64_C(28) == ((v2874 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(29) == v2840)));
            }
            t2968 = t2967;
        }
        int v2969 = t2968;
        uint64_t v2970 = (v2963 ? UINT64_C(29) : (v2964 ? UINT64_C(30) : v2806));
        uint64_t v2971 = (v2964 ? (((((uint64_t)(v2961 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(29)]))) : v2857);
        uint64_t v2972 = (v2965 ? ((v2823 + UINT64_C(1)) & UINT64_C(255)) : v2823);
        uint64_t v2973 = (v2965 ? UINT64_C(28) : v2874);
        uint64_t v2974 = (v2965 ? ((uint64_t)((UINT64_C(29) + v2961) & UINT64_C(255))) : v2840);
        uint64_t v2975 = ((v2963 || v2964) ? UINT64_C(1) : ((v2969 || (v2962 && (!v2965))) ? UINT64_C(2) : v2891));
        t2976 = v2973;
    } else {
        t2976 = v2874;
    }
    uint64_t v2977 = t2976;
    uint64_t t2993;
    if (v2892) {
        uint64_t v2978 = ((uint64_t)in_b[UINT64_C(28)]);
        int v2979 = ((v2891 == UINT64_C(0)) && (UINT64_C(28) == v2840));
        int v2980 = (v2979 && (v2978 == UINT64_C(0)));
        int v2981 = ((v2979 && ((v2978 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(29) < ((uint64_t)((uint64_t)in_b_len))));
        int v2982 = (((v2979 && (v2978 != UINT64_C(0))) && (v2978 < UINT64_C(64))) && (((uint64_t)((UINT64_C(28) + v2978) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t2985 = ((v2891 == UINT64_C(0)) && (UINT64_C(28) != v2840));
        if (t2985) {
                uint64_t v2983 = v2978;
            int t2984 = (!(((((v2983 | UINT64_C(32)) >= UINT64_C(97)) && ((v2983 | UINT64_C(32)) <= UINT64_C(122))) || ((v2983 >= UINT64_C(48)) && (v2983 <= UINT64_C(57)))) || (v2983 == UINT64_C(45))));
            if (!t2984) {
                t2984 = ((v2978 == UINT64_C(45)) && ((UINT64_C(28) == ((v2874 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(29) == v2840)));
            }
            t2985 = t2984;
        }
        int v2986 = t2985;
        uint64_t v2987 = (v2980 ? UINT64_C(29) : (v2981 ? UINT64_C(30) : v2806));
        uint64_t v2988 = (v2981 ? (((((uint64_t)(v2978 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(29)]))) : v2857);
        uint64_t v2989 = (v2982 ? ((v2823 + UINT64_C(1)) & UINT64_C(255)) : v2823);
        uint64_t v2990 = (v2982 ? UINT64_C(28) : v2874);
        uint64_t v2991 = (v2982 ? ((uint64_t)((UINT64_C(29) + v2978) & UINT64_C(255))) : v2840);
        uint64_t v2992 = ((v2980 || v2981) ? UINT64_C(1) : ((v2986 || (v2979 && (!v2982))) ? UINT64_C(2) : v2891));
        t2993 = v2992;
    } else {
        t2993 = v2891;
    }
    uint64_t v2994 = t2993;
    int v2995 = (UINT64_C(29) < v7);
    uint64_t t3011;
    if (v2995) {
        uint64_t v2996 = ((uint64_t)in_b[UINT64_C(29)]);
        int v2997 = ((v2994 == UINT64_C(0)) && (UINT64_C(29) == v2943));
        int v2998 = (v2997 && (v2996 == UINT64_C(0)));
        int v2999 = ((v2997 && ((v2996 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(30) < ((uint64_t)((uint64_t)in_b_len))));
        int v3000 = (((v2997 && (v2996 != UINT64_C(0))) && (v2996 < UINT64_C(64))) && (((uint64_t)((UINT64_C(29) + v2996) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3003 = ((v2994 == UINT64_C(0)) && (UINT64_C(29) != v2943));
        if (t3003) {
                uint64_t v3001 = v2996;
            int t3002 = (!(((((v3001 | UINT64_C(32)) >= UINT64_C(97)) && ((v3001 | UINT64_C(32)) <= UINT64_C(122))) || ((v3001 >= UINT64_C(48)) && (v3001 <= UINT64_C(57)))) || (v3001 == UINT64_C(45))));
            if (!t3002) {
                t3002 = ((v2996 == UINT64_C(45)) && ((UINT64_C(29) == ((v2977 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(30) == v2943)));
            }
            t3003 = t3002;
        }
        int v3004 = t3003;
        uint64_t v3005 = (v2998 ? UINT64_C(30) : (v2999 ? UINT64_C(31) : v2909));
        uint64_t v3006 = (v2999 ? (((((uint64_t)(v2996 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(30)]))) : v2960);
        uint64_t v3007 = (v3000 ? ((v2926 + UINT64_C(1)) & UINT64_C(255)) : v2926);
        uint64_t v3008 = (v3000 ? UINT64_C(29) : v2977);
        uint64_t v3009 = (v3000 ? ((uint64_t)((UINT64_C(30) + v2996) & UINT64_C(255))) : v2943);
        uint64_t v3010 = ((v2998 || v2999) ? UINT64_C(1) : ((v3004 || (v2997 && (!v3000))) ? UINT64_C(2) : v2994));
        t3011 = v3005;
    } else {
        t3011 = v2909;
    }
    uint64_t v3012 = t3011;
    uint64_t t3028;
    if (v2995) {
        uint64_t v3013 = ((uint64_t)in_b[UINT64_C(29)]);
        int v3014 = ((v2994 == UINT64_C(0)) && (UINT64_C(29) == v2943));
        int v3015 = (v3014 && (v3013 == UINT64_C(0)));
        int v3016 = ((v3014 && ((v3013 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(30) < ((uint64_t)((uint64_t)in_b_len))));
        int v3017 = (((v3014 && (v3013 != UINT64_C(0))) && (v3013 < UINT64_C(64))) && (((uint64_t)((UINT64_C(29) + v3013) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3020 = ((v2994 == UINT64_C(0)) && (UINT64_C(29) != v2943));
        if (t3020) {
                uint64_t v3018 = v3013;
            int t3019 = (!(((((v3018 | UINT64_C(32)) >= UINT64_C(97)) && ((v3018 | UINT64_C(32)) <= UINT64_C(122))) || ((v3018 >= UINT64_C(48)) && (v3018 <= UINT64_C(57)))) || (v3018 == UINT64_C(45))));
            if (!t3019) {
                t3019 = ((v3013 == UINT64_C(45)) && ((UINT64_C(29) == ((v2977 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(30) == v2943)));
            }
            t3020 = t3019;
        }
        int v3021 = t3020;
        uint64_t v3022 = (v3015 ? UINT64_C(30) : (v3016 ? UINT64_C(31) : v2909));
        uint64_t v3023 = (v3016 ? (((((uint64_t)(v3013 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(30)]))) : v2960);
        uint64_t v3024 = (v3017 ? ((v2926 + UINT64_C(1)) & UINT64_C(255)) : v2926);
        uint64_t v3025 = (v3017 ? UINT64_C(29) : v2977);
        uint64_t v3026 = (v3017 ? ((uint64_t)((UINT64_C(30) + v3013) & UINT64_C(255))) : v2943);
        uint64_t v3027 = ((v3015 || v3016) ? UINT64_C(1) : ((v3021 || (v3014 && (!v3017))) ? UINT64_C(2) : v2994));
        t3028 = v3024;
    } else {
        t3028 = v2926;
    }
    uint64_t v3029 = t3028;
    uint64_t t3045;
    if (v2995) {
        uint64_t v3030 = ((uint64_t)in_b[UINT64_C(29)]);
        int v3031 = ((v2994 == UINT64_C(0)) && (UINT64_C(29) == v2943));
        int v3032 = (v3031 && (v3030 == UINT64_C(0)));
        int v3033 = ((v3031 && ((v3030 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(30) < ((uint64_t)((uint64_t)in_b_len))));
        int v3034 = (((v3031 && (v3030 != UINT64_C(0))) && (v3030 < UINT64_C(64))) && (((uint64_t)((UINT64_C(29) + v3030) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3037 = ((v2994 == UINT64_C(0)) && (UINT64_C(29) != v2943));
        if (t3037) {
                uint64_t v3035 = v3030;
            int t3036 = (!(((((v3035 | UINT64_C(32)) >= UINT64_C(97)) && ((v3035 | UINT64_C(32)) <= UINT64_C(122))) || ((v3035 >= UINT64_C(48)) && (v3035 <= UINT64_C(57)))) || (v3035 == UINT64_C(45))));
            if (!t3036) {
                t3036 = ((v3030 == UINT64_C(45)) && ((UINT64_C(29) == ((v2977 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(30) == v2943)));
            }
            t3037 = t3036;
        }
        int v3038 = t3037;
        uint64_t v3039 = (v3032 ? UINT64_C(30) : (v3033 ? UINT64_C(31) : v2909));
        uint64_t v3040 = (v3033 ? (((((uint64_t)(v3030 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(30)]))) : v2960);
        uint64_t v3041 = (v3034 ? ((v2926 + UINT64_C(1)) & UINT64_C(255)) : v2926);
        uint64_t v3042 = (v3034 ? UINT64_C(29) : v2977);
        uint64_t v3043 = (v3034 ? ((uint64_t)((UINT64_C(30) + v3030) & UINT64_C(255))) : v2943);
        uint64_t v3044 = ((v3032 || v3033) ? UINT64_C(1) : ((v3038 || (v3031 && (!v3034))) ? UINT64_C(2) : v2994));
        t3045 = v3043;
    } else {
        t3045 = v2943;
    }
    uint64_t v3046 = t3045;
    uint64_t t3062;
    if (v2995) {
        uint64_t v3047 = ((uint64_t)in_b[UINT64_C(29)]);
        int v3048 = ((v2994 == UINT64_C(0)) && (UINT64_C(29) == v2943));
        int v3049 = (v3048 && (v3047 == UINT64_C(0)));
        int v3050 = ((v3048 && ((v3047 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(30) < ((uint64_t)((uint64_t)in_b_len))));
        int v3051 = (((v3048 && (v3047 != UINT64_C(0))) && (v3047 < UINT64_C(64))) && (((uint64_t)((UINT64_C(29) + v3047) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3054 = ((v2994 == UINT64_C(0)) && (UINT64_C(29) != v2943));
        if (t3054) {
                uint64_t v3052 = v3047;
            int t3053 = (!(((((v3052 | UINT64_C(32)) >= UINT64_C(97)) && ((v3052 | UINT64_C(32)) <= UINT64_C(122))) || ((v3052 >= UINT64_C(48)) && (v3052 <= UINT64_C(57)))) || (v3052 == UINT64_C(45))));
            if (!t3053) {
                t3053 = ((v3047 == UINT64_C(45)) && ((UINT64_C(29) == ((v2977 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(30) == v2943)));
            }
            t3054 = t3053;
        }
        int v3055 = t3054;
        uint64_t v3056 = (v3049 ? UINT64_C(30) : (v3050 ? UINT64_C(31) : v2909));
        uint64_t v3057 = (v3050 ? (((((uint64_t)(v3047 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(30)]))) : v2960);
        uint64_t v3058 = (v3051 ? ((v2926 + UINT64_C(1)) & UINT64_C(255)) : v2926);
        uint64_t v3059 = (v3051 ? UINT64_C(29) : v2977);
        uint64_t v3060 = (v3051 ? ((uint64_t)((UINT64_C(30) + v3047) & UINT64_C(255))) : v2943);
        uint64_t v3061 = ((v3049 || v3050) ? UINT64_C(1) : ((v3055 || (v3048 && (!v3051))) ? UINT64_C(2) : v2994));
        t3062 = v3057;
    } else {
        t3062 = v2960;
    }
    uint64_t v3063 = t3062;
    uint64_t t3079;
    if (v2995) {
        uint64_t v3064 = ((uint64_t)in_b[UINT64_C(29)]);
        int v3065 = ((v2994 == UINT64_C(0)) && (UINT64_C(29) == v2943));
        int v3066 = (v3065 && (v3064 == UINT64_C(0)));
        int v3067 = ((v3065 && ((v3064 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(30) < ((uint64_t)((uint64_t)in_b_len))));
        int v3068 = (((v3065 && (v3064 != UINT64_C(0))) && (v3064 < UINT64_C(64))) && (((uint64_t)((UINT64_C(29) + v3064) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3071 = ((v2994 == UINT64_C(0)) && (UINT64_C(29) != v2943));
        if (t3071) {
                uint64_t v3069 = v3064;
            int t3070 = (!(((((v3069 | UINT64_C(32)) >= UINT64_C(97)) && ((v3069 | UINT64_C(32)) <= UINT64_C(122))) || ((v3069 >= UINT64_C(48)) && (v3069 <= UINT64_C(57)))) || (v3069 == UINT64_C(45))));
            if (!t3070) {
                t3070 = ((v3064 == UINT64_C(45)) && ((UINT64_C(29) == ((v2977 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(30) == v2943)));
            }
            t3071 = t3070;
        }
        int v3072 = t3071;
        uint64_t v3073 = (v3066 ? UINT64_C(30) : (v3067 ? UINT64_C(31) : v2909));
        uint64_t v3074 = (v3067 ? (((((uint64_t)(v3064 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(30)]))) : v2960);
        uint64_t v3075 = (v3068 ? ((v2926 + UINT64_C(1)) & UINT64_C(255)) : v2926);
        uint64_t v3076 = (v3068 ? UINT64_C(29) : v2977);
        uint64_t v3077 = (v3068 ? ((uint64_t)((UINT64_C(30) + v3064) & UINT64_C(255))) : v2943);
        uint64_t v3078 = ((v3066 || v3067) ? UINT64_C(1) : ((v3072 || (v3065 && (!v3068))) ? UINT64_C(2) : v2994));
        t3079 = v3076;
    } else {
        t3079 = v2977;
    }
    uint64_t v3080 = t3079;
    uint64_t t3096;
    if (v2995) {
        uint64_t v3081 = ((uint64_t)in_b[UINT64_C(29)]);
        int v3082 = ((v2994 == UINT64_C(0)) && (UINT64_C(29) == v2943));
        int v3083 = (v3082 && (v3081 == UINT64_C(0)));
        int v3084 = ((v3082 && ((v3081 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(30) < ((uint64_t)((uint64_t)in_b_len))));
        int v3085 = (((v3082 && (v3081 != UINT64_C(0))) && (v3081 < UINT64_C(64))) && (((uint64_t)((UINT64_C(29) + v3081) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3088 = ((v2994 == UINT64_C(0)) && (UINT64_C(29) != v2943));
        if (t3088) {
                uint64_t v3086 = v3081;
            int t3087 = (!(((((v3086 | UINT64_C(32)) >= UINT64_C(97)) && ((v3086 | UINT64_C(32)) <= UINT64_C(122))) || ((v3086 >= UINT64_C(48)) && (v3086 <= UINT64_C(57)))) || (v3086 == UINT64_C(45))));
            if (!t3087) {
                t3087 = ((v3081 == UINT64_C(45)) && ((UINT64_C(29) == ((v2977 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(30) == v2943)));
            }
            t3088 = t3087;
        }
        int v3089 = t3088;
        uint64_t v3090 = (v3083 ? UINT64_C(30) : (v3084 ? UINT64_C(31) : v2909));
        uint64_t v3091 = (v3084 ? (((((uint64_t)(v3081 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(30)]))) : v2960);
        uint64_t v3092 = (v3085 ? ((v2926 + UINT64_C(1)) & UINT64_C(255)) : v2926);
        uint64_t v3093 = (v3085 ? UINT64_C(29) : v2977);
        uint64_t v3094 = (v3085 ? ((uint64_t)((UINT64_C(30) + v3081) & UINT64_C(255))) : v2943);
        uint64_t v3095 = ((v3083 || v3084) ? UINT64_C(1) : ((v3089 || (v3082 && (!v3085))) ? UINT64_C(2) : v2994));
        t3096 = v3095;
    } else {
        t3096 = v2994;
    }
    uint64_t v3097 = t3096;
    int v3098 = (UINT64_C(30) < v7);
    uint64_t t3114;
    if (v3098) {
        uint64_t v3099 = ((uint64_t)in_b[UINT64_C(30)]);
        int v3100 = ((v3097 == UINT64_C(0)) && (UINT64_C(30) == v3046));
        int v3101 = (v3100 && (v3099 == UINT64_C(0)));
        int v3102 = ((v3100 && ((v3099 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(31) < ((uint64_t)((uint64_t)in_b_len))));
        int v3103 = (((v3100 && (v3099 != UINT64_C(0))) && (v3099 < UINT64_C(64))) && (((uint64_t)((UINT64_C(30) + v3099) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3106 = ((v3097 == UINT64_C(0)) && (UINT64_C(30) != v3046));
        if (t3106) {
                uint64_t v3104 = v3099;
            int t3105 = (!(((((v3104 | UINT64_C(32)) >= UINT64_C(97)) && ((v3104 | UINT64_C(32)) <= UINT64_C(122))) || ((v3104 >= UINT64_C(48)) && (v3104 <= UINT64_C(57)))) || (v3104 == UINT64_C(45))));
            if (!t3105) {
                t3105 = ((v3099 == UINT64_C(45)) && ((UINT64_C(30) == ((v3080 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(31) == v3046)));
            }
            t3106 = t3105;
        }
        int v3107 = t3106;
        uint64_t v3108 = (v3101 ? UINT64_C(31) : (v3102 ? UINT64_C(32) : v3012));
        uint64_t v3109 = (v3102 ? (((((uint64_t)(v3099 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(31)]))) : v3063);
        uint64_t v3110 = (v3103 ? ((v3029 + UINT64_C(1)) & UINT64_C(255)) : v3029);
        uint64_t v3111 = (v3103 ? UINT64_C(30) : v3080);
        uint64_t v3112 = (v3103 ? ((uint64_t)((UINT64_C(31) + v3099) & UINT64_C(255))) : v3046);
        uint64_t v3113 = ((v3101 || v3102) ? UINT64_C(1) : ((v3107 || (v3100 && (!v3103))) ? UINT64_C(2) : v3097));
        t3114 = v3108;
    } else {
        t3114 = v3012;
    }
    uint64_t v3115 = t3114;
    uint64_t t3131;
    if (v3098) {
        uint64_t v3116 = ((uint64_t)in_b[UINT64_C(30)]);
        int v3117 = ((v3097 == UINT64_C(0)) && (UINT64_C(30) == v3046));
        int v3118 = (v3117 && (v3116 == UINT64_C(0)));
        int v3119 = ((v3117 && ((v3116 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(31) < ((uint64_t)((uint64_t)in_b_len))));
        int v3120 = (((v3117 && (v3116 != UINT64_C(0))) && (v3116 < UINT64_C(64))) && (((uint64_t)((UINT64_C(30) + v3116) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3123 = ((v3097 == UINT64_C(0)) && (UINT64_C(30) != v3046));
        if (t3123) {
                uint64_t v3121 = v3116;
            int t3122 = (!(((((v3121 | UINT64_C(32)) >= UINT64_C(97)) && ((v3121 | UINT64_C(32)) <= UINT64_C(122))) || ((v3121 >= UINT64_C(48)) && (v3121 <= UINT64_C(57)))) || (v3121 == UINT64_C(45))));
            if (!t3122) {
                t3122 = ((v3116 == UINT64_C(45)) && ((UINT64_C(30) == ((v3080 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(31) == v3046)));
            }
            t3123 = t3122;
        }
        int v3124 = t3123;
        uint64_t v3125 = (v3118 ? UINT64_C(31) : (v3119 ? UINT64_C(32) : v3012));
        uint64_t v3126 = (v3119 ? (((((uint64_t)(v3116 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(31)]))) : v3063);
        uint64_t v3127 = (v3120 ? ((v3029 + UINT64_C(1)) & UINT64_C(255)) : v3029);
        uint64_t v3128 = (v3120 ? UINT64_C(30) : v3080);
        uint64_t v3129 = (v3120 ? ((uint64_t)((UINT64_C(31) + v3116) & UINT64_C(255))) : v3046);
        uint64_t v3130 = ((v3118 || v3119) ? UINT64_C(1) : ((v3124 || (v3117 && (!v3120))) ? UINT64_C(2) : v3097));
        t3131 = v3127;
    } else {
        t3131 = v3029;
    }
    uint64_t v3132 = t3131;
    uint64_t t3148;
    if (v3098) {
        uint64_t v3133 = ((uint64_t)in_b[UINT64_C(30)]);
        int v3134 = ((v3097 == UINT64_C(0)) && (UINT64_C(30) == v3046));
        int v3135 = (v3134 && (v3133 == UINT64_C(0)));
        int v3136 = ((v3134 && ((v3133 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(31) < ((uint64_t)((uint64_t)in_b_len))));
        int v3137 = (((v3134 && (v3133 != UINT64_C(0))) && (v3133 < UINT64_C(64))) && (((uint64_t)((UINT64_C(30) + v3133) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3140 = ((v3097 == UINT64_C(0)) && (UINT64_C(30) != v3046));
        if (t3140) {
                uint64_t v3138 = v3133;
            int t3139 = (!(((((v3138 | UINT64_C(32)) >= UINT64_C(97)) && ((v3138 | UINT64_C(32)) <= UINT64_C(122))) || ((v3138 >= UINT64_C(48)) && (v3138 <= UINT64_C(57)))) || (v3138 == UINT64_C(45))));
            if (!t3139) {
                t3139 = ((v3133 == UINT64_C(45)) && ((UINT64_C(30) == ((v3080 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(31) == v3046)));
            }
            t3140 = t3139;
        }
        int v3141 = t3140;
        uint64_t v3142 = (v3135 ? UINT64_C(31) : (v3136 ? UINT64_C(32) : v3012));
        uint64_t v3143 = (v3136 ? (((((uint64_t)(v3133 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(31)]))) : v3063);
        uint64_t v3144 = (v3137 ? ((v3029 + UINT64_C(1)) & UINT64_C(255)) : v3029);
        uint64_t v3145 = (v3137 ? UINT64_C(30) : v3080);
        uint64_t v3146 = (v3137 ? ((uint64_t)((UINT64_C(31) + v3133) & UINT64_C(255))) : v3046);
        uint64_t v3147 = ((v3135 || v3136) ? UINT64_C(1) : ((v3141 || (v3134 && (!v3137))) ? UINT64_C(2) : v3097));
        t3148 = v3146;
    } else {
        t3148 = v3046;
    }
    uint64_t v3149 = t3148;
    uint64_t t3165;
    if (v3098) {
        uint64_t v3150 = ((uint64_t)in_b[UINT64_C(30)]);
        int v3151 = ((v3097 == UINT64_C(0)) && (UINT64_C(30) == v3046));
        int v3152 = (v3151 && (v3150 == UINT64_C(0)));
        int v3153 = ((v3151 && ((v3150 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(31) < ((uint64_t)((uint64_t)in_b_len))));
        int v3154 = (((v3151 && (v3150 != UINT64_C(0))) && (v3150 < UINT64_C(64))) && (((uint64_t)((UINT64_C(30) + v3150) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3157 = ((v3097 == UINT64_C(0)) && (UINT64_C(30) != v3046));
        if (t3157) {
                uint64_t v3155 = v3150;
            int t3156 = (!(((((v3155 | UINT64_C(32)) >= UINT64_C(97)) && ((v3155 | UINT64_C(32)) <= UINT64_C(122))) || ((v3155 >= UINT64_C(48)) && (v3155 <= UINT64_C(57)))) || (v3155 == UINT64_C(45))));
            if (!t3156) {
                t3156 = ((v3150 == UINT64_C(45)) && ((UINT64_C(30) == ((v3080 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(31) == v3046)));
            }
            t3157 = t3156;
        }
        int v3158 = t3157;
        uint64_t v3159 = (v3152 ? UINT64_C(31) : (v3153 ? UINT64_C(32) : v3012));
        uint64_t v3160 = (v3153 ? (((((uint64_t)(v3150 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(31)]))) : v3063);
        uint64_t v3161 = (v3154 ? ((v3029 + UINT64_C(1)) & UINT64_C(255)) : v3029);
        uint64_t v3162 = (v3154 ? UINT64_C(30) : v3080);
        uint64_t v3163 = (v3154 ? ((uint64_t)((UINT64_C(31) + v3150) & UINT64_C(255))) : v3046);
        uint64_t v3164 = ((v3152 || v3153) ? UINT64_C(1) : ((v3158 || (v3151 && (!v3154))) ? UINT64_C(2) : v3097));
        t3165 = v3160;
    } else {
        t3165 = v3063;
    }
    uint64_t v3166 = t3165;
    uint64_t t3182;
    if (v3098) {
        uint64_t v3167 = ((uint64_t)in_b[UINT64_C(30)]);
        int v3168 = ((v3097 == UINT64_C(0)) && (UINT64_C(30) == v3046));
        int v3169 = (v3168 && (v3167 == UINT64_C(0)));
        int v3170 = ((v3168 && ((v3167 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(31) < ((uint64_t)((uint64_t)in_b_len))));
        int v3171 = (((v3168 && (v3167 != UINT64_C(0))) && (v3167 < UINT64_C(64))) && (((uint64_t)((UINT64_C(30) + v3167) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3174 = ((v3097 == UINT64_C(0)) && (UINT64_C(30) != v3046));
        if (t3174) {
                uint64_t v3172 = v3167;
            int t3173 = (!(((((v3172 | UINT64_C(32)) >= UINT64_C(97)) && ((v3172 | UINT64_C(32)) <= UINT64_C(122))) || ((v3172 >= UINT64_C(48)) && (v3172 <= UINT64_C(57)))) || (v3172 == UINT64_C(45))));
            if (!t3173) {
                t3173 = ((v3167 == UINT64_C(45)) && ((UINT64_C(30) == ((v3080 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(31) == v3046)));
            }
            t3174 = t3173;
        }
        int v3175 = t3174;
        uint64_t v3176 = (v3169 ? UINT64_C(31) : (v3170 ? UINT64_C(32) : v3012));
        uint64_t v3177 = (v3170 ? (((((uint64_t)(v3167 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(31)]))) : v3063);
        uint64_t v3178 = (v3171 ? ((v3029 + UINT64_C(1)) & UINT64_C(255)) : v3029);
        uint64_t v3179 = (v3171 ? UINT64_C(30) : v3080);
        uint64_t v3180 = (v3171 ? ((uint64_t)((UINT64_C(31) + v3167) & UINT64_C(255))) : v3046);
        uint64_t v3181 = ((v3169 || v3170) ? UINT64_C(1) : ((v3175 || (v3168 && (!v3171))) ? UINT64_C(2) : v3097));
        t3182 = v3179;
    } else {
        t3182 = v3080;
    }
    uint64_t v3183 = t3182;
    uint64_t t3199;
    if (v3098) {
        uint64_t v3184 = ((uint64_t)in_b[UINT64_C(30)]);
        int v3185 = ((v3097 == UINT64_C(0)) && (UINT64_C(30) == v3046));
        int v3186 = (v3185 && (v3184 == UINT64_C(0)));
        int v3187 = ((v3185 && ((v3184 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(31) < ((uint64_t)((uint64_t)in_b_len))));
        int v3188 = (((v3185 && (v3184 != UINT64_C(0))) && (v3184 < UINT64_C(64))) && (((uint64_t)((UINT64_C(30) + v3184) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3191 = ((v3097 == UINT64_C(0)) && (UINT64_C(30) != v3046));
        if (t3191) {
                uint64_t v3189 = v3184;
            int t3190 = (!(((((v3189 | UINT64_C(32)) >= UINT64_C(97)) && ((v3189 | UINT64_C(32)) <= UINT64_C(122))) || ((v3189 >= UINT64_C(48)) && (v3189 <= UINT64_C(57)))) || (v3189 == UINT64_C(45))));
            if (!t3190) {
                t3190 = ((v3184 == UINT64_C(45)) && ((UINT64_C(30) == ((v3080 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(31) == v3046)));
            }
            t3191 = t3190;
        }
        int v3192 = t3191;
        uint64_t v3193 = (v3186 ? UINT64_C(31) : (v3187 ? UINT64_C(32) : v3012));
        uint64_t v3194 = (v3187 ? (((((uint64_t)(v3184 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(31)]))) : v3063);
        uint64_t v3195 = (v3188 ? ((v3029 + UINT64_C(1)) & UINT64_C(255)) : v3029);
        uint64_t v3196 = (v3188 ? UINT64_C(30) : v3080);
        uint64_t v3197 = (v3188 ? ((uint64_t)((UINT64_C(31) + v3184) & UINT64_C(255))) : v3046);
        uint64_t v3198 = ((v3186 || v3187) ? UINT64_C(1) : ((v3192 || (v3185 && (!v3188))) ? UINT64_C(2) : v3097));
        t3199 = v3198;
    } else {
        t3199 = v3097;
    }
    uint64_t v3200 = t3199;
    int v3201 = (UINT64_C(31) < v7);
    uint64_t t3217;
    if (v3201) {
        uint64_t v3202 = ((uint64_t)in_b[UINT64_C(31)]);
        int v3203 = ((v3200 == UINT64_C(0)) && (UINT64_C(31) == v3149));
        int v3204 = (v3203 && (v3202 == UINT64_C(0)));
        int v3205 = ((v3203 && ((v3202 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(32) < ((uint64_t)((uint64_t)in_b_len))));
        int v3206 = (((v3203 && (v3202 != UINT64_C(0))) && (v3202 < UINT64_C(64))) && (((uint64_t)((UINT64_C(31) + v3202) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3209 = ((v3200 == UINT64_C(0)) && (UINT64_C(31) != v3149));
        if (t3209) {
                uint64_t v3207 = v3202;
            int t3208 = (!(((((v3207 | UINT64_C(32)) >= UINT64_C(97)) && ((v3207 | UINT64_C(32)) <= UINT64_C(122))) || ((v3207 >= UINT64_C(48)) && (v3207 <= UINT64_C(57)))) || (v3207 == UINT64_C(45))));
            if (!t3208) {
                t3208 = ((v3202 == UINT64_C(45)) && ((UINT64_C(31) == ((v3183 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(32) == v3149)));
            }
            t3209 = t3208;
        }
        int v3210 = t3209;
        uint64_t v3211 = (v3204 ? UINT64_C(32) : (v3205 ? UINT64_C(33) : v3115));
        uint64_t v3212 = (v3205 ? (((((uint64_t)(v3202 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(32)]))) : v3166);
        uint64_t v3213 = (v3206 ? ((v3132 + UINT64_C(1)) & UINT64_C(255)) : v3132);
        uint64_t v3214 = (v3206 ? UINT64_C(31) : v3183);
        uint64_t v3215 = (v3206 ? ((uint64_t)((UINT64_C(32) + v3202) & UINT64_C(255))) : v3149);
        uint64_t v3216 = ((v3204 || v3205) ? UINT64_C(1) : ((v3210 || (v3203 && (!v3206))) ? UINT64_C(2) : v3200));
        t3217 = v3211;
    } else {
        t3217 = v3115;
    }
    uint64_t v3218 = t3217;
    uint64_t t3234;
    if (v3201) {
        uint64_t v3219 = ((uint64_t)in_b[UINT64_C(31)]);
        int v3220 = ((v3200 == UINT64_C(0)) && (UINT64_C(31) == v3149));
        int v3221 = (v3220 && (v3219 == UINT64_C(0)));
        int v3222 = ((v3220 && ((v3219 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(32) < ((uint64_t)((uint64_t)in_b_len))));
        int v3223 = (((v3220 && (v3219 != UINT64_C(0))) && (v3219 < UINT64_C(64))) && (((uint64_t)((UINT64_C(31) + v3219) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3226 = ((v3200 == UINT64_C(0)) && (UINT64_C(31) != v3149));
        if (t3226) {
                uint64_t v3224 = v3219;
            int t3225 = (!(((((v3224 | UINT64_C(32)) >= UINT64_C(97)) && ((v3224 | UINT64_C(32)) <= UINT64_C(122))) || ((v3224 >= UINT64_C(48)) && (v3224 <= UINT64_C(57)))) || (v3224 == UINT64_C(45))));
            if (!t3225) {
                t3225 = ((v3219 == UINT64_C(45)) && ((UINT64_C(31) == ((v3183 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(32) == v3149)));
            }
            t3226 = t3225;
        }
        int v3227 = t3226;
        uint64_t v3228 = (v3221 ? UINT64_C(32) : (v3222 ? UINT64_C(33) : v3115));
        uint64_t v3229 = (v3222 ? (((((uint64_t)(v3219 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(32)]))) : v3166);
        uint64_t v3230 = (v3223 ? ((v3132 + UINT64_C(1)) & UINT64_C(255)) : v3132);
        uint64_t v3231 = (v3223 ? UINT64_C(31) : v3183);
        uint64_t v3232 = (v3223 ? ((uint64_t)((UINT64_C(32) + v3219) & UINT64_C(255))) : v3149);
        uint64_t v3233 = ((v3221 || v3222) ? UINT64_C(1) : ((v3227 || (v3220 && (!v3223))) ? UINT64_C(2) : v3200));
        t3234 = v3230;
    } else {
        t3234 = v3132;
    }
    uint64_t v3235 = t3234;
    uint64_t t3251;
    if (v3201) {
        uint64_t v3236 = ((uint64_t)in_b[UINT64_C(31)]);
        int v3237 = ((v3200 == UINT64_C(0)) && (UINT64_C(31) == v3149));
        int v3238 = (v3237 && (v3236 == UINT64_C(0)));
        int v3239 = ((v3237 && ((v3236 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(32) < ((uint64_t)((uint64_t)in_b_len))));
        int v3240 = (((v3237 && (v3236 != UINT64_C(0))) && (v3236 < UINT64_C(64))) && (((uint64_t)((UINT64_C(31) + v3236) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3243 = ((v3200 == UINT64_C(0)) && (UINT64_C(31) != v3149));
        if (t3243) {
                uint64_t v3241 = v3236;
            int t3242 = (!(((((v3241 | UINT64_C(32)) >= UINT64_C(97)) && ((v3241 | UINT64_C(32)) <= UINT64_C(122))) || ((v3241 >= UINT64_C(48)) && (v3241 <= UINT64_C(57)))) || (v3241 == UINT64_C(45))));
            if (!t3242) {
                t3242 = ((v3236 == UINT64_C(45)) && ((UINT64_C(31) == ((v3183 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(32) == v3149)));
            }
            t3243 = t3242;
        }
        int v3244 = t3243;
        uint64_t v3245 = (v3238 ? UINT64_C(32) : (v3239 ? UINT64_C(33) : v3115));
        uint64_t v3246 = (v3239 ? (((((uint64_t)(v3236 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(32)]))) : v3166);
        uint64_t v3247 = (v3240 ? ((v3132 + UINT64_C(1)) & UINT64_C(255)) : v3132);
        uint64_t v3248 = (v3240 ? UINT64_C(31) : v3183);
        uint64_t v3249 = (v3240 ? ((uint64_t)((UINT64_C(32) + v3236) & UINT64_C(255))) : v3149);
        uint64_t v3250 = ((v3238 || v3239) ? UINT64_C(1) : ((v3244 || (v3237 && (!v3240))) ? UINT64_C(2) : v3200));
        t3251 = v3249;
    } else {
        t3251 = v3149;
    }
    uint64_t v3252 = t3251;
    uint64_t t3268;
    if (v3201) {
        uint64_t v3253 = ((uint64_t)in_b[UINT64_C(31)]);
        int v3254 = ((v3200 == UINT64_C(0)) && (UINT64_C(31) == v3149));
        int v3255 = (v3254 && (v3253 == UINT64_C(0)));
        int v3256 = ((v3254 && ((v3253 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(32) < ((uint64_t)((uint64_t)in_b_len))));
        int v3257 = (((v3254 && (v3253 != UINT64_C(0))) && (v3253 < UINT64_C(64))) && (((uint64_t)((UINT64_C(31) + v3253) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3260 = ((v3200 == UINT64_C(0)) && (UINT64_C(31) != v3149));
        if (t3260) {
                uint64_t v3258 = v3253;
            int t3259 = (!(((((v3258 | UINT64_C(32)) >= UINT64_C(97)) && ((v3258 | UINT64_C(32)) <= UINT64_C(122))) || ((v3258 >= UINT64_C(48)) && (v3258 <= UINT64_C(57)))) || (v3258 == UINT64_C(45))));
            if (!t3259) {
                t3259 = ((v3253 == UINT64_C(45)) && ((UINT64_C(31) == ((v3183 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(32) == v3149)));
            }
            t3260 = t3259;
        }
        int v3261 = t3260;
        uint64_t v3262 = (v3255 ? UINT64_C(32) : (v3256 ? UINT64_C(33) : v3115));
        uint64_t v3263 = (v3256 ? (((((uint64_t)(v3253 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(32)]))) : v3166);
        uint64_t v3264 = (v3257 ? ((v3132 + UINT64_C(1)) & UINT64_C(255)) : v3132);
        uint64_t v3265 = (v3257 ? UINT64_C(31) : v3183);
        uint64_t v3266 = (v3257 ? ((uint64_t)((UINT64_C(32) + v3253) & UINT64_C(255))) : v3149);
        uint64_t v3267 = ((v3255 || v3256) ? UINT64_C(1) : ((v3261 || (v3254 && (!v3257))) ? UINT64_C(2) : v3200));
        t3268 = v3263;
    } else {
        t3268 = v3166;
    }
    uint64_t v3269 = t3268;
    uint64_t t3285;
    if (v3201) {
        uint64_t v3270 = ((uint64_t)in_b[UINT64_C(31)]);
        int v3271 = ((v3200 == UINT64_C(0)) && (UINT64_C(31) == v3149));
        int v3272 = (v3271 && (v3270 == UINT64_C(0)));
        int v3273 = ((v3271 && ((v3270 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(32) < ((uint64_t)((uint64_t)in_b_len))));
        int v3274 = (((v3271 && (v3270 != UINT64_C(0))) && (v3270 < UINT64_C(64))) && (((uint64_t)((UINT64_C(31) + v3270) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3277 = ((v3200 == UINT64_C(0)) && (UINT64_C(31) != v3149));
        if (t3277) {
                uint64_t v3275 = v3270;
            int t3276 = (!(((((v3275 | UINT64_C(32)) >= UINT64_C(97)) && ((v3275 | UINT64_C(32)) <= UINT64_C(122))) || ((v3275 >= UINT64_C(48)) && (v3275 <= UINT64_C(57)))) || (v3275 == UINT64_C(45))));
            if (!t3276) {
                t3276 = ((v3270 == UINT64_C(45)) && ((UINT64_C(31) == ((v3183 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(32) == v3149)));
            }
            t3277 = t3276;
        }
        int v3278 = t3277;
        uint64_t v3279 = (v3272 ? UINT64_C(32) : (v3273 ? UINT64_C(33) : v3115));
        uint64_t v3280 = (v3273 ? (((((uint64_t)(v3270 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(32)]))) : v3166);
        uint64_t v3281 = (v3274 ? ((v3132 + UINT64_C(1)) & UINT64_C(255)) : v3132);
        uint64_t v3282 = (v3274 ? UINT64_C(31) : v3183);
        uint64_t v3283 = (v3274 ? ((uint64_t)((UINT64_C(32) + v3270) & UINT64_C(255))) : v3149);
        uint64_t v3284 = ((v3272 || v3273) ? UINT64_C(1) : ((v3278 || (v3271 && (!v3274))) ? UINT64_C(2) : v3200));
        t3285 = v3282;
    } else {
        t3285 = v3183;
    }
    uint64_t v3286 = t3285;
    uint64_t t3302;
    if (v3201) {
        uint64_t v3287 = ((uint64_t)in_b[UINT64_C(31)]);
        int v3288 = ((v3200 == UINT64_C(0)) && (UINT64_C(31) == v3149));
        int v3289 = (v3288 && (v3287 == UINT64_C(0)));
        int v3290 = ((v3288 && ((v3287 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(32) < ((uint64_t)((uint64_t)in_b_len))));
        int v3291 = (((v3288 && (v3287 != UINT64_C(0))) && (v3287 < UINT64_C(64))) && (((uint64_t)((UINT64_C(31) + v3287) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3294 = ((v3200 == UINT64_C(0)) && (UINT64_C(31) != v3149));
        if (t3294) {
                uint64_t v3292 = v3287;
            int t3293 = (!(((((v3292 | UINT64_C(32)) >= UINT64_C(97)) && ((v3292 | UINT64_C(32)) <= UINT64_C(122))) || ((v3292 >= UINT64_C(48)) && (v3292 <= UINT64_C(57)))) || (v3292 == UINT64_C(45))));
            if (!t3293) {
                t3293 = ((v3287 == UINT64_C(45)) && ((UINT64_C(31) == ((v3183 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(32) == v3149)));
            }
            t3294 = t3293;
        }
        int v3295 = t3294;
        uint64_t v3296 = (v3289 ? UINT64_C(32) : (v3290 ? UINT64_C(33) : v3115));
        uint64_t v3297 = (v3290 ? (((((uint64_t)(v3287 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(32)]))) : v3166);
        uint64_t v3298 = (v3291 ? ((v3132 + UINT64_C(1)) & UINT64_C(255)) : v3132);
        uint64_t v3299 = (v3291 ? UINT64_C(31) : v3183);
        uint64_t v3300 = (v3291 ? ((uint64_t)((UINT64_C(32) + v3287) & UINT64_C(255))) : v3149);
        uint64_t v3301 = ((v3289 || v3290) ? UINT64_C(1) : ((v3295 || (v3288 && (!v3291))) ? UINT64_C(2) : v3200));
        t3302 = v3301;
    } else {
        t3302 = v3200;
    }
    uint64_t v3303 = t3302;
    int v3304 = (UINT64_C(32) < v7);
    uint64_t t3320;
    if (v3304) {
        uint64_t v3305 = ((uint64_t)in_b[UINT64_C(32)]);
        int v3306 = ((v3303 == UINT64_C(0)) && (UINT64_C(32) == v3252));
        int v3307 = (v3306 && (v3305 == UINT64_C(0)));
        int v3308 = ((v3306 && ((v3305 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(33) < ((uint64_t)((uint64_t)in_b_len))));
        int v3309 = (((v3306 && (v3305 != UINT64_C(0))) && (v3305 < UINT64_C(64))) && (((uint64_t)((UINT64_C(32) + v3305) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3312 = ((v3303 == UINT64_C(0)) && (UINT64_C(32) != v3252));
        if (t3312) {
                uint64_t v3310 = v3305;
            int t3311 = (!(((((v3310 | UINT64_C(32)) >= UINT64_C(97)) && ((v3310 | UINT64_C(32)) <= UINT64_C(122))) || ((v3310 >= UINT64_C(48)) && (v3310 <= UINT64_C(57)))) || (v3310 == UINT64_C(45))));
            if (!t3311) {
                t3311 = ((v3305 == UINT64_C(45)) && ((UINT64_C(32) == ((v3286 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(33) == v3252)));
            }
            t3312 = t3311;
        }
        int v3313 = t3312;
        uint64_t v3314 = (v3307 ? UINT64_C(33) : (v3308 ? UINT64_C(34) : v3218));
        uint64_t v3315 = (v3308 ? (((((uint64_t)(v3305 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(33)]))) : v3269);
        uint64_t v3316 = (v3309 ? ((v3235 + UINT64_C(1)) & UINT64_C(255)) : v3235);
        uint64_t v3317 = (v3309 ? UINT64_C(32) : v3286);
        uint64_t v3318 = (v3309 ? ((uint64_t)((UINT64_C(33) + v3305) & UINT64_C(255))) : v3252);
        uint64_t v3319 = ((v3307 || v3308) ? UINT64_C(1) : ((v3313 || (v3306 && (!v3309))) ? UINT64_C(2) : v3303));
        t3320 = v3314;
    } else {
        t3320 = v3218;
    }
    uint64_t v3321 = t3320;
    uint64_t t3337;
    if (v3304) {
        uint64_t v3322 = ((uint64_t)in_b[UINT64_C(32)]);
        int v3323 = ((v3303 == UINT64_C(0)) && (UINT64_C(32) == v3252));
        int v3324 = (v3323 && (v3322 == UINT64_C(0)));
        int v3325 = ((v3323 && ((v3322 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(33) < ((uint64_t)((uint64_t)in_b_len))));
        int v3326 = (((v3323 && (v3322 != UINT64_C(0))) && (v3322 < UINT64_C(64))) && (((uint64_t)((UINT64_C(32) + v3322) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3329 = ((v3303 == UINT64_C(0)) && (UINT64_C(32) != v3252));
        if (t3329) {
                uint64_t v3327 = v3322;
            int t3328 = (!(((((v3327 | UINT64_C(32)) >= UINT64_C(97)) && ((v3327 | UINT64_C(32)) <= UINT64_C(122))) || ((v3327 >= UINT64_C(48)) && (v3327 <= UINT64_C(57)))) || (v3327 == UINT64_C(45))));
            if (!t3328) {
                t3328 = ((v3322 == UINT64_C(45)) && ((UINT64_C(32) == ((v3286 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(33) == v3252)));
            }
            t3329 = t3328;
        }
        int v3330 = t3329;
        uint64_t v3331 = (v3324 ? UINT64_C(33) : (v3325 ? UINT64_C(34) : v3218));
        uint64_t v3332 = (v3325 ? (((((uint64_t)(v3322 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(33)]))) : v3269);
        uint64_t v3333 = (v3326 ? ((v3235 + UINT64_C(1)) & UINT64_C(255)) : v3235);
        uint64_t v3334 = (v3326 ? UINT64_C(32) : v3286);
        uint64_t v3335 = (v3326 ? ((uint64_t)((UINT64_C(33) + v3322) & UINT64_C(255))) : v3252);
        uint64_t v3336 = ((v3324 || v3325) ? UINT64_C(1) : ((v3330 || (v3323 && (!v3326))) ? UINT64_C(2) : v3303));
        t3337 = v3333;
    } else {
        t3337 = v3235;
    }
    uint64_t v3338 = t3337;
    uint64_t t3354;
    if (v3304) {
        uint64_t v3339 = ((uint64_t)in_b[UINT64_C(32)]);
        int v3340 = ((v3303 == UINT64_C(0)) && (UINT64_C(32) == v3252));
        int v3341 = (v3340 && (v3339 == UINT64_C(0)));
        int v3342 = ((v3340 && ((v3339 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(33) < ((uint64_t)((uint64_t)in_b_len))));
        int v3343 = (((v3340 && (v3339 != UINT64_C(0))) && (v3339 < UINT64_C(64))) && (((uint64_t)((UINT64_C(32) + v3339) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3346 = ((v3303 == UINT64_C(0)) && (UINT64_C(32) != v3252));
        if (t3346) {
                uint64_t v3344 = v3339;
            int t3345 = (!(((((v3344 | UINT64_C(32)) >= UINT64_C(97)) && ((v3344 | UINT64_C(32)) <= UINT64_C(122))) || ((v3344 >= UINT64_C(48)) && (v3344 <= UINT64_C(57)))) || (v3344 == UINT64_C(45))));
            if (!t3345) {
                t3345 = ((v3339 == UINT64_C(45)) && ((UINT64_C(32) == ((v3286 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(33) == v3252)));
            }
            t3346 = t3345;
        }
        int v3347 = t3346;
        uint64_t v3348 = (v3341 ? UINT64_C(33) : (v3342 ? UINT64_C(34) : v3218));
        uint64_t v3349 = (v3342 ? (((((uint64_t)(v3339 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(33)]))) : v3269);
        uint64_t v3350 = (v3343 ? ((v3235 + UINT64_C(1)) & UINT64_C(255)) : v3235);
        uint64_t v3351 = (v3343 ? UINT64_C(32) : v3286);
        uint64_t v3352 = (v3343 ? ((uint64_t)((UINT64_C(33) + v3339) & UINT64_C(255))) : v3252);
        uint64_t v3353 = ((v3341 || v3342) ? UINT64_C(1) : ((v3347 || (v3340 && (!v3343))) ? UINT64_C(2) : v3303));
        t3354 = v3352;
    } else {
        t3354 = v3252;
    }
    uint64_t v3355 = t3354;
    uint64_t t3371;
    if (v3304) {
        uint64_t v3356 = ((uint64_t)in_b[UINT64_C(32)]);
        int v3357 = ((v3303 == UINT64_C(0)) && (UINT64_C(32) == v3252));
        int v3358 = (v3357 && (v3356 == UINT64_C(0)));
        int v3359 = ((v3357 && ((v3356 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(33) < ((uint64_t)((uint64_t)in_b_len))));
        int v3360 = (((v3357 && (v3356 != UINT64_C(0))) && (v3356 < UINT64_C(64))) && (((uint64_t)((UINT64_C(32) + v3356) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3363 = ((v3303 == UINT64_C(0)) && (UINT64_C(32) != v3252));
        if (t3363) {
                uint64_t v3361 = v3356;
            int t3362 = (!(((((v3361 | UINT64_C(32)) >= UINT64_C(97)) && ((v3361 | UINT64_C(32)) <= UINT64_C(122))) || ((v3361 >= UINT64_C(48)) && (v3361 <= UINT64_C(57)))) || (v3361 == UINT64_C(45))));
            if (!t3362) {
                t3362 = ((v3356 == UINT64_C(45)) && ((UINT64_C(32) == ((v3286 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(33) == v3252)));
            }
            t3363 = t3362;
        }
        int v3364 = t3363;
        uint64_t v3365 = (v3358 ? UINT64_C(33) : (v3359 ? UINT64_C(34) : v3218));
        uint64_t v3366 = (v3359 ? (((((uint64_t)(v3356 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(33)]))) : v3269);
        uint64_t v3367 = (v3360 ? ((v3235 + UINT64_C(1)) & UINT64_C(255)) : v3235);
        uint64_t v3368 = (v3360 ? UINT64_C(32) : v3286);
        uint64_t v3369 = (v3360 ? ((uint64_t)((UINT64_C(33) + v3356) & UINT64_C(255))) : v3252);
        uint64_t v3370 = ((v3358 || v3359) ? UINT64_C(1) : ((v3364 || (v3357 && (!v3360))) ? UINT64_C(2) : v3303));
        t3371 = v3366;
    } else {
        t3371 = v3269;
    }
    uint64_t v3372 = t3371;
    uint64_t t3388;
    if (v3304) {
        uint64_t v3373 = ((uint64_t)in_b[UINT64_C(32)]);
        int v3374 = ((v3303 == UINT64_C(0)) && (UINT64_C(32) == v3252));
        int v3375 = (v3374 && (v3373 == UINT64_C(0)));
        int v3376 = ((v3374 && ((v3373 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(33) < ((uint64_t)((uint64_t)in_b_len))));
        int v3377 = (((v3374 && (v3373 != UINT64_C(0))) && (v3373 < UINT64_C(64))) && (((uint64_t)((UINT64_C(32) + v3373) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3380 = ((v3303 == UINT64_C(0)) && (UINT64_C(32) != v3252));
        if (t3380) {
                uint64_t v3378 = v3373;
            int t3379 = (!(((((v3378 | UINT64_C(32)) >= UINT64_C(97)) && ((v3378 | UINT64_C(32)) <= UINT64_C(122))) || ((v3378 >= UINT64_C(48)) && (v3378 <= UINT64_C(57)))) || (v3378 == UINT64_C(45))));
            if (!t3379) {
                t3379 = ((v3373 == UINT64_C(45)) && ((UINT64_C(32) == ((v3286 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(33) == v3252)));
            }
            t3380 = t3379;
        }
        int v3381 = t3380;
        uint64_t v3382 = (v3375 ? UINT64_C(33) : (v3376 ? UINT64_C(34) : v3218));
        uint64_t v3383 = (v3376 ? (((((uint64_t)(v3373 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(33)]))) : v3269);
        uint64_t v3384 = (v3377 ? ((v3235 + UINT64_C(1)) & UINT64_C(255)) : v3235);
        uint64_t v3385 = (v3377 ? UINT64_C(32) : v3286);
        uint64_t v3386 = (v3377 ? ((uint64_t)((UINT64_C(33) + v3373) & UINT64_C(255))) : v3252);
        uint64_t v3387 = ((v3375 || v3376) ? UINT64_C(1) : ((v3381 || (v3374 && (!v3377))) ? UINT64_C(2) : v3303));
        t3388 = v3385;
    } else {
        t3388 = v3286;
    }
    uint64_t v3389 = t3388;
    uint64_t t3405;
    if (v3304) {
        uint64_t v3390 = ((uint64_t)in_b[UINT64_C(32)]);
        int v3391 = ((v3303 == UINT64_C(0)) && (UINT64_C(32) == v3252));
        int v3392 = (v3391 && (v3390 == UINT64_C(0)));
        int v3393 = ((v3391 && ((v3390 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(33) < ((uint64_t)((uint64_t)in_b_len))));
        int v3394 = (((v3391 && (v3390 != UINT64_C(0))) && (v3390 < UINT64_C(64))) && (((uint64_t)((UINT64_C(32) + v3390) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3397 = ((v3303 == UINT64_C(0)) && (UINT64_C(32) != v3252));
        if (t3397) {
                uint64_t v3395 = v3390;
            int t3396 = (!(((((v3395 | UINT64_C(32)) >= UINT64_C(97)) && ((v3395 | UINT64_C(32)) <= UINT64_C(122))) || ((v3395 >= UINT64_C(48)) && (v3395 <= UINT64_C(57)))) || (v3395 == UINT64_C(45))));
            if (!t3396) {
                t3396 = ((v3390 == UINT64_C(45)) && ((UINT64_C(32) == ((v3286 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(33) == v3252)));
            }
            t3397 = t3396;
        }
        int v3398 = t3397;
        uint64_t v3399 = (v3392 ? UINT64_C(33) : (v3393 ? UINT64_C(34) : v3218));
        uint64_t v3400 = (v3393 ? (((((uint64_t)(v3390 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(33)]))) : v3269);
        uint64_t v3401 = (v3394 ? ((v3235 + UINT64_C(1)) & UINT64_C(255)) : v3235);
        uint64_t v3402 = (v3394 ? UINT64_C(32) : v3286);
        uint64_t v3403 = (v3394 ? ((uint64_t)((UINT64_C(33) + v3390) & UINT64_C(255))) : v3252);
        uint64_t v3404 = ((v3392 || v3393) ? UINT64_C(1) : ((v3398 || (v3391 && (!v3394))) ? UINT64_C(2) : v3303));
        t3405 = v3404;
    } else {
        t3405 = v3303;
    }
    uint64_t v3406 = t3405;
    int v3407 = (UINT64_C(33) < v7);
    uint64_t t3423;
    if (v3407) {
        uint64_t v3408 = ((uint64_t)in_b[UINT64_C(33)]);
        int v3409 = ((v3406 == UINT64_C(0)) && (UINT64_C(33) == v3355));
        int v3410 = (v3409 && (v3408 == UINT64_C(0)));
        int v3411 = ((v3409 && ((v3408 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(34) < ((uint64_t)((uint64_t)in_b_len))));
        int v3412 = (((v3409 && (v3408 != UINT64_C(0))) && (v3408 < UINT64_C(64))) && (((uint64_t)((UINT64_C(33) + v3408) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3415 = ((v3406 == UINT64_C(0)) && (UINT64_C(33) != v3355));
        if (t3415) {
                uint64_t v3413 = v3408;
            int t3414 = (!(((((v3413 | UINT64_C(32)) >= UINT64_C(97)) && ((v3413 | UINT64_C(32)) <= UINT64_C(122))) || ((v3413 >= UINT64_C(48)) && (v3413 <= UINT64_C(57)))) || (v3413 == UINT64_C(45))));
            if (!t3414) {
                t3414 = ((v3408 == UINT64_C(45)) && ((UINT64_C(33) == ((v3389 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(34) == v3355)));
            }
            t3415 = t3414;
        }
        int v3416 = t3415;
        uint64_t v3417 = (v3410 ? UINT64_C(34) : (v3411 ? UINT64_C(35) : v3321));
        uint64_t v3418 = (v3411 ? (((((uint64_t)(v3408 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(34)]))) : v3372);
        uint64_t v3419 = (v3412 ? ((v3338 + UINT64_C(1)) & UINT64_C(255)) : v3338);
        uint64_t v3420 = (v3412 ? UINT64_C(33) : v3389);
        uint64_t v3421 = (v3412 ? ((uint64_t)((UINT64_C(34) + v3408) & UINT64_C(255))) : v3355);
        uint64_t v3422 = ((v3410 || v3411) ? UINT64_C(1) : ((v3416 || (v3409 && (!v3412))) ? UINT64_C(2) : v3406));
        t3423 = v3417;
    } else {
        t3423 = v3321;
    }
    uint64_t v3424 = t3423;
    uint64_t t3440;
    if (v3407) {
        uint64_t v3425 = ((uint64_t)in_b[UINT64_C(33)]);
        int v3426 = ((v3406 == UINT64_C(0)) && (UINT64_C(33) == v3355));
        int v3427 = (v3426 && (v3425 == UINT64_C(0)));
        int v3428 = ((v3426 && ((v3425 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(34) < ((uint64_t)((uint64_t)in_b_len))));
        int v3429 = (((v3426 && (v3425 != UINT64_C(0))) && (v3425 < UINT64_C(64))) && (((uint64_t)((UINT64_C(33) + v3425) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3432 = ((v3406 == UINT64_C(0)) && (UINT64_C(33) != v3355));
        if (t3432) {
                uint64_t v3430 = v3425;
            int t3431 = (!(((((v3430 | UINT64_C(32)) >= UINT64_C(97)) && ((v3430 | UINT64_C(32)) <= UINT64_C(122))) || ((v3430 >= UINT64_C(48)) && (v3430 <= UINT64_C(57)))) || (v3430 == UINT64_C(45))));
            if (!t3431) {
                t3431 = ((v3425 == UINT64_C(45)) && ((UINT64_C(33) == ((v3389 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(34) == v3355)));
            }
            t3432 = t3431;
        }
        int v3433 = t3432;
        uint64_t v3434 = (v3427 ? UINT64_C(34) : (v3428 ? UINT64_C(35) : v3321));
        uint64_t v3435 = (v3428 ? (((((uint64_t)(v3425 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(34)]))) : v3372);
        uint64_t v3436 = (v3429 ? ((v3338 + UINT64_C(1)) & UINT64_C(255)) : v3338);
        uint64_t v3437 = (v3429 ? UINT64_C(33) : v3389);
        uint64_t v3438 = (v3429 ? ((uint64_t)((UINT64_C(34) + v3425) & UINT64_C(255))) : v3355);
        uint64_t v3439 = ((v3427 || v3428) ? UINT64_C(1) : ((v3433 || (v3426 && (!v3429))) ? UINT64_C(2) : v3406));
        t3440 = v3436;
    } else {
        t3440 = v3338;
    }
    uint64_t v3441 = t3440;
    uint64_t t3457;
    if (v3407) {
        uint64_t v3442 = ((uint64_t)in_b[UINT64_C(33)]);
        int v3443 = ((v3406 == UINT64_C(0)) && (UINT64_C(33) == v3355));
        int v3444 = (v3443 && (v3442 == UINT64_C(0)));
        int v3445 = ((v3443 && ((v3442 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(34) < ((uint64_t)((uint64_t)in_b_len))));
        int v3446 = (((v3443 && (v3442 != UINT64_C(0))) && (v3442 < UINT64_C(64))) && (((uint64_t)((UINT64_C(33) + v3442) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3449 = ((v3406 == UINT64_C(0)) && (UINT64_C(33) != v3355));
        if (t3449) {
                uint64_t v3447 = v3442;
            int t3448 = (!(((((v3447 | UINT64_C(32)) >= UINT64_C(97)) && ((v3447 | UINT64_C(32)) <= UINT64_C(122))) || ((v3447 >= UINT64_C(48)) && (v3447 <= UINT64_C(57)))) || (v3447 == UINT64_C(45))));
            if (!t3448) {
                t3448 = ((v3442 == UINT64_C(45)) && ((UINT64_C(33) == ((v3389 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(34) == v3355)));
            }
            t3449 = t3448;
        }
        int v3450 = t3449;
        uint64_t v3451 = (v3444 ? UINT64_C(34) : (v3445 ? UINT64_C(35) : v3321));
        uint64_t v3452 = (v3445 ? (((((uint64_t)(v3442 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(34)]))) : v3372);
        uint64_t v3453 = (v3446 ? ((v3338 + UINT64_C(1)) & UINT64_C(255)) : v3338);
        uint64_t v3454 = (v3446 ? UINT64_C(33) : v3389);
        uint64_t v3455 = (v3446 ? ((uint64_t)((UINT64_C(34) + v3442) & UINT64_C(255))) : v3355);
        uint64_t v3456 = ((v3444 || v3445) ? UINT64_C(1) : ((v3450 || (v3443 && (!v3446))) ? UINT64_C(2) : v3406));
        t3457 = v3455;
    } else {
        t3457 = v3355;
    }
    uint64_t v3458 = t3457;
    uint64_t t3474;
    if (v3407) {
        uint64_t v3459 = ((uint64_t)in_b[UINT64_C(33)]);
        int v3460 = ((v3406 == UINT64_C(0)) && (UINT64_C(33) == v3355));
        int v3461 = (v3460 && (v3459 == UINT64_C(0)));
        int v3462 = ((v3460 && ((v3459 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(34) < ((uint64_t)((uint64_t)in_b_len))));
        int v3463 = (((v3460 && (v3459 != UINT64_C(0))) && (v3459 < UINT64_C(64))) && (((uint64_t)((UINT64_C(33) + v3459) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3466 = ((v3406 == UINT64_C(0)) && (UINT64_C(33) != v3355));
        if (t3466) {
                uint64_t v3464 = v3459;
            int t3465 = (!(((((v3464 | UINT64_C(32)) >= UINT64_C(97)) && ((v3464 | UINT64_C(32)) <= UINT64_C(122))) || ((v3464 >= UINT64_C(48)) && (v3464 <= UINT64_C(57)))) || (v3464 == UINT64_C(45))));
            if (!t3465) {
                t3465 = ((v3459 == UINT64_C(45)) && ((UINT64_C(33) == ((v3389 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(34) == v3355)));
            }
            t3466 = t3465;
        }
        int v3467 = t3466;
        uint64_t v3468 = (v3461 ? UINT64_C(34) : (v3462 ? UINT64_C(35) : v3321));
        uint64_t v3469 = (v3462 ? (((((uint64_t)(v3459 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(34)]))) : v3372);
        uint64_t v3470 = (v3463 ? ((v3338 + UINT64_C(1)) & UINT64_C(255)) : v3338);
        uint64_t v3471 = (v3463 ? UINT64_C(33) : v3389);
        uint64_t v3472 = (v3463 ? ((uint64_t)((UINT64_C(34) + v3459) & UINT64_C(255))) : v3355);
        uint64_t v3473 = ((v3461 || v3462) ? UINT64_C(1) : ((v3467 || (v3460 && (!v3463))) ? UINT64_C(2) : v3406));
        t3474 = v3469;
    } else {
        t3474 = v3372;
    }
    uint64_t v3475 = t3474;
    uint64_t t3491;
    if (v3407) {
        uint64_t v3476 = ((uint64_t)in_b[UINT64_C(33)]);
        int v3477 = ((v3406 == UINT64_C(0)) && (UINT64_C(33) == v3355));
        int v3478 = (v3477 && (v3476 == UINT64_C(0)));
        int v3479 = ((v3477 && ((v3476 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(34) < ((uint64_t)((uint64_t)in_b_len))));
        int v3480 = (((v3477 && (v3476 != UINT64_C(0))) && (v3476 < UINT64_C(64))) && (((uint64_t)((UINT64_C(33) + v3476) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3483 = ((v3406 == UINT64_C(0)) && (UINT64_C(33) != v3355));
        if (t3483) {
                uint64_t v3481 = v3476;
            int t3482 = (!(((((v3481 | UINT64_C(32)) >= UINT64_C(97)) && ((v3481 | UINT64_C(32)) <= UINT64_C(122))) || ((v3481 >= UINT64_C(48)) && (v3481 <= UINT64_C(57)))) || (v3481 == UINT64_C(45))));
            if (!t3482) {
                t3482 = ((v3476 == UINT64_C(45)) && ((UINT64_C(33) == ((v3389 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(34) == v3355)));
            }
            t3483 = t3482;
        }
        int v3484 = t3483;
        uint64_t v3485 = (v3478 ? UINT64_C(34) : (v3479 ? UINT64_C(35) : v3321));
        uint64_t v3486 = (v3479 ? (((((uint64_t)(v3476 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(34)]))) : v3372);
        uint64_t v3487 = (v3480 ? ((v3338 + UINT64_C(1)) & UINT64_C(255)) : v3338);
        uint64_t v3488 = (v3480 ? UINT64_C(33) : v3389);
        uint64_t v3489 = (v3480 ? ((uint64_t)((UINT64_C(34) + v3476) & UINT64_C(255))) : v3355);
        uint64_t v3490 = ((v3478 || v3479) ? UINT64_C(1) : ((v3484 || (v3477 && (!v3480))) ? UINT64_C(2) : v3406));
        t3491 = v3488;
    } else {
        t3491 = v3389;
    }
    uint64_t v3492 = t3491;
    uint64_t t3508;
    if (v3407) {
        uint64_t v3493 = ((uint64_t)in_b[UINT64_C(33)]);
        int v3494 = ((v3406 == UINT64_C(0)) && (UINT64_C(33) == v3355));
        int v3495 = (v3494 && (v3493 == UINT64_C(0)));
        int v3496 = ((v3494 && ((v3493 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(34) < ((uint64_t)((uint64_t)in_b_len))));
        int v3497 = (((v3494 && (v3493 != UINT64_C(0))) && (v3493 < UINT64_C(64))) && (((uint64_t)((UINT64_C(33) + v3493) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3500 = ((v3406 == UINT64_C(0)) && (UINT64_C(33) != v3355));
        if (t3500) {
                uint64_t v3498 = v3493;
            int t3499 = (!(((((v3498 | UINT64_C(32)) >= UINT64_C(97)) && ((v3498 | UINT64_C(32)) <= UINT64_C(122))) || ((v3498 >= UINT64_C(48)) && (v3498 <= UINT64_C(57)))) || (v3498 == UINT64_C(45))));
            if (!t3499) {
                t3499 = ((v3493 == UINT64_C(45)) && ((UINT64_C(33) == ((v3389 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(34) == v3355)));
            }
            t3500 = t3499;
        }
        int v3501 = t3500;
        uint64_t v3502 = (v3495 ? UINT64_C(34) : (v3496 ? UINT64_C(35) : v3321));
        uint64_t v3503 = (v3496 ? (((((uint64_t)(v3493 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(34)]))) : v3372);
        uint64_t v3504 = (v3497 ? ((v3338 + UINT64_C(1)) & UINT64_C(255)) : v3338);
        uint64_t v3505 = (v3497 ? UINT64_C(33) : v3389);
        uint64_t v3506 = (v3497 ? ((uint64_t)((UINT64_C(34) + v3493) & UINT64_C(255))) : v3355);
        uint64_t v3507 = ((v3495 || v3496) ? UINT64_C(1) : ((v3501 || (v3494 && (!v3497))) ? UINT64_C(2) : v3406));
        t3508 = v3507;
    } else {
        t3508 = v3406;
    }
    uint64_t v3509 = t3508;
    int v3510 = (UINT64_C(34) < v7);
    uint64_t t3526;
    if (v3510) {
        uint64_t v3511 = ((uint64_t)in_b[UINT64_C(34)]);
        int v3512 = ((v3509 == UINT64_C(0)) && (UINT64_C(34) == v3458));
        int v3513 = (v3512 && (v3511 == UINT64_C(0)));
        int v3514 = ((v3512 && ((v3511 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(35) < ((uint64_t)((uint64_t)in_b_len))));
        int v3515 = (((v3512 && (v3511 != UINT64_C(0))) && (v3511 < UINT64_C(64))) && (((uint64_t)((UINT64_C(34) + v3511) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3518 = ((v3509 == UINT64_C(0)) && (UINT64_C(34) != v3458));
        if (t3518) {
                uint64_t v3516 = v3511;
            int t3517 = (!(((((v3516 | UINT64_C(32)) >= UINT64_C(97)) && ((v3516 | UINT64_C(32)) <= UINT64_C(122))) || ((v3516 >= UINT64_C(48)) && (v3516 <= UINT64_C(57)))) || (v3516 == UINT64_C(45))));
            if (!t3517) {
                t3517 = ((v3511 == UINT64_C(45)) && ((UINT64_C(34) == ((v3492 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(35) == v3458)));
            }
            t3518 = t3517;
        }
        int v3519 = t3518;
        uint64_t v3520 = (v3513 ? UINT64_C(35) : (v3514 ? UINT64_C(36) : v3424));
        uint64_t v3521 = (v3514 ? (((((uint64_t)(v3511 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(35)]))) : v3475);
        uint64_t v3522 = (v3515 ? ((v3441 + UINT64_C(1)) & UINT64_C(255)) : v3441);
        uint64_t v3523 = (v3515 ? UINT64_C(34) : v3492);
        uint64_t v3524 = (v3515 ? ((uint64_t)((UINT64_C(35) + v3511) & UINT64_C(255))) : v3458);
        uint64_t v3525 = ((v3513 || v3514) ? UINT64_C(1) : ((v3519 || (v3512 && (!v3515))) ? UINT64_C(2) : v3509));
        t3526 = v3520;
    } else {
        t3526 = v3424;
    }
    uint64_t v3527 = t3526;
    uint64_t t3543;
    if (v3510) {
        uint64_t v3528 = ((uint64_t)in_b[UINT64_C(34)]);
        int v3529 = ((v3509 == UINT64_C(0)) && (UINT64_C(34) == v3458));
        int v3530 = (v3529 && (v3528 == UINT64_C(0)));
        int v3531 = ((v3529 && ((v3528 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(35) < ((uint64_t)((uint64_t)in_b_len))));
        int v3532 = (((v3529 && (v3528 != UINT64_C(0))) && (v3528 < UINT64_C(64))) && (((uint64_t)((UINT64_C(34) + v3528) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3535 = ((v3509 == UINT64_C(0)) && (UINT64_C(34) != v3458));
        if (t3535) {
                uint64_t v3533 = v3528;
            int t3534 = (!(((((v3533 | UINT64_C(32)) >= UINT64_C(97)) && ((v3533 | UINT64_C(32)) <= UINT64_C(122))) || ((v3533 >= UINT64_C(48)) && (v3533 <= UINT64_C(57)))) || (v3533 == UINT64_C(45))));
            if (!t3534) {
                t3534 = ((v3528 == UINT64_C(45)) && ((UINT64_C(34) == ((v3492 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(35) == v3458)));
            }
            t3535 = t3534;
        }
        int v3536 = t3535;
        uint64_t v3537 = (v3530 ? UINT64_C(35) : (v3531 ? UINT64_C(36) : v3424));
        uint64_t v3538 = (v3531 ? (((((uint64_t)(v3528 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(35)]))) : v3475);
        uint64_t v3539 = (v3532 ? ((v3441 + UINT64_C(1)) & UINT64_C(255)) : v3441);
        uint64_t v3540 = (v3532 ? UINT64_C(34) : v3492);
        uint64_t v3541 = (v3532 ? ((uint64_t)((UINT64_C(35) + v3528) & UINT64_C(255))) : v3458);
        uint64_t v3542 = ((v3530 || v3531) ? UINT64_C(1) : ((v3536 || (v3529 && (!v3532))) ? UINT64_C(2) : v3509));
        t3543 = v3539;
    } else {
        t3543 = v3441;
    }
    uint64_t v3544 = t3543;
    uint64_t t3560;
    if (v3510) {
        uint64_t v3545 = ((uint64_t)in_b[UINT64_C(34)]);
        int v3546 = ((v3509 == UINT64_C(0)) && (UINT64_C(34) == v3458));
        int v3547 = (v3546 && (v3545 == UINT64_C(0)));
        int v3548 = ((v3546 && ((v3545 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(35) < ((uint64_t)((uint64_t)in_b_len))));
        int v3549 = (((v3546 && (v3545 != UINT64_C(0))) && (v3545 < UINT64_C(64))) && (((uint64_t)((UINT64_C(34) + v3545) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3552 = ((v3509 == UINT64_C(0)) && (UINT64_C(34) != v3458));
        if (t3552) {
                uint64_t v3550 = v3545;
            int t3551 = (!(((((v3550 | UINT64_C(32)) >= UINT64_C(97)) && ((v3550 | UINT64_C(32)) <= UINT64_C(122))) || ((v3550 >= UINT64_C(48)) && (v3550 <= UINT64_C(57)))) || (v3550 == UINT64_C(45))));
            if (!t3551) {
                t3551 = ((v3545 == UINT64_C(45)) && ((UINT64_C(34) == ((v3492 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(35) == v3458)));
            }
            t3552 = t3551;
        }
        int v3553 = t3552;
        uint64_t v3554 = (v3547 ? UINT64_C(35) : (v3548 ? UINT64_C(36) : v3424));
        uint64_t v3555 = (v3548 ? (((((uint64_t)(v3545 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(35)]))) : v3475);
        uint64_t v3556 = (v3549 ? ((v3441 + UINT64_C(1)) & UINT64_C(255)) : v3441);
        uint64_t v3557 = (v3549 ? UINT64_C(34) : v3492);
        uint64_t v3558 = (v3549 ? ((uint64_t)((UINT64_C(35) + v3545) & UINT64_C(255))) : v3458);
        uint64_t v3559 = ((v3547 || v3548) ? UINT64_C(1) : ((v3553 || (v3546 && (!v3549))) ? UINT64_C(2) : v3509));
        t3560 = v3558;
    } else {
        t3560 = v3458;
    }
    uint64_t v3561 = t3560;
    uint64_t t3577;
    if (v3510) {
        uint64_t v3562 = ((uint64_t)in_b[UINT64_C(34)]);
        int v3563 = ((v3509 == UINT64_C(0)) && (UINT64_C(34) == v3458));
        int v3564 = (v3563 && (v3562 == UINT64_C(0)));
        int v3565 = ((v3563 && ((v3562 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(35) < ((uint64_t)((uint64_t)in_b_len))));
        int v3566 = (((v3563 && (v3562 != UINT64_C(0))) && (v3562 < UINT64_C(64))) && (((uint64_t)((UINT64_C(34) + v3562) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3569 = ((v3509 == UINT64_C(0)) && (UINT64_C(34) != v3458));
        if (t3569) {
                uint64_t v3567 = v3562;
            int t3568 = (!(((((v3567 | UINT64_C(32)) >= UINT64_C(97)) && ((v3567 | UINT64_C(32)) <= UINT64_C(122))) || ((v3567 >= UINT64_C(48)) && (v3567 <= UINT64_C(57)))) || (v3567 == UINT64_C(45))));
            if (!t3568) {
                t3568 = ((v3562 == UINT64_C(45)) && ((UINT64_C(34) == ((v3492 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(35) == v3458)));
            }
            t3569 = t3568;
        }
        int v3570 = t3569;
        uint64_t v3571 = (v3564 ? UINT64_C(35) : (v3565 ? UINT64_C(36) : v3424));
        uint64_t v3572 = (v3565 ? (((((uint64_t)(v3562 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(35)]))) : v3475);
        uint64_t v3573 = (v3566 ? ((v3441 + UINT64_C(1)) & UINT64_C(255)) : v3441);
        uint64_t v3574 = (v3566 ? UINT64_C(34) : v3492);
        uint64_t v3575 = (v3566 ? ((uint64_t)((UINT64_C(35) + v3562) & UINT64_C(255))) : v3458);
        uint64_t v3576 = ((v3564 || v3565) ? UINT64_C(1) : ((v3570 || (v3563 && (!v3566))) ? UINT64_C(2) : v3509));
        t3577 = v3572;
    } else {
        t3577 = v3475;
    }
    uint64_t v3578 = t3577;
    uint64_t t3594;
    if (v3510) {
        uint64_t v3579 = ((uint64_t)in_b[UINT64_C(34)]);
        int v3580 = ((v3509 == UINT64_C(0)) && (UINT64_C(34) == v3458));
        int v3581 = (v3580 && (v3579 == UINT64_C(0)));
        int v3582 = ((v3580 && ((v3579 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(35) < ((uint64_t)((uint64_t)in_b_len))));
        int v3583 = (((v3580 && (v3579 != UINT64_C(0))) && (v3579 < UINT64_C(64))) && (((uint64_t)((UINT64_C(34) + v3579) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3586 = ((v3509 == UINT64_C(0)) && (UINT64_C(34) != v3458));
        if (t3586) {
                uint64_t v3584 = v3579;
            int t3585 = (!(((((v3584 | UINT64_C(32)) >= UINT64_C(97)) && ((v3584 | UINT64_C(32)) <= UINT64_C(122))) || ((v3584 >= UINT64_C(48)) && (v3584 <= UINT64_C(57)))) || (v3584 == UINT64_C(45))));
            if (!t3585) {
                t3585 = ((v3579 == UINT64_C(45)) && ((UINT64_C(34) == ((v3492 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(35) == v3458)));
            }
            t3586 = t3585;
        }
        int v3587 = t3586;
        uint64_t v3588 = (v3581 ? UINT64_C(35) : (v3582 ? UINT64_C(36) : v3424));
        uint64_t v3589 = (v3582 ? (((((uint64_t)(v3579 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(35)]))) : v3475);
        uint64_t v3590 = (v3583 ? ((v3441 + UINT64_C(1)) & UINT64_C(255)) : v3441);
        uint64_t v3591 = (v3583 ? UINT64_C(34) : v3492);
        uint64_t v3592 = (v3583 ? ((uint64_t)((UINT64_C(35) + v3579) & UINT64_C(255))) : v3458);
        uint64_t v3593 = ((v3581 || v3582) ? UINT64_C(1) : ((v3587 || (v3580 && (!v3583))) ? UINT64_C(2) : v3509));
        t3594 = v3591;
    } else {
        t3594 = v3492;
    }
    uint64_t v3595 = t3594;
    uint64_t t3611;
    if (v3510) {
        uint64_t v3596 = ((uint64_t)in_b[UINT64_C(34)]);
        int v3597 = ((v3509 == UINT64_C(0)) && (UINT64_C(34) == v3458));
        int v3598 = (v3597 && (v3596 == UINT64_C(0)));
        int v3599 = ((v3597 && ((v3596 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(35) < ((uint64_t)((uint64_t)in_b_len))));
        int v3600 = (((v3597 && (v3596 != UINT64_C(0))) && (v3596 < UINT64_C(64))) && (((uint64_t)((UINT64_C(34) + v3596) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3603 = ((v3509 == UINT64_C(0)) && (UINT64_C(34) != v3458));
        if (t3603) {
                uint64_t v3601 = v3596;
            int t3602 = (!(((((v3601 | UINT64_C(32)) >= UINT64_C(97)) && ((v3601 | UINT64_C(32)) <= UINT64_C(122))) || ((v3601 >= UINT64_C(48)) && (v3601 <= UINT64_C(57)))) || (v3601 == UINT64_C(45))));
            if (!t3602) {
                t3602 = ((v3596 == UINT64_C(45)) && ((UINT64_C(34) == ((v3492 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(35) == v3458)));
            }
            t3603 = t3602;
        }
        int v3604 = t3603;
        uint64_t v3605 = (v3598 ? UINT64_C(35) : (v3599 ? UINT64_C(36) : v3424));
        uint64_t v3606 = (v3599 ? (((((uint64_t)(v3596 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(35)]))) : v3475);
        uint64_t v3607 = (v3600 ? ((v3441 + UINT64_C(1)) & UINT64_C(255)) : v3441);
        uint64_t v3608 = (v3600 ? UINT64_C(34) : v3492);
        uint64_t v3609 = (v3600 ? ((uint64_t)((UINT64_C(35) + v3596) & UINT64_C(255))) : v3458);
        uint64_t v3610 = ((v3598 || v3599) ? UINT64_C(1) : ((v3604 || (v3597 && (!v3600))) ? UINT64_C(2) : v3509));
        t3611 = v3610;
    } else {
        t3611 = v3509;
    }
    uint64_t v3612 = t3611;
    int v3613 = (UINT64_C(35) < v7);
    uint64_t t3629;
    if (v3613) {
        uint64_t v3614 = ((uint64_t)in_b[UINT64_C(35)]);
        int v3615 = ((v3612 == UINT64_C(0)) && (UINT64_C(35) == v3561));
        int v3616 = (v3615 && (v3614 == UINT64_C(0)));
        int v3617 = ((v3615 && ((v3614 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(36) < ((uint64_t)((uint64_t)in_b_len))));
        int v3618 = (((v3615 && (v3614 != UINT64_C(0))) && (v3614 < UINT64_C(64))) && (((uint64_t)((UINT64_C(35) + v3614) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3621 = ((v3612 == UINT64_C(0)) && (UINT64_C(35) != v3561));
        if (t3621) {
                uint64_t v3619 = v3614;
            int t3620 = (!(((((v3619 | UINT64_C(32)) >= UINT64_C(97)) && ((v3619 | UINT64_C(32)) <= UINT64_C(122))) || ((v3619 >= UINT64_C(48)) && (v3619 <= UINT64_C(57)))) || (v3619 == UINT64_C(45))));
            if (!t3620) {
                t3620 = ((v3614 == UINT64_C(45)) && ((UINT64_C(35) == ((v3595 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(36) == v3561)));
            }
            t3621 = t3620;
        }
        int v3622 = t3621;
        uint64_t v3623 = (v3616 ? UINT64_C(36) : (v3617 ? UINT64_C(37) : v3527));
        uint64_t v3624 = (v3617 ? (((((uint64_t)(v3614 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(36)]))) : v3578);
        uint64_t v3625 = (v3618 ? ((v3544 + UINT64_C(1)) & UINT64_C(255)) : v3544);
        uint64_t v3626 = (v3618 ? UINT64_C(35) : v3595);
        uint64_t v3627 = (v3618 ? ((uint64_t)((UINT64_C(36) + v3614) & UINT64_C(255))) : v3561);
        uint64_t v3628 = ((v3616 || v3617) ? UINT64_C(1) : ((v3622 || (v3615 && (!v3618))) ? UINT64_C(2) : v3612));
        t3629 = v3623;
    } else {
        t3629 = v3527;
    }
    uint64_t v3630 = t3629;
    uint64_t t3646;
    if (v3613) {
        uint64_t v3631 = ((uint64_t)in_b[UINT64_C(35)]);
        int v3632 = ((v3612 == UINT64_C(0)) && (UINT64_C(35) == v3561));
        int v3633 = (v3632 && (v3631 == UINT64_C(0)));
        int v3634 = ((v3632 && ((v3631 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(36) < ((uint64_t)((uint64_t)in_b_len))));
        int v3635 = (((v3632 && (v3631 != UINT64_C(0))) && (v3631 < UINT64_C(64))) && (((uint64_t)((UINT64_C(35) + v3631) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3638 = ((v3612 == UINT64_C(0)) && (UINT64_C(35) != v3561));
        if (t3638) {
                uint64_t v3636 = v3631;
            int t3637 = (!(((((v3636 | UINT64_C(32)) >= UINT64_C(97)) && ((v3636 | UINT64_C(32)) <= UINT64_C(122))) || ((v3636 >= UINT64_C(48)) && (v3636 <= UINT64_C(57)))) || (v3636 == UINT64_C(45))));
            if (!t3637) {
                t3637 = ((v3631 == UINT64_C(45)) && ((UINT64_C(35) == ((v3595 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(36) == v3561)));
            }
            t3638 = t3637;
        }
        int v3639 = t3638;
        uint64_t v3640 = (v3633 ? UINT64_C(36) : (v3634 ? UINT64_C(37) : v3527));
        uint64_t v3641 = (v3634 ? (((((uint64_t)(v3631 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(36)]))) : v3578);
        uint64_t v3642 = (v3635 ? ((v3544 + UINT64_C(1)) & UINT64_C(255)) : v3544);
        uint64_t v3643 = (v3635 ? UINT64_C(35) : v3595);
        uint64_t v3644 = (v3635 ? ((uint64_t)((UINT64_C(36) + v3631) & UINT64_C(255))) : v3561);
        uint64_t v3645 = ((v3633 || v3634) ? UINT64_C(1) : ((v3639 || (v3632 && (!v3635))) ? UINT64_C(2) : v3612));
        t3646 = v3642;
    } else {
        t3646 = v3544;
    }
    uint64_t v3647 = t3646;
    uint64_t t3663;
    if (v3613) {
        uint64_t v3648 = ((uint64_t)in_b[UINT64_C(35)]);
        int v3649 = ((v3612 == UINT64_C(0)) && (UINT64_C(35) == v3561));
        int v3650 = (v3649 && (v3648 == UINT64_C(0)));
        int v3651 = ((v3649 && ((v3648 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(36) < ((uint64_t)((uint64_t)in_b_len))));
        int v3652 = (((v3649 && (v3648 != UINT64_C(0))) && (v3648 < UINT64_C(64))) && (((uint64_t)((UINT64_C(35) + v3648) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3655 = ((v3612 == UINT64_C(0)) && (UINT64_C(35) != v3561));
        if (t3655) {
                uint64_t v3653 = v3648;
            int t3654 = (!(((((v3653 | UINT64_C(32)) >= UINT64_C(97)) && ((v3653 | UINT64_C(32)) <= UINT64_C(122))) || ((v3653 >= UINT64_C(48)) && (v3653 <= UINT64_C(57)))) || (v3653 == UINT64_C(45))));
            if (!t3654) {
                t3654 = ((v3648 == UINT64_C(45)) && ((UINT64_C(35) == ((v3595 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(36) == v3561)));
            }
            t3655 = t3654;
        }
        int v3656 = t3655;
        uint64_t v3657 = (v3650 ? UINT64_C(36) : (v3651 ? UINT64_C(37) : v3527));
        uint64_t v3658 = (v3651 ? (((((uint64_t)(v3648 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(36)]))) : v3578);
        uint64_t v3659 = (v3652 ? ((v3544 + UINT64_C(1)) & UINT64_C(255)) : v3544);
        uint64_t v3660 = (v3652 ? UINT64_C(35) : v3595);
        uint64_t v3661 = (v3652 ? ((uint64_t)((UINT64_C(36) + v3648) & UINT64_C(255))) : v3561);
        uint64_t v3662 = ((v3650 || v3651) ? UINT64_C(1) : ((v3656 || (v3649 && (!v3652))) ? UINT64_C(2) : v3612));
        t3663 = v3661;
    } else {
        t3663 = v3561;
    }
    uint64_t v3664 = t3663;
    uint64_t t3680;
    if (v3613) {
        uint64_t v3665 = ((uint64_t)in_b[UINT64_C(35)]);
        int v3666 = ((v3612 == UINT64_C(0)) && (UINT64_C(35) == v3561));
        int v3667 = (v3666 && (v3665 == UINT64_C(0)));
        int v3668 = ((v3666 && ((v3665 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(36) < ((uint64_t)((uint64_t)in_b_len))));
        int v3669 = (((v3666 && (v3665 != UINT64_C(0))) && (v3665 < UINT64_C(64))) && (((uint64_t)((UINT64_C(35) + v3665) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3672 = ((v3612 == UINT64_C(0)) && (UINT64_C(35) != v3561));
        if (t3672) {
                uint64_t v3670 = v3665;
            int t3671 = (!(((((v3670 | UINT64_C(32)) >= UINT64_C(97)) && ((v3670 | UINT64_C(32)) <= UINT64_C(122))) || ((v3670 >= UINT64_C(48)) && (v3670 <= UINT64_C(57)))) || (v3670 == UINT64_C(45))));
            if (!t3671) {
                t3671 = ((v3665 == UINT64_C(45)) && ((UINT64_C(35) == ((v3595 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(36) == v3561)));
            }
            t3672 = t3671;
        }
        int v3673 = t3672;
        uint64_t v3674 = (v3667 ? UINT64_C(36) : (v3668 ? UINT64_C(37) : v3527));
        uint64_t v3675 = (v3668 ? (((((uint64_t)(v3665 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(36)]))) : v3578);
        uint64_t v3676 = (v3669 ? ((v3544 + UINT64_C(1)) & UINT64_C(255)) : v3544);
        uint64_t v3677 = (v3669 ? UINT64_C(35) : v3595);
        uint64_t v3678 = (v3669 ? ((uint64_t)((UINT64_C(36) + v3665) & UINT64_C(255))) : v3561);
        uint64_t v3679 = ((v3667 || v3668) ? UINT64_C(1) : ((v3673 || (v3666 && (!v3669))) ? UINT64_C(2) : v3612));
        t3680 = v3675;
    } else {
        t3680 = v3578;
    }
    uint64_t v3681 = t3680;
    uint64_t t3697;
    if (v3613) {
        uint64_t v3682 = ((uint64_t)in_b[UINT64_C(35)]);
        int v3683 = ((v3612 == UINT64_C(0)) && (UINT64_C(35) == v3561));
        int v3684 = (v3683 && (v3682 == UINT64_C(0)));
        int v3685 = ((v3683 && ((v3682 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(36) < ((uint64_t)((uint64_t)in_b_len))));
        int v3686 = (((v3683 && (v3682 != UINT64_C(0))) && (v3682 < UINT64_C(64))) && (((uint64_t)((UINT64_C(35) + v3682) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3689 = ((v3612 == UINT64_C(0)) && (UINT64_C(35) != v3561));
        if (t3689) {
                uint64_t v3687 = v3682;
            int t3688 = (!(((((v3687 | UINT64_C(32)) >= UINT64_C(97)) && ((v3687 | UINT64_C(32)) <= UINT64_C(122))) || ((v3687 >= UINT64_C(48)) && (v3687 <= UINT64_C(57)))) || (v3687 == UINT64_C(45))));
            if (!t3688) {
                t3688 = ((v3682 == UINT64_C(45)) && ((UINT64_C(35) == ((v3595 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(36) == v3561)));
            }
            t3689 = t3688;
        }
        int v3690 = t3689;
        uint64_t v3691 = (v3684 ? UINT64_C(36) : (v3685 ? UINT64_C(37) : v3527));
        uint64_t v3692 = (v3685 ? (((((uint64_t)(v3682 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(36)]))) : v3578);
        uint64_t v3693 = (v3686 ? ((v3544 + UINT64_C(1)) & UINT64_C(255)) : v3544);
        uint64_t v3694 = (v3686 ? UINT64_C(35) : v3595);
        uint64_t v3695 = (v3686 ? ((uint64_t)((UINT64_C(36) + v3682) & UINT64_C(255))) : v3561);
        uint64_t v3696 = ((v3684 || v3685) ? UINT64_C(1) : ((v3690 || (v3683 && (!v3686))) ? UINT64_C(2) : v3612));
        t3697 = v3694;
    } else {
        t3697 = v3595;
    }
    uint64_t v3698 = t3697;
    uint64_t t3714;
    if (v3613) {
        uint64_t v3699 = ((uint64_t)in_b[UINT64_C(35)]);
        int v3700 = ((v3612 == UINT64_C(0)) && (UINT64_C(35) == v3561));
        int v3701 = (v3700 && (v3699 == UINT64_C(0)));
        int v3702 = ((v3700 && ((v3699 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(36) < ((uint64_t)((uint64_t)in_b_len))));
        int v3703 = (((v3700 && (v3699 != UINT64_C(0))) && (v3699 < UINT64_C(64))) && (((uint64_t)((UINT64_C(35) + v3699) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3706 = ((v3612 == UINT64_C(0)) && (UINT64_C(35) != v3561));
        if (t3706) {
                uint64_t v3704 = v3699;
            int t3705 = (!(((((v3704 | UINT64_C(32)) >= UINT64_C(97)) && ((v3704 | UINT64_C(32)) <= UINT64_C(122))) || ((v3704 >= UINT64_C(48)) && (v3704 <= UINT64_C(57)))) || (v3704 == UINT64_C(45))));
            if (!t3705) {
                t3705 = ((v3699 == UINT64_C(45)) && ((UINT64_C(35) == ((v3595 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(36) == v3561)));
            }
            t3706 = t3705;
        }
        int v3707 = t3706;
        uint64_t v3708 = (v3701 ? UINT64_C(36) : (v3702 ? UINT64_C(37) : v3527));
        uint64_t v3709 = (v3702 ? (((((uint64_t)(v3699 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(36)]))) : v3578);
        uint64_t v3710 = (v3703 ? ((v3544 + UINT64_C(1)) & UINT64_C(255)) : v3544);
        uint64_t v3711 = (v3703 ? UINT64_C(35) : v3595);
        uint64_t v3712 = (v3703 ? ((uint64_t)((UINT64_C(36) + v3699) & UINT64_C(255))) : v3561);
        uint64_t v3713 = ((v3701 || v3702) ? UINT64_C(1) : ((v3707 || (v3700 && (!v3703))) ? UINT64_C(2) : v3612));
        t3714 = v3713;
    } else {
        t3714 = v3612;
    }
    uint64_t v3715 = t3714;
    int v3716 = (UINT64_C(36) < v7);
    uint64_t t3732;
    if (v3716) {
        uint64_t v3717 = ((uint64_t)in_b[UINT64_C(36)]);
        int v3718 = ((v3715 == UINT64_C(0)) && (UINT64_C(36) == v3664));
        int v3719 = (v3718 && (v3717 == UINT64_C(0)));
        int v3720 = ((v3718 && ((v3717 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(37) < ((uint64_t)((uint64_t)in_b_len))));
        int v3721 = (((v3718 && (v3717 != UINT64_C(0))) && (v3717 < UINT64_C(64))) && (((uint64_t)((UINT64_C(36) + v3717) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3724 = ((v3715 == UINT64_C(0)) && (UINT64_C(36) != v3664));
        if (t3724) {
                uint64_t v3722 = v3717;
            int t3723 = (!(((((v3722 | UINT64_C(32)) >= UINT64_C(97)) && ((v3722 | UINT64_C(32)) <= UINT64_C(122))) || ((v3722 >= UINT64_C(48)) && (v3722 <= UINT64_C(57)))) || (v3722 == UINT64_C(45))));
            if (!t3723) {
                t3723 = ((v3717 == UINT64_C(45)) && ((UINT64_C(36) == ((v3698 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(37) == v3664)));
            }
            t3724 = t3723;
        }
        int v3725 = t3724;
        uint64_t v3726 = (v3719 ? UINT64_C(37) : (v3720 ? UINT64_C(38) : v3630));
        uint64_t v3727 = (v3720 ? (((((uint64_t)(v3717 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(37)]))) : v3681);
        uint64_t v3728 = (v3721 ? ((v3647 + UINT64_C(1)) & UINT64_C(255)) : v3647);
        uint64_t v3729 = (v3721 ? UINT64_C(36) : v3698);
        uint64_t v3730 = (v3721 ? ((uint64_t)((UINT64_C(37) + v3717) & UINT64_C(255))) : v3664);
        uint64_t v3731 = ((v3719 || v3720) ? UINT64_C(1) : ((v3725 || (v3718 && (!v3721))) ? UINT64_C(2) : v3715));
        t3732 = v3726;
    } else {
        t3732 = v3630;
    }
    uint64_t v3733 = t3732;
    uint64_t t3749;
    if (v3716) {
        uint64_t v3734 = ((uint64_t)in_b[UINT64_C(36)]);
        int v3735 = ((v3715 == UINT64_C(0)) && (UINT64_C(36) == v3664));
        int v3736 = (v3735 && (v3734 == UINT64_C(0)));
        int v3737 = ((v3735 && ((v3734 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(37) < ((uint64_t)((uint64_t)in_b_len))));
        int v3738 = (((v3735 && (v3734 != UINT64_C(0))) && (v3734 < UINT64_C(64))) && (((uint64_t)((UINT64_C(36) + v3734) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3741 = ((v3715 == UINT64_C(0)) && (UINT64_C(36) != v3664));
        if (t3741) {
                uint64_t v3739 = v3734;
            int t3740 = (!(((((v3739 | UINT64_C(32)) >= UINT64_C(97)) && ((v3739 | UINT64_C(32)) <= UINT64_C(122))) || ((v3739 >= UINT64_C(48)) && (v3739 <= UINT64_C(57)))) || (v3739 == UINT64_C(45))));
            if (!t3740) {
                t3740 = ((v3734 == UINT64_C(45)) && ((UINT64_C(36) == ((v3698 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(37) == v3664)));
            }
            t3741 = t3740;
        }
        int v3742 = t3741;
        uint64_t v3743 = (v3736 ? UINT64_C(37) : (v3737 ? UINT64_C(38) : v3630));
        uint64_t v3744 = (v3737 ? (((((uint64_t)(v3734 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(37)]))) : v3681);
        uint64_t v3745 = (v3738 ? ((v3647 + UINT64_C(1)) & UINT64_C(255)) : v3647);
        uint64_t v3746 = (v3738 ? UINT64_C(36) : v3698);
        uint64_t v3747 = (v3738 ? ((uint64_t)((UINT64_C(37) + v3734) & UINT64_C(255))) : v3664);
        uint64_t v3748 = ((v3736 || v3737) ? UINT64_C(1) : ((v3742 || (v3735 && (!v3738))) ? UINT64_C(2) : v3715));
        t3749 = v3745;
    } else {
        t3749 = v3647;
    }
    uint64_t v3750 = t3749;
    uint64_t t3766;
    if (v3716) {
        uint64_t v3751 = ((uint64_t)in_b[UINT64_C(36)]);
        int v3752 = ((v3715 == UINT64_C(0)) && (UINT64_C(36) == v3664));
        int v3753 = (v3752 && (v3751 == UINT64_C(0)));
        int v3754 = ((v3752 && ((v3751 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(37) < ((uint64_t)((uint64_t)in_b_len))));
        int v3755 = (((v3752 && (v3751 != UINT64_C(0))) && (v3751 < UINT64_C(64))) && (((uint64_t)((UINT64_C(36) + v3751) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3758 = ((v3715 == UINT64_C(0)) && (UINT64_C(36) != v3664));
        if (t3758) {
                uint64_t v3756 = v3751;
            int t3757 = (!(((((v3756 | UINT64_C(32)) >= UINT64_C(97)) && ((v3756 | UINT64_C(32)) <= UINT64_C(122))) || ((v3756 >= UINT64_C(48)) && (v3756 <= UINT64_C(57)))) || (v3756 == UINT64_C(45))));
            if (!t3757) {
                t3757 = ((v3751 == UINT64_C(45)) && ((UINT64_C(36) == ((v3698 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(37) == v3664)));
            }
            t3758 = t3757;
        }
        int v3759 = t3758;
        uint64_t v3760 = (v3753 ? UINT64_C(37) : (v3754 ? UINT64_C(38) : v3630));
        uint64_t v3761 = (v3754 ? (((((uint64_t)(v3751 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(37)]))) : v3681);
        uint64_t v3762 = (v3755 ? ((v3647 + UINT64_C(1)) & UINT64_C(255)) : v3647);
        uint64_t v3763 = (v3755 ? UINT64_C(36) : v3698);
        uint64_t v3764 = (v3755 ? ((uint64_t)((UINT64_C(37) + v3751) & UINT64_C(255))) : v3664);
        uint64_t v3765 = ((v3753 || v3754) ? UINT64_C(1) : ((v3759 || (v3752 && (!v3755))) ? UINT64_C(2) : v3715));
        t3766 = v3764;
    } else {
        t3766 = v3664;
    }
    uint64_t v3767 = t3766;
    uint64_t t3783;
    if (v3716) {
        uint64_t v3768 = ((uint64_t)in_b[UINT64_C(36)]);
        int v3769 = ((v3715 == UINT64_C(0)) && (UINT64_C(36) == v3664));
        int v3770 = (v3769 && (v3768 == UINT64_C(0)));
        int v3771 = ((v3769 && ((v3768 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(37) < ((uint64_t)((uint64_t)in_b_len))));
        int v3772 = (((v3769 && (v3768 != UINT64_C(0))) && (v3768 < UINT64_C(64))) && (((uint64_t)((UINT64_C(36) + v3768) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3775 = ((v3715 == UINT64_C(0)) && (UINT64_C(36) != v3664));
        if (t3775) {
                uint64_t v3773 = v3768;
            int t3774 = (!(((((v3773 | UINT64_C(32)) >= UINT64_C(97)) && ((v3773 | UINT64_C(32)) <= UINT64_C(122))) || ((v3773 >= UINT64_C(48)) && (v3773 <= UINT64_C(57)))) || (v3773 == UINT64_C(45))));
            if (!t3774) {
                t3774 = ((v3768 == UINT64_C(45)) && ((UINT64_C(36) == ((v3698 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(37) == v3664)));
            }
            t3775 = t3774;
        }
        int v3776 = t3775;
        uint64_t v3777 = (v3770 ? UINT64_C(37) : (v3771 ? UINT64_C(38) : v3630));
        uint64_t v3778 = (v3771 ? (((((uint64_t)(v3768 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(37)]))) : v3681);
        uint64_t v3779 = (v3772 ? ((v3647 + UINT64_C(1)) & UINT64_C(255)) : v3647);
        uint64_t v3780 = (v3772 ? UINT64_C(36) : v3698);
        uint64_t v3781 = (v3772 ? ((uint64_t)((UINT64_C(37) + v3768) & UINT64_C(255))) : v3664);
        uint64_t v3782 = ((v3770 || v3771) ? UINT64_C(1) : ((v3776 || (v3769 && (!v3772))) ? UINT64_C(2) : v3715));
        t3783 = v3778;
    } else {
        t3783 = v3681;
    }
    uint64_t v3784 = t3783;
    uint64_t t3800;
    if (v3716) {
        uint64_t v3785 = ((uint64_t)in_b[UINT64_C(36)]);
        int v3786 = ((v3715 == UINT64_C(0)) && (UINT64_C(36) == v3664));
        int v3787 = (v3786 && (v3785 == UINT64_C(0)));
        int v3788 = ((v3786 && ((v3785 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(37) < ((uint64_t)((uint64_t)in_b_len))));
        int v3789 = (((v3786 && (v3785 != UINT64_C(0))) && (v3785 < UINT64_C(64))) && (((uint64_t)((UINT64_C(36) + v3785) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3792 = ((v3715 == UINT64_C(0)) && (UINT64_C(36) != v3664));
        if (t3792) {
                uint64_t v3790 = v3785;
            int t3791 = (!(((((v3790 | UINT64_C(32)) >= UINT64_C(97)) && ((v3790 | UINT64_C(32)) <= UINT64_C(122))) || ((v3790 >= UINT64_C(48)) && (v3790 <= UINT64_C(57)))) || (v3790 == UINT64_C(45))));
            if (!t3791) {
                t3791 = ((v3785 == UINT64_C(45)) && ((UINT64_C(36) == ((v3698 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(37) == v3664)));
            }
            t3792 = t3791;
        }
        int v3793 = t3792;
        uint64_t v3794 = (v3787 ? UINT64_C(37) : (v3788 ? UINT64_C(38) : v3630));
        uint64_t v3795 = (v3788 ? (((((uint64_t)(v3785 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(37)]))) : v3681);
        uint64_t v3796 = (v3789 ? ((v3647 + UINT64_C(1)) & UINT64_C(255)) : v3647);
        uint64_t v3797 = (v3789 ? UINT64_C(36) : v3698);
        uint64_t v3798 = (v3789 ? ((uint64_t)((UINT64_C(37) + v3785) & UINT64_C(255))) : v3664);
        uint64_t v3799 = ((v3787 || v3788) ? UINT64_C(1) : ((v3793 || (v3786 && (!v3789))) ? UINT64_C(2) : v3715));
        t3800 = v3797;
    } else {
        t3800 = v3698;
    }
    uint64_t v3801 = t3800;
    uint64_t t3817;
    if (v3716) {
        uint64_t v3802 = ((uint64_t)in_b[UINT64_C(36)]);
        int v3803 = ((v3715 == UINT64_C(0)) && (UINT64_C(36) == v3664));
        int v3804 = (v3803 && (v3802 == UINT64_C(0)));
        int v3805 = ((v3803 && ((v3802 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(37) < ((uint64_t)((uint64_t)in_b_len))));
        int v3806 = (((v3803 && (v3802 != UINT64_C(0))) && (v3802 < UINT64_C(64))) && (((uint64_t)((UINT64_C(36) + v3802) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3809 = ((v3715 == UINT64_C(0)) && (UINT64_C(36) != v3664));
        if (t3809) {
                uint64_t v3807 = v3802;
            int t3808 = (!(((((v3807 | UINT64_C(32)) >= UINT64_C(97)) && ((v3807 | UINT64_C(32)) <= UINT64_C(122))) || ((v3807 >= UINT64_C(48)) && (v3807 <= UINT64_C(57)))) || (v3807 == UINT64_C(45))));
            if (!t3808) {
                t3808 = ((v3802 == UINT64_C(45)) && ((UINT64_C(36) == ((v3698 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(37) == v3664)));
            }
            t3809 = t3808;
        }
        int v3810 = t3809;
        uint64_t v3811 = (v3804 ? UINT64_C(37) : (v3805 ? UINT64_C(38) : v3630));
        uint64_t v3812 = (v3805 ? (((((uint64_t)(v3802 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(37)]))) : v3681);
        uint64_t v3813 = (v3806 ? ((v3647 + UINT64_C(1)) & UINT64_C(255)) : v3647);
        uint64_t v3814 = (v3806 ? UINT64_C(36) : v3698);
        uint64_t v3815 = (v3806 ? ((uint64_t)((UINT64_C(37) + v3802) & UINT64_C(255))) : v3664);
        uint64_t v3816 = ((v3804 || v3805) ? UINT64_C(1) : ((v3810 || (v3803 && (!v3806))) ? UINT64_C(2) : v3715));
        t3817 = v3816;
    } else {
        t3817 = v3715;
    }
    uint64_t v3818 = t3817;
    int v3819 = (UINT64_C(37) < v7);
    uint64_t t3835;
    if (v3819) {
        uint64_t v3820 = ((uint64_t)in_b[UINT64_C(37)]);
        int v3821 = ((v3818 == UINT64_C(0)) && (UINT64_C(37) == v3767));
        int v3822 = (v3821 && (v3820 == UINT64_C(0)));
        int v3823 = ((v3821 && ((v3820 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(38) < ((uint64_t)((uint64_t)in_b_len))));
        int v3824 = (((v3821 && (v3820 != UINT64_C(0))) && (v3820 < UINT64_C(64))) && (((uint64_t)((UINT64_C(37) + v3820) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3827 = ((v3818 == UINT64_C(0)) && (UINT64_C(37) != v3767));
        if (t3827) {
                uint64_t v3825 = v3820;
            int t3826 = (!(((((v3825 | UINT64_C(32)) >= UINT64_C(97)) && ((v3825 | UINT64_C(32)) <= UINT64_C(122))) || ((v3825 >= UINT64_C(48)) && (v3825 <= UINT64_C(57)))) || (v3825 == UINT64_C(45))));
            if (!t3826) {
                t3826 = ((v3820 == UINT64_C(45)) && ((UINT64_C(37) == ((v3801 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(38) == v3767)));
            }
            t3827 = t3826;
        }
        int v3828 = t3827;
        uint64_t v3829 = (v3822 ? UINT64_C(38) : (v3823 ? UINT64_C(39) : v3733));
        uint64_t v3830 = (v3823 ? (((((uint64_t)(v3820 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(38)]))) : v3784);
        uint64_t v3831 = (v3824 ? ((v3750 + UINT64_C(1)) & UINT64_C(255)) : v3750);
        uint64_t v3832 = (v3824 ? UINT64_C(37) : v3801);
        uint64_t v3833 = (v3824 ? ((uint64_t)((UINT64_C(38) + v3820) & UINT64_C(255))) : v3767);
        uint64_t v3834 = ((v3822 || v3823) ? UINT64_C(1) : ((v3828 || (v3821 && (!v3824))) ? UINT64_C(2) : v3818));
        t3835 = v3829;
    } else {
        t3835 = v3733;
    }
    uint64_t v3836 = t3835;
    uint64_t t3852;
    if (v3819) {
        uint64_t v3837 = ((uint64_t)in_b[UINT64_C(37)]);
        int v3838 = ((v3818 == UINT64_C(0)) && (UINT64_C(37) == v3767));
        int v3839 = (v3838 && (v3837 == UINT64_C(0)));
        int v3840 = ((v3838 && ((v3837 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(38) < ((uint64_t)((uint64_t)in_b_len))));
        int v3841 = (((v3838 && (v3837 != UINT64_C(0))) && (v3837 < UINT64_C(64))) && (((uint64_t)((UINT64_C(37) + v3837) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3844 = ((v3818 == UINT64_C(0)) && (UINT64_C(37) != v3767));
        if (t3844) {
                uint64_t v3842 = v3837;
            int t3843 = (!(((((v3842 | UINT64_C(32)) >= UINT64_C(97)) && ((v3842 | UINT64_C(32)) <= UINT64_C(122))) || ((v3842 >= UINT64_C(48)) && (v3842 <= UINT64_C(57)))) || (v3842 == UINT64_C(45))));
            if (!t3843) {
                t3843 = ((v3837 == UINT64_C(45)) && ((UINT64_C(37) == ((v3801 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(38) == v3767)));
            }
            t3844 = t3843;
        }
        int v3845 = t3844;
        uint64_t v3846 = (v3839 ? UINT64_C(38) : (v3840 ? UINT64_C(39) : v3733));
        uint64_t v3847 = (v3840 ? (((((uint64_t)(v3837 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(38)]))) : v3784);
        uint64_t v3848 = (v3841 ? ((v3750 + UINT64_C(1)) & UINT64_C(255)) : v3750);
        uint64_t v3849 = (v3841 ? UINT64_C(37) : v3801);
        uint64_t v3850 = (v3841 ? ((uint64_t)((UINT64_C(38) + v3837) & UINT64_C(255))) : v3767);
        uint64_t v3851 = ((v3839 || v3840) ? UINT64_C(1) : ((v3845 || (v3838 && (!v3841))) ? UINT64_C(2) : v3818));
        t3852 = v3848;
    } else {
        t3852 = v3750;
    }
    uint64_t v3853 = t3852;
    uint64_t t3869;
    if (v3819) {
        uint64_t v3854 = ((uint64_t)in_b[UINT64_C(37)]);
        int v3855 = ((v3818 == UINT64_C(0)) && (UINT64_C(37) == v3767));
        int v3856 = (v3855 && (v3854 == UINT64_C(0)));
        int v3857 = ((v3855 && ((v3854 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(38) < ((uint64_t)((uint64_t)in_b_len))));
        int v3858 = (((v3855 && (v3854 != UINT64_C(0))) && (v3854 < UINT64_C(64))) && (((uint64_t)((UINT64_C(37) + v3854) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3861 = ((v3818 == UINT64_C(0)) && (UINT64_C(37) != v3767));
        if (t3861) {
                uint64_t v3859 = v3854;
            int t3860 = (!(((((v3859 | UINT64_C(32)) >= UINT64_C(97)) && ((v3859 | UINT64_C(32)) <= UINT64_C(122))) || ((v3859 >= UINT64_C(48)) && (v3859 <= UINT64_C(57)))) || (v3859 == UINT64_C(45))));
            if (!t3860) {
                t3860 = ((v3854 == UINT64_C(45)) && ((UINT64_C(37) == ((v3801 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(38) == v3767)));
            }
            t3861 = t3860;
        }
        int v3862 = t3861;
        uint64_t v3863 = (v3856 ? UINT64_C(38) : (v3857 ? UINT64_C(39) : v3733));
        uint64_t v3864 = (v3857 ? (((((uint64_t)(v3854 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(38)]))) : v3784);
        uint64_t v3865 = (v3858 ? ((v3750 + UINT64_C(1)) & UINT64_C(255)) : v3750);
        uint64_t v3866 = (v3858 ? UINT64_C(37) : v3801);
        uint64_t v3867 = (v3858 ? ((uint64_t)((UINT64_C(38) + v3854) & UINT64_C(255))) : v3767);
        uint64_t v3868 = ((v3856 || v3857) ? UINT64_C(1) : ((v3862 || (v3855 && (!v3858))) ? UINT64_C(2) : v3818));
        t3869 = v3867;
    } else {
        t3869 = v3767;
    }
    uint64_t v3870 = t3869;
    uint64_t t3886;
    if (v3819) {
        uint64_t v3871 = ((uint64_t)in_b[UINT64_C(37)]);
        int v3872 = ((v3818 == UINT64_C(0)) && (UINT64_C(37) == v3767));
        int v3873 = (v3872 && (v3871 == UINT64_C(0)));
        int v3874 = ((v3872 && ((v3871 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(38) < ((uint64_t)((uint64_t)in_b_len))));
        int v3875 = (((v3872 && (v3871 != UINT64_C(0))) && (v3871 < UINT64_C(64))) && (((uint64_t)((UINT64_C(37) + v3871) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3878 = ((v3818 == UINT64_C(0)) && (UINT64_C(37) != v3767));
        if (t3878) {
                uint64_t v3876 = v3871;
            int t3877 = (!(((((v3876 | UINT64_C(32)) >= UINT64_C(97)) && ((v3876 | UINT64_C(32)) <= UINT64_C(122))) || ((v3876 >= UINT64_C(48)) && (v3876 <= UINT64_C(57)))) || (v3876 == UINT64_C(45))));
            if (!t3877) {
                t3877 = ((v3871 == UINT64_C(45)) && ((UINT64_C(37) == ((v3801 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(38) == v3767)));
            }
            t3878 = t3877;
        }
        int v3879 = t3878;
        uint64_t v3880 = (v3873 ? UINT64_C(38) : (v3874 ? UINT64_C(39) : v3733));
        uint64_t v3881 = (v3874 ? (((((uint64_t)(v3871 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(38)]))) : v3784);
        uint64_t v3882 = (v3875 ? ((v3750 + UINT64_C(1)) & UINT64_C(255)) : v3750);
        uint64_t v3883 = (v3875 ? UINT64_C(37) : v3801);
        uint64_t v3884 = (v3875 ? ((uint64_t)((UINT64_C(38) + v3871) & UINT64_C(255))) : v3767);
        uint64_t v3885 = ((v3873 || v3874) ? UINT64_C(1) : ((v3879 || (v3872 && (!v3875))) ? UINT64_C(2) : v3818));
        t3886 = v3881;
    } else {
        t3886 = v3784;
    }
    uint64_t v3887 = t3886;
    uint64_t t3903;
    if (v3819) {
        uint64_t v3888 = ((uint64_t)in_b[UINT64_C(37)]);
        int v3889 = ((v3818 == UINT64_C(0)) && (UINT64_C(37) == v3767));
        int v3890 = (v3889 && (v3888 == UINT64_C(0)));
        int v3891 = ((v3889 && ((v3888 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(38) < ((uint64_t)((uint64_t)in_b_len))));
        int v3892 = (((v3889 && (v3888 != UINT64_C(0))) && (v3888 < UINT64_C(64))) && (((uint64_t)((UINT64_C(37) + v3888) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3895 = ((v3818 == UINT64_C(0)) && (UINT64_C(37) != v3767));
        if (t3895) {
                uint64_t v3893 = v3888;
            int t3894 = (!(((((v3893 | UINT64_C(32)) >= UINT64_C(97)) && ((v3893 | UINT64_C(32)) <= UINT64_C(122))) || ((v3893 >= UINT64_C(48)) && (v3893 <= UINT64_C(57)))) || (v3893 == UINT64_C(45))));
            if (!t3894) {
                t3894 = ((v3888 == UINT64_C(45)) && ((UINT64_C(37) == ((v3801 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(38) == v3767)));
            }
            t3895 = t3894;
        }
        int v3896 = t3895;
        uint64_t v3897 = (v3890 ? UINT64_C(38) : (v3891 ? UINT64_C(39) : v3733));
        uint64_t v3898 = (v3891 ? (((((uint64_t)(v3888 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(38)]))) : v3784);
        uint64_t v3899 = (v3892 ? ((v3750 + UINT64_C(1)) & UINT64_C(255)) : v3750);
        uint64_t v3900 = (v3892 ? UINT64_C(37) : v3801);
        uint64_t v3901 = (v3892 ? ((uint64_t)((UINT64_C(38) + v3888) & UINT64_C(255))) : v3767);
        uint64_t v3902 = ((v3890 || v3891) ? UINT64_C(1) : ((v3896 || (v3889 && (!v3892))) ? UINT64_C(2) : v3818));
        t3903 = v3900;
    } else {
        t3903 = v3801;
    }
    uint64_t v3904 = t3903;
    uint64_t t3920;
    if (v3819) {
        uint64_t v3905 = ((uint64_t)in_b[UINT64_C(37)]);
        int v3906 = ((v3818 == UINT64_C(0)) && (UINT64_C(37) == v3767));
        int v3907 = (v3906 && (v3905 == UINT64_C(0)));
        int v3908 = ((v3906 && ((v3905 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(38) < ((uint64_t)((uint64_t)in_b_len))));
        int v3909 = (((v3906 && (v3905 != UINT64_C(0))) && (v3905 < UINT64_C(64))) && (((uint64_t)((UINT64_C(37) + v3905) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3912 = ((v3818 == UINT64_C(0)) && (UINT64_C(37) != v3767));
        if (t3912) {
                uint64_t v3910 = v3905;
            int t3911 = (!(((((v3910 | UINT64_C(32)) >= UINT64_C(97)) && ((v3910 | UINT64_C(32)) <= UINT64_C(122))) || ((v3910 >= UINT64_C(48)) && (v3910 <= UINT64_C(57)))) || (v3910 == UINT64_C(45))));
            if (!t3911) {
                t3911 = ((v3905 == UINT64_C(45)) && ((UINT64_C(37) == ((v3801 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(38) == v3767)));
            }
            t3912 = t3911;
        }
        int v3913 = t3912;
        uint64_t v3914 = (v3907 ? UINT64_C(38) : (v3908 ? UINT64_C(39) : v3733));
        uint64_t v3915 = (v3908 ? (((((uint64_t)(v3905 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(38)]))) : v3784);
        uint64_t v3916 = (v3909 ? ((v3750 + UINT64_C(1)) & UINT64_C(255)) : v3750);
        uint64_t v3917 = (v3909 ? UINT64_C(37) : v3801);
        uint64_t v3918 = (v3909 ? ((uint64_t)((UINT64_C(38) + v3905) & UINT64_C(255))) : v3767);
        uint64_t v3919 = ((v3907 || v3908) ? UINT64_C(1) : ((v3913 || (v3906 && (!v3909))) ? UINT64_C(2) : v3818));
        t3920 = v3919;
    } else {
        t3920 = v3818;
    }
    uint64_t v3921 = t3920;
    int v3922 = (UINT64_C(38) < v7);
    uint64_t t3938;
    if (v3922) {
        uint64_t v3923 = ((uint64_t)in_b[UINT64_C(38)]);
        int v3924 = ((v3921 == UINT64_C(0)) && (UINT64_C(38) == v3870));
        int v3925 = (v3924 && (v3923 == UINT64_C(0)));
        int v3926 = ((v3924 && ((v3923 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(39) < ((uint64_t)((uint64_t)in_b_len))));
        int v3927 = (((v3924 && (v3923 != UINT64_C(0))) && (v3923 < UINT64_C(64))) && (((uint64_t)((UINT64_C(38) + v3923) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3930 = ((v3921 == UINT64_C(0)) && (UINT64_C(38) != v3870));
        if (t3930) {
                uint64_t v3928 = v3923;
            int t3929 = (!(((((v3928 | UINT64_C(32)) >= UINT64_C(97)) && ((v3928 | UINT64_C(32)) <= UINT64_C(122))) || ((v3928 >= UINT64_C(48)) && (v3928 <= UINT64_C(57)))) || (v3928 == UINT64_C(45))));
            if (!t3929) {
                t3929 = ((v3923 == UINT64_C(45)) && ((UINT64_C(38) == ((v3904 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(39) == v3870)));
            }
            t3930 = t3929;
        }
        int v3931 = t3930;
        uint64_t v3932 = (v3925 ? UINT64_C(39) : (v3926 ? UINT64_C(40) : v3836));
        uint64_t v3933 = (v3926 ? (((((uint64_t)(v3923 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(39)]))) : v3887);
        uint64_t v3934 = (v3927 ? ((v3853 + UINT64_C(1)) & UINT64_C(255)) : v3853);
        uint64_t v3935 = (v3927 ? UINT64_C(38) : v3904);
        uint64_t v3936 = (v3927 ? ((uint64_t)((UINT64_C(39) + v3923) & UINT64_C(255))) : v3870);
        uint64_t v3937 = ((v3925 || v3926) ? UINT64_C(1) : ((v3931 || (v3924 && (!v3927))) ? UINT64_C(2) : v3921));
        t3938 = v3932;
    } else {
        t3938 = v3836;
    }
    uint64_t v3939 = t3938;
    uint64_t t3955;
    if (v3922) {
        uint64_t v3940 = ((uint64_t)in_b[UINT64_C(38)]);
        int v3941 = ((v3921 == UINT64_C(0)) && (UINT64_C(38) == v3870));
        int v3942 = (v3941 && (v3940 == UINT64_C(0)));
        int v3943 = ((v3941 && ((v3940 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(39) < ((uint64_t)((uint64_t)in_b_len))));
        int v3944 = (((v3941 && (v3940 != UINT64_C(0))) && (v3940 < UINT64_C(64))) && (((uint64_t)((UINT64_C(38) + v3940) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3947 = ((v3921 == UINT64_C(0)) && (UINT64_C(38) != v3870));
        if (t3947) {
                uint64_t v3945 = v3940;
            int t3946 = (!(((((v3945 | UINT64_C(32)) >= UINT64_C(97)) && ((v3945 | UINT64_C(32)) <= UINT64_C(122))) || ((v3945 >= UINT64_C(48)) && (v3945 <= UINT64_C(57)))) || (v3945 == UINT64_C(45))));
            if (!t3946) {
                t3946 = ((v3940 == UINT64_C(45)) && ((UINT64_C(38) == ((v3904 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(39) == v3870)));
            }
            t3947 = t3946;
        }
        int v3948 = t3947;
        uint64_t v3949 = (v3942 ? UINT64_C(39) : (v3943 ? UINT64_C(40) : v3836));
        uint64_t v3950 = (v3943 ? (((((uint64_t)(v3940 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(39)]))) : v3887);
        uint64_t v3951 = (v3944 ? ((v3853 + UINT64_C(1)) & UINT64_C(255)) : v3853);
        uint64_t v3952 = (v3944 ? UINT64_C(38) : v3904);
        uint64_t v3953 = (v3944 ? ((uint64_t)((UINT64_C(39) + v3940) & UINT64_C(255))) : v3870);
        uint64_t v3954 = ((v3942 || v3943) ? UINT64_C(1) : ((v3948 || (v3941 && (!v3944))) ? UINT64_C(2) : v3921));
        t3955 = v3951;
    } else {
        t3955 = v3853;
    }
    uint64_t v3956 = t3955;
    uint64_t t3972;
    if (v3922) {
        uint64_t v3957 = ((uint64_t)in_b[UINT64_C(38)]);
        int v3958 = ((v3921 == UINT64_C(0)) && (UINT64_C(38) == v3870));
        int v3959 = (v3958 && (v3957 == UINT64_C(0)));
        int v3960 = ((v3958 && ((v3957 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(39) < ((uint64_t)((uint64_t)in_b_len))));
        int v3961 = (((v3958 && (v3957 != UINT64_C(0))) && (v3957 < UINT64_C(64))) && (((uint64_t)((UINT64_C(38) + v3957) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3964 = ((v3921 == UINT64_C(0)) && (UINT64_C(38) != v3870));
        if (t3964) {
                uint64_t v3962 = v3957;
            int t3963 = (!(((((v3962 | UINT64_C(32)) >= UINT64_C(97)) && ((v3962 | UINT64_C(32)) <= UINT64_C(122))) || ((v3962 >= UINT64_C(48)) && (v3962 <= UINT64_C(57)))) || (v3962 == UINT64_C(45))));
            if (!t3963) {
                t3963 = ((v3957 == UINT64_C(45)) && ((UINT64_C(38) == ((v3904 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(39) == v3870)));
            }
            t3964 = t3963;
        }
        int v3965 = t3964;
        uint64_t v3966 = (v3959 ? UINT64_C(39) : (v3960 ? UINT64_C(40) : v3836));
        uint64_t v3967 = (v3960 ? (((((uint64_t)(v3957 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(39)]))) : v3887);
        uint64_t v3968 = (v3961 ? ((v3853 + UINT64_C(1)) & UINT64_C(255)) : v3853);
        uint64_t v3969 = (v3961 ? UINT64_C(38) : v3904);
        uint64_t v3970 = (v3961 ? ((uint64_t)((UINT64_C(39) + v3957) & UINT64_C(255))) : v3870);
        uint64_t v3971 = ((v3959 || v3960) ? UINT64_C(1) : ((v3965 || (v3958 && (!v3961))) ? UINT64_C(2) : v3921));
        t3972 = v3970;
    } else {
        t3972 = v3870;
    }
    uint64_t v3973 = t3972;
    uint64_t t3989;
    if (v3922) {
        uint64_t v3974 = ((uint64_t)in_b[UINT64_C(38)]);
        int v3975 = ((v3921 == UINT64_C(0)) && (UINT64_C(38) == v3870));
        int v3976 = (v3975 && (v3974 == UINT64_C(0)));
        int v3977 = ((v3975 && ((v3974 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(39) < ((uint64_t)((uint64_t)in_b_len))));
        int v3978 = (((v3975 && (v3974 != UINT64_C(0))) && (v3974 < UINT64_C(64))) && (((uint64_t)((UINT64_C(38) + v3974) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3981 = ((v3921 == UINT64_C(0)) && (UINT64_C(38) != v3870));
        if (t3981) {
                uint64_t v3979 = v3974;
            int t3980 = (!(((((v3979 | UINT64_C(32)) >= UINT64_C(97)) && ((v3979 | UINT64_C(32)) <= UINT64_C(122))) || ((v3979 >= UINT64_C(48)) && (v3979 <= UINT64_C(57)))) || (v3979 == UINT64_C(45))));
            if (!t3980) {
                t3980 = ((v3974 == UINT64_C(45)) && ((UINT64_C(38) == ((v3904 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(39) == v3870)));
            }
            t3981 = t3980;
        }
        int v3982 = t3981;
        uint64_t v3983 = (v3976 ? UINT64_C(39) : (v3977 ? UINT64_C(40) : v3836));
        uint64_t v3984 = (v3977 ? (((((uint64_t)(v3974 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(39)]))) : v3887);
        uint64_t v3985 = (v3978 ? ((v3853 + UINT64_C(1)) & UINT64_C(255)) : v3853);
        uint64_t v3986 = (v3978 ? UINT64_C(38) : v3904);
        uint64_t v3987 = (v3978 ? ((uint64_t)((UINT64_C(39) + v3974) & UINT64_C(255))) : v3870);
        uint64_t v3988 = ((v3976 || v3977) ? UINT64_C(1) : ((v3982 || (v3975 && (!v3978))) ? UINT64_C(2) : v3921));
        t3989 = v3984;
    } else {
        t3989 = v3887;
    }
    uint64_t v3990 = t3989;
    uint64_t t4006;
    if (v3922) {
        uint64_t v3991 = ((uint64_t)in_b[UINT64_C(38)]);
        int v3992 = ((v3921 == UINT64_C(0)) && (UINT64_C(38) == v3870));
        int v3993 = (v3992 && (v3991 == UINT64_C(0)));
        int v3994 = ((v3992 && ((v3991 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(39) < ((uint64_t)((uint64_t)in_b_len))));
        int v3995 = (((v3992 && (v3991 != UINT64_C(0))) && (v3991 < UINT64_C(64))) && (((uint64_t)((UINT64_C(38) + v3991) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t3998 = ((v3921 == UINT64_C(0)) && (UINT64_C(38) != v3870));
        if (t3998) {
                uint64_t v3996 = v3991;
            int t3997 = (!(((((v3996 | UINT64_C(32)) >= UINT64_C(97)) && ((v3996 | UINT64_C(32)) <= UINT64_C(122))) || ((v3996 >= UINT64_C(48)) && (v3996 <= UINT64_C(57)))) || (v3996 == UINT64_C(45))));
            if (!t3997) {
                t3997 = ((v3991 == UINT64_C(45)) && ((UINT64_C(38) == ((v3904 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(39) == v3870)));
            }
            t3998 = t3997;
        }
        int v3999 = t3998;
        uint64_t v4000 = (v3993 ? UINT64_C(39) : (v3994 ? UINT64_C(40) : v3836));
        uint64_t v4001 = (v3994 ? (((((uint64_t)(v3991 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(39)]))) : v3887);
        uint64_t v4002 = (v3995 ? ((v3853 + UINT64_C(1)) & UINT64_C(255)) : v3853);
        uint64_t v4003 = (v3995 ? UINT64_C(38) : v3904);
        uint64_t v4004 = (v3995 ? ((uint64_t)((UINT64_C(39) + v3991) & UINT64_C(255))) : v3870);
        uint64_t v4005 = ((v3993 || v3994) ? UINT64_C(1) : ((v3999 || (v3992 && (!v3995))) ? UINT64_C(2) : v3921));
        t4006 = v4003;
    } else {
        t4006 = v3904;
    }
    uint64_t v4007 = t4006;
    uint64_t t4023;
    if (v3922) {
        uint64_t v4008 = ((uint64_t)in_b[UINT64_C(38)]);
        int v4009 = ((v3921 == UINT64_C(0)) && (UINT64_C(38) == v3870));
        int v4010 = (v4009 && (v4008 == UINT64_C(0)));
        int v4011 = ((v4009 && ((v4008 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(39) < ((uint64_t)((uint64_t)in_b_len))));
        int v4012 = (((v4009 && (v4008 != UINT64_C(0))) && (v4008 < UINT64_C(64))) && (((uint64_t)((UINT64_C(38) + v4008) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4015 = ((v3921 == UINT64_C(0)) && (UINT64_C(38) != v3870));
        if (t4015) {
                uint64_t v4013 = v4008;
            int t4014 = (!(((((v4013 | UINT64_C(32)) >= UINT64_C(97)) && ((v4013 | UINT64_C(32)) <= UINT64_C(122))) || ((v4013 >= UINT64_C(48)) && (v4013 <= UINT64_C(57)))) || (v4013 == UINT64_C(45))));
            if (!t4014) {
                t4014 = ((v4008 == UINT64_C(45)) && ((UINT64_C(38) == ((v3904 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(39) == v3870)));
            }
            t4015 = t4014;
        }
        int v4016 = t4015;
        uint64_t v4017 = (v4010 ? UINT64_C(39) : (v4011 ? UINT64_C(40) : v3836));
        uint64_t v4018 = (v4011 ? (((((uint64_t)(v4008 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(39)]))) : v3887);
        uint64_t v4019 = (v4012 ? ((v3853 + UINT64_C(1)) & UINT64_C(255)) : v3853);
        uint64_t v4020 = (v4012 ? UINT64_C(38) : v3904);
        uint64_t v4021 = (v4012 ? ((uint64_t)((UINT64_C(39) + v4008) & UINT64_C(255))) : v3870);
        uint64_t v4022 = ((v4010 || v4011) ? UINT64_C(1) : ((v4016 || (v4009 && (!v4012))) ? UINT64_C(2) : v3921));
        t4023 = v4022;
    } else {
        t4023 = v3921;
    }
    uint64_t v4024 = t4023;
    int v4025 = (UINT64_C(39) < v7);
    uint64_t t4041;
    if (v4025) {
        uint64_t v4026 = ((uint64_t)in_b[UINT64_C(39)]);
        int v4027 = ((v4024 == UINT64_C(0)) && (UINT64_C(39) == v3973));
        int v4028 = (v4027 && (v4026 == UINT64_C(0)));
        int v4029 = ((v4027 && ((v4026 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(40) < ((uint64_t)((uint64_t)in_b_len))));
        int v4030 = (((v4027 && (v4026 != UINT64_C(0))) && (v4026 < UINT64_C(64))) && (((uint64_t)((UINT64_C(39) + v4026) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4033 = ((v4024 == UINT64_C(0)) && (UINT64_C(39) != v3973));
        if (t4033) {
                uint64_t v4031 = v4026;
            int t4032 = (!(((((v4031 | UINT64_C(32)) >= UINT64_C(97)) && ((v4031 | UINT64_C(32)) <= UINT64_C(122))) || ((v4031 >= UINT64_C(48)) && (v4031 <= UINT64_C(57)))) || (v4031 == UINT64_C(45))));
            if (!t4032) {
                t4032 = ((v4026 == UINT64_C(45)) && ((UINT64_C(39) == ((v4007 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(40) == v3973)));
            }
            t4033 = t4032;
        }
        int v4034 = t4033;
        uint64_t v4035 = (v4028 ? UINT64_C(40) : (v4029 ? UINT64_C(41) : v3939));
        uint64_t v4036 = (v4029 ? (((((uint64_t)(v4026 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(40)]))) : v3990);
        uint64_t v4037 = (v4030 ? ((v3956 + UINT64_C(1)) & UINT64_C(255)) : v3956);
        uint64_t v4038 = (v4030 ? UINT64_C(39) : v4007);
        uint64_t v4039 = (v4030 ? ((uint64_t)((UINT64_C(40) + v4026) & UINT64_C(255))) : v3973);
        uint64_t v4040 = ((v4028 || v4029) ? UINT64_C(1) : ((v4034 || (v4027 && (!v4030))) ? UINT64_C(2) : v4024));
        t4041 = v4035;
    } else {
        t4041 = v3939;
    }
    uint64_t v4042 = t4041;
    uint64_t t4058;
    if (v4025) {
        uint64_t v4043 = ((uint64_t)in_b[UINT64_C(39)]);
        int v4044 = ((v4024 == UINT64_C(0)) && (UINT64_C(39) == v3973));
        int v4045 = (v4044 && (v4043 == UINT64_C(0)));
        int v4046 = ((v4044 && ((v4043 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(40) < ((uint64_t)((uint64_t)in_b_len))));
        int v4047 = (((v4044 && (v4043 != UINT64_C(0))) && (v4043 < UINT64_C(64))) && (((uint64_t)((UINT64_C(39) + v4043) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4050 = ((v4024 == UINT64_C(0)) && (UINT64_C(39) != v3973));
        if (t4050) {
                uint64_t v4048 = v4043;
            int t4049 = (!(((((v4048 | UINT64_C(32)) >= UINT64_C(97)) && ((v4048 | UINT64_C(32)) <= UINT64_C(122))) || ((v4048 >= UINT64_C(48)) && (v4048 <= UINT64_C(57)))) || (v4048 == UINT64_C(45))));
            if (!t4049) {
                t4049 = ((v4043 == UINT64_C(45)) && ((UINT64_C(39) == ((v4007 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(40) == v3973)));
            }
            t4050 = t4049;
        }
        int v4051 = t4050;
        uint64_t v4052 = (v4045 ? UINT64_C(40) : (v4046 ? UINT64_C(41) : v3939));
        uint64_t v4053 = (v4046 ? (((((uint64_t)(v4043 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(40)]))) : v3990);
        uint64_t v4054 = (v4047 ? ((v3956 + UINT64_C(1)) & UINT64_C(255)) : v3956);
        uint64_t v4055 = (v4047 ? UINT64_C(39) : v4007);
        uint64_t v4056 = (v4047 ? ((uint64_t)((UINT64_C(40) + v4043) & UINT64_C(255))) : v3973);
        uint64_t v4057 = ((v4045 || v4046) ? UINT64_C(1) : ((v4051 || (v4044 && (!v4047))) ? UINT64_C(2) : v4024));
        t4058 = v4054;
    } else {
        t4058 = v3956;
    }
    uint64_t v4059 = t4058;
    uint64_t t4075;
    if (v4025) {
        uint64_t v4060 = ((uint64_t)in_b[UINT64_C(39)]);
        int v4061 = ((v4024 == UINT64_C(0)) && (UINT64_C(39) == v3973));
        int v4062 = (v4061 && (v4060 == UINT64_C(0)));
        int v4063 = ((v4061 && ((v4060 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(40) < ((uint64_t)((uint64_t)in_b_len))));
        int v4064 = (((v4061 && (v4060 != UINT64_C(0))) && (v4060 < UINT64_C(64))) && (((uint64_t)((UINT64_C(39) + v4060) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4067 = ((v4024 == UINT64_C(0)) && (UINT64_C(39) != v3973));
        if (t4067) {
                uint64_t v4065 = v4060;
            int t4066 = (!(((((v4065 | UINT64_C(32)) >= UINT64_C(97)) && ((v4065 | UINT64_C(32)) <= UINT64_C(122))) || ((v4065 >= UINT64_C(48)) && (v4065 <= UINT64_C(57)))) || (v4065 == UINT64_C(45))));
            if (!t4066) {
                t4066 = ((v4060 == UINT64_C(45)) && ((UINT64_C(39) == ((v4007 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(40) == v3973)));
            }
            t4067 = t4066;
        }
        int v4068 = t4067;
        uint64_t v4069 = (v4062 ? UINT64_C(40) : (v4063 ? UINT64_C(41) : v3939));
        uint64_t v4070 = (v4063 ? (((((uint64_t)(v4060 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(40)]))) : v3990);
        uint64_t v4071 = (v4064 ? ((v3956 + UINT64_C(1)) & UINT64_C(255)) : v3956);
        uint64_t v4072 = (v4064 ? UINT64_C(39) : v4007);
        uint64_t v4073 = (v4064 ? ((uint64_t)((UINT64_C(40) + v4060) & UINT64_C(255))) : v3973);
        uint64_t v4074 = ((v4062 || v4063) ? UINT64_C(1) : ((v4068 || (v4061 && (!v4064))) ? UINT64_C(2) : v4024));
        t4075 = v4073;
    } else {
        t4075 = v3973;
    }
    uint64_t v4076 = t4075;
    uint64_t t4092;
    if (v4025) {
        uint64_t v4077 = ((uint64_t)in_b[UINT64_C(39)]);
        int v4078 = ((v4024 == UINT64_C(0)) && (UINT64_C(39) == v3973));
        int v4079 = (v4078 && (v4077 == UINT64_C(0)));
        int v4080 = ((v4078 && ((v4077 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(40) < ((uint64_t)((uint64_t)in_b_len))));
        int v4081 = (((v4078 && (v4077 != UINT64_C(0))) && (v4077 < UINT64_C(64))) && (((uint64_t)((UINT64_C(39) + v4077) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4084 = ((v4024 == UINT64_C(0)) && (UINT64_C(39) != v3973));
        if (t4084) {
                uint64_t v4082 = v4077;
            int t4083 = (!(((((v4082 | UINT64_C(32)) >= UINT64_C(97)) && ((v4082 | UINT64_C(32)) <= UINT64_C(122))) || ((v4082 >= UINT64_C(48)) && (v4082 <= UINT64_C(57)))) || (v4082 == UINT64_C(45))));
            if (!t4083) {
                t4083 = ((v4077 == UINT64_C(45)) && ((UINT64_C(39) == ((v4007 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(40) == v3973)));
            }
            t4084 = t4083;
        }
        int v4085 = t4084;
        uint64_t v4086 = (v4079 ? UINT64_C(40) : (v4080 ? UINT64_C(41) : v3939));
        uint64_t v4087 = (v4080 ? (((((uint64_t)(v4077 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(40)]))) : v3990);
        uint64_t v4088 = (v4081 ? ((v3956 + UINT64_C(1)) & UINT64_C(255)) : v3956);
        uint64_t v4089 = (v4081 ? UINT64_C(39) : v4007);
        uint64_t v4090 = (v4081 ? ((uint64_t)((UINT64_C(40) + v4077) & UINT64_C(255))) : v3973);
        uint64_t v4091 = ((v4079 || v4080) ? UINT64_C(1) : ((v4085 || (v4078 && (!v4081))) ? UINT64_C(2) : v4024));
        t4092 = v4087;
    } else {
        t4092 = v3990;
    }
    uint64_t v4093 = t4092;
    uint64_t t4109;
    if (v4025) {
        uint64_t v4094 = ((uint64_t)in_b[UINT64_C(39)]);
        int v4095 = ((v4024 == UINT64_C(0)) && (UINT64_C(39) == v3973));
        int v4096 = (v4095 && (v4094 == UINT64_C(0)));
        int v4097 = ((v4095 && ((v4094 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(40) < ((uint64_t)((uint64_t)in_b_len))));
        int v4098 = (((v4095 && (v4094 != UINT64_C(0))) && (v4094 < UINT64_C(64))) && (((uint64_t)((UINT64_C(39) + v4094) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4101 = ((v4024 == UINT64_C(0)) && (UINT64_C(39) != v3973));
        if (t4101) {
                uint64_t v4099 = v4094;
            int t4100 = (!(((((v4099 | UINT64_C(32)) >= UINT64_C(97)) && ((v4099 | UINT64_C(32)) <= UINT64_C(122))) || ((v4099 >= UINT64_C(48)) && (v4099 <= UINT64_C(57)))) || (v4099 == UINT64_C(45))));
            if (!t4100) {
                t4100 = ((v4094 == UINT64_C(45)) && ((UINT64_C(39) == ((v4007 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(40) == v3973)));
            }
            t4101 = t4100;
        }
        int v4102 = t4101;
        uint64_t v4103 = (v4096 ? UINT64_C(40) : (v4097 ? UINT64_C(41) : v3939));
        uint64_t v4104 = (v4097 ? (((((uint64_t)(v4094 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(40)]))) : v3990);
        uint64_t v4105 = (v4098 ? ((v3956 + UINT64_C(1)) & UINT64_C(255)) : v3956);
        uint64_t v4106 = (v4098 ? UINT64_C(39) : v4007);
        uint64_t v4107 = (v4098 ? ((uint64_t)((UINT64_C(40) + v4094) & UINT64_C(255))) : v3973);
        uint64_t v4108 = ((v4096 || v4097) ? UINT64_C(1) : ((v4102 || (v4095 && (!v4098))) ? UINT64_C(2) : v4024));
        t4109 = v4106;
    } else {
        t4109 = v4007;
    }
    uint64_t v4110 = t4109;
    uint64_t t4126;
    if (v4025) {
        uint64_t v4111 = ((uint64_t)in_b[UINT64_C(39)]);
        int v4112 = ((v4024 == UINT64_C(0)) && (UINT64_C(39) == v3973));
        int v4113 = (v4112 && (v4111 == UINT64_C(0)));
        int v4114 = ((v4112 && ((v4111 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(40) < ((uint64_t)((uint64_t)in_b_len))));
        int v4115 = (((v4112 && (v4111 != UINT64_C(0))) && (v4111 < UINT64_C(64))) && (((uint64_t)((UINT64_C(39) + v4111) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4118 = ((v4024 == UINT64_C(0)) && (UINT64_C(39) != v3973));
        if (t4118) {
                uint64_t v4116 = v4111;
            int t4117 = (!(((((v4116 | UINT64_C(32)) >= UINT64_C(97)) && ((v4116 | UINT64_C(32)) <= UINT64_C(122))) || ((v4116 >= UINT64_C(48)) && (v4116 <= UINT64_C(57)))) || (v4116 == UINT64_C(45))));
            if (!t4117) {
                t4117 = ((v4111 == UINT64_C(45)) && ((UINT64_C(39) == ((v4007 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(40) == v3973)));
            }
            t4118 = t4117;
        }
        int v4119 = t4118;
        uint64_t v4120 = (v4113 ? UINT64_C(40) : (v4114 ? UINT64_C(41) : v3939));
        uint64_t v4121 = (v4114 ? (((((uint64_t)(v4111 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(40)]))) : v3990);
        uint64_t v4122 = (v4115 ? ((v3956 + UINT64_C(1)) & UINT64_C(255)) : v3956);
        uint64_t v4123 = (v4115 ? UINT64_C(39) : v4007);
        uint64_t v4124 = (v4115 ? ((uint64_t)((UINT64_C(40) + v4111) & UINT64_C(255))) : v3973);
        uint64_t v4125 = ((v4113 || v4114) ? UINT64_C(1) : ((v4119 || (v4112 && (!v4115))) ? UINT64_C(2) : v4024));
        t4126 = v4125;
    } else {
        t4126 = v4024;
    }
    uint64_t v4127 = t4126;
    int v4128 = (UINT64_C(40) < v7);
    uint64_t t4144;
    if (v4128) {
        uint64_t v4129 = ((uint64_t)in_b[UINT64_C(40)]);
        int v4130 = ((v4127 == UINT64_C(0)) && (UINT64_C(40) == v4076));
        int v4131 = (v4130 && (v4129 == UINT64_C(0)));
        int v4132 = ((v4130 && ((v4129 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(41) < ((uint64_t)((uint64_t)in_b_len))));
        int v4133 = (((v4130 && (v4129 != UINT64_C(0))) && (v4129 < UINT64_C(64))) && (((uint64_t)((UINT64_C(40) + v4129) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4136 = ((v4127 == UINT64_C(0)) && (UINT64_C(40) != v4076));
        if (t4136) {
                uint64_t v4134 = v4129;
            int t4135 = (!(((((v4134 | UINT64_C(32)) >= UINT64_C(97)) && ((v4134 | UINT64_C(32)) <= UINT64_C(122))) || ((v4134 >= UINT64_C(48)) && (v4134 <= UINT64_C(57)))) || (v4134 == UINT64_C(45))));
            if (!t4135) {
                t4135 = ((v4129 == UINT64_C(45)) && ((UINT64_C(40) == ((v4110 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(41) == v4076)));
            }
            t4136 = t4135;
        }
        int v4137 = t4136;
        uint64_t v4138 = (v4131 ? UINT64_C(41) : (v4132 ? UINT64_C(42) : v4042));
        uint64_t v4139 = (v4132 ? (((((uint64_t)(v4129 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(41)]))) : v4093);
        uint64_t v4140 = (v4133 ? ((v4059 + UINT64_C(1)) & UINT64_C(255)) : v4059);
        uint64_t v4141 = (v4133 ? UINT64_C(40) : v4110);
        uint64_t v4142 = (v4133 ? ((uint64_t)((UINT64_C(41) + v4129) & UINT64_C(255))) : v4076);
        uint64_t v4143 = ((v4131 || v4132) ? UINT64_C(1) : ((v4137 || (v4130 && (!v4133))) ? UINT64_C(2) : v4127));
        t4144 = v4138;
    } else {
        t4144 = v4042;
    }
    uint64_t v4145 = t4144;
    uint64_t t4161;
    if (v4128) {
        uint64_t v4146 = ((uint64_t)in_b[UINT64_C(40)]);
        int v4147 = ((v4127 == UINT64_C(0)) && (UINT64_C(40) == v4076));
        int v4148 = (v4147 && (v4146 == UINT64_C(0)));
        int v4149 = ((v4147 && ((v4146 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(41) < ((uint64_t)((uint64_t)in_b_len))));
        int v4150 = (((v4147 && (v4146 != UINT64_C(0))) && (v4146 < UINT64_C(64))) && (((uint64_t)((UINT64_C(40) + v4146) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4153 = ((v4127 == UINT64_C(0)) && (UINT64_C(40) != v4076));
        if (t4153) {
                uint64_t v4151 = v4146;
            int t4152 = (!(((((v4151 | UINT64_C(32)) >= UINT64_C(97)) && ((v4151 | UINT64_C(32)) <= UINT64_C(122))) || ((v4151 >= UINT64_C(48)) && (v4151 <= UINT64_C(57)))) || (v4151 == UINT64_C(45))));
            if (!t4152) {
                t4152 = ((v4146 == UINT64_C(45)) && ((UINT64_C(40) == ((v4110 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(41) == v4076)));
            }
            t4153 = t4152;
        }
        int v4154 = t4153;
        uint64_t v4155 = (v4148 ? UINT64_C(41) : (v4149 ? UINT64_C(42) : v4042));
        uint64_t v4156 = (v4149 ? (((((uint64_t)(v4146 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(41)]))) : v4093);
        uint64_t v4157 = (v4150 ? ((v4059 + UINT64_C(1)) & UINT64_C(255)) : v4059);
        uint64_t v4158 = (v4150 ? UINT64_C(40) : v4110);
        uint64_t v4159 = (v4150 ? ((uint64_t)((UINT64_C(41) + v4146) & UINT64_C(255))) : v4076);
        uint64_t v4160 = ((v4148 || v4149) ? UINT64_C(1) : ((v4154 || (v4147 && (!v4150))) ? UINT64_C(2) : v4127));
        t4161 = v4157;
    } else {
        t4161 = v4059;
    }
    uint64_t v4162 = t4161;
    uint64_t t4178;
    if (v4128) {
        uint64_t v4163 = ((uint64_t)in_b[UINT64_C(40)]);
        int v4164 = ((v4127 == UINT64_C(0)) && (UINT64_C(40) == v4076));
        int v4165 = (v4164 && (v4163 == UINT64_C(0)));
        int v4166 = ((v4164 && ((v4163 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(41) < ((uint64_t)((uint64_t)in_b_len))));
        int v4167 = (((v4164 && (v4163 != UINT64_C(0))) && (v4163 < UINT64_C(64))) && (((uint64_t)((UINT64_C(40) + v4163) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4170 = ((v4127 == UINT64_C(0)) && (UINT64_C(40) != v4076));
        if (t4170) {
                uint64_t v4168 = v4163;
            int t4169 = (!(((((v4168 | UINT64_C(32)) >= UINT64_C(97)) && ((v4168 | UINT64_C(32)) <= UINT64_C(122))) || ((v4168 >= UINT64_C(48)) && (v4168 <= UINT64_C(57)))) || (v4168 == UINT64_C(45))));
            if (!t4169) {
                t4169 = ((v4163 == UINT64_C(45)) && ((UINT64_C(40) == ((v4110 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(41) == v4076)));
            }
            t4170 = t4169;
        }
        int v4171 = t4170;
        uint64_t v4172 = (v4165 ? UINT64_C(41) : (v4166 ? UINT64_C(42) : v4042));
        uint64_t v4173 = (v4166 ? (((((uint64_t)(v4163 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(41)]))) : v4093);
        uint64_t v4174 = (v4167 ? ((v4059 + UINT64_C(1)) & UINT64_C(255)) : v4059);
        uint64_t v4175 = (v4167 ? UINT64_C(40) : v4110);
        uint64_t v4176 = (v4167 ? ((uint64_t)((UINT64_C(41) + v4163) & UINT64_C(255))) : v4076);
        uint64_t v4177 = ((v4165 || v4166) ? UINT64_C(1) : ((v4171 || (v4164 && (!v4167))) ? UINT64_C(2) : v4127));
        t4178 = v4176;
    } else {
        t4178 = v4076;
    }
    uint64_t v4179 = t4178;
    uint64_t t4195;
    if (v4128) {
        uint64_t v4180 = ((uint64_t)in_b[UINT64_C(40)]);
        int v4181 = ((v4127 == UINT64_C(0)) && (UINT64_C(40) == v4076));
        int v4182 = (v4181 && (v4180 == UINT64_C(0)));
        int v4183 = ((v4181 && ((v4180 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(41) < ((uint64_t)((uint64_t)in_b_len))));
        int v4184 = (((v4181 && (v4180 != UINT64_C(0))) && (v4180 < UINT64_C(64))) && (((uint64_t)((UINT64_C(40) + v4180) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4187 = ((v4127 == UINT64_C(0)) && (UINT64_C(40) != v4076));
        if (t4187) {
                uint64_t v4185 = v4180;
            int t4186 = (!(((((v4185 | UINT64_C(32)) >= UINT64_C(97)) && ((v4185 | UINT64_C(32)) <= UINT64_C(122))) || ((v4185 >= UINT64_C(48)) && (v4185 <= UINT64_C(57)))) || (v4185 == UINT64_C(45))));
            if (!t4186) {
                t4186 = ((v4180 == UINT64_C(45)) && ((UINT64_C(40) == ((v4110 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(41) == v4076)));
            }
            t4187 = t4186;
        }
        int v4188 = t4187;
        uint64_t v4189 = (v4182 ? UINT64_C(41) : (v4183 ? UINT64_C(42) : v4042));
        uint64_t v4190 = (v4183 ? (((((uint64_t)(v4180 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(41)]))) : v4093);
        uint64_t v4191 = (v4184 ? ((v4059 + UINT64_C(1)) & UINT64_C(255)) : v4059);
        uint64_t v4192 = (v4184 ? UINT64_C(40) : v4110);
        uint64_t v4193 = (v4184 ? ((uint64_t)((UINT64_C(41) + v4180) & UINT64_C(255))) : v4076);
        uint64_t v4194 = ((v4182 || v4183) ? UINT64_C(1) : ((v4188 || (v4181 && (!v4184))) ? UINT64_C(2) : v4127));
        t4195 = v4190;
    } else {
        t4195 = v4093;
    }
    uint64_t v4196 = t4195;
    uint64_t t4212;
    if (v4128) {
        uint64_t v4197 = ((uint64_t)in_b[UINT64_C(40)]);
        int v4198 = ((v4127 == UINT64_C(0)) && (UINT64_C(40) == v4076));
        int v4199 = (v4198 && (v4197 == UINT64_C(0)));
        int v4200 = ((v4198 && ((v4197 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(41) < ((uint64_t)((uint64_t)in_b_len))));
        int v4201 = (((v4198 && (v4197 != UINT64_C(0))) && (v4197 < UINT64_C(64))) && (((uint64_t)((UINT64_C(40) + v4197) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4204 = ((v4127 == UINT64_C(0)) && (UINT64_C(40) != v4076));
        if (t4204) {
                uint64_t v4202 = v4197;
            int t4203 = (!(((((v4202 | UINT64_C(32)) >= UINT64_C(97)) && ((v4202 | UINT64_C(32)) <= UINT64_C(122))) || ((v4202 >= UINT64_C(48)) && (v4202 <= UINT64_C(57)))) || (v4202 == UINT64_C(45))));
            if (!t4203) {
                t4203 = ((v4197 == UINT64_C(45)) && ((UINT64_C(40) == ((v4110 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(41) == v4076)));
            }
            t4204 = t4203;
        }
        int v4205 = t4204;
        uint64_t v4206 = (v4199 ? UINT64_C(41) : (v4200 ? UINT64_C(42) : v4042));
        uint64_t v4207 = (v4200 ? (((((uint64_t)(v4197 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(41)]))) : v4093);
        uint64_t v4208 = (v4201 ? ((v4059 + UINT64_C(1)) & UINT64_C(255)) : v4059);
        uint64_t v4209 = (v4201 ? UINT64_C(40) : v4110);
        uint64_t v4210 = (v4201 ? ((uint64_t)((UINT64_C(41) + v4197) & UINT64_C(255))) : v4076);
        uint64_t v4211 = ((v4199 || v4200) ? UINT64_C(1) : ((v4205 || (v4198 && (!v4201))) ? UINT64_C(2) : v4127));
        t4212 = v4209;
    } else {
        t4212 = v4110;
    }
    uint64_t v4213 = t4212;
    uint64_t t4229;
    if (v4128) {
        uint64_t v4214 = ((uint64_t)in_b[UINT64_C(40)]);
        int v4215 = ((v4127 == UINT64_C(0)) && (UINT64_C(40) == v4076));
        int v4216 = (v4215 && (v4214 == UINT64_C(0)));
        int v4217 = ((v4215 && ((v4214 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(41) < ((uint64_t)((uint64_t)in_b_len))));
        int v4218 = (((v4215 && (v4214 != UINT64_C(0))) && (v4214 < UINT64_C(64))) && (((uint64_t)((UINT64_C(40) + v4214) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4221 = ((v4127 == UINT64_C(0)) && (UINT64_C(40) != v4076));
        if (t4221) {
                uint64_t v4219 = v4214;
            int t4220 = (!(((((v4219 | UINT64_C(32)) >= UINT64_C(97)) && ((v4219 | UINT64_C(32)) <= UINT64_C(122))) || ((v4219 >= UINT64_C(48)) && (v4219 <= UINT64_C(57)))) || (v4219 == UINT64_C(45))));
            if (!t4220) {
                t4220 = ((v4214 == UINT64_C(45)) && ((UINT64_C(40) == ((v4110 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(41) == v4076)));
            }
            t4221 = t4220;
        }
        int v4222 = t4221;
        uint64_t v4223 = (v4216 ? UINT64_C(41) : (v4217 ? UINT64_C(42) : v4042));
        uint64_t v4224 = (v4217 ? (((((uint64_t)(v4214 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(41)]))) : v4093);
        uint64_t v4225 = (v4218 ? ((v4059 + UINT64_C(1)) & UINT64_C(255)) : v4059);
        uint64_t v4226 = (v4218 ? UINT64_C(40) : v4110);
        uint64_t v4227 = (v4218 ? ((uint64_t)((UINT64_C(41) + v4214) & UINT64_C(255))) : v4076);
        uint64_t v4228 = ((v4216 || v4217) ? UINT64_C(1) : ((v4222 || (v4215 && (!v4218))) ? UINT64_C(2) : v4127));
        t4229 = v4228;
    } else {
        t4229 = v4127;
    }
    uint64_t v4230 = t4229;
    int v4231 = (UINT64_C(41) < v7);
    uint64_t t4247;
    if (v4231) {
        uint64_t v4232 = ((uint64_t)in_b[UINT64_C(41)]);
        int v4233 = ((v4230 == UINT64_C(0)) && (UINT64_C(41) == v4179));
        int v4234 = (v4233 && (v4232 == UINT64_C(0)));
        int v4235 = ((v4233 && ((v4232 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(42) < ((uint64_t)((uint64_t)in_b_len))));
        int v4236 = (((v4233 && (v4232 != UINT64_C(0))) && (v4232 < UINT64_C(64))) && (((uint64_t)((UINT64_C(41) + v4232) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4239 = ((v4230 == UINT64_C(0)) && (UINT64_C(41) != v4179));
        if (t4239) {
                uint64_t v4237 = v4232;
            int t4238 = (!(((((v4237 | UINT64_C(32)) >= UINT64_C(97)) && ((v4237 | UINT64_C(32)) <= UINT64_C(122))) || ((v4237 >= UINT64_C(48)) && (v4237 <= UINT64_C(57)))) || (v4237 == UINT64_C(45))));
            if (!t4238) {
                t4238 = ((v4232 == UINT64_C(45)) && ((UINT64_C(41) == ((v4213 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(42) == v4179)));
            }
            t4239 = t4238;
        }
        int v4240 = t4239;
        uint64_t v4241 = (v4234 ? UINT64_C(42) : (v4235 ? UINT64_C(43) : v4145));
        uint64_t v4242 = (v4235 ? (((((uint64_t)(v4232 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(42)]))) : v4196);
        uint64_t v4243 = (v4236 ? ((v4162 + UINT64_C(1)) & UINT64_C(255)) : v4162);
        uint64_t v4244 = (v4236 ? UINT64_C(41) : v4213);
        uint64_t v4245 = (v4236 ? ((uint64_t)((UINT64_C(42) + v4232) & UINT64_C(255))) : v4179);
        uint64_t v4246 = ((v4234 || v4235) ? UINT64_C(1) : ((v4240 || (v4233 && (!v4236))) ? UINT64_C(2) : v4230));
        t4247 = v4241;
    } else {
        t4247 = v4145;
    }
    uint64_t v4248 = t4247;
    uint64_t t4264;
    if (v4231) {
        uint64_t v4249 = ((uint64_t)in_b[UINT64_C(41)]);
        int v4250 = ((v4230 == UINT64_C(0)) && (UINT64_C(41) == v4179));
        int v4251 = (v4250 && (v4249 == UINT64_C(0)));
        int v4252 = ((v4250 && ((v4249 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(42) < ((uint64_t)((uint64_t)in_b_len))));
        int v4253 = (((v4250 && (v4249 != UINT64_C(0))) && (v4249 < UINT64_C(64))) && (((uint64_t)((UINT64_C(41) + v4249) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4256 = ((v4230 == UINT64_C(0)) && (UINT64_C(41) != v4179));
        if (t4256) {
                uint64_t v4254 = v4249;
            int t4255 = (!(((((v4254 | UINT64_C(32)) >= UINT64_C(97)) && ((v4254 | UINT64_C(32)) <= UINT64_C(122))) || ((v4254 >= UINT64_C(48)) && (v4254 <= UINT64_C(57)))) || (v4254 == UINT64_C(45))));
            if (!t4255) {
                t4255 = ((v4249 == UINT64_C(45)) && ((UINT64_C(41) == ((v4213 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(42) == v4179)));
            }
            t4256 = t4255;
        }
        int v4257 = t4256;
        uint64_t v4258 = (v4251 ? UINT64_C(42) : (v4252 ? UINT64_C(43) : v4145));
        uint64_t v4259 = (v4252 ? (((((uint64_t)(v4249 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(42)]))) : v4196);
        uint64_t v4260 = (v4253 ? ((v4162 + UINT64_C(1)) & UINT64_C(255)) : v4162);
        uint64_t v4261 = (v4253 ? UINT64_C(41) : v4213);
        uint64_t v4262 = (v4253 ? ((uint64_t)((UINT64_C(42) + v4249) & UINT64_C(255))) : v4179);
        uint64_t v4263 = ((v4251 || v4252) ? UINT64_C(1) : ((v4257 || (v4250 && (!v4253))) ? UINT64_C(2) : v4230));
        t4264 = v4260;
    } else {
        t4264 = v4162;
    }
    uint64_t v4265 = t4264;
    uint64_t t4281;
    if (v4231) {
        uint64_t v4266 = ((uint64_t)in_b[UINT64_C(41)]);
        int v4267 = ((v4230 == UINT64_C(0)) && (UINT64_C(41) == v4179));
        int v4268 = (v4267 && (v4266 == UINT64_C(0)));
        int v4269 = ((v4267 && ((v4266 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(42) < ((uint64_t)((uint64_t)in_b_len))));
        int v4270 = (((v4267 && (v4266 != UINT64_C(0))) && (v4266 < UINT64_C(64))) && (((uint64_t)((UINT64_C(41) + v4266) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4273 = ((v4230 == UINT64_C(0)) && (UINT64_C(41) != v4179));
        if (t4273) {
                uint64_t v4271 = v4266;
            int t4272 = (!(((((v4271 | UINT64_C(32)) >= UINT64_C(97)) && ((v4271 | UINT64_C(32)) <= UINT64_C(122))) || ((v4271 >= UINT64_C(48)) && (v4271 <= UINT64_C(57)))) || (v4271 == UINT64_C(45))));
            if (!t4272) {
                t4272 = ((v4266 == UINT64_C(45)) && ((UINT64_C(41) == ((v4213 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(42) == v4179)));
            }
            t4273 = t4272;
        }
        int v4274 = t4273;
        uint64_t v4275 = (v4268 ? UINT64_C(42) : (v4269 ? UINT64_C(43) : v4145));
        uint64_t v4276 = (v4269 ? (((((uint64_t)(v4266 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(42)]))) : v4196);
        uint64_t v4277 = (v4270 ? ((v4162 + UINT64_C(1)) & UINT64_C(255)) : v4162);
        uint64_t v4278 = (v4270 ? UINT64_C(41) : v4213);
        uint64_t v4279 = (v4270 ? ((uint64_t)((UINT64_C(42) + v4266) & UINT64_C(255))) : v4179);
        uint64_t v4280 = ((v4268 || v4269) ? UINT64_C(1) : ((v4274 || (v4267 && (!v4270))) ? UINT64_C(2) : v4230));
        t4281 = v4279;
    } else {
        t4281 = v4179;
    }
    uint64_t v4282 = t4281;
    uint64_t t4298;
    if (v4231) {
        uint64_t v4283 = ((uint64_t)in_b[UINT64_C(41)]);
        int v4284 = ((v4230 == UINT64_C(0)) && (UINT64_C(41) == v4179));
        int v4285 = (v4284 && (v4283 == UINT64_C(0)));
        int v4286 = ((v4284 && ((v4283 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(42) < ((uint64_t)((uint64_t)in_b_len))));
        int v4287 = (((v4284 && (v4283 != UINT64_C(0))) && (v4283 < UINT64_C(64))) && (((uint64_t)((UINT64_C(41) + v4283) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4290 = ((v4230 == UINT64_C(0)) && (UINT64_C(41) != v4179));
        if (t4290) {
                uint64_t v4288 = v4283;
            int t4289 = (!(((((v4288 | UINT64_C(32)) >= UINT64_C(97)) && ((v4288 | UINT64_C(32)) <= UINT64_C(122))) || ((v4288 >= UINT64_C(48)) && (v4288 <= UINT64_C(57)))) || (v4288 == UINT64_C(45))));
            if (!t4289) {
                t4289 = ((v4283 == UINT64_C(45)) && ((UINT64_C(41) == ((v4213 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(42) == v4179)));
            }
            t4290 = t4289;
        }
        int v4291 = t4290;
        uint64_t v4292 = (v4285 ? UINT64_C(42) : (v4286 ? UINT64_C(43) : v4145));
        uint64_t v4293 = (v4286 ? (((((uint64_t)(v4283 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(42)]))) : v4196);
        uint64_t v4294 = (v4287 ? ((v4162 + UINT64_C(1)) & UINT64_C(255)) : v4162);
        uint64_t v4295 = (v4287 ? UINT64_C(41) : v4213);
        uint64_t v4296 = (v4287 ? ((uint64_t)((UINT64_C(42) + v4283) & UINT64_C(255))) : v4179);
        uint64_t v4297 = ((v4285 || v4286) ? UINT64_C(1) : ((v4291 || (v4284 && (!v4287))) ? UINT64_C(2) : v4230));
        t4298 = v4293;
    } else {
        t4298 = v4196;
    }
    uint64_t v4299 = t4298;
    uint64_t t4315;
    if (v4231) {
        uint64_t v4300 = ((uint64_t)in_b[UINT64_C(41)]);
        int v4301 = ((v4230 == UINT64_C(0)) && (UINT64_C(41) == v4179));
        int v4302 = (v4301 && (v4300 == UINT64_C(0)));
        int v4303 = ((v4301 && ((v4300 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(42) < ((uint64_t)((uint64_t)in_b_len))));
        int v4304 = (((v4301 && (v4300 != UINT64_C(0))) && (v4300 < UINT64_C(64))) && (((uint64_t)((UINT64_C(41) + v4300) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4307 = ((v4230 == UINT64_C(0)) && (UINT64_C(41) != v4179));
        if (t4307) {
                uint64_t v4305 = v4300;
            int t4306 = (!(((((v4305 | UINT64_C(32)) >= UINT64_C(97)) && ((v4305 | UINT64_C(32)) <= UINT64_C(122))) || ((v4305 >= UINT64_C(48)) && (v4305 <= UINT64_C(57)))) || (v4305 == UINT64_C(45))));
            if (!t4306) {
                t4306 = ((v4300 == UINT64_C(45)) && ((UINT64_C(41) == ((v4213 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(42) == v4179)));
            }
            t4307 = t4306;
        }
        int v4308 = t4307;
        uint64_t v4309 = (v4302 ? UINT64_C(42) : (v4303 ? UINT64_C(43) : v4145));
        uint64_t v4310 = (v4303 ? (((((uint64_t)(v4300 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(42)]))) : v4196);
        uint64_t v4311 = (v4304 ? ((v4162 + UINT64_C(1)) & UINT64_C(255)) : v4162);
        uint64_t v4312 = (v4304 ? UINT64_C(41) : v4213);
        uint64_t v4313 = (v4304 ? ((uint64_t)((UINT64_C(42) + v4300) & UINT64_C(255))) : v4179);
        uint64_t v4314 = ((v4302 || v4303) ? UINT64_C(1) : ((v4308 || (v4301 && (!v4304))) ? UINT64_C(2) : v4230));
        t4315 = v4312;
    } else {
        t4315 = v4213;
    }
    uint64_t v4316 = t4315;
    uint64_t t4332;
    if (v4231) {
        uint64_t v4317 = ((uint64_t)in_b[UINT64_C(41)]);
        int v4318 = ((v4230 == UINT64_C(0)) && (UINT64_C(41) == v4179));
        int v4319 = (v4318 && (v4317 == UINT64_C(0)));
        int v4320 = ((v4318 && ((v4317 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(42) < ((uint64_t)((uint64_t)in_b_len))));
        int v4321 = (((v4318 && (v4317 != UINT64_C(0))) && (v4317 < UINT64_C(64))) && (((uint64_t)((UINT64_C(41) + v4317) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4324 = ((v4230 == UINT64_C(0)) && (UINT64_C(41) != v4179));
        if (t4324) {
                uint64_t v4322 = v4317;
            int t4323 = (!(((((v4322 | UINT64_C(32)) >= UINT64_C(97)) && ((v4322 | UINT64_C(32)) <= UINT64_C(122))) || ((v4322 >= UINT64_C(48)) && (v4322 <= UINT64_C(57)))) || (v4322 == UINT64_C(45))));
            if (!t4323) {
                t4323 = ((v4317 == UINT64_C(45)) && ((UINT64_C(41) == ((v4213 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(42) == v4179)));
            }
            t4324 = t4323;
        }
        int v4325 = t4324;
        uint64_t v4326 = (v4319 ? UINT64_C(42) : (v4320 ? UINT64_C(43) : v4145));
        uint64_t v4327 = (v4320 ? (((((uint64_t)(v4317 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(42)]))) : v4196);
        uint64_t v4328 = (v4321 ? ((v4162 + UINT64_C(1)) & UINT64_C(255)) : v4162);
        uint64_t v4329 = (v4321 ? UINT64_C(41) : v4213);
        uint64_t v4330 = (v4321 ? ((uint64_t)((UINT64_C(42) + v4317) & UINT64_C(255))) : v4179);
        uint64_t v4331 = ((v4319 || v4320) ? UINT64_C(1) : ((v4325 || (v4318 && (!v4321))) ? UINT64_C(2) : v4230));
        t4332 = v4331;
    } else {
        t4332 = v4230;
    }
    uint64_t v4333 = t4332;
    int v4334 = (UINT64_C(42) < v7);
    uint64_t t4350;
    if (v4334) {
        uint64_t v4335 = ((uint64_t)in_b[UINT64_C(42)]);
        int v4336 = ((v4333 == UINT64_C(0)) && (UINT64_C(42) == v4282));
        int v4337 = (v4336 && (v4335 == UINT64_C(0)));
        int v4338 = ((v4336 && ((v4335 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(43) < ((uint64_t)((uint64_t)in_b_len))));
        int v4339 = (((v4336 && (v4335 != UINT64_C(0))) && (v4335 < UINT64_C(64))) && (((uint64_t)((UINT64_C(42) + v4335) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4342 = ((v4333 == UINT64_C(0)) && (UINT64_C(42) != v4282));
        if (t4342) {
                uint64_t v4340 = v4335;
            int t4341 = (!(((((v4340 | UINT64_C(32)) >= UINT64_C(97)) && ((v4340 | UINT64_C(32)) <= UINT64_C(122))) || ((v4340 >= UINT64_C(48)) && (v4340 <= UINT64_C(57)))) || (v4340 == UINT64_C(45))));
            if (!t4341) {
                t4341 = ((v4335 == UINT64_C(45)) && ((UINT64_C(42) == ((v4316 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(43) == v4282)));
            }
            t4342 = t4341;
        }
        int v4343 = t4342;
        uint64_t v4344 = (v4337 ? UINT64_C(43) : (v4338 ? UINT64_C(44) : v4248));
        uint64_t v4345 = (v4338 ? (((((uint64_t)(v4335 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(43)]))) : v4299);
        uint64_t v4346 = (v4339 ? ((v4265 + UINT64_C(1)) & UINT64_C(255)) : v4265);
        uint64_t v4347 = (v4339 ? UINT64_C(42) : v4316);
        uint64_t v4348 = (v4339 ? ((uint64_t)((UINT64_C(43) + v4335) & UINT64_C(255))) : v4282);
        uint64_t v4349 = ((v4337 || v4338) ? UINT64_C(1) : ((v4343 || (v4336 && (!v4339))) ? UINT64_C(2) : v4333));
        t4350 = v4344;
    } else {
        t4350 = v4248;
    }
    uint64_t v4351 = t4350;
    uint64_t t4367;
    if (v4334) {
        uint64_t v4352 = ((uint64_t)in_b[UINT64_C(42)]);
        int v4353 = ((v4333 == UINT64_C(0)) && (UINT64_C(42) == v4282));
        int v4354 = (v4353 && (v4352 == UINT64_C(0)));
        int v4355 = ((v4353 && ((v4352 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(43) < ((uint64_t)((uint64_t)in_b_len))));
        int v4356 = (((v4353 && (v4352 != UINT64_C(0))) && (v4352 < UINT64_C(64))) && (((uint64_t)((UINT64_C(42) + v4352) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4359 = ((v4333 == UINT64_C(0)) && (UINT64_C(42) != v4282));
        if (t4359) {
                uint64_t v4357 = v4352;
            int t4358 = (!(((((v4357 | UINT64_C(32)) >= UINT64_C(97)) && ((v4357 | UINT64_C(32)) <= UINT64_C(122))) || ((v4357 >= UINT64_C(48)) && (v4357 <= UINT64_C(57)))) || (v4357 == UINT64_C(45))));
            if (!t4358) {
                t4358 = ((v4352 == UINT64_C(45)) && ((UINT64_C(42) == ((v4316 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(43) == v4282)));
            }
            t4359 = t4358;
        }
        int v4360 = t4359;
        uint64_t v4361 = (v4354 ? UINT64_C(43) : (v4355 ? UINT64_C(44) : v4248));
        uint64_t v4362 = (v4355 ? (((((uint64_t)(v4352 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(43)]))) : v4299);
        uint64_t v4363 = (v4356 ? ((v4265 + UINT64_C(1)) & UINT64_C(255)) : v4265);
        uint64_t v4364 = (v4356 ? UINT64_C(42) : v4316);
        uint64_t v4365 = (v4356 ? ((uint64_t)((UINT64_C(43) + v4352) & UINT64_C(255))) : v4282);
        uint64_t v4366 = ((v4354 || v4355) ? UINT64_C(1) : ((v4360 || (v4353 && (!v4356))) ? UINT64_C(2) : v4333));
        t4367 = v4363;
    } else {
        t4367 = v4265;
    }
    uint64_t v4368 = t4367;
    uint64_t t4384;
    if (v4334) {
        uint64_t v4369 = ((uint64_t)in_b[UINT64_C(42)]);
        int v4370 = ((v4333 == UINT64_C(0)) && (UINT64_C(42) == v4282));
        int v4371 = (v4370 && (v4369 == UINT64_C(0)));
        int v4372 = ((v4370 && ((v4369 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(43) < ((uint64_t)((uint64_t)in_b_len))));
        int v4373 = (((v4370 && (v4369 != UINT64_C(0))) && (v4369 < UINT64_C(64))) && (((uint64_t)((UINT64_C(42) + v4369) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4376 = ((v4333 == UINT64_C(0)) && (UINT64_C(42) != v4282));
        if (t4376) {
                uint64_t v4374 = v4369;
            int t4375 = (!(((((v4374 | UINT64_C(32)) >= UINT64_C(97)) && ((v4374 | UINT64_C(32)) <= UINT64_C(122))) || ((v4374 >= UINT64_C(48)) && (v4374 <= UINT64_C(57)))) || (v4374 == UINT64_C(45))));
            if (!t4375) {
                t4375 = ((v4369 == UINT64_C(45)) && ((UINT64_C(42) == ((v4316 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(43) == v4282)));
            }
            t4376 = t4375;
        }
        int v4377 = t4376;
        uint64_t v4378 = (v4371 ? UINT64_C(43) : (v4372 ? UINT64_C(44) : v4248));
        uint64_t v4379 = (v4372 ? (((((uint64_t)(v4369 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(43)]))) : v4299);
        uint64_t v4380 = (v4373 ? ((v4265 + UINT64_C(1)) & UINT64_C(255)) : v4265);
        uint64_t v4381 = (v4373 ? UINT64_C(42) : v4316);
        uint64_t v4382 = (v4373 ? ((uint64_t)((UINT64_C(43) + v4369) & UINT64_C(255))) : v4282);
        uint64_t v4383 = ((v4371 || v4372) ? UINT64_C(1) : ((v4377 || (v4370 && (!v4373))) ? UINT64_C(2) : v4333));
        t4384 = v4382;
    } else {
        t4384 = v4282;
    }
    uint64_t v4385 = t4384;
    uint64_t t4401;
    if (v4334) {
        uint64_t v4386 = ((uint64_t)in_b[UINT64_C(42)]);
        int v4387 = ((v4333 == UINT64_C(0)) && (UINT64_C(42) == v4282));
        int v4388 = (v4387 && (v4386 == UINT64_C(0)));
        int v4389 = ((v4387 && ((v4386 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(43) < ((uint64_t)((uint64_t)in_b_len))));
        int v4390 = (((v4387 && (v4386 != UINT64_C(0))) && (v4386 < UINT64_C(64))) && (((uint64_t)((UINT64_C(42) + v4386) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4393 = ((v4333 == UINT64_C(0)) && (UINT64_C(42) != v4282));
        if (t4393) {
                uint64_t v4391 = v4386;
            int t4392 = (!(((((v4391 | UINT64_C(32)) >= UINT64_C(97)) && ((v4391 | UINT64_C(32)) <= UINT64_C(122))) || ((v4391 >= UINT64_C(48)) && (v4391 <= UINT64_C(57)))) || (v4391 == UINT64_C(45))));
            if (!t4392) {
                t4392 = ((v4386 == UINT64_C(45)) && ((UINT64_C(42) == ((v4316 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(43) == v4282)));
            }
            t4393 = t4392;
        }
        int v4394 = t4393;
        uint64_t v4395 = (v4388 ? UINT64_C(43) : (v4389 ? UINT64_C(44) : v4248));
        uint64_t v4396 = (v4389 ? (((((uint64_t)(v4386 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(43)]))) : v4299);
        uint64_t v4397 = (v4390 ? ((v4265 + UINT64_C(1)) & UINT64_C(255)) : v4265);
        uint64_t v4398 = (v4390 ? UINT64_C(42) : v4316);
        uint64_t v4399 = (v4390 ? ((uint64_t)((UINT64_C(43) + v4386) & UINT64_C(255))) : v4282);
        uint64_t v4400 = ((v4388 || v4389) ? UINT64_C(1) : ((v4394 || (v4387 && (!v4390))) ? UINT64_C(2) : v4333));
        t4401 = v4396;
    } else {
        t4401 = v4299;
    }
    uint64_t v4402 = t4401;
    uint64_t t4418;
    if (v4334) {
        uint64_t v4403 = ((uint64_t)in_b[UINT64_C(42)]);
        int v4404 = ((v4333 == UINT64_C(0)) && (UINT64_C(42) == v4282));
        int v4405 = (v4404 && (v4403 == UINT64_C(0)));
        int v4406 = ((v4404 && ((v4403 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(43) < ((uint64_t)((uint64_t)in_b_len))));
        int v4407 = (((v4404 && (v4403 != UINT64_C(0))) && (v4403 < UINT64_C(64))) && (((uint64_t)((UINT64_C(42) + v4403) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4410 = ((v4333 == UINT64_C(0)) && (UINT64_C(42) != v4282));
        if (t4410) {
                uint64_t v4408 = v4403;
            int t4409 = (!(((((v4408 | UINT64_C(32)) >= UINT64_C(97)) && ((v4408 | UINT64_C(32)) <= UINT64_C(122))) || ((v4408 >= UINT64_C(48)) && (v4408 <= UINT64_C(57)))) || (v4408 == UINT64_C(45))));
            if (!t4409) {
                t4409 = ((v4403 == UINT64_C(45)) && ((UINT64_C(42) == ((v4316 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(43) == v4282)));
            }
            t4410 = t4409;
        }
        int v4411 = t4410;
        uint64_t v4412 = (v4405 ? UINT64_C(43) : (v4406 ? UINT64_C(44) : v4248));
        uint64_t v4413 = (v4406 ? (((((uint64_t)(v4403 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(43)]))) : v4299);
        uint64_t v4414 = (v4407 ? ((v4265 + UINT64_C(1)) & UINT64_C(255)) : v4265);
        uint64_t v4415 = (v4407 ? UINT64_C(42) : v4316);
        uint64_t v4416 = (v4407 ? ((uint64_t)((UINT64_C(43) + v4403) & UINT64_C(255))) : v4282);
        uint64_t v4417 = ((v4405 || v4406) ? UINT64_C(1) : ((v4411 || (v4404 && (!v4407))) ? UINT64_C(2) : v4333));
        t4418 = v4415;
    } else {
        t4418 = v4316;
    }
    uint64_t v4419 = t4418;
    uint64_t t4435;
    if (v4334) {
        uint64_t v4420 = ((uint64_t)in_b[UINT64_C(42)]);
        int v4421 = ((v4333 == UINT64_C(0)) && (UINT64_C(42) == v4282));
        int v4422 = (v4421 && (v4420 == UINT64_C(0)));
        int v4423 = ((v4421 && ((v4420 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(43) < ((uint64_t)((uint64_t)in_b_len))));
        int v4424 = (((v4421 && (v4420 != UINT64_C(0))) && (v4420 < UINT64_C(64))) && (((uint64_t)((UINT64_C(42) + v4420) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4427 = ((v4333 == UINT64_C(0)) && (UINT64_C(42) != v4282));
        if (t4427) {
                uint64_t v4425 = v4420;
            int t4426 = (!(((((v4425 | UINT64_C(32)) >= UINT64_C(97)) && ((v4425 | UINT64_C(32)) <= UINT64_C(122))) || ((v4425 >= UINT64_C(48)) && (v4425 <= UINT64_C(57)))) || (v4425 == UINT64_C(45))));
            if (!t4426) {
                t4426 = ((v4420 == UINT64_C(45)) && ((UINT64_C(42) == ((v4316 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(43) == v4282)));
            }
            t4427 = t4426;
        }
        int v4428 = t4427;
        uint64_t v4429 = (v4422 ? UINT64_C(43) : (v4423 ? UINT64_C(44) : v4248));
        uint64_t v4430 = (v4423 ? (((((uint64_t)(v4420 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(43)]))) : v4299);
        uint64_t v4431 = (v4424 ? ((v4265 + UINT64_C(1)) & UINT64_C(255)) : v4265);
        uint64_t v4432 = (v4424 ? UINT64_C(42) : v4316);
        uint64_t v4433 = (v4424 ? ((uint64_t)((UINT64_C(43) + v4420) & UINT64_C(255))) : v4282);
        uint64_t v4434 = ((v4422 || v4423) ? UINT64_C(1) : ((v4428 || (v4421 && (!v4424))) ? UINT64_C(2) : v4333));
        t4435 = v4434;
    } else {
        t4435 = v4333;
    }
    uint64_t v4436 = t4435;
    int v4437 = (UINT64_C(43) < v7);
    uint64_t t4453;
    if (v4437) {
        uint64_t v4438 = ((uint64_t)in_b[UINT64_C(43)]);
        int v4439 = ((v4436 == UINT64_C(0)) && (UINT64_C(43) == v4385));
        int v4440 = (v4439 && (v4438 == UINT64_C(0)));
        int v4441 = ((v4439 && ((v4438 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(44) < ((uint64_t)((uint64_t)in_b_len))));
        int v4442 = (((v4439 && (v4438 != UINT64_C(0))) && (v4438 < UINT64_C(64))) && (((uint64_t)((UINT64_C(43) + v4438) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4445 = ((v4436 == UINT64_C(0)) && (UINT64_C(43) != v4385));
        if (t4445) {
                uint64_t v4443 = v4438;
            int t4444 = (!(((((v4443 | UINT64_C(32)) >= UINT64_C(97)) && ((v4443 | UINT64_C(32)) <= UINT64_C(122))) || ((v4443 >= UINT64_C(48)) && (v4443 <= UINT64_C(57)))) || (v4443 == UINT64_C(45))));
            if (!t4444) {
                t4444 = ((v4438 == UINT64_C(45)) && ((UINT64_C(43) == ((v4419 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(44) == v4385)));
            }
            t4445 = t4444;
        }
        int v4446 = t4445;
        uint64_t v4447 = (v4440 ? UINT64_C(44) : (v4441 ? UINT64_C(45) : v4351));
        uint64_t v4448 = (v4441 ? (((((uint64_t)(v4438 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(44)]))) : v4402);
        uint64_t v4449 = (v4442 ? ((v4368 + UINT64_C(1)) & UINT64_C(255)) : v4368);
        uint64_t v4450 = (v4442 ? UINT64_C(43) : v4419);
        uint64_t v4451 = (v4442 ? ((uint64_t)((UINT64_C(44) + v4438) & UINT64_C(255))) : v4385);
        uint64_t v4452 = ((v4440 || v4441) ? UINT64_C(1) : ((v4446 || (v4439 && (!v4442))) ? UINT64_C(2) : v4436));
        t4453 = v4447;
    } else {
        t4453 = v4351;
    }
    uint64_t v4454 = t4453;
    uint64_t t4470;
    if (v4437) {
        uint64_t v4455 = ((uint64_t)in_b[UINT64_C(43)]);
        int v4456 = ((v4436 == UINT64_C(0)) && (UINT64_C(43) == v4385));
        int v4457 = (v4456 && (v4455 == UINT64_C(0)));
        int v4458 = ((v4456 && ((v4455 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(44) < ((uint64_t)((uint64_t)in_b_len))));
        int v4459 = (((v4456 && (v4455 != UINT64_C(0))) && (v4455 < UINT64_C(64))) && (((uint64_t)((UINT64_C(43) + v4455) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4462 = ((v4436 == UINT64_C(0)) && (UINT64_C(43) != v4385));
        if (t4462) {
                uint64_t v4460 = v4455;
            int t4461 = (!(((((v4460 | UINT64_C(32)) >= UINT64_C(97)) && ((v4460 | UINT64_C(32)) <= UINT64_C(122))) || ((v4460 >= UINT64_C(48)) && (v4460 <= UINT64_C(57)))) || (v4460 == UINT64_C(45))));
            if (!t4461) {
                t4461 = ((v4455 == UINT64_C(45)) && ((UINT64_C(43) == ((v4419 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(44) == v4385)));
            }
            t4462 = t4461;
        }
        int v4463 = t4462;
        uint64_t v4464 = (v4457 ? UINT64_C(44) : (v4458 ? UINT64_C(45) : v4351));
        uint64_t v4465 = (v4458 ? (((((uint64_t)(v4455 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(44)]))) : v4402);
        uint64_t v4466 = (v4459 ? ((v4368 + UINT64_C(1)) & UINT64_C(255)) : v4368);
        uint64_t v4467 = (v4459 ? UINT64_C(43) : v4419);
        uint64_t v4468 = (v4459 ? ((uint64_t)((UINT64_C(44) + v4455) & UINT64_C(255))) : v4385);
        uint64_t v4469 = ((v4457 || v4458) ? UINT64_C(1) : ((v4463 || (v4456 && (!v4459))) ? UINT64_C(2) : v4436));
        t4470 = v4466;
    } else {
        t4470 = v4368;
    }
    uint64_t v4471 = t4470;
    uint64_t t4487;
    if (v4437) {
        uint64_t v4472 = ((uint64_t)in_b[UINT64_C(43)]);
        int v4473 = ((v4436 == UINT64_C(0)) && (UINT64_C(43) == v4385));
        int v4474 = (v4473 && (v4472 == UINT64_C(0)));
        int v4475 = ((v4473 && ((v4472 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(44) < ((uint64_t)((uint64_t)in_b_len))));
        int v4476 = (((v4473 && (v4472 != UINT64_C(0))) && (v4472 < UINT64_C(64))) && (((uint64_t)((UINT64_C(43) + v4472) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4479 = ((v4436 == UINT64_C(0)) && (UINT64_C(43) != v4385));
        if (t4479) {
                uint64_t v4477 = v4472;
            int t4478 = (!(((((v4477 | UINT64_C(32)) >= UINT64_C(97)) && ((v4477 | UINT64_C(32)) <= UINT64_C(122))) || ((v4477 >= UINT64_C(48)) && (v4477 <= UINT64_C(57)))) || (v4477 == UINT64_C(45))));
            if (!t4478) {
                t4478 = ((v4472 == UINT64_C(45)) && ((UINT64_C(43) == ((v4419 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(44) == v4385)));
            }
            t4479 = t4478;
        }
        int v4480 = t4479;
        uint64_t v4481 = (v4474 ? UINT64_C(44) : (v4475 ? UINT64_C(45) : v4351));
        uint64_t v4482 = (v4475 ? (((((uint64_t)(v4472 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(44)]))) : v4402);
        uint64_t v4483 = (v4476 ? ((v4368 + UINT64_C(1)) & UINT64_C(255)) : v4368);
        uint64_t v4484 = (v4476 ? UINT64_C(43) : v4419);
        uint64_t v4485 = (v4476 ? ((uint64_t)((UINT64_C(44) + v4472) & UINT64_C(255))) : v4385);
        uint64_t v4486 = ((v4474 || v4475) ? UINT64_C(1) : ((v4480 || (v4473 && (!v4476))) ? UINT64_C(2) : v4436));
        t4487 = v4485;
    } else {
        t4487 = v4385;
    }
    uint64_t v4488 = t4487;
    uint64_t t4504;
    if (v4437) {
        uint64_t v4489 = ((uint64_t)in_b[UINT64_C(43)]);
        int v4490 = ((v4436 == UINT64_C(0)) && (UINT64_C(43) == v4385));
        int v4491 = (v4490 && (v4489 == UINT64_C(0)));
        int v4492 = ((v4490 && ((v4489 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(44) < ((uint64_t)((uint64_t)in_b_len))));
        int v4493 = (((v4490 && (v4489 != UINT64_C(0))) && (v4489 < UINT64_C(64))) && (((uint64_t)((UINT64_C(43) + v4489) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4496 = ((v4436 == UINT64_C(0)) && (UINT64_C(43) != v4385));
        if (t4496) {
                uint64_t v4494 = v4489;
            int t4495 = (!(((((v4494 | UINT64_C(32)) >= UINT64_C(97)) && ((v4494 | UINT64_C(32)) <= UINT64_C(122))) || ((v4494 >= UINT64_C(48)) && (v4494 <= UINT64_C(57)))) || (v4494 == UINT64_C(45))));
            if (!t4495) {
                t4495 = ((v4489 == UINT64_C(45)) && ((UINT64_C(43) == ((v4419 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(44) == v4385)));
            }
            t4496 = t4495;
        }
        int v4497 = t4496;
        uint64_t v4498 = (v4491 ? UINT64_C(44) : (v4492 ? UINT64_C(45) : v4351));
        uint64_t v4499 = (v4492 ? (((((uint64_t)(v4489 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(44)]))) : v4402);
        uint64_t v4500 = (v4493 ? ((v4368 + UINT64_C(1)) & UINT64_C(255)) : v4368);
        uint64_t v4501 = (v4493 ? UINT64_C(43) : v4419);
        uint64_t v4502 = (v4493 ? ((uint64_t)((UINT64_C(44) + v4489) & UINT64_C(255))) : v4385);
        uint64_t v4503 = ((v4491 || v4492) ? UINT64_C(1) : ((v4497 || (v4490 && (!v4493))) ? UINT64_C(2) : v4436));
        t4504 = v4499;
    } else {
        t4504 = v4402;
    }
    uint64_t v4505 = t4504;
    uint64_t t4521;
    if (v4437) {
        uint64_t v4506 = ((uint64_t)in_b[UINT64_C(43)]);
        int v4507 = ((v4436 == UINT64_C(0)) && (UINT64_C(43) == v4385));
        int v4508 = (v4507 && (v4506 == UINT64_C(0)));
        int v4509 = ((v4507 && ((v4506 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(44) < ((uint64_t)((uint64_t)in_b_len))));
        int v4510 = (((v4507 && (v4506 != UINT64_C(0))) && (v4506 < UINT64_C(64))) && (((uint64_t)((UINT64_C(43) + v4506) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4513 = ((v4436 == UINT64_C(0)) && (UINT64_C(43) != v4385));
        if (t4513) {
                uint64_t v4511 = v4506;
            int t4512 = (!(((((v4511 | UINT64_C(32)) >= UINT64_C(97)) && ((v4511 | UINT64_C(32)) <= UINT64_C(122))) || ((v4511 >= UINT64_C(48)) && (v4511 <= UINT64_C(57)))) || (v4511 == UINT64_C(45))));
            if (!t4512) {
                t4512 = ((v4506 == UINT64_C(45)) && ((UINT64_C(43) == ((v4419 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(44) == v4385)));
            }
            t4513 = t4512;
        }
        int v4514 = t4513;
        uint64_t v4515 = (v4508 ? UINT64_C(44) : (v4509 ? UINT64_C(45) : v4351));
        uint64_t v4516 = (v4509 ? (((((uint64_t)(v4506 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(44)]))) : v4402);
        uint64_t v4517 = (v4510 ? ((v4368 + UINT64_C(1)) & UINT64_C(255)) : v4368);
        uint64_t v4518 = (v4510 ? UINT64_C(43) : v4419);
        uint64_t v4519 = (v4510 ? ((uint64_t)((UINT64_C(44) + v4506) & UINT64_C(255))) : v4385);
        uint64_t v4520 = ((v4508 || v4509) ? UINT64_C(1) : ((v4514 || (v4507 && (!v4510))) ? UINT64_C(2) : v4436));
        t4521 = v4518;
    } else {
        t4521 = v4419;
    }
    uint64_t v4522 = t4521;
    uint64_t t4538;
    if (v4437) {
        uint64_t v4523 = ((uint64_t)in_b[UINT64_C(43)]);
        int v4524 = ((v4436 == UINT64_C(0)) && (UINT64_C(43) == v4385));
        int v4525 = (v4524 && (v4523 == UINT64_C(0)));
        int v4526 = ((v4524 && ((v4523 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(44) < ((uint64_t)((uint64_t)in_b_len))));
        int v4527 = (((v4524 && (v4523 != UINT64_C(0))) && (v4523 < UINT64_C(64))) && (((uint64_t)((UINT64_C(43) + v4523) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4530 = ((v4436 == UINT64_C(0)) && (UINT64_C(43) != v4385));
        if (t4530) {
                uint64_t v4528 = v4523;
            int t4529 = (!(((((v4528 | UINT64_C(32)) >= UINT64_C(97)) && ((v4528 | UINT64_C(32)) <= UINT64_C(122))) || ((v4528 >= UINT64_C(48)) && (v4528 <= UINT64_C(57)))) || (v4528 == UINT64_C(45))));
            if (!t4529) {
                t4529 = ((v4523 == UINT64_C(45)) && ((UINT64_C(43) == ((v4419 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(44) == v4385)));
            }
            t4530 = t4529;
        }
        int v4531 = t4530;
        uint64_t v4532 = (v4525 ? UINT64_C(44) : (v4526 ? UINT64_C(45) : v4351));
        uint64_t v4533 = (v4526 ? (((((uint64_t)(v4523 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(44)]))) : v4402);
        uint64_t v4534 = (v4527 ? ((v4368 + UINT64_C(1)) & UINT64_C(255)) : v4368);
        uint64_t v4535 = (v4527 ? UINT64_C(43) : v4419);
        uint64_t v4536 = (v4527 ? ((uint64_t)((UINT64_C(44) + v4523) & UINT64_C(255))) : v4385);
        uint64_t v4537 = ((v4525 || v4526) ? UINT64_C(1) : ((v4531 || (v4524 && (!v4527))) ? UINT64_C(2) : v4436));
        t4538 = v4537;
    } else {
        t4538 = v4436;
    }
    uint64_t v4539 = t4538;
    int v4540 = (UINT64_C(44) < v7);
    uint64_t t4556;
    if (v4540) {
        uint64_t v4541 = ((uint64_t)in_b[UINT64_C(44)]);
        int v4542 = ((v4539 == UINT64_C(0)) && (UINT64_C(44) == v4488));
        int v4543 = (v4542 && (v4541 == UINT64_C(0)));
        int v4544 = ((v4542 && ((v4541 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(45) < ((uint64_t)((uint64_t)in_b_len))));
        int v4545 = (((v4542 && (v4541 != UINT64_C(0))) && (v4541 < UINT64_C(64))) && (((uint64_t)((UINT64_C(44) + v4541) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4548 = ((v4539 == UINT64_C(0)) && (UINT64_C(44) != v4488));
        if (t4548) {
                uint64_t v4546 = v4541;
            int t4547 = (!(((((v4546 | UINT64_C(32)) >= UINT64_C(97)) && ((v4546 | UINT64_C(32)) <= UINT64_C(122))) || ((v4546 >= UINT64_C(48)) && (v4546 <= UINT64_C(57)))) || (v4546 == UINT64_C(45))));
            if (!t4547) {
                t4547 = ((v4541 == UINT64_C(45)) && ((UINT64_C(44) == ((v4522 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(45) == v4488)));
            }
            t4548 = t4547;
        }
        int v4549 = t4548;
        uint64_t v4550 = (v4543 ? UINT64_C(45) : (v4544 ? UINT64_C(46) : v4454));
        uint64_t v4551 = (v4544 ? (((((uint64_t)(v4541 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(45)]))) : v4505);
        uint64_t v4552 = (v4545 ? ((v4471 + UINT64_C(1)) & UINT64_C(255)) : v4471);
        uint64_t v4553 = (v4545 ? UINT64_C(44) : v4522);
        uint64_t v4554 = (v4545 ? ((uint64_t)((UINT64_C(45) + v4541) & UINT64_C(255))) : v4488);
        uint64_t v4555 = ((v4543 || v4544) ? UINT64_C(1) : ((v4549 || (v4542 && (!v4545))) ? UINT64_C(2) : v4539));
        t4556 = v4550;
    } else {
        t4556 = v4454;
    }
    uint64_t v4557 = t4556;
    uint64_t t4573;
    if (v4540) {
        uint64_t v4558 = ((uint64_t)in_b[UINT64_C(44)]);
        int v4559 = ((v4539 == UINT64_C(0)) && (UINT64_C(44) == v4488));
        int v4560 = (v4559 && (v4558 == UINT64_C(0)));
        int v4561 = ((v4559 && ((v4558 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(45) < ((uint64_t)((uint64_t)in_b_len))));
        int v4562 = (((v4559 && (v4558 != UINT64_C(0))) && (v4558 < UINT64_C(64))) && (((uint64_t)((UINT64_C(44) + v4558) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4565 = ((v4539 == UINT64_C(0)) && (UINT64_C(44) != v4488));
        if (t4565) {
                uint64_t v4563 = v4558;
            int t4564 = (!(((((v4563 | UINT64_C(32)) >= UINT64_C(97)) && ((v4563 | UINT64_C(32)) <= UINT64_C(122))) || ((v4563 >= UINT64_C(48)) && (v4563 <= UINT64_C(57)))) || (v4563 == UINT64_C(45))));
            if (!t4564) {
                t4564 = ((v4558 == UINT64_C(45)) && ((UINT64_C(44) == ((v4522 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(45) == v4488)));
            }
            t4565 = t4564;
        }
        int v4566 = t4565;
        uint64_t v4567 = (v4560 ? UINT64_C(45) : (v4561 ? UINT64_C(46) : v4454));
        uint64_t v4568 = (v4561 ? (((((uint64_t)(v4558 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(45)]))) : v4505);
        uint64_t v4569 = (v4562 ? ((v4471 + UINT64_C(1)) & UINT64_C(255)) : v4471);
        uint64_t v4570 = (v4562 ? UINT64_C(44) : v4522);
        uint64_t v4571 = (v4562 ? ((uint64_t)((UINT64_C(45) + v4558) & UINT64_C(255))) : v4488);
        uint64_t v4572 = ((v4560 || v4561) ? UINT64_C(1) : ((v4566 || (v4559 && (!v4562))) ? UINT64_C(2) : v4539));
        t4573 = v4569;
    } else {
        t4573 = v4471;
    }
    uint64_t v4574 = t4573;
    uint64_t t4590;
    if (v4540) {
        uint64_t v4575 = ((uint64_t)in_b[UINT64_C(44)]);
        int v4576 = ((v4539 == UINT64_C(0)) && (UINT64_C(44) == v4488));
        int v4577 = (v4576 && (v4575 == UINT64_C(0)));
        int v4578 = ((v4576 && ((v4575 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(45) < ((uint64_t)((uint64_t)in_b_len))));
        int v4579 = (((v4576 && (v4575 != UINT64_C(0))) && (v4575 < UINT64_C(64))) && (((uint64_t)((UINT64_C(44) + v4575) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4582 = ((v4539 == UINT64_C(0)) && (UINT64_C(44) != v4488));
        if (t4582) {
                uint64_t v4580 = v4575;
            int t4581 = (!(((((v4580 | UINT64_C(32)) >= UINT64_C(97)) && ((v4580 | UINT64_C(32)) <= UINT64_C(122))) || ((v4580 >= UINT64_C(48)) && (v4580 <= UINT64_C(57)))) || (v4580 == UINT64_C(45))));
            if (!t4581) {
                t4581 = ((v4575 == UINT64_C(45)) && ((UINT64_C(44) == ((v4522 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(45) == v4488)));
            }
            t4582 = t4581;
        }
        int v4583 = t4582;
        uint64_t v4584 = (v4577 ? UINT64_C(45) : (v4578 ? UINT64_C(46) : v4454));
        uint64_t v4585 = (v4578 ? (((((uint64_t)(v4575 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(45)]))) : v4505);
        uint64_t v4586 = (v4579 ? ((v4471 + UINT64_C(1)) & UINT64_C(255)) : v4471);
        uint64_t v4587 = (v4579 ? UINT64_C(44) : v4522);
        uint64_t v4588 = (v4579 ? ((uint64_t)((UINT64_C(45) + v4575) & UINT64_C(255))) : v4488);
        uint64_t v4589 = ((v4577 || v4578) ? UINT64_C(1) : ((v4583 || (v4576 && (!v4579))) ? UINT64_C(2) : v4539));
        t4590 = v4588;
    } else {
        t4590 = v4488;
    }
    uint64_t v4591 = t4590;
    uint64_t t4607;
    if (v4540) {
        uint64_t v4592 = ((uint64_t)in_b[UINT64_C(44)]);
        int v4593 = ((v4539 == UINT64_C(0)) && (UINT64_C(44) == v4488));
        int v4594 = (v4593 && (v4592 == UINT64_C(0)));
        int v4595 = ((v4593 && ((v4592 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(45) < ((uint64_t)((uint64_t)in_b_len))));
        int v4596 = (((v4593 && (v4592 != UINT64_C(0))) && (v4592 < UINT64_C(64))) && (((uint64_t)((UINT64_C(44) + v4592) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4599 = ((v4539 == UINT64_C(0)) && (UINT64_C(44) != v4488));
        if (t4599) {
                uint64_t v4597 = v4592;
            int t4598 = (!(((((v4597 | UINT64_C(32)) >= UINT64_C(97)) && ((v4597 | UINT64_C(32)) <= UINT64_C(122))) || ((v4597 >= UINT64_C(48)) && (v4597 <= UINT64_C(57)))) || (v4597 == UINT64_C(45))));
            if (!t4598) {
                t4598 = ((v4592 == UINT64_C(45)) && ((UINT64_C(44) == ((v4522 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(45) == v4488)));
            }
            t4599 = t4598;
        }
        int v4600 = t4599;
        uint64_t v4601 = (v4594 ? UINT64_C(45) : (v4595 ? UINT64_C(46) : v4454));
        uint64_t v4602 = (v4595 ? (((((uint64_t)(v4592 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(45)]))) : v4505);
        uint64_t v4603 = (v4596 ? ((v4471 + UINT64_C(1)) & UINT64_C(255)) : v4471);
        uint64_t v4604 = (v4596 ? UINT64_C(44) : v4522);
        uint64_t v4605 = (v4596 ? ((uint64_t)((UINT64_C(45) + v4592) & UINT64_C(255))) : v4488);
        uint64_t v4606 = ((v4594 || v4595) ? UINT64_C(1) : ((v4600 || (v4593 && (!v4596))) ? UINT64_C(2) : v4539));
        t4607 = v4602;
    } else {
        t4607 = v4505;
    }
    uint64_t v4608 = t4607;
    uint64_t t4624;
    if (v4540) {
        uint64_t v4609 = ((uint64_t)in_b[UINT64_C(44)]);
        int v4610 = ((v4539 == UINT64_C(0)) && (UINT64_C(44) == v4488));
        int v4611 = (v4610 && (v4609 == UINT64_C(0)));
        int v4612 = ((v4610 && ((v4609 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(45) < ((uint64_t)((uint64_t)in_b_len))));
        int v4613 = (((v4610 && (v4609 != UINT64_C(0))) && (v4609 < UINT64_C(64))) && (((uint64_t)((UINT64_C(44) + v4609) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4616 = ((v4539 == UINT64_C(0)) && (UINT64_C(44) != v4488));
        if (t4616) {
                uint64_t v4614 = v4609;
            int t4615 = (!(((((v4614 | UINT64_C(32)) >= UINT64_C(97)) && ((v4614 | UINT64_C(32)) <= UINT64_C(122))) || ((v4614 >= UINT64_C(48)) && (v4614 <= UINT64_C(57)))) || (v4614 == UINT64_C(45))));
            if (!t4615) {
                t4615 = ((v4609 == UINT64_C(45)) && ((UINT64_C(44) == ((v4522 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(45) == v4488)));
            }
            t4616 = t4615;
        }
        int v4617 = t4616;
        uint64_t v4618 = (v4611 ? UINT64_C(45) : (v4612 ? UINT64_C(46) : v4454));
        uint64_t v4619 = (v4612 ? (((((uint64_t)(v4609 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(45)]))) : v4505);
        uint64_t v4620 = (v4613 ? ((v4471 + UINT64_C(1)) & UINT64_C(255)) : v4471);
        uint64_t v4621 = (v4613 ? UINT64_C(44) : v4522);
        uint64_t v4622 = (v4613 ? ((uint64_t)((UINT64_C(45) + v4609) & UINT64_C(255))) : v4488);
        uint64_t v4623 = ((v4611 || v4612) ? UINT64_C(1) : ((v4617 || (v4610 && (!v4613))) ? UINT64_C(2) : v4539));
        t4624 = v4621;
    } else {
        t4624 = v4522;
    }
    uint64_t v4625 = t4624;
    uint64_t t4641;
    if (v4540) {
        uint64_t v4626 = ((uint64_t)in_b[UINT64_C(44)]);
        int v4627 = ((v4539 == UINT64_C(0)) && (UINT64_C(44) == v4488));
        int v4628 = (v4627 && (v4626 == UINT64_C(0)));
        int v4629 = ((v4627 && ((v4626 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(45) < ((uint64_t)((uint64_t)in_b_len))));
        int v4630 = (((v4627 && (v4626 != UINT64_C(0))) && (v4626 < UINT64_C(64))) && (((uint64_t)((UINT64_C(44) + v4626) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4633 = ((v4539 == UINT64_C(0)) && (UINT64_C(44) != v4488));
        if (t4633) {
                uint64_t v4631 = v4626;
            int t4632 = (!(((((v4631 | UINT64_C(32)) >= UINT64_C(97)) && ((v4631 | UINT64_C(32)) <= UINT64_C(122))) || ((v4631 >= UINT64_C(48)) && (v4631 <= UINT64_C(57)))) || (v4631 == UINT64_C(45))));
            if (!t4632) {
                t4632 = ((v4626 == UINT64_C(45)) && ((UINT64_C(44) == ((v4522 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(45) == v4488)));
            }
            t4633 = t4632;
        }
        int v4634 = t4633;
        uint64_t v4635 = (v4628 ? UINT64_C(45) : (v4629 ? UINT64_C(46) : v4454));
        uint64_t v4636 = (v4629 ? (((((uint64_t)(v4626 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(45)]))) : v4505);
        uint64_t v4637 = (v4630 ? ((v4471 + UINT64_C(1)) & UINT64_C(255)) : v4471);
        uint64_t v4638 = (v4630 ? UINT64_C(44) : v4522);
        uint64_t v4639 = (v4630 ? ((uint64_t)((UINT64_C(45) + v4626) & UINT64_C(255))) : v4488);
        uint64_t v4640 = ((v4628 || v4629) ? UINT64_C(1) : ((v4634 || (v4627 && (!v4630))) ? UINT64_C(2) : v4539));
        t4641 = v4640;
    } else {
        t4641 = v4539;
    }
    uint64_t v4642 = t4641;
    int v4643 = (UINT64_C(45) < v7);
    uint64_t t4659;
    if (v4643) {
        uint64_t v4644 = ((uint64_t)in_b[UINT64_C(45)]);
        int v4645 = ((v4642 == UINT64_C(0)) && (UINT64_C(45) == v4591));
        int v4646 = (v4645 && (v4644 == UINT64_C(0)));
        int v4647 = ((v4645 && ((v4644 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(46) < ((uint64_t)((uint64_t)in_b_len))));
        int v4648 = (((v4645 && (v4644 != UINT64_C(0))) && (v4644 < UINT64_C(64))) && (((uint64_t)((UINT64_C(45) + v4644) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4651 = ((v4642 == UINT64_C(0)) && (UINT64_C(45) != v4591));
        if (t4651) {
                uint64_t v4649 = v4644;
            int t4650 = (!(((((v4649 | UINT64_C(32)) >= UINT64_C(97)) && ((v4649 | UINT64_C(32)) <= UINT64_C(122))) || ((v4649 >= UINT64_C(48)) && (v4649 <= UINT64_C(57)))) || (v4649 == UINT64_C(45))));
            if (!t4650) {
                t4650 = ((v4644 == UINT64_C(45)) && ((UINT64_C(45) == ((v4625 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(46) == v4591)));
            }
            t4651 = t4650;
        }
        int v4652 = t4651;
        uint64_t v4653 = (v4646 ? UINT64_C(46) : (v4647 ? UINT64_C(47) : v4557));
        uint64_t v4654 = (v4647 ? (((((uint64_t)(v4644 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(46)]))) : v4608);
        uint64_t v4655 = (v4648 ? ((v4574 + UINT64_C(1)) & UINT64_C(255)) : v4574);
        uint64_t v4656 = (v4648 ? UINT64_C(45) : v4625);
        uint64_t v4657 = (v4648 ? ((uint64_t)((UINT64_C(46) + v4644) & UINT64_C(255))) : v4591);
        uint64_t v4658 = ((v4646 || v4647) ? UINT64_C(1) : ((v4652 || (v4645 && (!v4648))) ? UINT64_C(2) : v4642));
        t4659 = v4653;
    } else {
        t4659 = v4557;
    }
    uint64_t v4660 = t4659;
    uint64_t t4676;
    if (v4643) {
        uint64_t v4661 = ((uint64_t)in_b[UINT64_C(45)]);
        int v4662 = ((v4642 == UINT64_C(0)) && (UINT64_C(45) == v4591));
        int v4663 = (v4662 && (v4661 == UINT64_C(0)));
        int v4664 = ((v4662 && ((v4661 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(46) < ((uint64_t)((uint64_t)in_b_len))));
        int v4665 = (((v4662 && (v4661 != UINT64_C(0))) && (v4661 < UINT64_C(64))) && (((uint64_t)((UINT64_C(45) + v4661) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4668 = ((v4642 == UINT64_C(0)) && (UINT64_C(45) != v4591));
        if (t4668) {
                uint64_t v4666 = v4661;
            int t4667 = (!(((((v4666 | UINT64_C(32)) >= UINT64_C(97)) && ((v4666 | UINT64_C(32)) <= UINT64_C(122))) || ((v4666 >= UINT64_C(48)) && (v4666 <= UINT64_C(57)))) || (v4666 == UINT64_C(45))));
            if (!t4667) {
                t4667 = ((v4661 == UINT64_C(45)) && ((UINT64_C(45) == ((v4625 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(46) == v4591)));
            }
            t4668 = t4667;
        }
        int v4669 = t4668;
        uint64_t v4670 = (v4663 ? UINT64_C(46) : (v4664 ? UINT64_C(47) : v4557));
        uint64_t v4671 = (v4664 ? (((((uint64_t)(v4661 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(46)]))) : v4608);
        uint64_t v4672 = (v4665 ? ((v4574 + UINT64_C(1)) & UINT64_C(255)) : v4574);
        uint64_t v4673 = (v4665 ? UINT64_C(45) : v4625);
        uint64_t v4674 = (v4665 ? ((uint64_t)((UINT64_C(46) + v4661) & UINT64_C(255))) : v4591);
        uint64_t v4675 = ((v4663 || v4664) ? UINT64_C(1) : ((v4669 || (v4662 && (!v4665))) ? UINT64_C(2) : v4642));
        t4676 = v4672;
    } else {
        t4676 = v4574;
    }
    uint64_t v4677 = t4676;
    uint64_t t4693;
    if (v4643) {
        uint64_t v4678 = ((uint64_t)in_b[UINT64_C(45)]);
        int v4679 = ((v4642 == UINT64_C(0)) && (UINT64_C(45) == v4591));
        int v4680 = (v4679 && (v4678 == UINT64_C(0)));
        int v4681 = ((v4679 && ((v4678 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(46) < ((uint64_t)((uint64_t)in_b_len))));
        int v4682 = (((v4679 && (v4678 != UINT64_C(0))) && (v4678 < UINT64_C(64))) && (((uint64_t)((UINT64_C(45) + v4678) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4685 = ((v4642 == UINT64_C(0)) && (UINT64_C(45) != v4591));
        if (t4685) {
                uint64_t v4683 = v4678;
            int t4684 = (!(((((v4683 | UINT64_C(32)) >= UINT64_C(97)) && ((v4683 | UINT64_C(32)) <= UINT64_C(122))) || ((v4683 >= UINT64_C(48)) && (v4683 <= UINT64_C(57)))) || (v4683 == UINT64_C(45))));
            if (!t4684) {
                t4684 = ((v4678 == UINT64_C(45)) && ((UINT64_C(45) == ((v4625 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(46) == v4591)));
            }
            t4685 = t4684;
        }
        int v4686 = t4685;
        uint64_t v4687 = (v4680 ? UINT64_C(46) : (v4681 ? UINT64_C(47) : v4557));
        uint64_t v4688 = (v4681 ? (((((uint64_t)(v4678 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(46)]))) : v4608);
        uint64_t v4689 = (v4682 ? ((v4574 + UINT64_C(1)) & UINT64_C(255)) : v4574);
        uint64_t v4690 = (v4682 ? UINT64_C(45) : v4625);
        uint64_t v4691 = (v4682 ? ((uint64_t)((UINT64_C(46) + v4678) & UINT64_C(255))) : v4591);
        uint64_t v4692 = ((v4680 || v4681) ? UINT64_C(1) : ((v4686 || (v4679 && (!v4682))) ? UINT64_C(2) : v4642));
        t4693 = v4691;
    } else {
        t4693 = v4591;
    }
    uint64_t v4694 = t4693;
    uint64_t t4710;
    if (v4643) {
        uint64_t v4695 = ((uint64_t)in_b[UINT64_C(45)]);
        int v4696 = ((v4642 == UINT64_C(0)) && (UINT64_C(45) == v4591));
        int v4697 = (v4696 && (v4695 == UINT64_C(0)));
        int v4698 = ((v4696 && ((v4695 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(46) < ((uint64_t)((uint64_t)in_b_len))));
        int v4699 = (((v4696 && (v4695 != UINT64_C(0))) && (v4695 < UINT64_C(64))) && (((uint64_t)((UINT64_C(45) + v4695) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4702 = ((v4642 == UINT64_C(0)) && (UINT64_C(45) != v4591));
        if (t4702) {
                uint64_t v4700 = v4695;
            int t4701 = (!(((((v4700 | UINT64_C(32)) >= UINT64_C(97)) && ((v4700 | UINT64_C(32)) <= UINT64_C(122))) || ((v4700 >= UINT64_C(48)) && (v4700 <= UINT64_C(57)))) || (v4700 == UINT64_C(45))));
            if (!t4701) {
                t4701 = ((v4695 == UINT64_C(45)) && ((UINT64_C(45) == ((v4625 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(46) == v4591)));
            }
            t4702 = t4701;
        }
        int v4703 = t4702;
        uint64_t v4704 = (v4697 ? UINT64_C(46) : (v4698 ? UINT64_C(47) : v4557));
        uint64_t v4705 = (v4698 ? (((((uint64_t)(v4695 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(46)]))) : v4608);
        uint64_t v4706 = (v4699 ? ((v4574 + UINT64_C(1)) & UINT64_C(255)) : v4574);
        uint64_t v4707 = (v4699 ? UINT64_C(45) : v4625);
        uint64_t v4708 = (v4699 ? ((uint64_t)((UINT64_C(46) + v4695) & UINT64_C(255))) : v4591);
        uint64_t v4709 = ((v4697 || v4698) ? UINT64_C(1) : ((v4703 || (v4696 && (!v4699))) ? UINT64_C(2) : v4642));
        t4710 = v4705;
    } else {
        t4710 = v4608;
    }
    uint64_t v4711 = t4710;
    uint64_t t4727;
    if (v4643) {
        uint64_t v4712 = ((uint64_t)in_b[UINT64_C(45)]);
        int v4713 = ((v4642 == UINT64_C(0)) && (UINT64_C(45) == v4591));
        int v4714 = (v4713 && (v4712 == UINT64_C(0)));
        int v4715 = ((v4713 && ((v4712 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(46) < ((uint64_t)((uint64_t)in_b_len))));
        int v4716 = (((v4713 && (v4712 != UINT64_C(0))) && (v4712 < UINT64_C(64))) && (((uint64_t)((UINT64_C(45) + v4712) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4719 = ((v4642 == UINT64_C(0)) && (UINT64_C(45) != v4591));
        if (t4719) {
                uint64_t v4717 = v4712;
            int t4718 = (!(((((v4717 | UINT64_C(32)) >= UINT64_C(97)) && ((v4717 | UINT64_C(32)) <= UINT64_C(122))) || ((v4717 >= UINT64_C(48)) && (v4717 <= UINT64_C(57)))) || (v4717 == UINT64_C(45))));
            if (!t4718) {
                t4718 = ((v4712 == UINT64_C(45)) && ((UINT64_C(45) == ((v4625 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(46) == v4591)));
            }
            t4719 = t4718;
        }
        int v4720 = t4719;
        uint64_t v4721 = (v4714 ? UINT64_C(46) : (v4715 ? UINT64_C(47) : v4557));
        uint64_t v4722 = (v4715 ? (((((uint64_t)(v4712 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(46)]))) : v4608);
        uint64_t v4723 = (v4716 ? ((v4574 + UINT64_C(1)) & UINT64_C(255)) : v4574);
        uint64_t v4724 = (v4716 ? UINT64_C(45) : v4625);
        uint64_t v4725 = (v4716 ? ((uint64_t)((UINT64_C(46) + v4712) & UINT64_C(255))) : v4591);
        uint64_t v4726 = ((v4714 || v4715) ? UINT64_C(1) : ((v4720 || (v4713 && (!v4716))) ? UINT64_C(2) : v4642));
        t4727 = v4724;
    } else {
        t4727 = v4625;
    }
    uint64_t v4728 = t4727;
    uint64_t t4744;
    if (v4643) {
        uint64_t v4729 = ((uint64_t)in_b[UINT64_C(45)]);
        int v4730 = ((v4642 == UINT64_C(0)) && (UINT64_C(45) == v4591));
        int v4731 = (v4730 && (v4729 == UINT64_C(0)));
        int v4732 = ((v4730 && ((v4729 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(46) < ((uint64_t)((uint64_t)in_b_len))));
        int v4733 = (((v4730 && (v4729 != UINT64_C(0))) && (v4729 < UINT64_C(64))) && (((uint64_t)((UINT64_C(45) + v4729) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4736 = ((v4642 == UINT64_C(0)) && (UINT64_C(45) != v4591));
        if (t4736) {
                uint64_t v4734 = v4729;
            int t4735 = (!(((((v4734 | UINT64_C(32)) >= UINT64_C(97)) && ((v4734 | UINT64_C(32)) <= UINT64_C(122))) || ((v4734 >= UINT64_C(48)) && (v4734 <= UINT64_C(57)))) || (v4734 == UINT64_C(45))));
            if (!t4735) {
                t4735 = ((v4729 == UINT64_C(45)) && ((UINT64_C(45) == ((v4625 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(46) == v4591)));
            }
            t4736 = t4735;
        }
        int v4737 = t4736;
        uint64_t v4738 = (v4731 ? UINT64_C(46) : (v4732 ? UINT64_C(47) : v4557));
        uint64_t v4739 = (v4732 ? (((((uint64_t)(v4729 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(46)]))) : v4608);
        uint64_t v4740 = (v4733 ? ((v4574 + UINT64_C(1)) & UINT64_C(255)) : v4574);
        uint64_t v4741 = (v4733 ? UINT64_C(45) : v4625);
        uint64_t v4742 = (v4733 ? ((uint64_t)((UINT64_C(46) + v4729) & UINT64_C(255))) : v4591);
        uint64_t v4743 = ((v4731 || v4732) ? UINT64_C(1) : ((v4737 || (v4730 && (!v4733))) ? UINT64_C(2) : v4642));
        t4744 = v4743;
    } else {
        t4744 = v4642;
    }
    uint64_t v4745 = t4744;
    int v4746 = (UINT64_C(46) < v7);
    uint64_t t4762;
    if (v4746) {
        uint64_t v4747 = ((uint64_t)in_b[UINT64_C(46)]);
        int v4748 = ((v4745 == UINT64_C(0)) && (UINT64_C(46) == v4694));
        int v4749 = (v4748 && (v4747 == UINT64_C(0)));
        int v4750 = ((v4748 && ((v4747 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(47) < ((uint64_t)((uint64_t)in_b_len))));
        int v4751 = (((v4748 && (v4747 != UINT64_C(0))) && (v4747 < UINT64_C(64))) && (((uint64_t)((UINT64_C(46) + v4747) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4754 = ((v4745 == UINT64_C(0)) && (UINT64_C(46) != v4694));
        if (t4754) {
                uint64_t v4752 = v4747;
            int t4753 = (!(((((v4752 | UINT64_C(32)) >= UINT64_C(97)) && ((v4752 | UINT64_C(32)) <= UINT64_C(122))) || ((v4752 >= UINT64_C(48)) && (v4752 <= UINT64_C(57)))) || (v4752 == UINT64_C(45))));
            if (!t4753) {
                t4753 = ((v4747 == UINT64_C(45)) && ((UINT64_C(46) == ((v4728 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(47) == v4694)));
            }
            t4754 = t4753;
        }
        int v4755 = t4754;
        uint64_t v4756 = (v4749 ? UINT64_C(47) : (v4750 ? UINT64_C(48) : v4660));
        uint64_t v4757 = (v4750 ? (((((uint64_t)(v4747 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(47)]))) : v4711);
        uint64_t v4758 = (v4751 ? ((v4677 + UINT64_C(1)) & UINT64_C(255)) : v4677);
        uint64_t v4759 = (v4751 ? UINT64_C(46) : v4728);
        uint64_t v4760 = (v4751 ? ((uint64_t)((UINT64_C(47) + v4747) & UINT64_C(255))) : v4694);
        uint64_t v4761 = ((v4749 || v4750) ? UINT64_C(1) : ((v4755 || (v4748 && (!v4751))) ? UINT64_C(2) : v4745));
        t4762 = v4756;
    } else {
        t4762 = v4660;
    }
    uint64_t v4763 = t4762;
    uint64_t t4779;
    if (v4746) {
        uint64_t v4764 = ((uint64_t)in_b[UINT64_C(46)]);
        int v4765 = ((v4745 == UINT64_C(0)) && (UINT64_C(46) == v4694));
        int v4766 = (v4765 && (v4764 == UINT64_C(0)));
        int v4767 = ((v4765 && ((v4764 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(47) < ((uint64_t)((uint64_t)in_b_len))));
        int v4768 = (((v4765 && (v4764 != UINT64_C(0))) && (v4764 < UINT64_C(64))) && (((uint64_t)((UINT64_C(46) + v4764) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4771 = ((v4745 == UINT64_C(0)) && (UINT64_C(46) != v4694));
        if (t4771) {
                uint64_t v4769 = v4764;
            int t4770 = (!(((((v4769 | UINT64_C(32)) >= UINT64_C(97)) && ((v4769 | UINT64_C(32)) <= UINT64_C(122))) || ((v4769 >= UINT64_C(48)) && (v4769 <= UINT64_C(57)))) || (v4769 == UINT64_C(45))));
            if (!t4770) {
                t4770 = ((v4764 == UINT64_C(45)) && ((UINT64_C(46) == ((v4728 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(47) == v4694)));
            }
            t4771 = t4770;
        }
        int v4772 = t4771;
        uint64_t v4773 = (v4766 ? UINT64_C(47) : (v4767 ? UINT64_C(48) : v4660));
        uint64_t v4774 = (v4767 ? (((((uint64_t)(v4764 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(47)]))) : v4711);
        uint64_t v4775 = (v4768 ? ((v4677 + UINT64_C(1)) & UINT64_C(255)) : v4677);
        uint64_t v4776 = (v4768 ? UINT64_C(46) : v4728);
        uint64_t v4777 = (v4768 ? ((uint64_t)((UINT64_C(47) + v4764) & UINT64_C(255))) : v4694);
        uint64_t v4778 = ((v4766 || v4767) ? UINT64_C(1) : ((v4772 || (v4765 && (!v4768))) ? UINT64_C(2) : v4745));
        t4779 = v4775;
    } else {
        t4779 = v4677;
    }
    uint64_t v4780 = t4779;
    uint64_t t4796;
    if (v4746) {
        uint64_t v4781 = ((uint64_t)in_b[UINT64_C(46)]);
        int v4782 = ((v4745 == UINT64_C(0)) && (UINT64_C(46) == v4694));
        int v4783 = (v4782 && (v4781 == UINT64_C(0)));
        int v4784 = ((v4782 && ((v4781 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(47) < ((uint64_t)((uint64_t)in_b_len))));
        int v4785 = (((v4782 && (v4781 != UINT64_C(0))) && (v4781 < UINT64_C(64))) && (((uint64_t)((UINT64_C(46) + v4781) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4788 = ((v4745 == UINT64_C(0)) && (UINT64_C(46) != v4694));
        if (t4788) {
                uint64_t v4786 = v4781;
            int t4787 = (!(((((v4786 | UINT64_C(32)) >= UINT64_C(97)) && ((v4786 | UINT64_C(32)) <= UINT64_C(122))) || ((v4786 >= UINT64_C(48)) && (v4786 <= UINT64_C(57)))) || (v4786 == UINT64_C(45))));
            if (!t4787) {
                t4787 = ((v4781 == UINT64_C(45)) && ((UINT64_C(46) == ((v4728 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(47) == v4694)));
            }
            t4788 = t4787;
        }
        int v4789 = t4788;
        uint64_t v4790 = (v4783 ? UINT64_C(47) : (v4784 ? UINT64_C(48) : v4660));
        uint64_t v4791 = (v4784 ? (((((uint64_t)(v4781 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(47)]))) : v4711);
        uint64_t v4792 = (v4785 ? ((v4677 + UINT64_C(1)) & UINT64_C(255)) : v4677);
        uint64_t v4793 = (v4785 ? UINT64_C(46) : v4728);
        uint64_t v4794 = (v4785 ? ((uint64_t)((UINT64_C(47) + v4781) & UINT64_C(255))) : v4694);
        uint64_t v4795 = ((v4783 || v4784) ? UINT64_C(1) : ((v4789 || (v4782 && (!v4785))) ? UINT64_C(2) : v4745));
        t4796 = v4794;
    } else {
        t4796 = v4694;
    }
    uint64_t v4797 = t4796;
    uint64_t t4813;
    if (v4746) {
        uint64_t v4798 = ((uint64_t)in_b[UINT64_C(46)]);
        int v4799 = ((v4745 == UINT64_C(0)) && (UINT64_C(46) == v4694));
        int v4800 = (v4799 && (v4798 == UINT64_C(0)));
        int v4801 = ((v4799 && ((v4798 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(47) < ((uint64_t)((uint64_t)in_b_len))));
        int v4802 = (((v4799 && (v4798 != UINT64_C(0))) && (v4798 < UINT64_C(64))) && (((uint64_t)((UINT64_C(46) + v4798) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4805 = ((v4745 == UINT64_C(0)) && (UINT64_C(46) != v4694));
        if (t4805) {
                uint64_t v4803 = v4798;
            int t4804 = (!(((((v4803 | UINT64_C(32)) >= UINT64_C(97)) && ((v4803 | UINT64_C(32)) <= UINT64_C(122))) || ((v4803 >= UINT64_C(48)) && (v4803 <= UINT64_C(57)))) || (v4803 == UINT64_C(45))));
            if (!t4804) {
                t4804 = ((v4798 == UINT64_C(45)) && ((UINT64_C(46) == ((v4728 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(47) == v4694)));
            }
            t4805 = t4804;
        }
        int v4806 = t4805;
        uint64_t v4807 = (v4800 ? UINT64_C(47) : (v4801 ? UINT64_C(48) : v4660));
        uint64_t v4808 = (v4801 ? (((((uint64_t)(v4798 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(47)]))) : v4711);
        uint64_t v4809 = (v4802 ? ((v4677 + UINT64_C(1)) & UINT64_C(255)) : v4677);
        uint64_t v4810 = (v4802 ? UINT64_C(46) : v4728);
        uint64_t v4811 = (v4802 ? ((uint64_t)((UINT64_C(47) + v4798) & UINT64_C(255))) : v4694);
        uint64_t v4812 = ((v4800 || v4801) ? UINT64_C(1) : ((v4806 || (v4799 && (!v4802))) ? UINT64_C(2) : v4745));
        t4813 = v4808;
    } else {
        t4813 = v4711;
    }
    uint64_t v4814 = t4813;
    uint64_t t4830;
    if (v4746) {
        uint64_t v4815 = ((uint64_t)in_b[UINT64_C(46)]);
        int v4816 = ((v4745 == UINT64_C(0)) && (UINT64_C(46) == v4694));
        int v4817 = (v4816 && (v4815 == UINT64_C(0)));
        int v4818 = ((v4816 && ((v4815 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(47) < ((uint64_t)((uint64_t)in_b_len))));
        int v4819 = (((v4816 && (v4815 != UINT64_C(0))) && (v4815 < UINT64_C(64))) && (((uint64_t)((UINT64_C(46) + v4815) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4822 = ((v4745 == UINT64_C(0)) && (UINT64_C(46) != v4694));
        if (t4822) {
                uint64_t v4820 = v4815;
            int t4821 = (!(((((v4820 | UINT64_C(32)) >= UINT64_C(97)) && ((v4820 | UINT64_C(32)) <= UINT64_C(122))) || ((v4820 >= UINT64_C(48)) && (v4820 <= UINT64_C(57)))) || (v4820 == UINT64_C(45))));
            if (!t4821) {
                t4821 = ((v4815 == UINT64_C(45)) && ((UINT64_C(46) == ((v4728 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(47) == v4694)));
            }
            t4822 = t4821;
        }
        int v4823 = t4822;
        uint64_t v4824 = (v4817 ? UINT64_C(47) : (v4818 ? UINT64_C(48) : v4660));
        uint64_t v4825 = (v4818 ? (((((uint64_t)(v4815 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(47)]))) : v4711);
        uint64_t v4826 = (v4819 ? ((v4677 + UINT64_C(1)) & UINT64_C(255)) : v4677);
        uint64_t v4827 = (v4819 ? UINT64_C(46) : v4728);
        uint64_t v4828 = (v4819 ? ((uint64_t)((UINT64_C(47) + v4815) & UINT64_C(255))) : v4694);
        uint64_t v4829 = ((v4817 || v4818) ? UINT64_C(1) : ((v4823 || (v4816 && (!v4819))) ? UINT64_C(2) : v4745));
        t4830 = v4827;
    } else {
        t4830 = v4728;
    }
    uint64_t v4831 = t4830;
    uint64_t t4847;
    if (v4746) {
        uint64_t v4832 = ((uint64_t)in_b[UINT64_C(46)]);
        int v4833 = ((v4745 == UINT64_C(0)) && (UINT64_C(46) == v4694));
        int v4834 = (v4833 && (v4832 == UINT64_C(0)));
        int v4835 = ((v4833 && ((v4832 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(47) < ((uint64_t)((uint64_t)in_b_len))));
        int v4836 = (((v4833 && (v4832 != UINT64_C(0))) && (v4832 < UINT64_C(64))) && (((uint64_t)((UINT64_C(46) + v4832) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4839 = ((v4745 == UINT64_C(0)) && (UINT64_C(46) != v4694));
        if (t4839) {
                uint64_t v4837 = v4832;
            int t4838 = (!(((((v4837 | UINT64_C(32)) >= UINT64_C(97)) && ((v4837 | UINT64_C(32)) <= UINT64_C(122))) || ((v4837 >= UINT64_C(48)) && (v4837 <= UINT64_C(57)))) || (v4837 == UINT64_C(45))));
            if (!t4838) {
                t4838 = ((v4832 == UINT64_C(45)) && ((UINT64_C(46) == ((v4728 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(47) == v4694)));
            }
            t4839 = t4838;
        }
        int v4840 = t4839;
        uint64_t v4841 = (v4834 ? UINT64_C(47) : (v4835 ? UINT64_C(48) : v4660));
        uint64_t v4842 = (v4835 ? (((((uint64_t)(v4832 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(47)]))) : v4711);
        uint64_t v4843 = (v4836 ? ((v4677 + UINT64_C(1)) & UINT64_C(255)) : v4677);
        uint64_t v4844 = (v4836 ? UINT64_C(46) : v4728);
        uint64_t v4845 = (v4836 ? ((uint64_t)((UINT64_C(47) + v4832) & UINT64_C(255))) : v4694);
        uint64_t v4846 = ((v4834 || v4835) ? UINT64_C(1) : ((v4840 || (v4833 && (!v4836))) ? UINT64_C(2) : v4745));
        t4847 = v4846;
    } else {
        t4847 = v4745;
    }
    uint64_t v4848 = t4847;
    int v4849 = (UINT64_C(47) < v7);
    uint64_t t4865;
    if (v4849) {
        uint64_t v4850 = ((uint64_t)in_b[UINT64_C(47)]);
        int v4851 = ((v4848 == UINT64_C(0)) && (UINT64_C(47) == v4797));
        int v4852 = (v4851 && (v4850 == UINT64_C(0)));
        int v4853 = ((v4851 && ((v4850 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(48) < ((uint64_t)((uint64_t)in_b_len))));
        int v4854 = (((v4851 && (v4850 != UINT64_C(0))) && (v4850 < UINT64_C(64))) && (((uint64_t)((UINT64_C(47) + v4850) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4857 = ((v4848 == UINT64_C(0)) && (UINT64_C(47) != v4797));
        if (t4857) {
                uint64_t v4855 = v4850;
            int t4856 = (!(((((v4855 | UINT64_C(32)) >= UINT64_C(97)) && ((v4855 | UINT64_C(32)) <= UINT64_C(122))) || ((v4855 >= UINT64_C(48)) && (v4855 <= UINT64_C(57)))) || (v4855 == UINT64_C(45))));
            if (!t4856) {
                t4856 = ((v4850 == UINT64_C(45)) && ((UINT64_C(47) == ((v4831 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(48) == v4797)));
            }
            t4857 = t4856;
        }
        int v4858 = t4857;
        uint64_t v4859 = (v4852 ? UINT64_C(48) : (v4853 ? UINT64_C(49) : v4763));
        uint64_t v4860 = (v4853 ? (((((uint64_t)(v4850 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(48)]))) : v4814);
        uint64_t v4861 = (v4854 ? ((v4780 + UINT64_C(1)) & UINT64_C(255)) : v4780);
        uint64_t v4862 = (v4854 ? UINT64_C(47) : v4831);
        uint64_t v4863 = (v4854 ? ((uint64_t)((UINT64_C(48) + v4850) & UINT64_C(255))) : v4797);
        uint64_t v4864 = ((v4852 || v4853) ? UINT64_C(1) : ((v4858 || (v4851 && (!v4854))) ? UINT64_C(2) : v4848));
        t4865 = v4859;
    } else {
        t4865 = v4763;
    }
    uint64_t v4866 = t4865;
    uint64_t t4882;
    if (v4849) {
        uint64_t v4867 = ((uint64_t)in_b[UINT64_C(47)]);
        int v4868 = ((v4848 == UINT64_C(0)) && (UINT64_C(47) == v4797));
        int v4869 = (v4868 && (v4867 == UINT64_C(0)));
        int v4870 = ((v4868 && ((v4867 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(48) < ((uint64_t)((uint64_t)in_b_len))));
        int v4871 = (((v4868 && (v4867 != UINT64_C(0))) && (v4867 < UINT64_C(64))) && (((uint64_t)((UINT64_C(47) + v4867) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4874 = ((v4848 == UINT64_C(0)) && (UINT64_C(47) != v4797));
        if (t4874) {
                uint64_t v4872 = v4867;
            int t4873 = (!(((((v4872 | UINT64_C(32)) >= UINT64_C(97)) && ((v4872 | UINT64_C(32)) <= UINT64_C(122))) || ((v4872 >= UINT64_C(48)) && (v4872 <= UINT64_C(57)))) || (v4872 == UINT64_C(45))));
            if (!t4873) {
                t4873 = ((v4867 == UINT64_C(45)) && ((UINT64_C(47) == ((v4831 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(48) == v4797)));
            }
            t4874 = t4873;
        }
        int v4875 = t4874;
        uint64_t v4876 = (v4869 ? UINT64_C(48) : (v4870 ? UINT64_C(49) : v4763));
        uint64_t v4877 = (v4870 ? (((((uint64_t)(v4867 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(48)]))) : v4814);
        uint64_t v4878 = (v4871 ? ((v4780 + UINT64_C(1)) & UINT64_C(255)) : v4780);
        uint64_t v4879 = (v4871 ? UINT64_C(47) : v4831);
        uint64_t v4880 = (v4871 ? ((uint64_t)((UINT64_C(48) + v4867) & UINT64_C(255))) : v4797);
        uint64_t v4881 = ((v4869 || v4870) ? UINT64_C(1) : ((v4875 || (v4868 && (!v4871))) ? UINT64_C(2) : v4848));
        t4882 = v4878;
    } else {
        t4882 = v4780;
    }
    uint64_t v4883 = t4882;
    uint64_t t4899;
    if (v4849) {
        uint64_t v4884 = ((uint64_t)in_b[UINT64_C(47)]);
        int v4885 = ((v4848 == UINT64_C(0)) && (UINT64_C(47) == v4797));
        int v4886 = (v4885 && (v4884 == UINT64_C(0)));
        int v4887 = ((v4885 && ((v4884 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(48) < ((uint64_t)((uint64_t)in_b_len))));
        int v4888 = (((v4885 && (v4884 != UINT64_C(0))) && (v4884 < UINT64_C(64))) && (((uint64_t)((UINT64_C(47) + v4884) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4891 = ((v4848 == UINT64_C(0)) && (UINT64_C(47) != v4797));
        if (t4891) {
                uint64_t v4889 = v4884;
            int t4890 = (!(((((v4889 | UINT64_C(32)) >= UINT64_C(97)) && ((v4889 | UINT64_C(32)) <= UINT64_C(122))) || ((v4889 >= UINT64_C(48)) && (v4889 <= UINT64_C(57)))) || (v4889 == UINT64_C(45))));
            if (!t4890) {
                t4890 = ((v4884 == UINT64_C(45)) && ((UINT64_C(47) == ((v4831 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(48) == v4797)));
            }
            t4891 = t4890;
        }
        int v4892 = t4891;
        uint64_t v4893 = (v4886 ? UINT64_C(48) : (v4887 ? UINT64_C(49) : v4763));
        uint64_t v4894 = (v4887 ? (((((uint64_t)(v4884 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(48)]))) : v4814);
        uint64_t v4895 = (v4888 ? ((v4780 + UINT64_C(1)) & UINT64_C(255)) : v4780);
        uint64_t v4896 = (v4888 ? UINT64_C(47) : v4831);
        uint64_t v4897 = (v4888 ? ((uint64_t)((UINT64_C(48) + v4884) & UINT64_C(255))) : v4797);
        uint64_t v4898 = ((v4886 || v4887) ? UINT64_C(1) : ((v4892 || (v4885 && (!v4888))) ? UINT64_C(2) : v4848));
        t4899 = v4897;
    } else {
        t4899 = v4797;
    }
    uint64_t v4900 = t4899;
    uint64_t t4916;
    if (v4849) {
        uint64_t v4901 = ((uint64_t)in_b[UINT64_C(47)]);
        int v4902 = ((v4848 == UINT64_C(0)) && (UINT64_C(47) == v4797));
        int v4903 = (v4902 && (v4901 == UINT64_C(0)));
        int v4904 = ((v4902 && ((v4901 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(48) < ((uint64_t)((uint64_t)in_b_len))));
        int v4905 = (((v4902 && (v4901 != UINT64_C(0))) && (v4901 < UINT64_C(64))) && (((uint64_t)((UINT64_C(47) + v4901) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4908 = ((v4848 == UINT64_C(0)) && (UINT64_C(47) != v4797));
        if (t4908) {
                uint64_t v4906 = v4901;
            int t4907 = (!(((((v4906 | UINT64_C(32)) >= UINT64_C(97)) && ((v4906 | UINT64_C(32)) <= UINT64_C(122))) || ((v4906 >= UINT64_C(48)) && (v4906 <= UINT64_C(57)))) || (v4906 == UINT64_C(45))));
            if (!t4907) {
                t4907 = ((v4901 == UINT64_C(45)) && ((UINT64_C(47) == ((v4831 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(48) == v4797)));
            }
            t4908 = t4907;
        }
        int v4909 = t4908;
        uint64_t v4910 = (v4903 ? UINT64_C(48) : (v4904 ? UINT64_C(49) : v4763));
        uint64_t v4911 = (v4904 ? (((((uint64_t)(v4901 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(48)]))) : v4814);
        uint64_t v4912 = (v4905 ? ((v4780 + UINT64_C(1)) & UINT64_C(255)) : v4780);
        uint64_t v4913 = (v4905 ? UINT64_C(47) : v4831);
        uint64_t v4914 = (v4905 ? ((uint64_t)((UINT64_C(48) + v4901) & UINT64_C(255))) : v4797);
        uint64_t v4915 = ((v4903 || v4904) ? UINT64_C(1) : ((v4909 || (v4902 && (!v4905))) ? UINT64_C(2) : v4848));
        t4916 = v4911;
    } else {
        t4916 = v4814;
    }
    uint64_t v4917 = t4916;
    uint64_t t4933;
    if (v4849) {
        uint64_t v4918 = ((uint64_t)in_b[UINT64_C(47)]);
        int v4919 = ((v4848 == UINT64_C(0)) && (UINT64_C(47) == v4797));
        int v4920 = (v4919 && (v4918 == UINT64_C(0)));
        int v4921 = ((v4919 && ((v4918 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(48) < ((uint64_t)((uint64_t)in_b_len))));
        int v4922 = (((v4919 && (v4918 != UINT64_C(0))) && (v4918 < UINT64_C(64))) && (((uint64_t)((UINT64_C(47) + v4918) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4925 = ((v4848 == UINT64_C(0)) && (UINT64_C(47) != v4797));
        if (t4925) {
                uint64_t v4923 = v4918;
            int t4924 = (!(((((v4923 | UINT64_C(32)) >= UINT64_C(97)) && ((v4923 | UINT64_C(32)) <= UINT64_C(122))) || ((v4923 >= UINT64_C(48)) && (v4923 <= UINT64_C(57)))) || (v4923 == UINT64_C(45))));
            if (!t4924) {
                t4924 = ((v4918 == UINT64_C(45)) && ((UINT64_C(47) == ((v4831 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(48) == v4797)));
            }
            t4925 = t4924;
        }
        int v4926 = t4925;
        uint64_t v4927 = (v4920 ? UINT64_C(48) : (v4921 ? UINT64_C(49) : v4763));
        uint64_t v4928 = (v4921 ? (((((uint64_t)(v4918 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(48)]))) : v4814);
        uint64_t v4929 = (v4922 ? ((v4780 + UINT64_C(1)) & UINT64_C(255)) : v4780);
        uint64_t v4930 = (v4922 ? UINT64_C(47) : v4831);
        uint64_t v4931 = (v4922 ? ((uint64_t)((UINT64_C(48) + v4918) & UINT64_C(255))) : v4797);
        uint64_t v4932 = ((v4920 || v4921) ? UINT64_C(1) : ((v4926 || (v4919 && (!v4922))) ? UINT64_C(2) : v4848));
        t4933 = v4930;
    } else {
        t4933 = v4831;
    }
    uint64_t v4934 = t4933;
    uint64_t t4950;
    if (v4849) {
        uint64_t v4935 = ((uint64_t)in_b[UINT64_C(47)]);
        int v4936 = ((v4848 == UINT64_C(0)) && (UINT64_C(47) == v4797));
        int v4937 = (v4936 && (v4935 == UINT64_C(0)));
        int v4938 = ((v4936 && ((v4935 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(48) < ((uint64_t)((uint64_t)in_b_len))));
        int v4939 = (((v4936 && (v4935 != UINT64_C(0))) && (v4935 < UINT64_C(64))) && (((uint64_t)((UINT64_C(47) + v4935) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4942 = ((v4848 == UINT64_C(0)) && (UINT64_C(47) != v4797));
        if (t4942) {
                uint64_t v4940 = v4935;
            int t4941 = (!(((((v4940 | UINT64_C(32)) >= UINT64_C(97)) && ((v4940 | UINT64_C(32)) <= UINT64_C(122))) || ((v4940 >= UINT64_C(48)) && (v4940 <= UINT64_C(57)))) || (v4940 == UINT64_C(45))));
            if (!t4941) {
                t4941 = ((v4935 == UINT64_C(45)) && ((UINT64_C(47) == ((v4831 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(48) == v4797)));
            }
            t4942 = t4941;
        }
        int v4943 = t4942;
        uint64_t v4944 = (v4937 ? UINT64_C(48) : (v4938 ? UINT64_C(49) : v4763));
        uint64_t v4945 = (v4938 ? (((((uint64_t)(v4935 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(48)]))) : v4814);
        uint64_t v4946 = (v4939 ? ((v4780 + UINT64_C(1)) & UINT64_C(255)) : v4780);
        uint64_t v4947 = (v4939 ? UINT64_C(47) : v4831);
        uint64_t v4948 = (v4939 ? ((uint64_t)((UINT64_C(48) + v4935) & UINT64_C(255))) : v4797);
        uint64_t v4949 = ((v4937 || v4938) ? UINT64_C(1) : ((v4943 || (v4936 && (!v4939))) ? UINT64_C(2) : v4848));
        t4950 = v4949;
    } else {
        t4950 = v4848;
    }
    uint64_t v4951 = t4950;
    int v4952 = (UINT64_C(48) < v7);
    uint64_t t4968;
    if (v4952) {
        uint64_t v4953 = ((uint64_t)in_b[UINT64_C(48)]);
        int v4954 = ((v4951 == UINT64_C(0)) && (UINT64_C(48) == v4900));
        int v4955 = (v4954 && (v4953 == UINT64_C(0)));
        int v4956 = ((v4954 && ((v4953 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(49) < ((uint64_t)((uint64_t)in_b_len))));
        int v4957 = (((v4954 && (v4953 != UINT64_C(0))) && (v4953 < UINT64_C(64))) && (((uint64_t)((UINT64_C(48) + v4953) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4960 = ((v4951 == UINT64_C(0)) && (UINT64_C(48) != v4900));
        if (t4960) {
                uint64_t v4958 = v4953;
            int t4959 = (!(((((v4958 | UINT64_C(32)) >= UINT64_C(97)) && ((v4958 | UINT64_C(32)) <= UINT64_C(122))) || ((v4958 >= UINT64_C(48)) && (v4958 <= UINT64_C(57)))) || (v4958 == UINT64_C(45))));
            if (!t4959) {
                t4959 = ((v4953 == UINT64_C(45)) && ((UINT64_C(48) == ((v4934 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(49) == v4900)));
            }
            t4960 = t4959;
        }
        int v4961 = t4960;
        uint64_t v4962 = (v4955 ? UINT64_C(49) : (v4956 ? UINT64_C(50) : v4866));
        uint64_t v4963 = (v4956 ? (((((uint64_t)(v4953 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(49)]))) : v4917);
        uint64_t v4964 = (v4957 ? ((v4883 + UINT64_C(1)) & UINT64_C(255)) : v4883);
        uint64_t v4965 = (v4957 ? UINT64_C(48) : v4934);
        uint64_t v4966 = (v4957 ? ((uint64_t)((UINT64_C(49) + v4953) & UINT64_C(255))) : v4900);
        uint64_t v4967 = ((v4955 || v4956) ? UINT64_C(1) : ((v4961 || (v4954 && (!v4957))) ? UINT64_C(2) : v4951));
        t4968 = v4962;
    } else {
        t4968 = v4866;
    }
    uint64_t v4969 = t4968;
    uint64_t t4985;
    if (v4952) {
        uint64_t v4970 = ((uint64_t)in_b[UINT64_C(48)]);
        int v4971 = ((v4951 == UINT64_C(0)) && (UINT64_C(48) == v4900));
        int v4972 = (v4971 && (v4970 == UINT64_C(0)));
        int v4973 = ((v4971 && ((v4970 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(49) < ((uint64_t)((uint64_t)in_b_len))));
        int v4974 = (((v4971 && (v4970 != UINT64_C(0))) && (v4970 < UINT64_C(64))) && (((uint64_t)((UINT64_C(48) + v4970) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4977 = ((v4951 == UINT64_C(0)) && (UINT64_C(48) != v4900));
        if (t4977) {
                uint64_t v4975 = v4970;
            int t4976 = (!(((((v4975 | UINT64_C(32)) >= UINT64_C(97)) && ((v4975 | UINT64_C(32)) <= UINT64_C(122))) || ((v4975 >= UINT64_C(48)) && (v4975 <= UINT64_C(57)))) || (v4975 == UINT64_C(45))));
            if (!t4976) {
                t4976 = ((v4970 == UINT64_C(45)) && ((UINT64_C(48) == ((v4934 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(49) == v4900)));
            }
            t4977 = t4976;
        }
        int v4978 = t4977;
        uint64_t v4979 = (v4972 ? UINT64_C(49) : (v4973 ? UINT64_C(50) : v4866));
        uint64_t v4980 = (v4973 ? (((((uint64_t)(v4970 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(49)]))) : v4917);
        uint64_t v4981 = (v4974 ? ((v4883 + UINT64_C(1)) & UINT64_C(255)) : v4883);
        uint64_t v4982 = (v4974 ? UINT64_C(48) : v4934);
        uint64_t v4983 = (v4974 ? ((uint64_t)((UINT64_C(49) + v4970) & UINT64_C(255))) : v4900);
        uint64_t v4984 = ((v4972 || v4973) ? UINT64_C(1) : ((v4978 || (v4971 && (!v4974))) ? UINT64_C(2) : v4951));
        t4985 = v4981;
    } else {
        t4985 = v4883;
    }
    uint64_t v4986 = t4985;
    uint64_t t5002;
    if (v4952) {
        uint64_t v4987 = ((uint64_t)in_b[UINT64_C(48)]);
        int v4988 = ((v4951 == UINT64_C(0)) && (UINT64_C(48) == v4900));
        int v4989 = (v4988 && (v4987 == UINT64_C(0)));
        int v4990 = ((v4988 && ((v4987 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(49) < ((uint64_t)((uint64_t)in_b_len))));
        int v4991 = (((v4988 && (v4987 != UINT64_C(0))) && (v4987 < UINT64_C(64))) && (((uint64_t)((UINT64_C(48) + v4987) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t4994 = ((v4951 == UINT64_C(0)) && (UINT64_C(48) != v4900));
        if (t4994) {
                uint64_t v4992 = v4987;
            int t4993 = (!(((((v4992 | UINT64_C(32)) >= UINT64_C(97)) && ((v4992 | UINT64_C(32)) <= UINT64_C(122))) || ((v4992 >= UINT64_C(48)) && (v4992 <= UINT64_C(57)))) || (v4992 == UINT64_C(45))));
            if (!t4993) {
                t4993 = ((v4987 == UINT64_C(45)) && ((UINT64_C(48) == ((v4934 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(49) == v4900)));
            }
            t4994 = t4993;
        }
        int v4995 = t4994;
        uint64_t v4996 = (v4989 ? UINT64_C(49) : (v4990 ? UINT64_C(50) : v4866));
        uint64_t v4997 = (v4990 ? (((((uint64_t)(v4987 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(49)]))) : v4917);
        uint64_t v4998 = (v4991 ? ((v4883 + UINT64_C(1)) & UINT64_C(255)) : v4883);
        uint64_t v4999 = (v4991 ? UINT64_C(48) : v4934);
        uint64_t v5000 = (v4991 ? ((uint64_t)((UINT64_C(49) + v4987) & UINT64_C(255))) : v4900);
        uint64_t v5001 = ((v4989 || v4990) ? UINT64_C(1) : ((v4995 || (v4988 && (!v4991))) ? UINT64_C(2) : v4951));
        t5002 = v5000;
    } else {
        t5002 = v4900;
    }
    uint64_t v5003 = t5002;
    uint64_t t5019;
    if (v4952) {
        uint64_t v5004 = ((uint64_t)in_b[UINT64_C(48)]);
        int v5005 = ((v4951 == UINT64_C(0)) && (UINT64_C(48) == v4900));
        int v5006 = (v5005 && (v5004 == UINT64_C(0)));
        int v5007 = ((v5005 && ((v5004 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(49) < ((uint64_t)((uint64_t)in_b_len))));
        int v5008 = (((v5005 && (v5004 != UINT64_C(0))) && (v5004 < UINT64_C(64))) && (((uint64_t)((UINT64_C(48) + v5004) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5011 = ((v4951 == UINT64_C(0)) && (UINT64_C(48) != v4900));
        if (t5011) {
                uint64_t v5009 = v5004;
            int t5010 = (!(((((v5009 | UINT64_C(32)) >= UINT64_C(97)) && ((v5009 | UINT64_C(32)) <= UINT64_C(122))) || ((v5009 >= UINT64_C(48)) && (v5009 <= UINT64_C(57)))) || (v5009 == UINT64_C(45))));
            if (!t5010) {
                t5010 = ((v5004 == UINT64_C(45)) && ((UINT64_C(48) == ((v4934 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(49) == v4900)));
            }
            t5011 = t5010;
        }
        int v5012 = t5011;
        uint64_t v5013 = (v5006 ? UINT64_C(49) : (v5007 ? UINT64_C(50) : v4866));
        uint64_t v5014 = (v5007 ? (((((uint64_t)(v5004 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(49)]))) : v4917);
        uint64_t v5015 = (v5008 ? ((v4883 + UINT64_C(1)) & UINT64_C(255)) : v4883);
        uint64_t v5016 = (v5008 ? UINT64_C(48) : v4934);
        uint64_t v5017 = (v5008 ? ((uint64_t)((UINT64_C(49) + v5004) & UINT64_C(255))) : v4900);
        uint64_t v5018 = ((v5006 || v5007) ? UINT64_C(1) : ((v5012 || (v5005 && (!v5008))) ? UINT64_C(2) : v4951));
        t5019 = v5014;
    } else {
        t5019 = v4917;
    }
    uint64_t v5020 = t5019;
    uint64_t t5036;
    if (v4952) {
        uint64_t v5021 = ((uint64_t)in_b[UINT64_C(48)]);
        int v5022 = ((v4951 == UINT64_C(0)) && (UINT64_C(48) == v4900));
        int v5023 = (v5022 && (v5021 == UINT64_C(0)));
        int v5024 = ((v5022 && ((v5021 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(49) < ((uint64_t)((uint64_t)in_b_len))));
        int v5025 = (((v5022 && (v5021 != UINT64_C(0))) && (v5021 < UINT64_C(64))) && (((uint64_t)((UINT64_C(48) + v5021) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5028 = ((v4951 == UINT64_C(0)) && (UINT64_C(48) != v4900));
        if (t5028) {
                uint64_t v5026 = v5021;
            int t5027 = (!(((((v5026 | UINT64_C(32)) >= UINT64_C(97)) && ((v5026 | UINT64_C(32)) <= UINT64_C(122))) || ((v5026 >= UINT64_C(48)) && (v5026 <= UINT64_C(57)))) || (v5026 == UINT64_C(45))));
            if (!t5027) {
                t5027 = ((v5021 == UINT64_C(45)) && ((UINT64_C(48) == ((v4934 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(49) == v4900)));
            }
            t5028 = t5027;
        }
        int v5029 = t5028;
        uint64_t v5030 = (v5023 ? UINT64_C(49) : (v5024 ? UINT64_C(50) : v4866));
        uint64_t v5031 = (v5024 ? (((((uint64_t)(v5021 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(49)]))) : v4917);
        uint64_t v5032 = (v5025 ? ((v4883 + UINT64_C(1)) & UINT64_C(255)) : v4883);
        uint64_t v5033 = (v5025 ? UINT64_C(48) : v4934);
        uint64_t v5034 = (v5025 ? ((uint64_t)((UINT64_C(49) + v5021) & UINT64_C(255))) : v4900);
        uint64_t v5035 = ((v5023 || v5024) ? UINT64_C(1) : ((v5029 || (v5022 && (!v5025))) ? UINT64_C(2) : v4951));
        t5036 = v5033;
    } else {
        t5036 = v4934;
    }
    uint64_t v5037 = t5036;
    uint64_t t5053;
    if (v4952) {
        uint64_t v5038 = ((uint64_t)in_b[UINT64_C(48)]);
        int v5039 = ((v4951 == UINT64_C(0)) && (UINT64_C(48) == v4900));
        int v5040 = (v5039 && (v5038 == UINT64_C(0)));
        int v5041 = ((v5039 && ((v5038 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(49) < ((uint64_t)((uint64_t)in_b_len))));
        int v5042 = (((v5039 && (v5038 != UINT64_C(0))) && (v5038 < UINT64_C(64))) && (((uint64_t)((UINT64_C(48) + v5038) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5045 = ((v4951 == UINT64_C(0)) && (UINT64_C(48) != v4900));
        if (t5045) {
                uint64_t v5043 = v5038;
            int t5044 = (!(((((v5043 | UINT64_C(32)) >= UINT64_C(97)) && ((v5043 | UINT64_C(32)) <= UINT64_C(122))) || ((v5043 >= UINT64_C(48)) && (v5043 <= UINT64_C(57)))) || (v5043 == UINT64_C(45))));
            if (!t5044) {
                t5044 = ((v5038 == UINT64_C(45)) && ((UINT64_C(48) == ((v4934 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(49) == v4900)));
            }
            t5045 = t5044;
        }
        int v5046 = t5045;
        uint64_t v5047 = (v5040 ? UINT64_C(49) : (v5041 ? UINT64_C(50) : v4866));
        uint64_t v5048 = (v5041 ? (((((uint64_t)(v5038 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(49)]))) : v4917);
        uint64_t v5049 = (v5042 ? ((v4883 + UINT64_C(1)) & UINT64_C(255)) : v4883);
        uint64_t v5050 = (v5042 ? UINT64_C(48) : v4934);
        uint64_t v5051 = (v5042 ? ((uint64_t)((UINT64_C(49) + v5038) & UINT64_C(255))) : v4900);
        uint64_t v5052 = ((v5040 || v5041) ? UINT64_C(1) : ((v5046 || (v5039 && (!v5042))) ? UINT64_C(2) : v4951));
        t5053 = v5052;
    } else {
        t5053 = v4951;
    }
    uint64_t v5054 = t5053;
    int v5055 = (UINT64_C(49) < v7);
    uint64_t t5071;
    if (v5055) {
        uint64_t v5056 = ((uint64_t)in_b[UINT64_C(49)]);
        int v5057 = ((v5054 == UINT64_C(0)) && (UINT64_C(49) == v5003));
        int v5058 = (v5057 && (v5056 == UINT64_C(0)));
        int v5059 = ((v5057 && ((v5056 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(50) < ((uint64_t)((uint64_t)in_b_len))));
        int v5060 = (((v5057 && (v5056 != UINT64_C(0))) && (v5056 < UINT64_C(64))) && (((uint64_t)((UINT64_C(49) + v5056) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5063 = ((v5054 == UINT64_C(0)) && (UINT64_C(49) != v5003));
        if (t5063) {
                uint64_t v5061 = v5056;
            int t5062 = (!(((((v5061 | UINT64_C(32)) >= UINT64_C(97)) && ((v5061 | UINT64_C(32)) <= UINT64_C(122))) || ((v5061 >= UINT64_C(48)) && (v5061 <= UINT64_C(57)))) || (v5061 == UINT64_C(45))));
            if (!t5062) {
                t5062 = ((v5056 == UINT64_C(45)) && ((UINT64_C(49) == ((v5037 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(50) == v5003)));
            }
            t5063 = t5062;
        }
        int v5064 = t5063;
        uint64_t v5065 = (v5058 ? UINT64_C(50) : (v5059 ? UINT64_C(51) : v4969));
        uint64_t v5066 = (v5059 ? (((((uint64_t)(v5056 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(50)]))) : v5020);
        uint64_t v5067 = (v5060 ? ((v4986 + UINT64_C(1)) & UINT64_C(255)) : v4986);
        uint64_t v5068 = (v5060 ? UINT64_C(49) : v5037);
        uint64_t v5069 = (v5060 ? ((uint64_t)((UINT64_C(50) + v5056) & UINT64_C(255))) : v5003);
        uint64_t v5070 = ((v5058 || v5059) ? UINT64_C(1) : ((v5064 || (v5057 && (!v5060))) ? UINT64_C(2) : v5054));
        t5071 = v5065;
    } else {
        t5071 = v4969;
    }
    uint64_t v5072 = t5071;
    uint64_t t5088;
    if (v5055) {
        uint64_t v5073 = ((uint64_t)in_b[UINT64_C(49)]);
        int v5074 = ((v5054 == UINT64_C(0)) && (UINT64_C(49) == v5003));
        int v5075 = (v5074 && (v5073 == UINT64_C(0)));
        int v5076 = ((v5074 && ((v5073 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(50) < ((uint64_t)((uint64_t)in_b_len))));
        int v5077 = (((v5074 && (v5073 != UINT64_C(0))) && (v5073 < UINT64_C(64))) && (((uint64_t)((UINT64_C(49) + v5073) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5080 = ((v5054 == UINT64_C(0)) && (UINT64_C(49) != v5003));
        if (t5080) {
                uint64_t v5078 = v5073;
            int t5079 = (!(((((v5078 | UINT64_C(32)) >= UINT64_C(97)) && ((v5078 | UINT64_C(32)) <= UINT64_C(122))) || ((v5078 >= UINT64_C(48)) && (v5078 <= UINT64_C(57)))) || (v5078 == UINT64_C(45))));
            if (!t5079) {
                t5079 = ((v5073 == UINT64_C(45)) && ((UINT64_C(49) == ((v5037 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(50) == v5003)));
            }
            t5080 = t5079;
        }
        int v5081 = t5080;
        uint64_t v5082 = (v5075 ? UINT64_C(50) : (v5076 ? UINT64_C(51) : v4969));
        uint64_t v5083 = (v5076 ? (((((uint64_t)(v5073 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(50)]))) : v5020);
        uint64_t v5084 = (v5077 ? ((v4986 + UINT64_C(1)) & UINT64_C(255)) : v4986);
        uint64_t v5085 = (v5077 ? UINT64_C(49) : v5037);
        uint64_t v5086 = (v5077 ? ((uint64_t)((UINT64_C(50) + v5073) & UINT64_C(255))) : v5003);
        uint64_t v5087 = ((v5075 || v5076) ? UINT64_C(1) : ((v5081 || (v5074 && (!v5077))) ? UINT64_C(2) : v5054));
        t5088 = v5084;
    } else {
        t5088 = v4986;
    }
    uint64_t v5089 = t5088;
    uint64_t t5105;
    if (v5055) {
        uint64_t v5090 = ((uint64_t)in_b[UINT64_C(49)]);
        int v5091 = ((v5054 == UINT64_C(0)) && (UINT64_C(49) == v5003));
        int v5092 = (v5091 && (v5090 == UINT64_C(0)));
        int v5093 = ((v5091 && ((v5090 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(50) < ((uint64_t)((uint64_t)in_b_len))));
        int v5094 = (((v5091 && (v5090 != UINT64_C(0))) && (v5090 < UINT64_C(64))) && (((uint64_t)((UINT64_C(49) + v5090) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5097 = ((v5054 == UINT64_C(0)) && (UINT64_C(49) != v5003));
        if (t5097) {
                uint64_t v5095 = v5090;
            int t5096 = (!(((((v5095 | UINT64_C(32)) >= UINT64_C(97)) && ((v5095 | UINT64_C(32)) <= UINT64_C(122))) || ((v5095 >= UINT64_C(48)) && (v5095 <= UINT64_C(57)))) || (v5095 == UINT64_C(45))));
            if (!t5096) {
                t5096 = ((v5090 == UINT64_C(45)) && ((UINT64_C(49) == ((v5037 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(50) == v5003)));
            }
            t5097 = t5096;
        }
        int v5098 = t5097;
        uint64_t v5099 = (v5092 ? UINT64_C(50) : (v5093 ? UINT64_C(51) : v4969));
        uint64_t v5100 = (v5093 ? (((((uint64_t)(v5090 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(50)]))) : v5020);
        uint64_t v5101 = (v5094 ? ((v4986 + UINT64_C(1)) & UINT64_C(255)) : v4986);
        uint64_t v5102 = (v5094 ? UINT64_C(49) : v5037);
        uint64_t v5103 = (v5094 ? ((uint64_t)((UINT64_C(50) + v5090) & UINT64_C(255))) : v5003);
        uint64_t v5104 = ((v5092 || v5093) ? UINT64_C(1) : ((v5098 || (v5091 && (!v5094))) ? UINT64_C(2) : v5054));
        t5105 = v5103;
    } else {
        t5105 = v5003;
    }
    uint64_t v5106 = t5105;
    uint64_t t5122;
    if (v5055) {
        uint64_t v5107 = ((uint64_t)in_b[UINT64_C(49)]);
        int v5108 = ((v5054 == UINT64_C(0)) && (UINT64_C(49) == v5003));
        int v5109 = (v5108 && (v5107 == UINT64_C(0)));
        int v5110 = ((v5108 && ((v5107 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(50) < ((uint64_t)((uint64_t)in_b_len))));
        int v5111 = (((v5108 && (v5107 != UINT64_C(0))) && (v5107 < UINT64_C(64))) && (((uint64_t)((UINT64_C(49) + v5107) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5114 = ((v5054 == UINT64_C(0)) && (UINT64_C(49) != v5003));
        if (t5114) {
                uint64_t v5112 = v5107;
            int t5113 = (!(((((v5112 | UINT64_C(32)) >= UINT64_C(97)) && ((v5112 | UINT64_C(32)) <= UINT64_C(122))) || ((v5112 >= UINT64_C(48)) && (v5112 <= UINT64_C(57)))) || (v5112 == UINT64_C(45))));
            if (!t5113) {
                t5113 = ((v5107 == UINT64_C(45)) && ((UINT64_C(49) == ((v5037 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(50) == v5003)));
            }
            t5114 = t5113;
        }
        int v5115 = t5114;
        uint64_t v5116 = (v5109 ? UINT64_C(50) : (v5110 ? UINT64_C(51) : v4969));
        uint64_t v5117 = (v5110 ? (((((uint64_t)(v5107 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(50)]))) : v5020);
        uint64_t v5118 = (v5111 ? ((v4986 + UINT64_C(1)) & UINT64_C(255)) : v4986);
        uint64_t v5119 = (v5111 ? UINT64_C(49) : v5037);
        uint64_t v5120 = (v5111 ? ((uint64_t)((UINT64_C(50) + v5107) & UINT64_C(255))) : v5003);
        uint64_t v5121 = ((v5109 || v5110) ? UINT64_C(1) : ((v5115 || (v5108 && (!v5111))) ? UINT64_C(2) : v5054));
        t5122 = v5117;
    } else {
        t5122 = v5020;
    }
    uint64_t v5123 = t5122;
    uint64_t t5139;
    if (v5055) {
        uint64_t v5124 = ((uint64_t)in_b[UINT64_C(49)]);
        int v5125 = ((v5054 == UINT64_C(0)) && (UINT64_C(49) == v5003));
        int v5126 = (v5125 && (v5124 == UINT64_C(0)));
        int v5127 = ((v5125 && ((v5124 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(50) < ((uint64_t)((uint64_t)in_b_len))));
        int v5128 = (((v5125 && (v5124 != UINT64_C(0))) && (v5124 < UINT64_C(64))) && (((uint64_t)((UINT64_C(49) + v5124) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5131 = ((v5054 == UINT64_C(0)) && (UINT64_C(49) != v5003));
        if (t5131) {
                uint64_t v5129 = v5124;
            int t5130 = (!(((((v5129 | UINT64_C(32)) >= UINT64_C(97)) && ((v5129 | UINT64_C(32)) <= UINT64_C(122))) || ((v5129 >= UINT64_C(48)) && (v5129 <= UINT64_C(57)))) || (v5129 == UINT64_C(45))));
            if (!t5130) {
                t5130 = ((v5124 == UINT64_C(45)) && ((UINT64_C(49) == ((v5037 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(50) == v5003)));
            }
            t5131 = t5130;
        }
        int v5132 = t5131;
        uint64_t v5133 = (v5126 ? UINT64_C(50) : (v5127 ? UINT64_C(51) : v4969));
        uint64_t v5134 = (v5127 ? (((((uint64_t)(v5124 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(50)]))) : v5020);
        uint64_t v5135 = (v5128 ? ((v4986 + UINT64_C(1)) & UINT64_C(255)) : v4986);
        uint64_t v5136 = (v5128 ? UINT64_C(49) : v5037);
        uint64_t v5137 = (v5128 ? ((uint64_t)((UINT64_C(50) + v5124) & UINT64_C(255))) : v5003);
        uint64_t v5138 = ((v5126 || v5127) ? UINT64_C(1) : ((v5132 || (v5125 && (!v5128))) ? UINT64_C(2) : v5054));
        t5139 = v5136;
    } else {
        t5139 = v5037;
    }
    uint64_t v5140 = t5139;
    uint64_t t5156;
    if (v5055) {
        uint64_t v5141 = ((uint64_t)in_b[UINT64_C(49)]);
        int v5142 = ((v5054 == UINT64_C(0)) && (UINT64_C(49) == v5003));
        int v5143 = (v5142 && (v5141 == UINT64_C(0)));
        int v5144 = ((v5142 && ((v5141 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(50) < ((uint64_t)((uint64_t)in_b_len))));
        int v5145 = (((v5142 && (v5141 != UINT64_C(0))) && (v5141 < UINT64_C(64))) && (((uint64_t)((UINT64_C(49) + v5141) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5148 = ((v5054 == UINT64_C(0)) && (UINT64_C(49) != v5003));
        if (t5148) {
                uint64_t v5146 = v5141;
            int t5147 = (!(((((v5146 | UINT64_C(32)) >= UINT64_C(97)) && ((v5146 | UINT64_C(32)) <= UINT64_C(122))) || ((v5146 >= UINT64_C(48)) && (v5146 <= UINT64_C(57)))) || (v5146 == UINT64_C(45))));
            if (!t5147) {
                t5147 = ((v5141 == UINT64_C(45)) && ((UINT64_C(49) == ((v5037 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(50) == v5003)));
            }
            t5148 = t5147;
        }
        int v5149 = t5148;
        uint64_t v5150 = (v5143 ? UINT64_C(50) : (v5144 ? UINT64_C(51) : v4969));
        uint64_t v5151 = (v5144 ? (((((uint64_t)(v5141 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(50)]))) : v5020);
        uint64_t v5152 = (v5145 ? ((v4986 + UINT64_C(1)) & UINT64_C(255)) : v4986);
        uint64_t v5153 = (v5145 ? UINT64_C(49) : v5037);
        uint64_t v5154 = (v5145 ? ((uint64_t)((UINT64_C(50) + v5141) & UINT64_C(255))) : v5003);
        uint64_t v5155 = ((v5143 || v5144) ? UINT64_C(1) : ((v5149 || (v5142 && (!v5145))) ? UINT64_C(2) : v5054));
        t5156 = v5155;
    } else {
        t5156 = v5054;
    }
    uint64_t v5157 = t5156;
    int v5158 = (UINT64_C(50) < v7);
    uint64_t t5174;
    if (v5158) {
        uint64_t v5159 = ((uint64_t)in_b[UINT64_C(50)]);
        int v5160 = ((v5157 == UINT64_C(0)) && (UINT64_C(50) == v5106));
        int v5161 = (v5160 && (v5159 == UINT64_C(0)));
        int v5162 = ((v5160 && ((v5159 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(51) < ((uint64_t)((uint64_t)in_b_len))));
        int v5163 = (((v5160 && (v5159 != UINT64_C(0))) && (v5159 < UINT64_C(64))) && (((uint64_t)((UINT64_C(50) + v5159) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5166 = ((v5157 == UINT64_C(0)) && (UINT64_C(50) != v5106));
        if (t5166) {
                uint64_t v5164 = v5159;
            int t5165 = (!(((((v5164 | UINT64_C(32)) >= UINT64_C(97)) && ((v5164 | UINT64_C(32)) <= UINT64_C(122))) || ((v5164 >= UINT64_C(48)) && (v5164 <= UINT64_C(57)))) || (v5164 == UINT64_C(45))));
            if (!t5165) {
                t5165 = ((v5159 == UINT64_C(45)) && ((UINT64_C(50) == ((v5140 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(51) == v5106)));
            }
            t5166 = t5165;
        }
        int v5167 = t5166;
        uint64_t v5168 = (v5161 ? UINT64_C(51) : (v5162 ? UINT64_C(52) : v5072));
        uint64_t v5169 = (v5162 ? (((((uint64_t)(v5159 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(51)]))) : v5123);
        uint64_t v5170 = (v5163 ? ((v5089 + UINT64_C(1)) & UINT64_C(255)) : v5089);
        uint64_t v5171 = (v5163 ? UINT64_C(50) : v5140);
        uint64_t v5172 = (v5163 ? ((uint64_t)((UINT64_C(51) + v5159) & UINT64_C(255))) : v5106);
        uint64_t v5173 = ((v5161 || v5162) ? UINT64_C(1) : ((v5167 || (v5160 && (!v5163))) ? UINT64_C(2) : v5157));
        t5174 = v5168;
    } else {
        t5174 = v5072;
    }
    uint64_t v5175 = t5174;
    uint64_t t5191;
    if (v5158) {
        uint64_t v5176 = ((uint64_t)in_b[UINT64_C(50)]);
        int v5177 = ((v5157 == UINT64_C(0)) && (UINT64_C(50) == v5106));
        int v5178 = (v5177 && (v5176 == UINT64_C(0)));
        int v5179 = ((v5177 && ((v5176 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(51) < ((uint64_t)((uint64_t)in_b_len))));
        int v5180 = (((v5177 && (v5176 != UINT64_C(0))) && (v5176 < UINT64_C(64))) && (((uint64_t)((UINT64_C(50) + v5176) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5183 = ((v5157 == UINT64_C(0)) && (UINT64_C(50) != v5106));
        if (t5183) {
                uint64_t v5181 = v5176;
            int t5182 = (!(((((v5181 | UINT64_C(32)) >= UINT64_C(97)) && ((v5181 | UINT64_C(32)) <= UINT64_C(122))) || ((v5181 >= UINT64_C(48)) && (v5181 <= UINT64_C(57)))) || (v5181 == UINT64_C(45))));
            if (!t5182) {
                t5182 = ((v5176 == UINT64_C(45)) && ((UINT64_C(50) == ((v5140 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(51) == v5106)));
            }
            t5183 = t5182;
        }
        int v5184 = t5183;
        uint64_t v5185 = (v5178 ? UINT64_C(51) : (v5179 ? UINT64_C(52) : v5072));
        uint64_t v5186 = (v5179 ? (((((uint64_t)(v5176 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(51)]))) : v5123);
        uint64_t v5187 = (v5180 ? ((v5089 + UINT64_C(1)) & UINT64_C(255)) : v5089);
        uint64_t v5188 = (v5180 ? UINT64_C(50) : v5140);
        uint64_t v5189 = (v5180 ? ((uint64_t)((UINT64_C(51) + v5176) & UINT64_C(255))) : v5106);
        uint64_t v5190 = ((v5178 || v5179) ? UINT64_C(1) : ((v5184 || (v5177 && (!v5180))) ? UINT64_C(2) : v5157));
        t5191 = v5187;
    } else {
        t5191 = v5089;
    }
    uint64_t v5192 = t5191;
    uint64_t t5208;
    if (v5158) {
        uint64_t v5193 = ((uint64_t)in_b[UINT64_C(50)]);
        int v5194 = ((v5157 == UINT64_C(0)) && (UINT64_C(50) == v5106));
        int v5195 = (v5194 && (v5193 == UINT64_C(0)));
        int v5196 = ((v5194 && ((v5193 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(51) < ((uint64_t)((uint64_t)in_b_len))));
        int v5197 = (((v5194 && (v5193 != UINT64_C(0))) && (v5193 < UINT64_C(64))) && (((uint64_t)((UINT64_C(50) + v5193) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5200 = ((v5157 == UINT64_C(0)) && (UINT64_C(50) != v5106));
        if (t5200) {
                uint64_t v5198 = v5193;
            int t5199 = (!(((((v5198 | UINT64_C(32)) >= UINT64_C(97)) && ((v5198 | UINT64_C(32)) <= UINT64_C(122))) || ((v5198 >= UINT64_C(48)) && (v5198 <= UINT64_C(57)))) || (v5198 == UINT64_C(45))));
            if (!t5199) {
                t5199 = ((v5193 == UINT64_C(45)) && ((UINT64_C(50) == ((v5140 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(51) == v5106)));
            }
            t5200 = t5199;
        }
        int v5201 = t5200;
        uint64_t v5202 = (v5195 ? UINT64_C(51) : (v5196 ? UINT64_C(52) : v5072));
        uint64_t v5203 = (v5196 ? (((((uint64_t)(v5193 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(51)]))) : v5123);
        uint64_t v5204 = (v5197 ? ((v5089 + UINT64_C(1)) & UINT64_C(255)) : v5089);
        uint64_t v5205 = (v5197 ? UINT64_C(50) : v5140);
        uint64_t v5206 = (v5197 ? ((uint64_t)((UINT64_C(51) + v5193) & UINT64_C(255))) : v5106);
        uint64_t v5207 = ((v5195 || v5196) ? UINT64_C(1) : ((v5201 || (v5194 && (!v5197))) ? UINT64_C(2) : v5157));
        t5208 = v5206;
    } else {
        t5208 = v5106;
    }
    uint64_t v5209 = t5208;
    uint64_t t5225;
    if (v5158) {
        uint64_t v5210 = ((uint64_t)in_b[UINT64_C(50)]);
        int v5211 = ((v5157 == UINT64_C(0)) && (UINT64_C(50) == v5106));
        int v5212 = (v5211 && (v5210 == UINT64_C(0)));
        int v5213 = ((v5211 && ((v5210 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(51) < ((uint64_t)((uint64_t)in_b_len))));
        int v5214 = (((v5211 && (v5210 != UINT64_C(0))) && (v5210 < UINT64_C(64))) && (((uint64_t)((UINT64_C(50) + v5210) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5217 = ((v5157 == UINT64_C(0)) && (UINT64_C(50) != v5106));
        if (t5217) {
                uint64_t v5215 = v5210;
            int t5216 = (!(((((v5215 | UINT64_C(32)) >= UINT64_C(97)) && ((v5215 | UINT64_C(32)) <= UINT64_C(122))) || ((v5215 >= UINT64_C(48)) && (v5215 <= UINT64_C(57)))) || (v5215 == UINT64_C(45))));
            if (!t5216) {
                t5216 = ((v5210 == UINT64_C(45)) && ((UINT64_C(50) == ((v5140 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(51) == v5106)));
            }
            t5217 = t5216;
        }
        int v5218 = t5217;
        uint64_t v5219 = (v5212 ? UINT64_C(51) : (v5213 ? UINT64_C(52) : v5072));
        uint64_t v5220 = (v5213 ? (((((uint64_t)(v5210 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(51)]))) : v5123);
        uint64_t v5221 = (v5214 ? ((v5089 + UINT64_C(1)) & UINT64_C(255)) : v5089);
        uint64_t v5222 = (v5214 ? UINT64_C(50) : v5140);
        uint64_t v5223 = (v5214 ? ((uint64_t)((UINT64_C(51) + v5210) & UINT64_C(255))) : v5106);
        uint64_t v5224 = ((v5212 || v5213) ? UINT64_C(1) : ((v5218 || (v5211 && (!v5214))) ? UINT64_C(2) : v5157));
        t5225 = v5220;
    } else {
        t5225 = v5123;
    }
    uint64_t v5226 = t5225;
    uint64_t t5242;
    if (v5158) {
        uint64_t v5227 = ((uint64_t)in_b[UINT64_C(50)]);
        int v5228 = ((v5157 == UINT64_C(0)) && (UINT64_C(50) == v5106));
        int v5229 = (v5228 && (v5227 == UINT64_C(0)));
        int v5230 = ((v5228 && ((v5227 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(51) < ((uint64_t)((uint64_t)in_b_len))));
        int v5231 = (((v5228 && (v5227 != UINT64_C(0))) && (v5227 < UINT64_C(64))) && (((uint64_t)((UINT64_C(50) + v5227) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5234 = ((v5157 == UINT64_C(0)) && (UINT64_C(50) != v5106));
        if (t5234) {
                uint64_t v5232 = v5227;
            int t5233 = (!(((((v5232 | UINT64_C(32)) >= UINT64_C(97)) && ((v5232 | UINT64_C(32)) <= UINT64_C(122))) || ((v5232 >= UINT64_C(48)) && (v5232 <= UINT64_C(57)))) || (v5232 == UINT64_C(45))));
            if (!t5233) {
                t5233 = ((v5227 == UINT64_C(45)) && ((UINT64_C(50) == ((v5140 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(51) == v5106)));
            }
            t5234 = t5233;
        }
        int v5235 = t5234;
        uint64_t v5236 = (v5229 ? UINT64_C(51) : (v5230 ? UINT64_C(52) : v5072));
        uint64_t v5237 = (v5230 ? (((((uint64_t)(v5227 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(51)]))) : v5123);
        uint64_t v5238 = (v5231 ? ((v5089 + UINT64_C(1)) & UINT64_C(255)) : v5089);
        uint64_t v5239 = (v5231 ? UINT64_C(50) : v5140);
        uint64_t v5240 = (v5231 ? ((uint64_t)((UINT64_C(51) + v5227) & UINT64_C(255))) : v5106);
        uint64_t v5241 = ((v5229 || v5230) ? UINT64_C(1) : ((v5235 || (v5228 && (!v5231))) ? UINT64_C(2) : v5157));
        t5242 = v5239;
    } else {
        t5242 = v5140;
    }
    uint64_t v5243 = t5242;
    uint64_t t5259;
    if (v5158) {
        uint64_t v5244 = ((uint64_t)in_b[UINT64_C(50)]);
        int v5245 = ((v5157 == UINT64_C(0)) && (UINT64_C(50) == v5106));
        int v5246 = (v5245 && (v5244 == UINT64_C(0)));
        int v5247 = ((v5245 && ((v5244 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(51) < ((uint64_t)((uint64_t)in_b_len))));
        int v5248 = (((v5245 && (v5244 != UINT64_C(0))) && (v5244 < UINT64_C(64))) && (((uint64_t)((UINT64_C(50) + v5244) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5251 = ((v5157 == UINT64_C(0)) && (UINT64_C(50) != v5106));
        if (t5251) {
                uint64_t v5249 = v5244;
            int t5250 = (!(((((v5249 | UINT64_C(32)) >= UINT64_C(97)) && ((v5249 | UINT64_C(32)) <= UINT64_C(122))) || ((v5249 >= UINT64_C(48)) && (v5249 <= UINT64_C(57)))) || (v5249 == UINT64_C(45))));
            if (!t5250) {
                t5250 = ((v5244 == UINT64_C(45)) && ((UINT64_C(50) == ((v5140 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(51) == v5106)));
            }
            t5251 = t5250;
        }
        int v5252 = t5251;
        uint64_t v5253 = (v5246 ? UINT64_C(51) : (v5247 ? UINT64_C(52) : v5072));
        uint64_t v5254 = (v5247 ? (((((uint64_t)(v5244 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(51)]))) : v5123);
        uint64_t v5255 = (v5248 ? ((v5089 + UINT64_C(1)) & UINT64_C(255)) : v5089);
        uint64_t v5256 = (v5248 ? UINT64_C(50) : v5140);
        uint64_t v5257 = (v5248 ? ((uint64_t)((UINT64_C(51) + v5244) & UINT64_C(255))) : v5106);
        uint64_t v5258 = ((v5246 || v5247) ? UINT64_C(1) : ((v5252 || (v5245 && (!v5248))) ? UINT64_C(2) : v5157));
        t5259 = v5258;
    } else {
        t5259 = v5157;
    }
    uint64_t v5260 = t5259;
    int v5261 = (UINT64_C(51) < v7);
    uint64_t t5277;
    if (v5261) {
        uint64_t v5262 = ((uint64_t)in_b[UINT64_C(51)]);
        int v5263 = ((v5260 == UINT64_C(0)) && (UINT64_C(51) == v5209));
        int v5264 = (v5263 && (v5262 == UINT64_C(0)));
        int v5265 = ((v5263 && ((v5262 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(52) < ((uint64_t)((uint64_t)in_b_len))));
        int v5266 = (((v5263 && (v5262 != UINT64_C(0))) && (v5262 < UINT64_C(64))) && (((uint64_t)((UINT64_C(51) + v5262) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5269 = ((v5260 == UINT64_C(0)) && (UINT64_C(51) != v5209));
        if (t5269) {
                uint64_t v5267 = v5262;
            int t5268 = (!(((((v5267 | UINT64_C(32)) >= UINT64_C(97)) && ((v5267 | UINT64_C(32)) <= UINT64_C(122))) || ((v5267 >= UINT64_C(48)) && (v5267 <= UINT64_C(57)))) || (v5267 == UINT64_C(45))));
            if (!t5268) {
                t5268 = ((v5262 == UINT64_C(45)) && ((UINT64_C(51) == ((v5243 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(52) == v5209)));
            }
            t5269 = t5268;
        }
        int v5270 = t5269;
        uint64_t v5271 = (v5264 ? UINT64_C(52) : (v5265 ? UINT64_C(53) : v5175));
        uint64_t v5272 = (v5265 ? (((((uint64_t)(v5262 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(52)]))) : v5226);
        uint64_t v5273 = (v5266 ? ((v5192 + UINT64_C(1)) & UINT64_C(255)) : v5192);
        uint64_t v5274 = (v5266 ? UINT64_C(51) : v5243);
        uint64_t v5275 = (v5266 ? ((uint64_t)((UINT64_C(52) + v5262) & UINT64_C(255))) : v5209);
        uint64_t v5276 = ((v5264 || v5265) ? UINT64_C(1) : ((v5270 || (v5263 && (!v5266))) ? UINT64_C(2) : v5260));
        t5277 = v5271;
    } else {
        t5277 = v5175;
    }
    uint64_t v5278 = t5277;
    uint64_t t5294;
    if (v5261) {
        uint64_t v5279 = ((uint64_t)in_b[UINT64_C(51)]);
        int v5280 = ((v5260 == UINT64_C(0)) && (UINT64_C(51) == v5209));
        int v5281 = (v5280 && (v5279 == UINT64_C(0)));
        int v5282 = ((v5280 && ((v5279 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(52) < ((uint64_t)((uint64_t)in_b_len))));
        int v5283 = (((v5280 && (v5279 != UINT64_C(0))) && (v5279 < UINT64_C(64))) && (((uint64_t)((UINT64_C(51) + v5279) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5286 = ((v5260 == UINT64_C(0)) && (UINT64_C(51) != v5209));
        if (t5286) {
                uint64_t v5284 = v5279;
            int t5285 = (!(((((v5284 | UINT64_C(32)) >= UINT64_C(97)) && ((v5284 | UINT64_C(32)) <= UINT64_C(122))) || ((v5284 >= UINT64_C(48)) && (v5284 <= UINT64_C(57)))) || (v5284 == UINT64_C(45))));
            if (!t5285) {
                t5285 = ((v5279 == UINT64_C(45)) && ((UINT64_C(51) == ((v5243 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(52) == v5209)));
            }
            t5286 = t5285;
        }
        int v5287 = t5286;
        uint64_t v5288 = (v5281 ? UINT64_C(52) : (v5282 ? UINT64_C(53) : v5175));
        uint64_t v5289 = (v5282 ? (((((uint64_t)(v5279 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(52)]))) : v5226);
        uint64_t v5290 = (v5283 ? ((v5192 + UINT64_C(1)) & UINT64_C(255)) : v5192);
        uint64_t v5291 = (v5283 ? UINT64_C(51) : v5243);
        uint64_t v5292 = (v5283 ? ((uint64_t)((UINT64_C(52) + v5279) & UINT64_C(255))) : v5209);
        uint64_t v5293 = ((v5281 || v5282) ? UINT64_C(1) : ((v5287 || (v5280 && (!v5283))) ? UINT64_C(2) : v5260));
        t5294 = v5290;
    } else {
        t5294 = v5192;
    }
    uint64_t v5295 = t5294;
    uint64_t t5311;
    if (v5261) {
        uint64_t v5296 = ((uint64_t)in_b[UINT64_C(51)]);
        int v5297 = ((v5260 == UINT64_C(0)) && (UINT64_C(51) == v5209));
        int v5298 = (v5297 && (v5296 == UINT64_C(0)));
        int v5299 = ((v5297 && ((v5296 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(52) < ((uint64_t)((uint64_t)in_b_len))));
        int v5300 = (((v5297 && (v5296 != UINT64_C(0))) && (v5296 < UINT64_C(64))) && (((uint64_t)((UINT64_C(51) + v5296) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5303 = ((v5260 == UINT64_C(0)) && (UINT64_C(51) != v5209));
        if (t5303) {
                uint64_t v5301 = v5296;
            int t5302 = (!(((((v5301 | UINT64_C(32)) >= UINT64_C(97)) && ((v5301 | UINT64_C(32)) <= UINT64_C(122))) || ((v5301 >= UINT64_C(48)) && (v5301 <= UINT64_C(57)))) || (v5301 == UINT64_C(45))));
            if (!t5302) {
                t5302 = ((v5296 == UINT64_C(45)) && ((UINT64_C(51) == ((v5243 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(52) == v5209)));
            }
            t5303 = t5302;
        }
        int v5304 = t5303;
        uint64_t v5305 = (v5298 ? UINT64_C(52) : (v5299 ? UINT64_C(53) : v5175));
        uint64_t v5306 = (v5299 ? (((((uint64_t)(v5296 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(52)]))) : v5226);
        uint64_t v5307 = (v5300 ? ((v5192 + UINT64_C(1)) & UINT64_C(255)) : v5192);
        uint64_t v5308 = (v5300 ? UINT64_C(51) : v5243);
        uint64_t v5309 = (v5300 ? ((uint64_t)((UINT64_C(52) + v5296) & UINT64_C(255))) : v5209);
        uint64_t v5310 = ((v5298 || v5299) ? UINT64_C(1) : ((v5304 || (v5297 && (!v5300))) ? UINT64_C(2) : v5260));
        t5311 = v5309;
    } else {
        t5311 = v5209;
    }
    uint64_t v5312 = t5311;
    uint64_t t5328;
    if (v5261) {
        uint64_t v5313 = ((uint64_t)in_b[UINT64_C(51)]);
        int v5314 = ((v5260 == UINT64_C(0)) && (UINT64_C(51) == v5209));
        int v5315 = (v5314 && (v5313 == UINT64_C(0)));
        int v5316 = ((v5314 && ((v5313 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(52) < ((uint64_t)((uint64_t)in_b_len))));
        int v5317 = (((v5314 && (v5313 != UINT64_C(0))) && (v5313 < UINT64_C(64))) && (((uint64_t)((UINT64_C(51) + v5313) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5320 = ((v5260 == UINT64_C(0)) && (UINT64_C(51) != v5209));
        if (t5320) {
                uint64_t v5318 = v5313;
            int t5319 = (!(((((v5318 | UINT64_C(32)) >= UINT64_C(97)) && ((v5318 | UINT64_C(32)) <= UINT64_C(122))) || ((v5318 >= UINT64_C(48)) && (v5318 <= UINT64_C(57)))) || (v5318 == UINT64_C(45))));
            if (!t5319) {
                t5319 = ((v5313 == UINT64_C(45)) && ((UINT64_C(51) == ((v5243 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(52) == v5209)));
            }
            t5320 = t5319;
        }
        int v5321 = t5320;
        uint64_t v5322 = (v5315 ? UINT64_C(52) : (v5316 ? UINT64_C(53) : v5175));
        uint64_t v5323 = (v5316 ? (((((uint64_t)(v5313 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(52)]))) : v5226);
        uint64_t v5324 = (v5317 ? ((v5192 + UINT64_C(1)) & UINT64_C(255)) : v5192);
        uint64_t v5325 = (v5317 ? UINT64_C(51) : v5243);
        uint64_t v5326 = (v5317 ? ((uint64_t)((UINT64_C(52) + v5313) & UINT64_C(255))) : v5209);
        uint64_t v5327 = ((v5315 || v5316) ? UINT64_C(1) : ((v5321 || (v5314 && (!v5317))) ? UINT64_C(2) : v5260));
        t5328 = v5323;
    } else {
        t5328 = v5226;
    }
    uint64_t v5329 = t5328;
    uint64_t t5345;
    if (v5261) {
        uint64_t v5330 = ((uint64_t)in_b[UINT64_C(51)]);
        int v5331 = ((v5260 == UINT64_C(0)) && (UINT64_C(51) == v5209));
        int v5332 = (v5331 && (v5330 == UINT64_C(0)));
        int v5333 = ((v5331 && ((v5330 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(52) < ((uint64_t)((uint64_t)in_b_len))));
        int v5334 = (((v5331 && (v5330 != UINT64_C(0))) && (v5330 < UINT64_C(64))) && (((uint64_t)((UINT64_C(51) + v5330) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5337 = ((v5260 == UINT64_C(0)) && (UINT64_C(51) != v5209));
        if (t5337) {
                uint64_t v5335 = v5330;
            int t5336 = (!(((((v5335 | UINT64_C(32)) >= UINT64_C(97)) && ((v5335 | UINT64_C(32)) <= UINT64_C(122))) || ((v5335 >= UINT64_C(48)) && (v5335 <= UINT64_C(57)))) || (v5335 == UINT64_C(45))));
            if (!t5336) {
                t5336 = ((v5330 == UINT64_C(45)) && ((UINT64_C(51) == ((v5243 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(52) == v5209)));
            }
            t5337 = t5336;
        }
        int v5338 = t5337;
        uint64_t v5339 = (v5332 ? UINT64_C(52) : (v5333 ? UINT64_C(53) : v5175));
        uint64_t v5340 = (v5333 ? (((((uint64_t)(v5330 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(52)]))) : v5226);
        uint64_t v5341 = (v5334 ? ((v5192 + UINT64_C(1)) & UINT64_C(255)) : v5192);
        uint64_t v5342 = (v5334 ? UINT64_C(51) : v5243);
        uint64_t v5343 = (v5334 ? ((uint64_t)((UINT64_C(52) + v5330) & UINT64_C(255))) : v5209);
        uint64_t v5344 = ((v5332 || v5333) ? UINT64_C(1) : ((v5338 || (v5331 && (!v5334))) ? UINT64_C(2) : v5260));
        t5345 = v5342;
    } else {
        t5345 = v5243;
    }
    uint64_t v5346 = t5345;
    uint64_t t5362;
    if (v5261) {
        uint64_t v5347 = ((uint64_t)in_b[UINT64_C(51)]);
        int v5348 = ((v5260 == UINT64_C(0)) && (UINT64_C(51) == v5209));
        int v5349 = (v5348 && (v5347 == UINT64_C(0)));
        int v5350 = ((v5348 && ((v5347 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(52) < ((uint64_t)((uint64_t)in_b_len))));
        int v5351 = (((v5348 && (v5347 != UINT64_C(0))) && (v5347 < UINT64_C(64))) && (((uint64_t)((UINT64_C(51) + v5347) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5354 = ((v5260 == UINT64_C(0)) && (UINT64_C(51) != v5209));
        if (t5354) {
                uint64_t v5352 = v5347;
            int t5353 = (!(((((v5352 | UINT64_C(32)) >= UINT64_C(97)) && ((v5352 | UINT64_C(32)) <= UINT64_C(122))) || ((v5352 >= UINT64_C(48)) && (v5352 <= UINT64_C(57)))) || (v5352 == UINT64_C(45))));
            if (!t5353) {
                t5353 = ((v5347 == UINT64_C(45)) && ((UINT64_C(51) == ((v5243 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(52) == v5209)));
            }
            t5354 = t5353;
        }
        int v5355 = t5354;
        uint64_t v5356 = (v5349 ? UINT64_C(52) : (v5350 ? UINT64_C(53) : v5175));
        uint64_t v5357 = (v5350 ? (((((uint64_t)(v5347 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(52)]))) : v5226);
        uint64_t v5358 = (v5351 ? ((v5192 + UINT64_C(1)) & UINT64_C(255)) : v5192);
        uint64_t v5359 = (v5351 ? UINT64_C(51) : v5243);
        uint64_t v5360 = (v5351 ? ((uint64_t)((UINT64_C(52) + v5347) & UINT64_C(255))) : v5209);
        uint64_t v5361 = ((v5349 || v5350) ? UINT64_C(1) : ((v5355 || (v5348 && (!v5351))) ? UINT64_C(2) : v5260));
        t5362 = v5361;
    } else {
        t5362 = v5260;
    }
    uint64_t v5363 = t5362;
    int v5364 = (UINT64_C(52) < v7);
    uint64_t t5380;
    if (v5364) {
        uint64_t v5365 = ((uint64_t)in_b[UINT64_C(52)]);
        int v5366 = ((v5363 == UINT64_C(0)) && (UINT64_C(52) == v5312));
        int v5367 = (v5366 && (v5365 == UINT64_C(0)));
        int v5368 = ((v5366 && ((v5365 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(53) < ((uint64_t)((uint64_t)in_b_len))));
        int v5369 = (((v5366 && (v5365 != UINT64_C(0))) && (v5365 < UINT64_C(64))) && (((uint64_t)((UINT64_C(52) + v5365) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5372 = ((v5363 == UINT64_C(0)) && (UINT64_C(52) != v5312));
        if (t5372) {
                uint64_t v5370 = v5365;
            int t5371 = (!(((((v5370 | UINT64_C(32)) >= UINT64_C(97)) && ((v5370 | UINT64_C(32)) <= UINT64_C(122))) || ((v5370 >= UINT64_C(48)) && (v5370 <= UINT64_C(57)))) || (v5370 == UINT64_C(45))));
            if (!t5371) {
                t5371 = ((v5365 == UINT64_C(45)) && ((UINT64_C(52) == ((v5346 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(53) == v5312)));
            }
            t5372 = t5371;
        }
        int v5373 = t5372;
        uint64_t v5374 = (v5367 ? UINT64_C(53) : (v5368 ? UINT64_C(54) : v5278));
        uint64_t v5375 = (v5368 ? (((((uint64_t)(v5365 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(53)]))) : v5329);
        uint64_t v5376 = (v5369 ? ((v5295 + UINT64_C(1)) & UINT64_C(255)) : v5295);
        uint64_t v5377 = (v5369 ? UINT64_C(52) : v5346);
        uint64_t v5378 = (v5369 ? ((uint64_t)((UINT64_C(53) + v5365) & UINT64_C(255))) : v5312);
        uint64_t v5379 = ((v5367 || v5368) ? UINT64_C(1) : ((v5373 || (v5366 && (!v5369))) ? UINT64_C(2) : v5363));
        t5380 = v5374;
    } else {
        t5380 = v5278;
    }
    uint64_t v5381 = t5380;
    uint64_t t5397;
    if (v5364) {
        uint64_t v5382 = ((uint64_t)in_b[UINT64_C(52)]);
        int v5383 = ((v5363 == UINT64_C(0)) && (UINT64_C(52) == v5312));
        int v5384 = (v5383 && (v5382 == UINT64_C(0)));
        int v5385 = ((v5383 && ((v5382 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(53) < ((uint64_t)((uint64_t)in_b_len))));
        int v5386 = (((v5383 && (v5382 != UINT64_C(0))) && (v5382 < UINT64_C(64))) && (((uint64_t)((UINT64_C(52) + v5382) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5389 = ((v5363 == UINT64_C(0)) && (UINT64_C(52) != v5312));
        if (t5389) {
                uint64_t v5387 = v5382;
            int t5388 = (!(((((v5387 | UINT64_C(32)) >= UINT64_C(97)) && ((v5387 | UINT64_C(32)) <= UINT64_C(122))) || ((v5387 >= UINT64_C(48)) && (v5387 <= UINT64_C(57)))) || (v5387 == UINT64_C(45))));
            if (!t5388) {
                t5388 = ((v5382 == UINT64_C(45)) && ((UINT64_C(52) == ((v5346 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(53) == v5312)));
            }
            t5389 = t5388;
        }
        int v5390 = t5389;
        uint64_t v5391 = (v5384 ? UINT64_C(53) : (v5385 ? UINT64_C(54) : v5278));
        uint64_t v5392 = (v5385 ? (((((uint64_t)(v5382 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(53)]))) : v5329);
        uint64_t v5393 = (v5386 ? ((v5295 + UINT64_C(1)) & UINT64_C(255)) : v5295);
        uint64_t v5394 = (v5386 ? UINT64_C(52) : v5346);
        uint64_t v5395 = (v5386 ? ((uint64_t)((UINT64_C(53) + v5382) & UINT64_C(255))) : v5312);
        uint64_t v5396 = ((v5384 || v5385) ? UINT64_C(1) : ((v5390 || (v5383 && (!v5386))) ? UINT64_C(2) : v5363));
        t5397 = v5393;
    } else {
        t5397 = v5295;
    }
    uint64_t v5398 = t5397;
    uint64_t t5414;
    if (v5364) {
        uint64_t v5399 = ((uint64_t)in_b[UINT64_C(52)]);
        int v5400 = ((v5363 == UINT64_C(0)) && (UINT64_C(52) == v5312));
        int v5401 = (v5400 && (v5399 == UINT64_C(0)));
        int v5402 = ((v5400 && ((v5399 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(53) < ((uint64_t)((uint64_t)in_b_len))));
        int v5403 = (((v5400 && (v5399 != UINT64_C(0))) && (v5399 < UINT64_C(64))) && (((uint64_t)((UINT64_C(52) + v5399) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5406 = ((v5363 == UINT64_C(0)) && (UINT64_C(52) != v5312));
        if (t5406) {
                uint64_t v5404 = v5399;
            int t5405 = (!(((((v5404 | UINT64_C(32)) >= UINT64_C(97)) && ((v5404 | UINT64_C(32)) <= UINT64_C(122))) || ((v5404 >= UINT64_C(48)) && (v5404 <= UINT64_C(57)))) || (v5404 == UINT64_C(45))));
            if (!t5405) {
                t5405 = ((v5399 == UINT64_C(45)) && ((UINT64_C(52) == ((v5346 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(53) == v5312)));
            }
            t5406 = t5405;
        }
        int v5407 = t5406;
        uint64_t v5408 = (v5401 ? UINT64_C(53) : (v5402 ? UINT64_C(54) : v5278));
        uint64_t v5409 = (v5402 ? (((((uint64_t)(v5399 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(53)]))) : v5329);
        uint64_t v5410 = (v5403 ? ((v5295 + UINT64_C(1)) & UINT64_C(255)) : v5295);
        uint64_t v5411 = (v5403 ? UINT64_C(52) : v5346);
        uint64_t v5412 = (v5403 ? ((uint64_t)((UINT64_C(53) + v5399) & UINT64_C(255))) : v5312);
        uint64_t v5413 = ((v5401 || v5402) ? UINT64_C(1) : ((v5407 || (v5400 && (!v5403))) ? UINT64_C(2) : v5363));
        t5414 = v5412;
    } else {
        t5414 = v5312;
    }
    uint64_t v5415 = t5414;
    uint64_t t5431;
    if (v5364) {
        uint64_t v5416 = ((uint64_t)in_b[UINT64_C(52)]);
        int v5417 = ((v5363 == UINT64_C(0)) && (UINT64_C(52) == v5312));
        int v5418 = (v5417 && (v5416 == UINT64_C(0)));
        int v5419 = ((v5417 && ((v5416 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(53) < ((uint64_t)((uint64_t)in_b_len))));
        int v5420 = (((v5417 && (v5416 != UINT64_C(0))) && (v5416 < UINT64_C(64))) && (((uint64_t)((UINT64_C(52) + v5416) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5423 = ((v5363 == UINT64_C(0)) && (UINT64_C(52) != v5312));
        if (t5423) {
                uint64_t v5421 = v5416;
            int t5422 = (!(((((v5421 | UINT64_C(32)) >= UINT64_C(97)) && ((v5421 | UINT64_C(32)) <= UINT64_C(122))) || ((v5421 >= UINT64_C(48)) && (v5421 <= UINT64_C(57)))) || (v5421 == UINT64_C(45))));
            if (!t5422) {
                t5422 = ((v5416 == UINT64_C(45)) && ((UINT64_C(52) == ((v5346 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(53) == v5312)));
            }
            t5423 = t5422;
        }
        int v5424 = t5423;
        uint64_t v5425 = (v5418 ? UINT64_C(53) : (v5419 ? UINT64_C(54) : v5278));
        uint64_t v5426 = (v5419 ? (((((uint64_t)(v5416 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(53)]))) : v5329);
        uint64_t v5427 = (v5420 ? ((v5295 + UINT64_C(1)) & UINT64_C(255)) : v5295);
        uint64_t v5428 = (v5420 ? UINT64_C(52) : v5346);
        uint64_t v5429 = (v5420 ? ((uint64_t)((UINT64_C(53) + v5416) & UINT64_C(255))) : v5312);
        uint64_t v5430 = ((v5418 || v5419) ? UINT64_C(1) : ((v5424 || (v5417 && (!v5420))) ? UINT64_C(2) : v5363));
        t5431 = v5426;
    } else {
        t5431 = v5329;
    }
    uint64_t v5432 = t5431;
    uint64_t t5448;
    if (v5364) {
        uint64_t v5433 = ((uint64_t)in_b[UINT64_C(52)]);
        int v5434 = ((v5363 == UINT64_C(0)) && (UINT64_C(52) == v5312));
        int v5435 = (v5434 && (v5433 == UINT64_C(0)));
        int v5436 = ((v5434 && ((v5433 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(53) < ((uint64_t)((uint64_t)in_b_len))));
        int v5437 = (((v5434 && (v5433 != UINT64_C(0))) && (v5433 < UINT64_C(64))) && (((uint64_t)((UINT64_C(52) + v5433) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5440 = ((v5363 == UINT64_C(0)) && (UINT64_C(52) != v5312));
        if (t5440) {
                uint64_t v5438 = v5433;
            int t5439 = (!(((((v5438 | UINT64_C(32)) >= UINT64_C(97)) && ((v5438 | UINT64_C(32)) <= UINT64_C(122))) || ((v5438 >= UINT64_C(48)) && (v5438 <= UINT64_C(57)))) || (v5438 == UINT64_C(45))));
            if (!t5439) {
                t5439 = ((v5433 == UINT64_C(45)) && ((UINT64_C(52) == ((v5346 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(53) == v5312)));
            }
            t5440 = t5439;
        }
        int v5441 = t5440;
        uint64_t v5442 = (v5435 ? UINT64_C(53) : (v5436 ? UINT64_C(54) : v5278));
        uint64_t v5443 = (v5436 ? (((((uint64_t)(v5433 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(53)]))) : v5329);
        uint64_t v5444 = (v5437 ? ((v5295 + UINT64_C(1)) & UINT64_C(255)) : v5295);
        uint64_t v5445 = (v5437 ? UINT64_C(52) : v5346);
        uint64_t v5446 = (v5437 ? ((uint64_t)((UINT64_C(53) + v5433) & UINT64_C(255))) : v5312);
        uint64_t v5447 = ((v5435 || v5436) ? UINT64_C(1) : ((v5441 || (v5434 && (!v5437))) ? UINT64_C(2) : v5363));
        t5448 = v5445;
    } else {
        t5448 = v5346;
    }
    uint64_t v5449 = t5448;
    uint64_t t5465;
    if (v5364) {
        uint64_t v5450 = ((uint64_t)in_b[UINT64_C(52)]);
        int v5451 = ((v5363 == UINT64_C(0)) && (UINT64_C(52) == v5312));
        int v5452 = (v5451 && (v5450 == UINT64_C(0)));
        int v5453 = ((v5451 && ((v5450 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(53) < ((uint64_t)((uint64_t)in_b_len))));
        int v5454 = (((v5451 && (v5450 != UINT64_C(0))) && (v5450 < UINT64_C(64))) && (((uint64_t)((UINT64_C(52) + v5450) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5457 = ((v5363 == UINT64_C(0)) && (UINT64_C(52) != v5312));
        if (t5457) {
                uint64_t v5455 = v5450;
            int t5456 = (!(((((v5455 | UINT64_C(32)) >= UINT64_C(97)) && ((v5455 | UINT64_C(32)) <= UINT64_C(122))) || ((v5455 >= UINT64_C(48)) && (v5455 <= UINT64_C(57)))) || (v5455 == UINT64_C(45))));
            if (!t5456) {
                t5456 = ((v5450 == UINT64_C(45)) && ((UINT64_C(52) == ((v5346 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(53) == v5312)));
            }
            t5457 = t5456;
        }
        int v5458 = t5457;
        uint64_t v5459 = (v5452 ? UINT64_C(53) : (v5453 ? UINT64_C(54) : v5278));
        uint64_t v5460 = (v5453 ? (((((uint64_t)(v5450 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(53)]))) : v5329);
        uint64_t v5461 = (v5454 ? ((v5295 + UINT64_C(1)) & UINT64_C(255)) : v5295);
        uint64_t v5462 = (v5454 ? UINT64_C(52) : v5346);
        uint64_t v5463 = (v5454 ? ((uint64_t)((UINT64_C(53) + v5450) & UINT64_C(255))) : v5312);
        uint64_t v5464 = ((v5452 || v5453) ? UINT64_C(1) : ((v5458 || (v5451 && (!v5454))) ? UINT64_C(2) : v5363));
        t5465 = v5464;
    } else {
        t5465 = v5363;
    }
    uint64_t v5466 = t5465;
    int v5467 = (UINT64_C(53) < v7);
    uint64_t t5483;
    if (v5467) {
        uint64_t v5468 = ((uint64_t)in_b[UINT64_C(53)]);
        int v5469 = ((v5466 == UINT64_C(0)) && (UINT64_C(53) == v5415));
        int v5470 = (v5469 && (v5468 == UINT64_C(0)));
        int v5471 = ((v5469 && ((v5468 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(54) < ((uint64_t)((uint64_t)in_b_len))));
        int v5472 = (((v5469 && (v5468 != UINT64_C(0))) && (v5468 < UINT64_C(64))) && (((uint64_t)((UINT64_C(53) + v5468) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5475 = ((v5466 == UINT64_C(0)) && (UINT64_C(53) != v5415));
        if (t5475) {
                uint64_t v5473 = v5468;
            int t5474 = (!(((((v5473 | UINT64_C(32)) >= UINT64_C(97)) && ((v5473 | UINT64_C(32)) <= UINT64_C(122))) || ((v5473 >= UINT64_C(48)) && (v5473 <= UINT64_C(57)))) || (v5473 == UINT64_C(45))));
            if (!t5474) {
                t5474 = ((v5468 == UINT64_C(45)) && ((UINT64_C(53) == ((v5449 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(54) == v5415)));
            }
            t5475 = t5474;
        }
        int v5476 = t5475;
        uint64_t v5477 = (v5470 ? UINT64_C(54) : (v5471 ? UINT64_C(55) : v5381));
        uint64_t v5478 = (v5471 ? (((((uint64_t)(v5468 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(54)]))) : v5432);
        uint64_t v5479 = (v5472 ? ((v5398 + UINT64_C(1)) & UINT64_C(255)) : v5398);
        uint64_t v5480 = (v5472 ? UINT64_C(53) : v5449);
        uint64_t v5481 = (v5472 ? ((uint64_t)((UINT64_C(54) + v5468) & UINT64_C(255))) : v5415);
        uint64_t v5482 = ((v5470 || v5471) ? UINT64_C(1) : ((v5476 || (v5469 && (!v5472))) ? UINT64_C(2) : v5466));
        t5483 = v5477;
    } else {
        t5483 = v5381;
    }
    uint64_t v5484 = t5483;
    uint64_t t5500;
    if (v5467) {
        uint64_t v5485 = ((uint64_t)in_b[UINT64_C(53)]);
        int v5486 = ((v5466 == UINT64_C(0)) && (UINT64_C(53) == v5415));
        int v5487 = (v5486 && (v5485 == UINT64_C(0)));
        int v5488 = ((v5486 && ((v5485 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(54) < ((uint64_t)((uint64_t)in_b_len))));
        int v5489 = (((v5486 && (v5485 != UINT64_C(0))) && (v5485 < UINT64_C(64))) && (((uint64_t)((UINT64_C(53) + v5485) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5492 = ((v5466 == UINT64_C(0)) && (UINT64_C(53) != v5415));
        if (t5492) {
                uint64_t v5490 = v5485;
            int t5491 = (!(((((v5490 | UINT64_C(32)) >= UINT64_C(97)) && ((v5490 | UINT64_C(32)) <= UINT64_C(122))) || ((v5490 >= UINT64_C(48)) && (v5490 <= UINT64_C(57)))) || (v5490 == UINT64_C(45))));
            if (!t5491) {
                t5491 = ((v5485 == UINT64_C(45)) && ((UINT64_C(53) == ((v5449 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(54) == v5415)));
            }
            t5492 = t5491;
        }
        int v5493 = t5492;
        uint64_t v5494 = (v5487 ? UINT64_C(54) : (v5488 ? UINT64_C(55) : v5381));
        uint64_t v5495 = (v5488 ? (((((uint64_t)(v5485 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(54)]))) : v5432);
        uint64_t v5496 = (v5489 ? ((v5398 + UINT64_C(1)) & UINT64_C(255)) : v5398);
        uint64_t v5497 = (v5489 ? UINT64_C(53) : v5449);
        uint64_t v5498 = (v5489 ? ((uint64_t)((UINT64_C(54) + v5485) & UINT64_C(255))) : v5415);
        uint64_t v5499 = ((v5487 || v5488) ? UINT64_C(1) : ((v5493 || (v5486 && (!v5489))) ? UINT64_C(2) : v5466));
        t5500 = v5496;
    } else {
        t5500 = v5398;
    }
    uint64_t v5501 = t5500;
    uint64_t t5517;
    if (v5467) {
        uint64_t v5502 = ((uint64_t)in_b[UINT64_C(53)]);
        int v5503 = ((v5466 == UINT64_C(0)) && (UINT64_C(53) == v5415));
        int v5504 = (v5503 && (v5502 == UINT64_C(0)));
        int v5505 = ((v5503 && ((v5502 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(54) < ((uint64_t)((uint64_t)in_b_len))));
        int v5506 = (((v5503 && (v5502 != UINT64_C(0))) && (v5502 < UINT64_C(64))) && (((uint64_t)((UINT64_C(53) + v5502) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5509 = ((v5466 == UINT64_C(0)) && (UINT64_C(53) != v5415));
        if (t5509) {
                uint64_t v5507 = v5502;
            int t5508 = (!(((((v5507 | UINT64_C(32)) >= UINT64_C(97)) && ((v5507 | UINT64_C(32)) <= UINT64_C(122))) || ((v5507 >= UINT64_C(48)) && (v5507 <= UINT64_C(57)))) || (v5507 == UINT64_C(45))));
            if (!t5508) {
                t5508 = ((v5502 == UINT64_C(45)) && ((UINT64_C(53) == ((v5449 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(54) == v5415)));
            }
            t5509 = t5508;
        }
        int v5510 = t5509;
        uint64_t v5511 = (v5504 ? UINT64_C(54) : (v5505 ? UINT64_C(55) : v5381));
        uint64_t v5512 = (v5505 ? (((((uint64_t)(v5502 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(54)]))) : v5432);
        uint64_t v5513 = (v5506 ? ((v5398 + UINT64_C(1)) & UINT64_C(255)) : v5398);
        uint64_t v5514 = (v5506 ? UINT64_C(53) : v5449);
        uint64_t v5515 = (v5506 ? ((uint64_t)((UINT64_C(54) + v5502) & UINT64_C(255))) : v5415);
        uint64_t v5516 = ((v5504 || v5505) ? UINT64_C(1) : ((v5510 || (v5503 && (!v5506))) ? UINT64_C(2) : v5466));
        t5517 = v5515;
    } else {
        t5517 = v5415;
    }
    uint64_t v5518 = t5517;
    uint64_t t5534;
    if (v5467) {
        uint64_t v5519 = ((uint64_t)in_b[UINT64_C(53)]);
        int v5520 = ((v5466 == UINT64_C(0)) && (UINT64_C(53) == v5415));
        int v5521 = (v5520 && (v5519 == UINT64_C(0)));
        int v5522 = ((v5520 && ((v5519 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(54) < ((uint64_t)((uint64_t)in_b_len))));
        int v5523 = (((v5520 && (v5519 != UINT64_C(0))) && (v5519 < UINT64_C(64))) && (((uint64_t)((UINT64_C(53) + v5519) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5526 = ((v5466 == UINT64_C(0)) && (UINT64_C(53) != v5415));
        if (t5526) {
                uint64_t v5524 = v5519;
            int t5525 = (!(((((v5524 | UINT64_C(32)) >= UINT64_C(97)) && ((v5524 | UINT64_C(32)) <= UINT64_C(122))) || ((v5524 >= UINT64_C(48)) && (v5524 <= UINT64_C(57)))) || (v5524 == UINT64_C(45))));
            if (!t5525) {
                t5525 = ((v5519 == UINT64_C(45)) && ((UINT64_C(53) == ((v5449 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(54) == v5415)));
            }
            t5526 = t5525;
        }
        int v5527 = t5526;
        uint64_t v5528 = (v5521 ? UINT64_C(54) : (v5522 ? UINT64_C(55) : v5381));
        uint64_t v5529 = (v5522 ? (((((uint64_t)(v5519 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(54)]))) : v5432);
        uint64_t v5530 = (v5523 ? ((v5398 + UINT64_C(1)) & UINT64_C(255)) : v5398);
        uint64_t v5531 = (v5523 ? UINT64_C(53) : v5449);
        uint64_t v5532 = (v5523 ? ((uint64_t)((UINT64_C(54) + v5519) & UINT64_C(255))) : v5415);
        uint64_t v5533 = ((v5521 || v5522) ? UINT64_C(1) : ((v5527 || (v5520 && (!v5523))) ? UINT64_C(2) : v5466));
        t5534 = v5529;
    } else {
        t5534 = v5432;
    }
    uint64_t v5535 = t5534;
    uint64_t t5551;
    if (v5467) {
        uint64_t v5536 = ((uint64_t)in_b[UINT64_C(53)]);
        int v5537 = ((v5466 == UINT64_C(0)) && (UINT64_C(53) == v5415));
        int v5538 = (v5537 && (v5536 == UINT64_C(0)));
        int v5539 = ((v5537 && ((v5536 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(54) < ((uint64_t)((uint64_t)in_b_len))));
        int v5540 = (((v5537 && (v5536 != UINT64_C(0))) && (v5536 < UINT64_C(64))) && (((uint64_t)((UINT64_C(53) + v5536) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5543 = ((v5466 == UINT64_C(0)) && (UINT64_C(53) != v5415));
        if (t5543) {
                uint64_t v5541 = v5536;
            int t5542 = (!(((((v5541 | UINT64_C(32)) >= UINT64_C(97)) && ((v5541 | UINT64_C(32)) <= UINT64_C(122))) || ((v5541 >= UINT64_C(48)) && (v5541 <= UINT64_C(57)))) || (v5541 == UINT64_C(45))));
            if (!t5542) {
                t5542 = ((v5536 == UINT64_C(45)) && ((UINT64_C(53) == ((v5449 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(54) == v5415)));
            }
            t5543 = t5542;
        }
        int v5544 = t5543;
        uint64_t v5545 = (v5538 ? UINT64_C(54) : (v5539 ? UINT64_C(55) : v5381));
        uint64_t v5546 = (v5539 ? (((((uint64_t)(v5536 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(54)]))) : v5432);
        uint64_t v5547 = (v5540 ? ((v5398 + UINT64_C(1)) & UINT64_C(255)) : v5398);
        uint64_t v5548 = (v5540 ? UINT64_C(53) : v5449);
        uint64_t v5549 = (v5540 ? ((uint64_t)((UINT64_C(54) + v5536) & UINT64_C(255))) : v5415);
        uint64_t v5550 = ((v5538 || v5539) ? UINT64_C(1) : ((v5544 || (v5537 && (!v5540))) ? UINT64_C(2) : v5466));
        t5551 = v5548;
    } else {
        t5551 = v5449;
    }
    uint64_t v5552 = t5551;
    uint64_t t5568;
    if (v5467) {
        uint64_t v5553 = ((uint64_t)in_b[UINT64_C(53)]);
        int v5554 = ((v5466 == UINT64_C(0)) && (UINT64_C(53) == v5415));
        int v5555 = (v5554 && (v5553 == UINT64_C(0)));
        int v5556 = ((v5554 && ((v5553 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(54) < ((uint64_t)((uint64_t)in_b_len))));
        int v5557 = (((v5554 && (v5553 != UINT64_C(0))) && (v5553 < UINT64_C(64))) && (((uint64_t)((UINT64_C(53) + v5553) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5560 = ((v5466 == UINT64_C(0)) && (UINT64_C(53) != v5415));
        if (t5560) {
                uint64_t v5558 = v5553;
            int t5559 = (!(((((v5558 | UINT64_C(32)) >= UINT64_C(97)) && ((v5558 | UINT64_C(32)) <= UINT64_C(122))) || ((v5558 >= UINT64_C(48)) && (v5558 <= UINT64_C(57)))) || (v5558 == UINT64_C(45))));
            if (!t5559) {
                t5559 = ((v5553 == UINT64_C(45)) && ((UINT64_C(53) == ((v5449 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(54) == v5415)));
            }
            t5560 = t5559;
        }
        int v5561 = t5560;
        uint64_t v5562 = (v5555 ? UINT64_C(54) : (v5556 ? UINT64_C(55) : v5381));
        uint64_t v5563 = (v5556 ? (((((uint64_t)(v5553 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(54)]))) : v5432);
        uint64_t v5564 = (v5557 ? ((v5398 + UINT64_C(1)) & UINT64_C(255)) : v5398);
        uint64_t v5565 = (v5557 ? UINT64_C(53) : v5449);
        uint64_t v5566 = (v5557 ? ((uint64_t)((UINT64_C(54) + v5553) & UINT64_C(255))) : v5415);
        uint64_t v5567 = ((v5555 || v5556) ? UINT64_C(1) : ((v5561 || (v5554 && (!v5557))) ? UINT64_C(2) : v5466));
        t5568 = v5567;
    } else {
        t5568 = v5466;
    }
    uint64_t v5569 = t5568;
    int v5570 = (UINT64_C(54) < v7);
    uint64_t t5586;
    if (v5570) {
        uint64_t v5571 = ((uint64_t)in_b[UINT64_C(54)]);
        int v5572 = ((v5569 == UINT64_C(0)) && (UINT64_C(54) == v5518));
        int v5573 = (v5572 && (v5571 == UINT64_C(0)));
        int v5574 = ((v5572 && ((v5571 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(55) < ((uint64_t)((uint64_t)in_b_len))));
        int v5575 = (((v5572 && (v5571 != UINT64_C(0))) && (v5571 < UINT64_C(64))) && (((uint64_t)((UINT64_C(54) + v5571) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5578 = ((v5569 == UINT64_C(0)) && (UINT64_C(54) != v5518));
        if (t5578) {
                uint64_t v5576 = v5571;
            int t5577 = (!(((((v5576 | UINT64_C(32)) >= UINT64_C(97)) && ((v5576 | UINT64_C(32)) <= UINT64_C(122))) || ((v5576 >= UINT64_C(48)) && (v5576 <= UINT64_C(57)))) || (v5576 == UINT64_C(45))));
            if (!t5577) {
                t5577 = ((v5571 == UINT64_C(45)) && ((UINT64_C(54) == ((v5552 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(55) == v5518)));
            }
            t5578 = t5577;
        }
        int v5579 = t5578;
        uint64_t v5580 = (v5573 ? UINT64_C(55) : (v5574 ? UINT64_C(56) : v5484));
        uint64_t v5581 = (v5574 ? (((((uint64_t)(v5571 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(55)]))) : v5535);
        uint64_t v5582 = (v5575 ? ((v5501 + UINT64_C(1)) & UINT64_C(255)) : v5501);
        uint64_t v5583 = (v5575 ? UINT64_C(54) : v5552);
        uint64_t v5584 = (v5575 ? ((uint64_t)((UINT64_C(55) + v5571) & UINT64_C(255))) : v5518);
        uint64_t v5585 = ((v5573 || v5574) ? UINT64_C(1) : ((v5579 || (v5572 && (!v5575))) ? UINT64_C(2) : v5569));
        t5586 = v5580;
    } else {
        t5586 = v5484;
    }
    uint64_t v5587 = t5586;
    uint64_t t5603;
    if (v5570) {
        uint64_t v5588 = ((uint64_t)in_b[UINT64_C(54)]);
        int v5589 = ((v5569 == UINT64_C(0)) && (UINT64_C(54) == v5518));
        int v5590 = (v5589 && (v5588 == UINT64_C(0)));
        int v5591 = ((v5589 && ((v5588 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(55) < ((uint64_t)((uint64_t)in_b_len))));
        int v5592 = (((v5589 && (v5588 != UINT64_C(0))) && (v5588 < UINT64_C(64))) && (((uint64_t)((UINT64_C(54) + v5588) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5595 = ((v5569 == UINT64_C(0)) && (UINT64_C(54) != v5518));
        if (t5595) {
                uint64_t v5593 = v5588;
            int t5594 = (!(((((v5593 | UINT64_C(32)) >= UINT64_C(97)) && ((v5593 | UINT64_C(32)) <= UINT64_C(122))) || ((v5593 >= UINT64_C(48)) && (v5593 <= UINT64_C(57)))) || (v5593 == UINT64_C(45))));
            if (!t5594) {
                t5594 = ((v5588 == UINT64_C(45)) && ((UINT64_C(54) == ((v5552 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(55) == v5518)));
            }
            t5595 = t5594;
        }
        int v5596 = t5595;
        uint64_t v5597 = (v5590 ? UINT64_C(55) : (v5591 ? UINT64_C(56) : v5484));
        uint64_t v5598 = (v5591 ? (((((uint64_t)(v5588 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(55)]))) : v5535);
        uint64_t v5599 = (v5592 ? ((v5501 + UINT64_C(1)) & UINT64_C(255)) : v5501);
        uint64_t v5600 = (v5592 ? UINT64_C(54) : v5552);
        uint64_t v5601 = (v5592 ? ((uint64_t)((UINT64_C(55) + v5588) & UINT64_C(255))) : v5518);
        uint64_t v5602 = ((v5590 || v5591) ? UINT64_C(1) : ((v5596 || (v5589 && (!v5592))) ? UINT64_C(2) : v5569));
        t5603 = v5599;
    } else {
        t5603 = v5501;
    }
    uint64_t v5604 = t5603;
    uint64_t t5620;
    if (v5570) {
        uint64_t v5605 = ((uint64_t)in_b[UINT64_C(54)]);
        int v5606 = ((v5569 == UINT64_C(0)) && (UINT64_C(54) == v5518));
        int v5607 = (v5606 && (v5605 == UINT64_C(0)));
        int v5608 = ((v5606 && ((v5605 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(55) < ((uint64_t)((uint64_t)in_b_len))));
        int v5609 = (((v5606 && (v5605 != UINT64_C(0))) && (v5605 < UINT64_C(64))) && (((uint64_t)((UINT64_C(54) + v5605) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5612 = ((v5569 == UINT64_C(0)) && (UINT64_C(54) != v5518));
        if (t5612) {
                uint64_t v5610 = v5605;
            int t5611 = (!(((((v5610 | UINT64_C(32)) >= UINT64_C(97)) && ((v5610 | UINT64_C(32)) <= UINT64_C(122))) || ((v5610 >= UINT64_C(48)) && (v5610 <= UINT64_C(57)))) || (v5610 == UINT64_C(45))));
            if (!t5611) {
                t5611 = ((v5605 == UINT64_C(45)) && ((UINT64_C(54) == ((v5552 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(55) == v5518)));
            }
            t5612 = t5611;
        }
        int v5613 = t5612;
        uint64_t v5614 = (v5607 ? UINT64_C(55) : (v5608 ? UINT64_C(56) : v5484));
        uint64_t v5615 = (v5608 ? (((((uint64_t)(v5605 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(55)]))) : v5535);
        uint64_t v5616 = (v5609 ? ((v5501 + UINT64_C(1)) & UINT64_C(255)) : v5501);
        uint64_t v5617 = (v5609 ? UINT64_C(54) : v5552);
        uint64_t v5618 = (v5609 ? ((uint64_t)((UINT64_C(55) + v5605) & UINT64_C(255))) : v5518);
        uint64_t v5619 = ((v5607 || v5608) ? UINT64_C(1) : ((v5613 || (v5606 && (!v5609))) ? UINT64_C(2) : v5569));
        t5620 = v5618;
    } else {
        t5620 = v5518;
    }
    uint64_t v5621 = t5620;
    uint64_t t5637;
    if (v5570) {
        uint64_t v5622 = ((uint64_t)in_b[UINT64_C(54)]);
        int v5623 = ((v5569 == UINT64_C(0)) && (UINT64_C(54) == v5518));
        int v5624 = (v5623 && (v5622 == UINT64_C(0)));
        int v5625 = ((v5623 && ((v5622 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(55) < ((uint64_t)((uint64_t)in_b_len))));
        int v5626 = (((v5623 && (v5622 != UINT64_C(0))) && (v5622 < UINT64_C(64))) && (((uint64_t)((UINT64_C(54) + v5622) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5629 = ((v5569 == UINT64_C(0)) && (UINT64_C(54) != v5518));
        if (t5629) {
                uint64_t v5627 = v5622;
            int t5628 = (!(((((v5627 | UINT64_C(32)) >= UINT64_C(97)) && ((v5627 | UINT64_C(32)) <= UINT64_C(122))) || ((v5627 >= UINT64_C(48)) && (v5627 <= UINT64_C(57)))) || (v5627 == UINT64_C(45))));
            if (!t5628) {
                t5628 = ((v5622 == UINT64_C(45)) && ((UINT64_C(54) == ((v5552 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(55) == v5518)));
            }
            t5629 = t5628;
        }
        int v5630 = t5629;
        uint64_t v5631 = (v5624 ? UINT64_C(55) : (v5625 ? UINT64_C(56) : v5484));
        uint64_t v5632 = (v5625 ? (((((uint64_t)(v5622 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(55)]))) : v5535);
        uint64_t v5633 = (v5626 ? ((v5501 + UINT64_C(1)) & UINT64_C(255)) : v5501);
        uint64_t v5634 = (v5626 ? UINT64_C(54) : v5552);
        uint64_t v5635 = (v5626 ? ((uint64_t)((UINT64_C(55) + v5622) & UINT64_C(255))) : v5518);
        uint64_t v5636 = ((v5624 || v5625) ? UINT64_C(1) : ((v5630 || (v5623 && (!v5626))) ? UINT64_C(2) : v5569));
        t5637 = v5632;
    } else {
        t5637 = v5535;
    }
    uint64_t v5638 = t5637;
    uint64_t t5654;
    if (v5570) {
        uint64_t v5639 = ((uint64_t)in_b[UINT64_C(54)]);
        int v5640 = ((v5569 == UINT64_C(0)) && (UINT64_C(54) == v5518));
        int v5641 = (v5640 && (v5639 == UINT64_C(0)));
        int v5642 = ((v5640 && ((v5639 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(55) < ((uint64_t)((uint64_t)in_b_len))));
        int v5643 = (((v5640 && (v5639 != UINT64_C(0))) && (v5639 < UINT64_C(64))) && (((uint64_t)((UINT64_C(54) + v5639) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5646 = ((v5569 == UINT64_C(0)) && (UINT64_C(54) != v5518));
        if (t5646) {
                uint64_t v5644 = v5639;
            int t5645 = (!(((((v5644 | UINT64_C(32)) >= UINT64_C(97)) && ((v5644 | UINT64_C(32)) <= UINT64_C(122))) || ((v5644 >= UINT64_C(48)) && (v5644 <= UINT64_C(57)))) || (v5644 == UINT64_C(45))));
            if (!t5645) {
                t5645 = ((v5639 == UINT64_C(45)) && ((UINT64_C(54) == ((v5552 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(55) == v5518)));
            }
            t5646 = t5645;
        }
        int v5647 = t5646;
        uint64_t v5648 = (v5641 ? UINT64_C(55) : (v5642 ? UINT64_C(56) : v5484));
        uint64_t v5649 = (v5642 ? (((((uint64_t)(v5639 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(55)]))) : v5535);
        uint64_t v5650 = (v5643 ? ((v5501 + UINT64_C(1)) & UINT64_C(255)) : v5501);
        uint64_t v5651 = (v5643 ? UINT64_C(54) : v5552);
        uint64_t v5652 = (v5643 ? ((uint64_t)((UINT64_C(55) + v5639) & UINT64_C(255))) : v5518);
        uint64_t v5653 = ((v5641 || v5642) ? UINT64_C(1) : ((v5647 || (v5640 && (!v5643))) ? UINT64_C(2) : v5569));
        t5654 = v5651;
    } else {
        t5654 = v5552;
    }
    uint64_t v5655 = t5654;
    uint64_t t5671;
    if (v5570) {
        uint64_t v5656 = ((uint64_t)in_b[UINT64_C(54)]);
        int v5657 = ((v5569 == UINT64_C(0)) && (UINT64_C(54) == v5518));
        int v5658 = (v5657 && (v5656 == UINT64_C(0)));
        int v5659 = ((v5657 && ((v5656 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(55) < ((uint64_t)((uint64_t)in_b_len))));
        int v5660 = (((v5657 && (v5656 != UINT64_C(0))) && (v5656 < UINT64_C(64))) && (((uint64_t)((UINT64_C(54) + v5656) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5663 = ((v5569 == UINT64_C(0)) && (UINT64_C(54) != v5518));
        if (t5663) {
                uint64_t v5661 = v5656;
            int t5662 = (!(((((v5661 | UINT64_C(32)) >= UINT64_C(97)) && ((v5661 | UINT64_C(32)) <= UINT64_C(122))) || ((v5661 >= UINT64_C(48)) && (v5661 <= UINT64_C(57)))) || (v5661 == UINT64_C(45))));
            if (!t5662) {
                t5662 = ((v5656 == UINT64_C(45)) && ((UINT64_C(54) == ((v5552 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(55) == v5518)));
            }
            t5663 = t5662;
        }
        int v5664 = t5663;
        uint64_t v5665 = (v5658 ? UINT64_C(55) : (v5659 ? UINT64_C(56) : v5484));
        uint64_t v5666 = (v5659 ? (((((uint64_t)(v5656 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(55)]))) : v5535);
        uint64_t v5667 = (v5660 ? ((v5501 + UINT64_C(1)) & UINT64_C(255)) : v5501);
        uint64_t v5668 = (v5660 ? UINT64_C(54) : v5552);
        uint64_t v5669 = (v5660 ? ((uint64_t)((UINT64_C(55) + v5656) & UINT64_C(255))) : v5518);
        uint64_t v5670 = ((v5658 || v5659) ? UINT64_C(1) : ((v5664 || (v5657 && (!v5660))) ? UINT64_C(2) : v5569));
        t5671 = v5670;
    } else {
        t5671 = v5569;
    }
    uint64_t v5672 = t5671;
    int v5673 = (UINT64_C(55) < v7);
    uint64_t t5689;
    if (v5673) {
        uint64_t v5674 = ((uint64_t)in_b[UINT64_C(55)]);
        int v5675 = ((v5672 == UINT64_C(0)) && (UINT64_C(55) == v5621));
        int v5676 = (v5675 && (v5674 == UINT64_C(0)));
        int v5677 = ((v5675 && ((v5674 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(56) < ((uint64_t)((uint64_t)in_b_len))));
        int v5678 = (((v5675 && (v5674 != UINT64_C(0))) && (v5674 < UINT64_C(64))) && (((uint64_t)((UINT64_C(55) + v5674) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5681 = ((v5672 == UINT64_C(0)) && (UINT64_C(55) != v5621));
        if (t5681) {
                uint64_t v5679 = v5674;
            int t5680 = (!(((((v5679 | UINT64_C(32)) >= UINT64_C(97)) && ((v5679 | UINT64_C(32)) <= UINT64_C(122))) || ((v5679 >= UINT64_C(48)) && (v5679 <= UINT64_C(57)))) || (v5679 == UINT64_C(45))));
            if (!t5680) {
                t5680 = ((v5674 == UINT64_C(45)) && ((UINT64_C(55) == ((v5655 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(56) == v5621)));
            }
            t5681 = t5680;
        }
        int v5682 = t5681;
        uint64_t v5683 = (v5676 ? UINT64_C(56) : (v5677 ? UINT64_C(57) : v5587));
        uint64_t v5684 = (v5677 ? (((((uint64_t)(v5674 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(56)]))) : v5638);
        uint64_t v5685 = (v5678 ? ((v5604 + UINT64_C(1)) & UINT64_C(255)) : v5604);
        uint64_t v5686 = (v5678 ? UINT64_C(55) : v5655);
        uint64_t v5687 = (v5678 ? ((uint64_t)((UINT64_C(56) + v5674) & UINT64_C(255))) : v5621);
        uint64_t v5688 = ((v5676 || v5677) ? UINT64_C(1) : ((v5682 || (v5675 && (!v5678))) ? UINT64_C(2) : v5672));
        t5689 = v5683;
    } else {
        t5689 = v5587;
    }
    uint64_t v5690 = t5689;
    uint64_t t5706;
    if (v5673) {
        uint64_t v5691 = ((uint64_t)in_b[UINT64_C(55)]);
        int v5692 = ((v5672 == UINT64_C(0)) && (UINT64_C(55) == v5621));
        int v5693 = (v5692 && (v5691 == UINT64_C(0)));
        int v5694 = ((v5692 && ((v5691 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(56) < ((uint64_t)((uint64_t)in_b_len))));
        int v5695 = (((v5692 && (v5691 != UINT64_C(0))) && (v5691 < UINT64_C(64))) && (((uint64_t)((UINT64_C(55) + v5691) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5698 = ((v5672 == UINT64_C(0)) && (UINT64_C(55) != v5621));
        if (t5698) {
                uint64_t v5696 = v5691;
            int t5697 = (!(((((v5696 | UINT64_C(32)) >= UINT64_C(97)) && ((v5696 | UINT64_C(32)) <= UINT64_C(122))) || ((v5696 >= UINT64_C(48)) && (v5696 <= UINT64_C(57)))) || (v5696 == UINT64_C(45))));
            if (!t5697) {
                t5697 = ((v5691 == UINT64_C(45)) && ((UINT64_C(55) == ((v5655 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(56) == v5621)));
            }
            t5698 = t5697;
        }
        int v5699 = t5698;
        uint64_t v5700 = (v5693 ? UINT64_C(56) : (v5694 ? UINT64_C(57) : v5587));
        uint64_t v5701 = (v5694 ? (((((uint64_t)(v5691 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(56)]))) : v5638);
        uint64_t v5702 = (v5695 ? ((v5604 + UINT64_C(1)) & UINT64_C(255)) : v5604);
        uint64_t v5703 = (v5695 ? UINT64_C(55) : v5655);
        uint64_t v5704 = (v5695 ? ((uint64_t)((UINT64_C(56) + v5691) & UINT64_C(255))) : v5621);
        uint64_t v5705 = ((v5693 || v5694) ? UINT64_C(1) : ((v5699 || (v5692 && (!v5695))) ? UINT64_C(2) : v5672));
        t5706 = v5702;
    } else {
        t5706 = v5604;
    }
    uint64_t v5707 = t5706;
    uint64_t t5723;
    if (v5673) {
        uint64_t v5708 = ((uint64_t)in_b[UINT64_C(55)]);
        int v5709 = ((v5672 == UINT64_C(0)) && (UINT64_C(55) == v5621));
        int v5710 = (v5709 && (v5708 == UINT64_C(0)));
        int v5711 = ((v5709 && ((v5708 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(56) < ((uint64_t)((uint64_t)in_b_len))));
        int v5712 = (((v5709 && (v5708 != UINT64_C(0))) && (v5708 < UINT64_C(64))) && (((uint64_t)((UINT64_C(55) + v5708) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5715 = ((v5672 == UINT64_C(0)) && (UINT64_C(55) != v5621));
        if (t5715) {
                uint64_t v5713 = v5708;
            int t5714 = (!(((((v5713 | UINT64_C(32)) >= UINT64_C(97)) && ((v5713 | UINT64_C(32)) <= UINT64_C(122))) || ((v5713 >= UINT64_C(48)) && (v5713 <= UINT64_C(57)))) || (v5713 == UINT64_C(45))));
            if (!t5714) {
                t5714 = ((v5708 == UINT64_C(45)) && ((UINT64_C(55) == ((v5655 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(56) == v5621)));
            }
            t5715 = t5714;
        }
        int v5716 = t5715;
        uint64_t v5717 = (v5710 ? UINT64_C(56) : (v5711 ? UINT64_C(57) : v5587));
        uint64_t v5718 = (v5711 ? (((((uint64_t)(v5708 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(56)]))) : v5638);
        uint64_t v5719 = (v5712 ? ((v5604 + UINT64_C(1)) & UINT64_C(255)) : v5604);
        uint64_t v5720 = (v5712 ? UINT64_C(55) : v5655);
        uint64_t v5721 = (v5712 ? ((uint64_t)((UINT64_C(56) + v5708) & UINT64_C(255))) : v5621);
        uint64_t v5722 = ((v5710 || v5711) ? UINT64_C(1) : ((v5716 || (v5709 && (!v5712))) ? UINT64_C(2) : v5672));
        t5723 = v5721;
    } else {
        t5723 = v5621;
    }
    uint64_t v5724 = t5723;
    uint64_t t5740;
    if (v5673) {
        uint64_t v5725 = ((uint64_t)in_b[UINT64_C(55)]);
        int v5726 = ((v5672 == UINT64_C(0)) && (UINT64_C(55) == v5621));
        int v5727 = (v5726 && (v5725 == UINT64_C(0)));
        int v5728 = ((v5726 && ((v5725 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(56) < ((uint64_t)((uint64_t)in_b_len))));
        int v5729 = (((v5726 && (v5725 != UINT64_C(0))) && (v5725 < UINT64_C(64))) && (((uint64_t)((UINT64_C(55) + v5725) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5732 = ((v5672 == UINT64_C(0)) && (UINT64_C(55) != v5621));
        if (t5732) {
                uint64_t v5730 = v5725;
            int t5731 = (!(((((v5730 | UINT64_C(32)) >= UINT64_C(97)) && ((v5730 | UINT64_C(32)) <= UINT64_C(122))) || ((v5730 >= UINT64_C(48)) && (v5730 <= UINT64_C(57)))) || (v5730 == UINT64_C(45))));
            if (!t5731) {
                t5731 = ((v5725 == UINT64_C(45)) && ((UINT64_C(55) == ((v5655 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(56) == v5621)));
            }
            t5732 = t5731;
        }
        int v5733 = t5732;
        uint64_t v5734 = (v5727 ? UINT64_C(56) : (v5728 ? UINT64_C(57) : v5587));
        uint64_t v5735 = (v5728 ? (((((uint64_t)(v5725 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(56)]))) : v5638);
        uint64_t v5736 = (v5729 ? ((v5604 + UINT64_C(1)) & UINT64_C(255)) : v5604);
        uint64_t v5737 = (v5729 ? UINT64_C(55) : v5655);
        uint64_t v5738 = (v5729 ? ((uint64_t)((UINT64_C(56) + v5725) & UINT64_C(255))) : v5621);
        uint64_t v5739 = ((v5727 || v5728) ? UINT64_C(1) : ((v5733 || (v5726 && (!v5729))) ? UINT64_C(2) : v5672));
        t5740 = v5735;
    } else {
        t5740 = v5638;
    }
    uint64_t v5741 = t5740;
    uint64_t t5757;
    if (v5673) {
        uint64_t v5742 = ((uint64_t)in_b[UINT64_C(55)]);
        int v5743 = ((v5672 == UINT64_C(0)) && (UINT64_C(55) == v5621));
        int v5744 = (v5743 && (v5742 == UINT64_C(0)));
        int v5745 = ((v5743 && ((v5742 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(56) < ((uint64_t)((uint64_t)in_b_len))));
        int v5746 = (((v5743 && (v5742 != UINT64_C(0))) && (v5742 < UINT64_C(64))) && (((uint64_t)((UINT64_C(55) + v5742) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5749 = ((v5672 == UINT64_C(0)) && (UINT64_C(55) != v5621));
        if (t5749) {
                uint64_t v5747 = v5742;
            int t5748 = (!(((((v5747 | UINT64_C(32)) >= UINT64_C(97)) && ((v5747 | UINT64_C(32)) <= UINT64_C(122))) || ((v5747 >= UINT64_C(48)) && (v5747 <= UINT64_C(57)))) || (v5747 == UINT64_C(45))));
            if (!t5748) {
                t5748 = ((v5742 == UINT64_C(45)) && ((UINT64_C(55) == ((v5655 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(56) == v5621)));
            }
            t5749 = t5748;
        }
        int v5750 = t5749;
        uint64_t v5751 = (v5744 ? UINT64_C(56) : (v5745 ? UINT64_C(57) : v5587));
        uint64_t v5752 = (v5745 ? (((((uint64_t)(v5742 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(56)]))) : v5638);
        uint64_t v5753 = (v5746 ? ((v5604 + UINT64_C(1)) & UINT64_C(255)) : v5604);
        uint64_t v5754 = (v5746 ? UINT64_C(55) : v5655);
        uint64_t v5755 = (v5746 ? ((uint64_t)((UINT64_C(56) + v5742) & UINT64_C(255))) : v5621);
        uint64_t v5756 = ((v5744 || v5745) ? UINT64_C(1) : ((v5750 || (v5743 && (!v5746))) ? UINT64_C(2) : v5672));
        t5757 = v5754;
    } else {
        t5757 = v5655;
    }
    uint64_t v5758 = t5757;
    uint64_t t5774;
    if (v5673) {
        uint64_t v5759 = ((uint64_t)in_b[UINT64_C(55)]);
        int v5760 = ((v5672 == UINT64_C(0)) && (UINT64_C(55) == v5621));
        int v5761 = (v5760 && (v5759 == UINT64_C(0)));
        int v5762 = ((v5760 && ((v5759 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(56) < ((uint64_t)((uint64_t)in_b_len))));
        int v5763 = (((v5760 && (v5759 != UINT64_C(0))) && (v5759 < UINT64_C(64))) && (((uint64_t)((UINT64_C(55) + v5759) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5766 = ((v5672 == UINT64_C(0)) && (UINT64_C(55) != v5621));
        if (t5766) {
                uint64_t v5764 = v5759;
            int t5765 = (!(((((v5764 | UINT64_C(32)) >= UINT64_C(97)) && ((v5764 | UINT64_C(32)) <= UINT64_C(122))) || ((v5764 >= UINT64_C(48)) && (v5764 <= UINT64_C(57)))) || (v5764 == UINT64_C(45))));
            if (!t5765) {
                t5765 = ((v5759 == UINT64_C(45)) && ((UINT64_C(55) == ((v5655 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(56) == v5621)));
            }
            t5766 = t5765;
        }
        int v5767 = t5766;
        uint64_t v5768 = (v5761 ? UINT64_C(56) : (v5762 ? UINT64_C(57) : v5587));
        uint64_t v5769 = (v5762 ? (((((uint64_t)(v5759 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(56)]))) : v5638);
        uint64_t v5770 = (v5763 ? ((v5604 + UINT64_C(1)) & UINT64_C(255)) : v5604);
        uint64_t v5771 = (v5763 ? UINT64_C(55) : v5655);
        uint64_t v5772 = (v5763 ? ((uint64_t)((UINT64_C(56) + v5759) & UINT64_C(255))) : v5621);
        uint64_t v5773 = ((v5761 || v5762) ? UINT64_C(1) : ((v5767 || (v5760 && (!v5763))) ? UINT64_C(2) : v5672));
        t5774 = v5773;
    } else {
        t5774 = v5672;
    }
    uint64_t v5775 = t5774;
    int v5776 = (UINT64_C(56) < v7);
    uint64_t t5792;
    if (v5776) {
        uint64_t v5777 = ((uint64_t)in_b[UINT64_C(56)]);
        int v5778 = ((v5775 == UINT64_C(0)) && (UINT64_C(56) == v5724));
        int v5779 = (v5778 && (v5777 == UINT64_C(0)));
        int v5780 = ((v5778 && ((v5777 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(57) < ((uint64_t)((uint64_t)in_b_len))));
        int v5781 = (((v5778 && (v5777 != UINT64_C(0))) && (v5777 < UINT64_C(64))) && (((uint64_t)((UINT64_C(56) + v5777) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5784 = ((v5775 == UINT64_C(0)) && (UINT64_C(56) != v5724));
        if (t5784) {
                uint64_t v5782 = v5777;
            int t5783 = (!(((((v5782 | UINT64_C(32)) >= UINT64_C(97)) && ((v5782 | UINT64_C(32)) <= UINT64_C(122))) || ((v5782 >= UINT64_C(48)) && (v5782 <= UINT64_C(57)))) || (v5782 == UINT64_C(45))));
            if (!t5783) {
                t5783 = ((v5777 == UINT64_C(45)) && ((UINT64_C(56) == ((v5758 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(57) == v5724)));
            }
            t5784 = t5783;
        }
        int v5785 = t5784;
        uint64_t v5786 = (v5779 ? UINT64_C(57) : (v5780 ? UINT64_C(58) : v5690));
        uint64_t v5787 = (v5780 ? (((((uint64_t)(v5777 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(57)]))) : v5741);
        uint64_t v5788 = (v5781 ? ((v5707 + UINT64_C(1)) & UINT64_C(255)) : v5707);
        uint64_t v5789 = (v5781 ? UINT64_C(56) : v5758);
        uint64_t v5790 = (v5781 ? ((uint64_t)((UINT64_C(57) + v5777) & UINT64_C(255))) : v5724);
        uint64_t v5791 = ((v5779 || v5780) ? UINT64_C(1) : ((v5785 || (v5778 && (!v5781))) ? UINT64_C(2) : v5775));
        t5792 = v5786;
    } else {
        t5792 = v5690;
    }
    uint64_t v5793 = t5792;
    uint64_t t5809;
    if (v5776) {
        uint64_t v5794 = ((uint64_t)in_b[UINT64_C(56)]);
        int v5795 = ((v5775 == UINT64_C(0)) && (UINT64_C(56) == v5724));
        int v5796 = (v5795 && (v5794 == UINT64_C(0)));
        int v5797 = ((v5795 && ((v5794 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(57) < ((uint64_t)((uint64_t)in_b_len))));
        int v5798 = (((v5795 && (v5794 != UINT64_C(0))) && (v5794 < UINT64_C(64))) && (((uint64_t)((UINT64_C(56) + v5794) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5801 = ((v5775 == UINT64_C(0)) && (UINT64_C(56) != v5724));
        if (t5801) {
                uint64_t v5799 = v5794;
            int t5800 = (!(((((v5799 | UINT64_C(32)) >= UINT64_C(97)) && ((v5799 | UINT64_C(32)) <= UINT64_C(122))) || ((v5799 >= UINT64_C(48)) && (v5799 <= UINT64_C(57)))) || (v5799 == UINT64_C(45))));
            if (!t5800) {
                t5800 = ((v5794 == UINT64_C(45)) && ((UINT64_C(56) == ((v5758 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(57) == v5724)));
            }
            t5801 = t5800;
        }
        int v5802 = t5801;
        uint64_t v5803 = (v5796 ? UINT64_C(57) : (v5797 ? UINT64_C(58) : v5690));
        uint64_t v5804 = (v5797 ? (((((uint64_t)(v5794 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(57)]))) : v5741);
        uint64_t v5805 = (v5798 ? ((v5707 + UINT64_C(1)) & UINT64_C(255)) : v5707);
        uint64_t v5806 = (v5798 ? UINT64_C(56) : v5758);
        uint64_t v5807 = (v5798 ? ((uint64_t)((UINT64_C(57) + v5794) & UINT64_C(255))) : v5724);
        uint64_t v5808 = ((v5796 || v5797) ? UINT64_C(1) : ((v5802 || (v5795 && (!v5798))) ? UINT64_C(2) : v5775));
        t5809 = v5805;
    } else {
        t5809 = v5707;
    }
    uint64_t v5810 = t5809;
    uint64_t t5826;
    if (v5776) {
        uint64_t v5811 = ((uint64_t)in_b[UINT64_C(56)]);
        int v5812 = ((v5775 == UINT64_C(0)) && (UINT64_C(56) == v5724));
        int v5813 = (v5812 && (v5811 == UINT64_C(0)));
        int v5814 = ((v5812 && ((v5811 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(57) < ((uint64_t)((uint64_t)in_b_len))));
        int v5815 = (((v5812 && (v5811 != UINT64_C(0))) && (v5811 < UINT64_C(64))) && (((uint64_t)((UINT64_C(56) + v5811) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5818 = ((v5775 == UINT64_C(0)) && (UINT64_C(56) != v5724));
        if (t5818) {
                uint64_t v5816 = v5811;
            int t5817 = (!(((((v5816 | UINT64_C(32)) >= UINT64_C(97)) && ((v5816 | UINT64_C(32)) <= UINT64_C(122))) || ((v5816 >= UINT64_C(48)) && (v5816 <= UINT64_C(57)))) || (v5816 == UINT64_C(45))));
            if (!t5817) {
                t5817 = ((v5811 == UINT64_C(45)) && ((UINT64_C(56) == ((v5758 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(57) == v5724)));
            }
            t5818 = t5817;
        }
        int v5819 = t5818;
        uint64_t v5820 = (v5813 ? UINT64_C(57) : (v5814 ? UINT64_C(58) : v5690));
        uint64_t v5821 = (v5814 ? (((((uint64_t)(v5811 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(57)]))) : v5741);
        uint64_t v5822 = (v5815 ? ((v5707 + UINT64_C(1)) & UINT64_C(255)) : v5707);
        uint64_t v5823 = (v5815 ? UINT64_C(56) : v5758);
        uint64_t v5824 = (v5815 ? ((uint64_t)((UINT64_C(57) + v5811) & UINT64_C(255))) : v5724);
        uint64_t v5825 = ((v5813 || v5814) ? UINT64_C(1) : ((v5819 || (v5812 && (!v5815))) ? UINT64_C(2) : v5775));
        t5826 = v5824;
    } else {
        t5826 = v5724;
    }
    uint64_t v5827 = t5826;
    uint64_t t5843;
    if (v5776) {
        uint64_t v5828 = ((uint64_t)in_b[UINT64_C(56)]);
        int v5829 = ((v5775 == UINT64_C(0)) && (UINT64_C(56) == v5724));
        int v5830 = (v5829 && (v5828 == UINT64_C(0)));
        int v5831 = ((v5829 && ((v5828 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(57) < ((uint64_t)((uint64_t)in_b_len))));
        int v5832 = (((v5829 && (v5828 != UINT64_C(0))) && (v5828 < UINT64_C(64))) && (((uint64_t)((UINT64_C(56) + v5828) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5835 = ((v5775 == UINT64_C(0)) && (UINT64_C(56) != v5724));
        if (t5835) {
                uint64_t v5833 = v5828;
            int t5834 = (!(((((v5833 | UINT64_C(32)) >= UINT64_C(97)) && ((v5833 | UINT64_C(32)) <= UINT64_C(122))) || ((v5833 >= UINT64_C(48)) && (v5833 <= UINT64_C(57)))) || (v5833 == UINT64_C(45))));
            if (!t5834) {
                t5834 = ((v5828 == UINT64_C(45)) && ((UINT64_C(56) == ((v5758 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(57) == v5724)));
            }
            t5835 = t5834;
        }
        int v5836 = t5835;
        uint64_t v5837 = (v5830 ? UINT64_C(57) : (v5831 ? UINT64_C(58) : v5690));
        uint64_t v5838 = (v5831 ? (((((uint64_t)(v5828 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(57)]))) : v5741);
        uint64_t v5839 = (v5832 ? ((v5707 + UINT64_C(1)) & UINT64_C(255)) : v5707);
        uint64_t v5840 = (v5832 ? UINT64_C(56) : v5758);
        uint64_t v5841 = (v5832 ? ((uint64_t)((UINT64_C(57) + v5828) & UINT64_C(255))) : v5724);
        uint64_t v5842 = ((v5830 || v5831) ? UINT64_C(1) : ((v5836 || (v5829 && (!v5832))) ? UINT64_C(2) : v5775));
        t5843 = v5838;
    } else {
        t5843 = v5741;
    }
    uint64_t v5844 = t5843;
    uint64_t t5860;
    if (v5776) {
        uint64_t v5845 = ((uint64_t)in_b[UINT64_C(56)]);
        int v5846 = ((v5775 == UINT64_C(0)) && (UINT64_C(56) == v5724));
        int v5847 = (v5846 && (v5845 == UINT64_C(0)));
        int v5848 = ((v5846 && ((v5845 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(57) < ((uint64_t)((uint64_t)in_b_len))));
        int v5849 = (((v5846 && (v5845 != UINT64_C(0))) && (v5845 < UINT64_C(64))) && (((uint64_t)((UINT64_C(56) + v5845) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5852 = ((v5775 == UINT64_C(0)) && (UINT64_C(56) != v5724));
        if (t5852) {
                uint64_t v5850 = v5845;
            int t5851 = (!(((((v5850 | UINT64_C(32)) >= UINT64_C(97)) && ((v5850 | UINT64_C(32)) <= UINT64_C(122))) || ((v5850 >= UINT64_C(48)) && (v5850 <= UINT64_C(57)))) || (v5850 == UINT64_C(45))));
            if (!t5851) {
                t5851 = ((v5845 == UINT64_C(45)) && ((UINT64_C(56) == ((v5758 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(57) == v5724)));
            }
            t5852 = t5851;
        }
        int v5853 = t5852;
        uint64_t v5854 = (v5847 ? UINT64_C(57) : (v5848 ? UINT64_C(58) : v5690));
        uint64_t v5855 = (v5848 ? (((((uint64_t)(v5845 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(57)]))) : v5741);
        uint64_t v5856 = (v5849 ? ((v5707 + UINT64_C(1)) & UINT64_C(255)) : v5707);
        uint64_t v5857 = (v5849 ? UINT64_C(56) : v5758);
        uint64_t v5858 = (v5849 ? ((uint64_t)((UINT64_C(57) + v5845) & UINT64_C(255))) : v5724);
        uint64_t v5859 = ((v5847 || v5848) ? UINT64_C(1) : ((v5853 || (v5846 && (!v5849))) ? UINT64_C(2) : v5775));
        t5860 = v5857;
    } else {
        t5860 = v5758;
    }
    uint64_t v5861 = t5860;
    uint64_t t5877;
    if (v5776) {
        uint64_t v5862 = ((uint64_t)in_b[UINT64_C(56)]);
        int v5863 = ((v5775 == UINT64_C(0)) && (UINT64_C(56) == v5724));
        int v5864 = (v5863 && (v5862 == UINT64_C(0)));
        int v5865 = ((v5863 && ((v5862 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(57) < ((uint64_t)((uint64_t)in_b_len))));
        int v5866 = (((v5863 && (v5862 != UINT64_C(0))) && (v5862 < UINT64_C(64))) && (((uint64_t)((UINT64_C(56) + v5862) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5869 = ((v5775 == UINT64_C(0)) && (UINT64_C(56) != v5724));
        if (t5869) {
                uint64_t v5867 = v5862;
            int t5868 = (!(((((v5867 | UINT64_C(32)) >= UINT64_C(97)) && ((v5867 | UINT64_C(32)) <= UINT64_C(122))) || ((v5867 >= UINT64_C(48)) && (v5867 <= UINT64_C(57)))) || (v5867 == UINT64_C(45))));
            if (!t5868) {
                t5868 = ((v5862 == UINT64_C(45)) && ((UINT64_C(56) == ((v5758 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(57) == v5724)));
            }
            t5869 = t5868;
        }
        int v5870 = t5869;
        uint64_t v5871 = (v5864 ? UINT64_C(57) : (v5865 ? UINT64_C(58) : v5690));
        uint64_t v5872 = (v5865 ? (((((uint64_t)(v5862 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(57)]))) : v5741);
        uint64_t v5873 = (v5866 ? ((v5707 + UINT64_C(1)) & UINT64_C(255)) : v5707);
        uint64_t v5874 = (v5866 ? UINT64_C(56) : v5758);
        uint64_t v5875 = (v5866 ? ((uint64_t)((UINT64_C(57) + v5862) & UINT64_C(255))) : v5724);
        uint64_t v5876 = ((v5864 || v5865) ? UINT64_C(1) : ((v5870 || (v5863 && (!v5866))) ? UINT64_C(2) : v5775));
        t5877 = v5876;
    } else {
        t5877 = v5775;
    }
    uint64_t v5878 = t5877;
    int v5879 = (UINT64_C(57) < v7);
    uint64_t t5895;
    if (v5879) {
        uint64_t v5880 = ((uint64_t)in_b[UINT64_C(57)]);
        int v5881 = ((v5878 == UINT64_C(0)) && (UINT64_C(57) == v5827));
        int v5882 = (v5881 && (v5880 == UINT64_C(0)));
        int v5883 = ((v5881 && ((v5880 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(58) < ((uint64_t)((uint64_t)in_b_len))));
        int v5884 = (((v5881 && (v5880 != UINT64_C(0))) && (v5880 < UINT64_C(64))) && (((uint64_t)((UINT64_C(57) + v5880) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5887 = ((v5878 == UINT64_C(0)) && (UINT64_C(57) != v5827));
        if (t5887) {
                uint64_t v5885 = v5880;
            int t5886 = (!(((((v5885 | UINT64_C(32)) >= UINT64_C(97)) && ((v5885 | UINT64_C(32)) <= UINT64_C(122))) || ((v5885 >= UINT64_C(48)) && (v5885 <= UINT64_C(57)))) || (v5885 == UINT64_C(45))));
            if (!t5886) {
                t5886 = ((v5880 == UINT64_C(45)) && ((UINT64_C(57) == ((v5861 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(58) == v5827)));
            }
            t5887 = t5886;
        }
        int v5888 = t5887;
        uint64_t v5889 = (v5882 ? UINT64_C(58) : (v5883 ? UINT64_C(59) : v5793));
        uint64_t v5890 = (v5883 ? (((((uint64_t)(v5880 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(58)]))) : v5844);
        uint64_t v5891 = (v5884 ? ((v5810 + UINT64_C(1)) & UINT64_C(255)) : v5810);
        uint64_t v5892 = (v5884 ? UINT64_C(57) : v5861);
        uint64_t v5893 = (v5884 ? ((uint64_t)((UINT64_C(58) + v5880) & UINT64_C(255))) : v5827);
        uint64_t v5894 = ((v5882 || v5883) ? UINT64_C(1) : ((v5888 || (v5881 && (!v5884))) ? UINT64_C(2) : v5878));
        t5895 = v5889;
    } else {
        t5895 = v5793;
    }
    uint64_t v5896 = t5895;
    uint64_t t5912;
    if (v5879) {
        uint64_t v5897 = ((uint64_t)in_b[UINT64_C(57)]);
        int v5898 = ((v5878 == UINT64_C(0)) && (UINT64_C(57) == v5827));
        int v5899 = (v5898 && (v5897 == UINT64_C(0)));
        int v5900 = ((v5898 && ((v5897 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(58) < ((uint64_t)((uint64_t)in_b_len))));
        int v5901 = (((v5898 && (v5897 != UINT64_C(0))) && (v5897 < UINT64_C(64))) && (((uint64_t)((UINT64_C(57) + v5897) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5904 = ((v5878 == UINT64_C(0)) && (UINT64_C(57) != v5827));
        if (t5904) {
                uint64_t v5902 = v5897;
            int t5903 = (!(((((v5902 | UINT64_C(32)) >= UINT64_C(97)) && ((v5902 | UINT64_C(32)) <= UINT64_C(122))) || ((v5902 >= UINT64_C(48)) && (v5902 <= UINT64_C(57)))) || (v5902 == UINT64_C(45))));
            if (!t5903) {
                t5903 = ((v5897 == UINT64_C(45)) && ((UINT64_C(57) == ((v5861 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(58) == v5827)));
            }
            t5904 = t5903;
        }
        int v5905 = t5904;
        uint64_t v5906 = (v5899 ? UINT64_C(58) : (v5900 ? UINT64_C(59) : v5793));
        uint64_t v5907 = (v5900 ? (((((uint64_t)(v5897 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(58)]))) : v5844);
        uint64_t v5908 = (v5901 ? ((v5810 + UINT64_C(1)) & UINT64_C(255)) : v5810);
        uint64_t v5909 = (v5901 ? UINT64_C(57) : v5861);
        uint64_t v5910 = (v5901 ? ((uint64_t)((UINT64_C(58) + v5897) & UINT64_C(255))) : v5827);
        uint64_t v5911 = ((v5899 || v5900) ? UINT64_C(1) : ((v5905 || (v5898 && (!v5901))) ? UINT64_C(2) : v5878));
        t5912 = v5908;
    } else {
        t5912 = v5810;
    }
    uint64_t v5913 = t5912;
    uint64_t t5929;
    if (v5879) {
        uint64_t v5914 = ((uint64_t)in_b[UINT64_C(57)]);
        int v5915 = ((v5878 == UINT64_C(0)) && (UINT64_C(57) == v5827));
        int v5916 = (v5915 && (v5914 == UINT64_C(0)));
        int v5917 = ((v5915 && ((v5914 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(58) < ((uint64_t)((uint64_t)in_b_len))));
        int v5918 = (((v5915 && (v5914 != UINT64_C(0))) && (v5914 < UINT64_C(64))) && (((uint64_t)((UINT64_C(57) + v5914) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5921 = ((v5878 == UINT64_C(0)) && (UINT64_C(57) != v5827));
        if (t5921) {
                uint64_t v5919 = v5914;
            int t5920 = (!(((((v5919 | UINT64_C(32)) >= UINT64_C(97)) && ((v5919 | UINT64_C(32)) <= UINT64_C(122))) || ((v5919 >= UINT64_C(48)) && (v5919 <= UINT64_C(57)))) || (v5919 == UINT64_C(45))));
            if (!t5920) {
                t5920 = ((v5914 == UINT64_C(45)) && ((UINT64_C(57) == ((v5861 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(58) == v5827)));
            }
            t5921 = t5920;
        }
        int v5922 = t5921;
        uint64_t v5923 = (v5916 ? UINT64_C(58) : (v5917 ? UINT64_C(59) : v5793));
        uint64_t v5924 = (v5917 ? (((((uint64_t)(v5914 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(58)]))) : v5844);
        uint64_t v5925 = (v5918 ? ((v5810 + UINT64_C(1)) & UINT64_C(255)) : v5810);
        uint64_t v5926 = (v5918 ? UINT64_C(57) : v5861);
        uint64_t v5927 = (v5918 ? ((uint64_t)((UINT64_C(58) + v5914) & UINT64_C(255))) : v5827);
        uint64_t v5928 = ((v5916 || v5917) ? UINT64_C(1) : ((v5922 || (v5915 && (!v5918))) ? UINT64_C(2) : v5878));
        t5929 = v5927;
    } else {
        t5929 = v5827;
    }
    uint64_t v5930 = t5929;
    uint64_t t5946;
    if (v5879) {
        uint64_t v5931 = ((uint64_t)in_b[UINT64_C(57)]);
        int v5932 = ((v5878 == UINT64_C(0)) && (UINT64_C(57) == v5827));
        int v5933 = (v5932 && (v5931 == UINT64_C(0)));
        int v5934 = ((v5932 && ((v5931 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(58) < ((uint64_t)((uint64_t)in_b_len))));
        int v5935 = (((v5932 && (v5931 != UINT64_C(0))) && (v5931 < UINT64_C(64))) && (((uint64_t)((UINT64_C(57) + v5931) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5938 = ((v5878 == UINT64_C(0)) && (UINT64_C(57) != v5827));
        if (t5938) {
                uint64_t v5936 = v5931;
            int t5937 = (!(((((v5936 | UINT64_C(32)) >= UINT64_C(97)) && ((v5936 | UINT64_C(32)) <= UINT64_C(122))) || ((v5936 >= UINT64_C(48)) && (v5936 <= UINT64_C(57)))) || (v5936 == UINT64_C(45))));
            if (!t5937) {
                t5937 = ((v5931 == UINT64_C(45)) && ((UINT64_C(57) == ((v5861 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(58) == v5827)));
            }
            t5938 = t5937;
        }
        int v5939 = t5938;
        uint64_t v5940 = (v5933 ? UINT64_C(58) : (v5934 ? UINT64_C(59) : v5793));
        uint64_t v5941 = (v5934 ? (((((uint64_t)(v5931 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(58)]))) : v5844);
        uint64_t v5942 = (v5935 ? ((v5810 + UINT64_C(1)) & UINT64_C(255)) : v5810);
        uint64_t v5943 = (v5935 ? UINT64_C(57) : v5861);
        uint64_t v5944 = (v5935 ? ((uint64_t)((UINT64_C(58) + v5931) & UINT64_C(255))) : v5827);
        uint64_t v5945 = ((v5933 || v5934) ? UINT64_C(1) : ((v5939 || (v5932 && (!v5935))) ? UINT64_C(2) : v5878));
        t5946 = v5941;
    } else {
        t5946 = v5844;
    }
    uint64_t v5947 = t5946;
    uint64_t t5963;
    if (v5879) {
        uint64_t v5948 = ((uint64_t)in_b[UINT64_C(57)]);
        int v5949 = ((v5878 == UINT64_C(0)) && (UINT64_C(57) == v5827));
        int v5950 = (v5949 && (v5948 == UINT64_C(0)));
        int v5951 = ((v5949 && ((v5948 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(58) < ((uint64_t)((uint64_t)in_b_len))));
        int v5952 = (((v5949 && (v5948 != UINT64_C(0))) && (v5948 < UINT64_C(64))) && (((uint64_t)((UINT64_C(57) + v5948) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5955 = ((v5878 == UINT64_C(0)) && (UINT64_C(57) != v5827));
        if (t5955) {
                uint64_t v5953 = v5948;
            int t5954 = (!(((((v5953 | UINT64_C(32)) >= UINT64_C(97)) && ((v5953 | UINT64_C(32)) <= UINT64_C(122))) || ((v5953 >= UINT64_C(48)) && (v5953 <= UINT64_C(57)))) || (v5953 == UINT64_C(45))));
            if (!t5954) {
                t5954 = ((v5948 == UINT64_C(45)) && ((UINT64_C(57) == ((v5861 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(58) == v5827)));
            }
            t5955 = t5954;
        }
        int v5956 = t5955;
        uint64_t v5957 = (v5950 ? UINT64_C(58) : (v5951 ? UINT64_C(59) : v5793));
        uint64_t v5958 = (v5951 ? (((((uint64_t)(v5948 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(58)]))) : v5844);
        uint64_t v5959 = (v5952 ? ((v5810 + UINT64_C(1)) & UINT64_C(255)) : v5810);
        uint64_t v5960 = (v5952 ? UINT64_C(57) : v5861);
        uint64_t v5961 = (v5952 ? ((uint64_t)((UINT64_C(58) + v5948) & UINT64_C(255))) : v5827);
        uint64_t v5962 = ((v5950 || v5951) ? UINT64_C(1) : ((v5956 || (v5949 && (!v5952))) ? UINT64_C(2) : v5878));
        t5963 = v5960;
    } else {
        t5963 = v5861;
    }
    uint64_t v5964 = t5963;
    uint64_t t5980;
    if (v5879) {
        uint64_t v5965 = ((uint64_t)in_b[UINT64_C(57)]);
        int v5966 = ((v5878 == UINT64_C(0)) && (UINT64_C(57) == v5827));
        int v5967 = (v5966 && (v5965 == UINT64_C(0)));
        int v5968 = ((v5966 && ((v5965 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(58) < ((uint64_t)((uint64_t)in_b_len))));
        int v5969 = (((v5966 && (v5965 != UINT64_C(0))) && (v5965 < UINT64_C(64))) && (((uint64_t)((UINT64_C(57) + v5965) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5972 = ((v5878 == UINT64_C(0)) && (UINT64_C(57) != v5827));
        if (t5972) {
                uint64_t v5970 = v5965;
            int t5971 = (!(((((v5970 | UINT64_C(32)) >= UINT64_C(97)) && ((v5970 | UINT64_C(32)) <= UINT64_C(122))) || ((v5970 >= UINT64_C(48)) && (v5970 <= UINT64_C(57)))) || (v5970 == UINT64_C(45))));
            if (!t5971) {
                t5971 = ((v5965 == UINT64_C(45)) && ((UINT64_C(57) == ((v5861 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(58) == v5827)));
            }
            t5972 = t5971;
        }
        int v5973 = t5972;
        uint64_t v5974 = (v5967 ? UINT64_C(58) : (v5968 ? UINT64_C(59) : v5793));
        uint64_t v5975 = (v5968 ? (((((uint64_t)(v5965 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(58)]))) : v5844);
        uint64_t v5976 = (v5969 ? ((v5810 + UINT64_C(1)) & UINT64_C(255)) : v5810);
        uint64_t v5977 = (v5969 ? UINT64_C(57) : v5861);
        uint64_t v5978 = (v5969 ? ((uint64_t)((UINT64_C(58) + v5965) & UINT64_C(255))) : v5827);
        uint64_t v5979 = ((v5967 || v5968) ? UINT64_C(1) : ((v5973 || (v5966 && (!v5969))) ? UINT64_C(2) : v5878));
        t5980 = v5979;
    } else {
        t5980 = v5878;
    }
    uint64_t v5981 = t5980;
    int v5982 = (UINT64_C(58) < v7);
    uint64_t t5998;
    if (v5982) {
        uint64_t v5983 = ((uint64_t)in_b[UINT64_C(58)]);
        int v5984 = ((v5981 == UINT64_C(0)) && (UINT64_C(58) == v5930));
        int v5985 = (v5984 && (v5983 == UINT64_C(0)));
        int v5986 = ((v5984 && ((v5983 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(59) < ((uint64_t)((uint64_t)in_b_len))));
        int v5987 = (((v5984 && (v5983 != UINT64_C(0))) && (v5983 < UINT64_C(64))) && (((uint64_t)((UINT64_C(58) + v5983) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t5990 = ((v5981 == UINT64_C(0)) && (UINT64_C(58) != v5930));
        if (t5990) {
                uint64_t v5988 = v5983;
            int t5989 = (!(((((v5988 | UINT64_C(32)) >= UINT64_C(97)) && ((v5988 | UINT64_C(32)) <= UINT64_C(122))) || ((v5988 >= UINT64_C(48)) && (v5988 <= UINT64_C(57)))) || (v5988 == UINT64_C(45))));
            if (!t5989) {
                t5989 = ((v5983 == UINT64_C(45)) && ((UINT64_C(58) == ((v5964 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(59) == v5930)));
            }
            t5990 = t5989;
        }
        int v5991 = t5990;
        uint64_t v5992 = (v5985 ? UINT64_C(59) : (v5986 ? UINT64_C(60) : v5896));
        uint64_t v5993 = (v5986 ? (((((uint64_t)(v5983 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(59)]))) : v5947);
        uint64_t v5994 = (v5987 ? ((v5913 + UINT64_C(1)) & UINT64_C(255)) : v5913);
        uint64_t v5995 = (v5987 ? UINT64_C(58) : v5964);
        uint64_t v5996 = (v5987 ? ((uint64_t)((UINT64_C(59) + v5983) & UINT64_C(255))) : v5930);
        uint64_t v5997 = ((v5985 || v5986) ? UINT64_C(1) : ((v5991 || (v5984 && (!v5987))) ? UINT64_C(2) : v5981));
        t5998 = v5992;
    } else {
        t5998 = v5896;
    }
    uint64_t v5999 = t5998;
    uint64_t t6015;
    if (v5982) {
        uint64_t v6000 = ((uint64_t)in_b[UINT64_C(58)]);
        int v6001 = ((v5981 == UINT64_C(0)) && (UINT64_C(58) == v5930));
        int v6002 = (v6001 && (v6000 == UINT64_C(0)));
        int v6003 = ((v6001 && ((v6000 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(59) < ((uint64_t)((uint64_t)in_b_len))));
        int v6004 = (((v6001 && (v6000 != UINT64_C(0))) && (v6000 < UINT64_C(64))) && (((uint64_t)((UINT64_C(58) + v6000) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6007 = ((v5981 == UINT64_C(0)) && (UINT64_C(58) != v5930));
        if (t6007) {
                uint64_t v6005 = v6000;
            int t6006 = (!(((((v6005 | UINT64_C(32)) >= UINT64_C(97)) && ((v6005 | UINT64_C(32)) <= UINT64_C(122))) || ((v6005 >= UINT64_C(48)) && (v6005 <= UINT64_C(57)))) || (v6005 == UINT64_C(45))));
            if (!t6006) {
                t6006 = ((v6000 == UINT64_C(45)) && ((UINT64_C(58) == ((v5964 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(59) == v5930)));
            }
            t6007 = t6006;
        }
        int v6008 = t6007;
        uint64_t v6009 = (v6002 ? UINT64_C(59) : (v6003 ? UINT64_C(60) : v5896));
        uint64_t v6010 = (v6003 ? (((((uint64_t)(v6000 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(59)]))) : v5947);
        uint64_t v6011 = (v6004 ? ((v5913 + UINT64_C(1)) & UINT64_C(255)) : v5913);
        uint64_t v6012 = (v6004 ? UINT64_C(58) : v5964);
        uint64_t v6013 = (v6004 ? ((uint64_t)((UINT64_C(59) + v6000) & UINT64_C(255))) : v5930);
        uint64_t v6014 = ((v6002 || v6003) ? UINT64_C(1) : ((v6008 || (v6001 && (!v6004))) ? UINT64_C(2) : v5981));
        t6015 = v6011;
    } else {
        t6015 = v5913;
    }
    uint64_t v6016 = t6015;
    uint64_t t6032;
    if (v5982) {
        uint64_t v6017 = ((uint64_t)in_b[UINT64_C(58)]);
        int v6018 = ((v5981 == UINT64_C(0)) && (UINT64_C(58) == v5930));
        int v6019 = (v6018 && (v6017 == UINT64_C(0)));
        int v6020 = ((v6018 && ((v6017 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(59) < ((uint64_t)((uint64_t)in_b_len))));
        int v6021 = (((v6018 && (v6017 != UINT64_C(0))) && (v6017 < UINT64_C(64))) && (((uint64_t)((UINT64_C(58) + v6017) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6024 = ((v5981 == UINT64_C(0)) && (UINT64_C(58) != v5930));
        if (t6024) {
                uint64_t v6022 = v6017;
            int t6023 = (!(((((v6022 | UINT64_C(32)) >= UINT64_C(97)) && ((v6022 | UINT64_C(32)) <= UINT64_C(122))) || ((v6022 >= UINT64_C(48)) && (v6022 <= UINT64_C(57)))) || (v6022 == UINT64_C(45))));
            if (!t6023) {
                t6023 = ((v6017 == UINT64_C(45)) && ((UINT64_C(58) == ((v5964 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(59) == v5930)));
            }
            t6024 = t6023;
        }
        int v6025 = t6024;
        uint64_t v6026 = (v6019 ? UINT64_C(59) : (v6020 ? UINT64_C(60) : v5896));
        uint64_t v6027 = (v6020 ? (((((uint64_t)(v6017 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(59)]))) : v5947);
        uint64_t v6028 = (v6021 ? ((v5913 + UINT64_C(1)) & UINT64_C(255)) : v5913);
        uint64_t v6029 = (v6021 ? UINT64_C(58) : v5964);
        uint64_t v6030 = (v6021 ? ((uint64_t)((UINT64_C(59) + v6017) & UINT64_C(255))) : v5930);
        uint64_t v6031 = ((v6019 || v6020) ? UINT64_C(1) : ((v6025 || (v6018 && (!v6021))) ? UINT64_C(2) : v5981));
        t6032 = v6030;
    } else {
        t6032 = v5930;
    }
    uint64_t v6033 = t6032;
    uint64_t t6049;
    if (v5982) {
        uint64_t v6034 = ((uint64_t)in_b[UINT64_C(58)]);
        int v6035 = ((v5981 == UINT64_C(0)) && (UINT64_C(58) == v5930));
        int v6036 = (v6035 && (v6034 == UINT64_C(0)));
        int v6037 = ((v6035 && ((v6034 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(59) < ((uint64_t)((uint64_t)in_b_len))));
        int v6038 = (((v6035 && (v6034 != UINT64_C(0))) && (v6034 < UINT64_C(64))) && (((uint64_t)((UINT64_C(58) + v6034) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6041 = ((v5981 == UINT64_C(0)) && (UINT64_C(58) != v5930));
        if (t6041) {
                uint64_t v6039 = v6034;
            int t6040 = (!(((((v6039 | UINT64_C(32)) >= UINT64_C(97)) && ((v6039 | UINT64_C(32)) <= UINT64_C(122))) || ((v6039 >= UINT64_C(48)) && (v6039 <= UINT64_C(57)))) || (v6039 == UINT64_C(45))));
            if (!t6040) {
                t6040 = ((v6034 == UINT64_C(45)) && ((UINT64_C(58) == ((v5964 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(59) == v5930)));
            }
            t6041 = t6040;
        }
        int v6042 = t6041;
        uint64_t v6043 = (v6036 ? UINT64_C(59) : (v6037 ? UINT64_C(60) : v5896));
        uint64_t v6044 = (v6037 ? (((((uint64_t)(v6034 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(59)]))) : v5947);
        uint64_t v6045 = (v6038 ? ((v5913 + UINT64_C(1)) & UINT64_C(255)) : v5913);
        uint64_t v6046 = (v6038 ? UINT64_C(58) : v5964);
        uint64_t v6047 = (v6038 ? ((uint64_t)((UINT64_C(59) + v6034) & UINT64_C(255))) : v5930);
        uint64_t v6048 = ((v6036 || v6037) ? UINT64_C(1) : ((v6042 || (v6035 && (!v6038))) ? UINT64_C(2) : v5981));
        t6049 = v6044;
    } else {
        t6049 = v5947;
    }
    uint64_t v6050 = t6049;
    uint64_t t6066;
    if (v5982) {
        uint64_t v6051 = ((uint64_t)in_b[UINT64_C(58)]);
        int v6052 = ((v5981 == UINT64_C(0)) && (UINT64_C(58) == v5930));
        int v6053 = (v6052 && (v6051 == UINT64_C(0)));
        int v6054 = ((v6052 && ((v6051 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(59) < ((uint64_t)((uint64_t)in_b_len))));
        int v6055 = (((v6052 && (v6051 != UINT64_C(0))) && (v6051 < UINT64_C(64))) && (((uint64_t)((UINT64_C(58) + v6051) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6058 = ((v5981 == UINT64_C(0)) && (UINT64_C(58) != v5930));
        if (t6058) {
                uint64_t v6056 = v6051;
            int t6057 = (!(((((v6056 | UINT64_C(32)) >= UINT64_C(97)) && ((v6056 | UINT64_C(32)) <= UINT64_C(122))) || ((v6056 >= UINT64_C(48)) && (v6056 <= UINT64_C(57)))) || (v6056 == UINT64_C(45))));
            if (!t6057) {
                t6057 = ((v6051 == UINT64_C(45)) && ((UINT64_C(58) == ((v5964 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(59) == v5930)));
            }
            t6058 = t6057;
        }
        int v6059 = t6058;
        uint64_t v6060 = (v6053 ? UINT64_C(59) : (v6054 ? UINT64_C(60) : v5896));
        uint64_t v6061 = (v6054 ? (((((uint64_t)(v6051 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(59)]))) : v5947);
        uint64_t v6062 = (v6055 ? ((v5913 + UINT64_C(1)) & UINT64_C(255)) : v5913);
        uint64_t v6063 = (v6055 ? UINT64_C(58) : v5964);
        uint64_t v6064 = (v6055 ? ((uint64_t)((UINT64_C(59) + v6051) & UINT64_C(255))) : v5930);
        uint64_t v6065 = ((v6053 || v6054) ? UINT64_C(1) : ((v6059 || (v6052 && (!v6055))) ? UINT64_C(2) : v5981));
        t6066 = v6063;
    } else {
        t6066 = v5964;
    }
    uint64_t v6067 = t6066;
    uint64_t t6083;
    if (v5982) {
        uint64_t v6068 = ((uint64_t)in_b[UINT64_C(58)]);
        int v6069 = ((v5981 == UINT64_C(0)) && (UINT64_C(58) == v5930));
        int v6070 = (v6069 && (v6068 == UINT64_C(0)));
        int v6071 = ((v6069 && ((v6068 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(59) < ((uint64_t)((uint64_t)in_b_len))));
        int v6072 = (((v6069 && (v6068 != UINT64_C(0))) && (v6068 < UINT64_C(64))) && (((uint64_t)((UINT64_C(58) + v6068) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6075 = ((v5981 == UINT64_C(0)) && (UINT64_C(58) != v5930));
        if (t6075) {
                uint64_t v6073 = v6068;
            int t6074 = (!(((((v6073 | UINT64_C(32)) >= UINT64_C(97)) && ((v6073 | UINT64_C(32)) <= UINT64_C(122))) || ((v6073 >= UINT64_C(48)) && (v6073 <= UINT64_C(57)))) || (v6073 == UINT64_C(45))));
            if (!t6074) {
                t6074 = ((v6068 == UINT64_C(45)) && ((UINT64_C(58) == ((v5964 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(59) == v5930)));
            }
            t6075 = t6074;
        }
        int v6076 = t6075;
        uint64_t v6077 = (v6070 ? UINT64_C(59) : (v6071 ? UINT64_C(60) : v5896));
        uint64_t v6078 = (v6071 ? (((((uint64_t)(v6068 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(59)]))) : v5947);
        uint64_t v6079 = (v6072 ? ((v5913 + UINT64_C(1)) & UINT64_C(255)) : v5913);
        uint64_t v6080 = (v6072 ? UINT64_C(58) : v5964);
        uint64_t v6081 = (v6072 ? ((uint64_t)((UINT64_C(59) + v6068) & UINT64_C(255))) : v5930);
        uint64_t v6082 = ((v6070 || v6071) ? UINT64_C(1) : ((v6076 || (v6069 && (!v6072))) ? UINT64_C(2) : v5981));
        t6083 = v6082;
    } else {
        t6083 = v5981;
    }
    uint64_t v6084 = t6083;
    int v6085 = (UINT64_C(59) < v7);
    uint64_t t6101;
    if (v6085) {
        uint64_t v6086 = ((uint64_t)in_b[UINT64_C(59)]);
        int v6087 = ((v6084 == UINT64_C(0)) && (UINT64_C(59) == v6033));
        int v6088 = (v6087 && (v6086 == UINT64_C(0)));
        int v6089 = ((v6087 && ((v6086 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(60) < ((uint64_t)((uint64_t)in_b_len))));
        int v6090 = (((v6087 && (v6086 != UINT64_C(0))) && (v6086 < UINT64_C(64))) && (((uint64_t)((UINT64_C(59) + v6086) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6093 = ((v6084 == UINT64_C(0)) && (UINT64_C(59) != v6033));
        if (t6093) {
                uint64_t v6091 = v6086;
            int t6092 = (!(((((v6091 | UINT64_C(32)) >= UINT64_C(97)) && ((v6091 | UINT64_C(32)) <= UINT64_C(122))) || ((v6091 >= UINT64_C(48)) && (v6091 <= UINT64_C(57)))) || (v6091 == UINT64_C(45))));
            if (!t6092) {
                t6092 = ((v6086 == UINT64_C(45)) && ((UINT64_C(59) == ((v6067 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(60) == v6033)));
            }
            t6093 = t6092;
        }
        int v6094 = t6093;
        uint64_t v6095 = (v6088 ? UINT64_C(60) : (v6089 ? UINT64_C(61) : v5999));
        uint64_t v6096 = (v6089 ? (((((uint64_t)(v6086 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(60)]))) : v6050);
        uint64_t v6097 = (v6090 ? ((v6016 + UINT64_C(1)) & UINT64_C(255)) : v6016);
        uint64_t v6098 = (v6090 ? UINT64_C(59) : v6067);
        uint64_t v6099 = (v6090 ? ((uint64_t)((UINT64_C(60) + v6086) & UINT64_C(255))) : v6033);
        uint64_t v6100 = ((v6088 || v6089) ? UINT64_C(1) : ((v6094 || (v6087 && (!v6090))) ? UINT64_C(2) : v6084));
        t6101 = v6095;
    } else {
        t6101 = v5999;
    }
    uint64_t v6102 = t6101;
    uint64_t t6118;
    if (v6085) {
        uint64_t v6103 = ((uint64_t)in_b[UINT64_C(59)]);
        int v6104 = ((v6084 == UINT64_C(0)) && (UINT64_C(59) == v6033));
        int v6105 = (v6104 && (v6103 == UINT64_C(0)));
        int v6106 = ((v6104 && ((v6103 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(60) < ((uint64_t)((uint64_t)in_b_len))));
        int v6107 = (((v6104 && (v6103 != UINT64_C(0))) && (v6103 < UINT64_C(64))) && (((uint64_t)((UINT64_C(59) + v6103) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6110 = ((v6084 == UINT64_C(0)) && (UINT64_C(59) != v6033));
        if (t6110) {
                uint64_t v6108 = v6103;
            int t6109 = (!(((((v6108 | UINT64_C(32)) >= UINT64_C(97)) && ((v6108 | UINT64_C(32)) <= UINT64_C(122))) || ((v6108 >= UINT64_C(48)) && (v6108 <= UINT64_C(57)))) || (v6108 == UINT64_C(45))));
            if (!t6109) {
                t6109 = ((v6103 == UINT64_C(45)) && ((UINT64_C(59) == ((v6067 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(60) == v6033)));
            }
            t6110 = t6109;
        }
        int v6111 = t6110;
        uint64_t v6112 = (v6105 ? UINT64_C(60) : (v6106 ? UINT64_C(61) : v5999));
        uint64_t v6113 = (v6106 ? (((((uint64_t)(v6103 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(60)]))) : v6050);
        uint64_t v6114 = (v6107 ? ((v6016 + UINT64_C(1)) & UINT64_C(255)) : v6016);
        uint64_t v6115 = (v6107 ? UINT64_C(59) : v6067);
        uint64_t v6116 = (v6107 ? ((uint64_t)((UINT64_C(60) + v6103) & UINT64_C(255))) : v6033);
        uint64_t v6117 = ((v6105 || v6106) ? UINT64_C(1) : ((v6111 || (v6104 && (!v6107))) ? UINT64_C(2) : v6084));
        t6118 = v6114;
    } else {
        t6118 = v6016;
    }
    uint64_t v6119 = t6118;
    uint64_t t6135;
    if (v6085) {
        uint64_t v6120 = ((uint64_t)in_b[UINT64_C(59)]);
        int v6121 = ((v6084 == UINT64_C(0)) && (UINT64_C(59) == v6033));
        int v6122 = (v6121 && (v6120 == UINT64_C(0)));
        int v6123 = ((v6121 && ((v6120 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(60) < ((uint64_t)((uint64_t)in_b_len))));
        int v6124 = (((v6121 && (v6120 != UINT64_C(0))) && (v6120 < UINT64_C(64))) && (((uint64_t)((UINT64_C(59) + v6120) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6127 = ((v6084 == UINT64_C(0)) && (UINT64_C(59) != v6033));
        if (t6127) {
                uint64_t v6125 = v6120;
            int t6126 = (!(((((v6125 | UINT64_C(32)) >= UINT64_C(97)) && ((v6125 | UINT64_C(32)) <= UINT64_C(122))) || ((v6125 >= UINT64_C(48)) && (v6125 <= UINT64_C(57)))) || (v6125 == UINT64_C(45))));
            if (!t6126) {
                t6126 = ((v6120 == UINT64_C(45)) && ((UINT64_C(59) == ((v6067 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(60) == v6033)));
            }
            t6127 = t6126;
        }
        int v6128 = t6127;
        uint64_t v6129 = (v6122 ? UINT64_C(60) : (v6123 ? UINT64_C(61) : v5999));
        uint64_t v6130 = (v6123 ? (((((uint64_t)(v6120 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(60)]))) : v6050);
        uint64_t v6131 = (v6124 ? ((v6016 + UINT64_C(1)) & UINT64_C(255)) : v6016);
        uint64_t v6132 = (v6124 ? UINT64_C(59) : v6067);
        uint64_t v6133 = (v6124 ? ((uint64_t)((UINT64_C(60) + v6120) & UINT64_C(255))) : v6033);
        uint64_t v6134 = ((v6122 || v6123) ? UINT64_C(1) : ((v6128 || (v6121 && (!v6124))) ? UINT64_C(2) : v6084));
        t6135 = v6133;
    } else {
        t6135 = v6033;
    }
    uint64_t v6136 = t6135;
    uint64_t t6152;
    if (v6085) {
        uint64_t v6137 = ((uint64_t)in_b[UINT64_C(59)]);
        int v6138 = ((v6084 == UINT64_C(0)) && (UINT64_C(59) == v6033));
        int v6139 = (v6138 && (v6137 == UINT64_C(0)));
        int v6140 = ((v6138 && ((v6137 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(60) < ((uint64_t)((uint64_t)in_b_len))));
        int v6141 = (((v6138 && (v6137 != UINT64_C(0))) && (v6137 < UINT64_C(64))) && (((uint64_t)((UINT64_C(59) + v6137) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6144 = ((v6084 == UINT64_C(0)) && (UINT64_C(59) != v6033));
        if (t6144) {
                uint64_t v6142 = v6137;
            int t6143 = (!(((((v6142 | UINT64_C(32)) >= UINT64_C(97)) && ((v6142 | UINT64_C(32)) <= UINT64_C(122))) || ((v6142 >= UINT64_C(48)) && (v6142 <= UINT64_C(57)))) || (v6142 == UINT64_C(45))));
            if (!t6143) {
                t6143 = ((v6137 == UINT64_C(45)) && ((UINT64_C(59) == ((v6067 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(60) == v6033)));
            }
            t6144 = t6143;
        }
        int v6145 = t6144;
        uint64_t v6146 = (v6139 ? UINT64_C(60) : (v6140 ? UINT64_C(61) : v5999));
        uint64_t v6147 = (v6140 ? (((((uint64_t)(v6137 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(60)]))) : v6050);
        uint64_t v6148 = (v6141 ? ((v6016 + UINT64_C(1)) & UINT64_C(255)) : v6016);
        uint64_t v6149 = (v6141 ? UINT64_C(59) : v6067);
        uint64_t v6150 = (v6141 ? ((uint64_t)((UINT64_C(60) + v6137) & UINT64_C(255))) : v6033);
        uint64_t v6151 = ((v6139 || v6140) ? UINT64_C(1) : ((v6145 || (v6138 && (!v6141))) ? UINT64_C(2) : v6084));
        t6152 = v6147;
    } else {
        t6152 = v6050;
    }
    uint64_t v6153 = t6152;
    uint64_t t6169;
    if (v6085) {
        uint64_t v6154 = ((uint64_t)in_b[UINT64_C(59)]);
        int v6155 = ((v6084 == UINT64_C(0)) && (UINT64_C(59) == v6033));
        int v6156 = (v6155 && (v6154 == UINT64_C(0)));
        int v6157 = ((v6155 && ((v6154 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(60) < ((uint64_t)((uint64_t)in_b_len))));
        int v6158 = (((v6155 && (v6154 != UINT64_C(0))) && (v6154 < UINT64_C(64))) && (((uint64_t)((UINT64_C(59) + v6154) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6161 = ((v6084 == UINT64_C(0)) && (UINT64_C(59) != v6033));
        if (t6161) {
                uint64_t v6159 = v6154;
            int t6160 = (!(((((v6159 | UINT64_C(32)) >= UINT64_C(97)) && ((v6159 | UINT64_C(32)) <= UINT64_C(122))) || ((v6159 >= UINT64_C(48)) && (v6159 <= UINT64_C(57)))) || (v6159 == UINT64_C(45))));
            if (!t6160) {
                t6160 = ((v6154 == UINT64_C(45)) && ((UINT64_C(59) == ((v6067 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(60) == v6033)));
            }
            t6161 = t6160;
        }
        int v6162 = t6161;
        uint64_t v6163 = (v6156 ? UINT64_C(60) : (v6157 ? UINT64_C(61) : v5999));
        uint64_t v6164 = (v6157 ? (((((uint64_t)(v6154 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(60)]))) : v6050);
        uint64_t v6165 = (v6158 ? ((v6016 + UINT64_C(1)) & UINT64_C(255)) : v6016);
        uint64_t v6166 = (v6158 ? UINT64_C(59) : v6067);
        uint64_t v6167 = (v6158 ? ((uint64_t)((UINT64_C(60) + v6154) & UINT64_C(255))) : v6033);
        uint64_t v6168 = ((v6156 || v6157) ? UINT64_C(1) : ((v6162 || (v6155 && (!v6158))) ? UINT64_C(2) : v6084));
        t6169 = v6166;
    } else {
        t6169 = v6067;
    }
    uint64_t v6170 = t6169;
    uint64_t t6186;
    if (v6085) {
        uint64_t v6171 = ((uint64_t)in_b[UINT64_C(59)]);
        int v6172 = ((v6084 == UINT64_C(0)) && (UINT64_C(59) == v6033));
        int v6173 = (v6172 && (v6171 == UINT64_C(0)));
        int v6174 = ((v6172 && ((v6171 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(60) < ((uint64_t)((uint64_t)in_b_len))));
        int v6175 = (((v6172 && (v6171 != UINT64_C(0))) && (v6171 < UINT64_C(64))) && (((uint64_t)((UINT64_C(59) + v6171) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6178 = ((v6084 == UINT64_C(0)) && (UINT64_C(59) != v6033));
        if (t6178) {
                uint64_t v6176 = v6171;
            int t6177 = (!(((((v6176 | UINT64_C(32)) >= UINT64_C(97)) && ((v6176 | UINT64_C(32)) <= UINT64_C(122))) || ((v6176 >= UINT64_C(48)) && (v6176 <= UINT64_C(57)))) || (v6176 == UINT64_C(45))));
            if (!t6177) {
                t6177 = ((v6171 == UINT64_C(45)) && ((UINT64_C(59) == ((v6067 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(60) == v6033)));
            }
            t6178 = t6177;
        }
        int v6179 = t6178;
        uint64_t v6180 = (v6173 ? UINT64_C(60) : (v6174 ? UINT64_C(61) : v5999));
        uint64_t v6181 = (v6174 ? (((((uint64_t)(v6171 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(60)]))) : v6050);
        uint64_t v6182 = (v6175 ? ((v6016 + UINT64_C(1)) & UINT64_C(255)) : v6016);
        uint64_t v6183 = (v6175 ? UINT64_C(59) : v6067);
        uint64_t v6184 = (v6175 ? ((uint64_t)((UINT64_C(60) + v6171) & UINT64_C(255))) : v6033);
        uint64_t v6185 = ((v6173 || v6174) ? UINT64_C(1) : ((v6179 || (v6172 && (!v6175))) ? UINT64_C(2) : v6084));
        t6186 = v6185;
    } else {
        t6186 = v6084;
    }
    uint64_t v6187 = t6186;
    int v6188 = (UINT64_C(60) < v7);
    uint64_t t6204;
    if (v6188) {
        uint64_t v6189 = ((uint64_t)in_b[UINT64_C(60)]);
        int v6190 = ((v6187 == UINT64_C(0)) && (UINT64_C(60) == v6136));
        int v6191 = (v6190 && (v6189 == UINT64_C(0)));
        int v6192 = ((v6190 && ((v6189 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(61) < ((uint64_t)((uint64_t)in_b_len))));
        int v6193 = (((v6190 && (v6189 != UINT64_C(0))) && (v6189 < UINT64_C(64))) && (((uint64_t)((UINT64_C(60) + v6189) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6196 = ((v6187 == UINT64_C(0)) && (UINT64_C(60) != v6136));
        if (t6196) {
                uint64_t v6194 = v6189;
            int t6195 = (!(((((v6194 | UINT64_C(32)) >= UINT64_C(97)) && ((v6194 | UINT64_C(32)) <= UINT64_C(122))) || ((v6194 >= UINT64_C(48)) && (v6194 <= UINT64_C(57)))) || (v6194 == UINT64_C(45))));
            if (!t6195) {
                t6195 = ((v6189 == UINT64_C(45)) && ((UINT64_C(60) == ((v6170 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(61) == v6136)));
            }
            t6196 = t6195;
        }
        int v6197 = t6196;
        uint64_t v6198 = (v6191 ? UINT64_C(61) : (v6192 ? UINT64_C(62) : v6102));
        uint64_t v6199 = (v6192 ? (((((uint64_t)(v6189 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(61)]))) : v6153);
        uint64_t v6200 = (v6193 ? ((v6119 + UINT64_C(1)) & UINT64_C(255)) : v6119);
        uint64_t v6201 = (v6193 ? UINT64_C(60) : v6170);
        uint64_t v6202 = (v6193 ? ((uint64_t)((UINT64_C(61) + v6189) & UINT64_C(255))) : v6136);
        uint64_t v6203 = ((v6191 || v6192) ? UINT64_C(1) : ((v6197 || (v6190 && (!v6193))) ? UINT64_C(2) : v6187));
        t6204 = v6198;
    } else {
        t6204 = v6102;
    }
    uint64_t v6205 = t6204;
    uint64_t t6221;
    if (v6188) {
        uint64_t v6206 = ((uint64_t)in_b[UINT64_C(60)]);
        int v6207 = ((v6187 == UINT64_C(0)) && (UINT64_C(60) == v6136));
        int v6208 = (v6207 && (v6206 == UINT64_C(0)));
        int v6209 = ((v6207 && ((v6206 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(61) < ((uint64_t)((uint64_t)in_b_len))));
        int v6210 = (((v6207 && (v6206 != UINT64_C(0))) && (v6206 < UINT64_C(64))) && (((uint64_t)((UINT64_C(60) + v6206) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6213 = ((v6187 == UINT64_C(0)) && (UINT64_C(60) != v6136));
        if (t6213) {
                uint64_t v6211 = v6206;
            int t6212 = (!(((((v6211 | UINT64_C(32)) >= UINT64_C(97)) && ((v6211 | UINT64_C(32)) <= UINT64_C(122))) || ((v6211 >= UINT64_C(48)) && (v6211 <= UINT64_C(57)))) || (v6211 == UINT64_C(45))));
            if (!t6212) {
                t6212 = ((v6206 == UINT64_C(45)) && ((UINT64_C(60) == ((v6170 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(61) == v6136)));
            }
            t6213 = t6212;
        }
        int v6214 = t6213;
        uint64_t v6215 = (v6208 ? UINT64_C(61) : (v6209 ? UINT64_C(62) : v6102));
        uint64_t v6216 = (v6209 ? (((((uint64_t)(v6206 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(61)]))) : v6153);
        uint64_t v6217 = (v6210 ? ((v6119 + UINT64_C(1)) & UINT64_C(255)) : v6119);
        uint64_t v6218 = (v6210 ? UINT64_C(60) : v6170);
        uint64_t v6219 = (v6210 ? ((uint64_t)((UINT64_C(61) + v6206) & UINT64_C(255))) : v6136);
        uint64_t v6220 = ((v6208 || v6209) ? UINT64_C(1) : ((v6214 || (v6207 && (!v6210))) ? UINT64_C(2) : v6187));
        t6221 = v6217;
    } else {
        t6221 = v6119;
    }
    uint64_t v6222 = t6221;
    uint64_t t6238;
    if (v6188) {
        uint64_t v6223 = ((uint64_t)in_b[UINT64_C(60)]);
        int v6224 = ((v6187 == UINT64_C(0)) && (UINT64_C(60) == v6136));
        int v6225 = (v6224 && (v6223 == UINT64_C(0)));
        int v6226 = ((v6224 && ((v6223 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(61) < ((uint64_t)((uint64_t)in_b_len))));
        int v6227 = (((v6224 && (v6223 != UINT64_C(0))) && (v6223 < UINT64_C(64))) && (((uint64_t)((UINT64_C(60) + v6223) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6230 = ((v6187 == UINT64_C(0)) && (UINT64_C(60) != v6136));
        if (t6230) {
                uint64_t v6228 = v6223;
            int t6229 = (!(((((v6228 | UINT64_C(32)) >= UINT64_C(97)) && ((v6228 | UINT64_C(32)) <= UINT64_C(122))) || ((v6228 >= UINT64_C(48)) && (v6228 <= UINT64_C(57)))) || (v6228 == UINT64_C(45))));
            if (!t6229) {
                t6229 = ((v6223 == UINT64_C(45)) && ((UINT64_C(60) == ((v6170 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(61) == v6136)));
            }
            t6230 = t6229;
        }
        int v6231 = t6230;
        uint64_t v6232 = (v6225 ? UINT64_C(61) : (v6226 ? UINT64_C(62) : v6102));
        uint64_t v6233 = (v6226 ? (((((uint64_t)(v6223 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(61)]))) : v6153);
        uint64_t v6234 = (v6227 ? ((v6119 + UINT64_C(1)) & UINT64_C(255)) : v6119);
        uint64_t v6235 = (v6227 ? UINT64_C(60) : v6170);
        uint64_t v6236 = (v6227 ? ((uint64_t)((UINT64_C(61) + v6223) & UINT64_C(255))) : v6136);
        uint64_t v6237 = ((v6225 || v6226) ? UINT64_C(1) : ((v6231 || (v6224 && (!v6227))) ? UINT64_C(2) : v6187));
        t6238 = v6236;
    } else {
        t6238 = v6136;
    }
    uint64_t v6239 = t6238;
    uint64_t t6255;
    if (v6188) {
        uint64_t v6240 = ((uint64_t)in_b[UINT64_C(60)]);
        int v6241 = ((v6187 == UINT64_C(0)) && (UINT64_C(60) == v6136));
        int v6242 = (v6241 && (v6240 == UINT64_C(0)));
        int v6243 = ((v6241 && ((v6240 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(61) < ((uint64_t)((uint64_t)in_b_len))));
        int v6244 = (((v6241 && (v6240 != UINT64_C(0))) && (v6240 < UINT64_C(64))) && (((uint64_t)((UINT64_C(60) + v6240) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6247 = ((v6187 == UINT64_C(0)) && (UINT64_C(60) != v6136));
        if (t6247) {
                uint64_t v6245 = v6240;
            int t6246 = (!(((((v6245 | UINT64_C(32)) >= UINT64_C(97)) && ((v6245 | UINT64_C(32)) <= UINT64_C(122))) || ((v6245 >= UINT64_C(48)) && (v6245 <= UINT64_C(57)))) || (v6245 == UINT64_C(45))));
            if (!t6246) {
                t6246 = ((v6240 == UINT64_C(45)) && ((UINT64_C(60) == ((v6170 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(61) == v6136)));
            }
            t6247 = t6246;
        }
        int v6248 = t6247;
        uint64_t v6249 = (v6242 ? UINT64_C(61) : (v6243 ? UINT64_C(62) : v6102));
        uint64_t v6250 = (v6243 ? (((((uint64_t)(v6240 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(61)]))) : v6153);
        uint64_t v6251 = (v6244 ? ((v6119 + UINT64_C(1)) & UINT64_C(255)) : v6119);
        uint64_t v6252 = (v6244 ? UINT64_C(60) : v6170);
        uint64_t v6253 = (v6244 ? ((uint64_t)((UINT64_C(61) + v6240) & UINT64_C(255))) : v6136);
        uint64_t v6254 = ((v6242 || v6243) ? UINT64_C(1) : ((v6248 || (v6241 && (!v6244))) ? UINT64_C(2) : v6187));
        t6255 = v6250;
    } else {
        t6255 = v6153;
    }
    uint64_t v6256 = t6255;
    uint64_t t6272;
    if (v6188) {
        uint64_t v6257 = ((uint64_t)in_b[UINT64_C(60)]);
        int v6258 = ((v6187 == UINT64_C(0)) && (UINT64_C(60) == v6136));
        int v6259 = (v6258 && (v6257 == UINT64_C(0)));
        int v6260 = ((v6258 && ((v6257 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(61) < ((uint64_t)((uint64_t)in_b_len))));
        int v6261 = (((v6258 && (v6257 != UINT64_C(0))) && (v6257 < UINT64_C(64))) && (((uint64_t)((UINT64_C(60) + v6257) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6264 = ((v6187 == UINT64_C(0)) && (UINT64_C(60) != v6136));
        if (t6264) {
                uint64_t v6262 = v6257;
            int t6263 = (!(((((v6262 | UINT64_C(32)) >= UINT64_C(97)) && ((v6262 | UINT64_C(32)) <= UINT64_C(122))) || ((v6262 >= UINT64_C(48)) && (v6262 <= UINT64_C(57)))) || (v6262 == UINT64_C(45))));
            if (!t6263) {
                t6263 = ((v6257 == UINT64_C(45)) && ((UINT64_C(60) == ((v6170 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(61) == v6136)));
            }
            t6264 = t6263;
        }
        int v6265 = t6264;
        uint64_t v6266 = (v6259 ? UINT64_C(61) : (v6260 ? UINT64_C(62) : v6102));
        uint64_t v6267 = (v6260 ? (((((uint64_t)(v6257 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(61)]))) : v6153);
        uint64_t v6268 = (v6261 ? ((v6119 + UINT64_C(1)) & UINT64_C(255)) : v6119);
        uint64_t v6269 = (v6261 ? UINT64_C(60) : v6170);
        uint64_t v6270 = (v6261 ? ((uint64_t)((UINT64_C(61) + v6257) & UINT64_C(255))) : v6136);
        uint64_t v6271 = ((v6259 || v6260) ? UINT64_C(1) : ((v6265 || (v6258 && (!v6261))) ? UINT64_C(2) : v6187));
        t6272 = v6269;
    } else {
        t6272 = v6170;
    }
    uint64_t v6273 = t6272;
    uint64_t t6289;
    if (v6188) {
        uint64_t v6274 = ((uint64_t)in_b[UINT64_C(60)]);
        int v6275 = ((v6187 == UINT64_C(0)) && (UINT64_C(60) == v6136));
        int v6276 = (v6275 && (v6274 == UINT64_C(0)));
        int v6277 = ((v6275 && ((v6274 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(61) < ((uint64_t)((uint64_t)in_b_len))));
        int v6278 = (((v6275 && (v6274 != UINT64_C(0))) && (v6274 < UINT64_C(64))) && (((uint64_t)((UINT64_C(60) + v6274) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6281 = ((v6187 == UINT64_C(0)) && (UINT64_C(60) != v6136));
        if (t6281) {
                uint64_t v6279 = v6274;
            int t6280 = (!(((((v6279 | UINT64_C(32)) >= UINT64_C(97)) && ((v6279 | UINT64_C(32)) <= UINT64_C(122))) || ((v6279 >= UINT64_C(48)) && (v6279 <= UINT64_C(57)))) || (v6279 == UINT64_C(45))));
            if (!t6280) {
                t6280 = ((v6274 == UINT64_C(45)) && ((UINT64_C(60) == ((v6170 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(61) == v6136)));
            }
            t6281 = t6280;
        }
        int v6282 = t6281;
        uint64_t v6283 = (v6276 ? UINT64_C(61) : (v6277 ? UINT64_C(62) : v6102));
        uint64_t v6284 = (v6277 ? (((((uint64_t)(v6274 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(61)]))) : v6153);
        uint64_t v6285 = (v6278 ? ((v6119 + UINT64_C(1)) & UINT64_C(255)) : v6119);
        uint64_t v6286 = (v6278 ? UINT64_C(60) : v6170);
        uint64_t v6287 = (v6278 ? ((uint64_t)((UINT64_C(61) + v6274) & UINT64_C(255))) : v6136);
        uint64_t v6288 = ((v6276 || v6277) ? UINT64_C(1) : ((v6282 || (v6275 && (!v6278))) ? UINT64_C(2) : v6187));
        t6289 = v6288;
    } else {
        t6289 = v6187;
    }
    uint64_t v6290 = t6289;
    int v6291 = (UINT64_C(61) < v7);
    uint64_t t6307;
    if (v6291) {
        uint64_t v6292 = ((uint64_t)in_b[UINT64_C(61)]);
        int v6293 = ((v6290 == UINT64_C(0)) && (UINT64_C(61) == v6239));
        int v6294 = (v6293 && (v6292 == UINT64_C(0)));
        int v6295 = ((v6293 && ((v6292 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(62) < ((uint64_t)((uint64_t)in_b_len))));
        int v6296 = (((v6293 && (v6292 != UINT64_C(0))) && (v6292 < UINT64_C(64))) && (((uint64_t)((UINT64_C(61) + v6292) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6299 = ((v6290 == UINT64_C(0)) && (UINT64_C(61) != v6239));
        if (t6299) {
                uint64_t v6297 = v6292;
            int t6298 = (!(((((v6297 | UINT64_C(32)) >= UINT64_C(97)) && ((v6297 | UINT64_C(32)) <= UINT64_C(122))) || ((v6297 >= UINT64_C(48)) && (v6297 <= UINT64_C(57)))) || (v6297 == UINT64_C(45))));
            if (!t6298) {
                t6298 = ((v6292 == UINT64_C(45)) && ((UINT64_C(61) == ((v6273 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(62) == v6239)));
            }
            t6299 = t6298;
        }
        int v6300 = t6299;
        uint64_t v6301 = (v6294 ? UINT64_C(62) : (v6295 ? UINT64_C(63) : v6205));
        uint64_t v6302 = (v6295 ? (((((uint64_t)(v6292 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(62)]))) : v6256);
        uint64_t v6303 = (v6296 ? ((v6222 + UINT64_C(1)) & UINT64_C(255)) : v6222);
        uint64_t v6304 = (v6296 ? UINT64_C(61) : v6273);
        uint64_t v6305 = (v6296 ? ((uint64_t)((UINT64_C(62) + v6292) & UINT64_C(255))) : v6239);
        uint64_t v6306 = ((v6294 || v6295) ? UINT64_C(1) : ((v6300 || (v6293 && (!v6296))) ? UINT64_C(2) : v6290));
        t6307 = v6301;
    } else {
        t6307 = v6205;
    }
    uint64_t v6308 = t6307;
    uint64_t t6324;
    if (v6291) {
        uint64_t v6309 = ((uint64_t)in_b[UINT64_C(61)]);
        int v6310 = ((v6290 == UINT64_C(0)) && (UINT64_C(61) == v6239));
        int v6311 = (v6310 && (v6309 == UINT64_C(0)));
        int v6312 = ((v6310 && ((v6309 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(62) < ((uint64_t)((uint64_t)in_b_len))));
        int v6313 = (((v6310 && (v6309 != UINT64_C(0))) && (v6309 < UINT64_C(64))) && (((uint64_t)((UINT64_C(61) + v6309) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6316 = ((v6290 == UINT64_C(0)) && (UINT64_C(61) != v6239));
        if (t6316) {
                uint64_t v6314 = v6309;
            int t6315 = (!(((((v6314 | UINT64_C(32)) >= UINT64_C(97)) && ((v6314 | UINT64_C(32)) <= UINT64_C(122))) || ((v6314 >= UINT64_C(48)) && (v6314 <= UINT64_C(57)))) || (v6314 == UINT64_C(45))));
            if (!t6315) {
                t6315 = ((v6309 == UINT64_C(45)) && ((UINT64_C(61) == ((v6273 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(62) == v6239)));
            }
            t6316 = t6315;
        }
        int v6317 = t6316;
        uint64_t v6318 = (v6311 ? UINT64_C(62) : (v6312 ? UINT64_C(63) : v6205));
        uint64_t v6319 = (v6312 ? (((((uint64_t)(v6309 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(62)]))) : v6256);
        uint64_t v6320 = (v6313 ? ((v6222 + UINT64_C(1)) & UINT64_C(255)) : v6222);
        uint64_t v6321 = (v6313 ? UINT64_C(61) : v6273);
        uint64_t v6322 = (v6313 ? ((uint64_t)((UINT64_C(62) + v6309) & UINT64_C(255))) : v6239);
        uint64_t v6323 = ((v6311 || v6312) ? UINT64_C(1) : ((v6317 || (v6310 && (!v6313))) ? UINT64_C(2) : v6290));
        t6324 = v6320;
    } else {
        t6324 = v6222;
    }
    uint64_t v6325 = t6324;
    uint64_t t6341;
    if (v6291) {
        uint64_t v6326 = ((uint64_t)in_b[UINT64_C(61)]);
        int v6327 = ((v6290 == UINT64_C(0)) && (UINT64_C(61) == v6239));
        int v6328 = (v6327 && (v6326 == UINT64_C(0)));
        int v6329 = ((v6327 && ((v6326 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(62) < ((uint64_t)((uint64_t)in_b_len))));
        int v6330 = (((v6327 && (v6326 != UINT64_C(0))) && (v6326 < UINT64_C(64))) && (((uint64_t)((UINT64_C(61) + v6326) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6333 = ((v6290 == UINT64_C(0)) && (UINT64_C(61) != v6239));
        if (t6333) {
                uint64_t v6331 = v6326;
            int t6332 = (!(((((v6331 | UINT64_C(32)) >= UINT64_C(97)) && ((v6331 | UINT64_C(32)) <= UINT64_C(122))) || ((v6331 >= UINT64_C(48)) && (v6331 <= UINT64_C(57)))) || (v6331 == UINT64_C(45))));
            if (!t6332) {
                t6332 = ((v6326 == UINT64_C(45)) && ((UINT64_C(61) == ((v6273 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(62) == v6239)));
            }
            t6333 = t6332;
        }
        int v6334 = t6333;
        uint64_t v6335 = (v6328 ? UINT64_C(62) : (v6329 ? UINT64_C(63) : v6205));
        uint64_t v6336 = (v6329 ? (((((uint64_t)(v6326 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(62)]))) : v6256);
        uint64_t v6337 = (v6330 ? ((v6222 + UINT64_C(1)) & UINT64_C(255)) : v6222);
        uint64_t v6338 = (v6330 ? UINT64_C(61) : v6273);
        uint64_t v6339 = (v6330 ? ((uint64_t)((UINT64_C(62) + v6326) & UINT64_C(255))) : v6239);
        uint64_t v6340 = ((v6328 || v6329) ? UINT64_C(1) : ((v6334 || (v6327 && (!v6330))) ? UINT64_C(2) : v6290));
        t6341 = v6339;
    } else {
        t6341 = v6239;
    }
    uint64_t v6342 = t6341;
    uint64_t t6358;
    if (v6291) {
        uint64_t v6343 = ((uint64_t)in_b[UINT64_C(61)]);
        int v6344 = ((v6290 == UINT64_C(0)) && (UINT64_C(61) == v6239));
        int v6345 = (v6344 && (v6343 == UINT64_C(0)));
        int v6346 = ((v6344 && ((v6343 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(62) < ((uint64_t)((uint64_t)in_b_len))));
        int v6347 = (((v6344 && (v6343 != UINT64_C(0))) && (v6343 < UINT64_C(64))) && (((uint64_t)((UINT64_C(61) + v6343) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6350 = ((v6290 == UINT64_C(0)) && (UINT64_C(61) != v6239));
        if (t6350) {
                uint64_t v6348 = v6343;
            int t6349 = (!(((((v6348 | UINT64_C(32)) >= UINT64_C(97)) && ((v6348 | UINT64_C(32)) <= UINT64_C(122))) || ((v6348 >= UINT64_C(48)) && (v6348 <= UINT64_C(57)))) || (v6348 == UINT64_C(45))));
            if (!t6349) {
                t6349 = ((v6343 == UINT64_C(45)) && ((UINT64_C(61) == ((v6273 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(62) == v6239)));
            }
            t6350 = t6349;
        }
        int v6351 = t6350;
        uint64_t v6352 = (v6345 ? UINT64_C(62) : (v6346 ? UINT64_C(63) : v6205));
        uint64_t v6353 = (v6346 ? (((((uint64_t)(v6343 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(62)]))) : v6256);
        uint64_t v6354 = (v6347 ? ((v6222 + UINT64_C(1)) & UINT64_C(255)) : v6222);
        uint64_t v6355 = (v6347 ? UINT64_C(61) : v6273);
        uint64_t v6356 = (v6347 ? ((uint64_t)((UINT64_C(62) + v6343) & UINT64_C(255))) : v6239);
        uint64_t v6357 = ((v6345 || v6346) ? UINT64_C(1) : ((v6351 || (v6344 && (!v6347))) ? UINT64_C(2) : v6290));
        t6358 = v6353;
    } else {
        t6358 = v6256;
    }
    uint64_t v6359 = t6358;
    uint64_t t6375;
    if (v6291) {
        uint64_t v6360 = ((uint64_t)in_b[UINT64_C(61)]);
        int v6361 = ((v6290 == UINT64_C(0)) && (UINT64_C(61) == v6239));
        int v6362 = (v6361 && (v6360 == UINT64_C(0)));
        int v6363 = ((v6361 && ((v6360 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(62) < ((uint64_t)((uint64_t)in_b_len))));
        int v6364 = (((v6361 && (v6360 != UINT64_C(0))) && (v6360 < UINT64_C(64))) && (((uint64_t)((UINT64_C(61) + v6360) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6367 = ((v6290 == UINT64_C(0)) && (UINT64_C(61) != v6239));
        if (t6367) {
                uint64_t v6365 = v6360;
            int t6366 = (!(((((v6365 | UINT64_C(32)) >= UINT64_C(97)) && ((v6365 | UINT64_C(32)) <= UINT64_C(122))) || ((v6365 >= UINT64_C(48)) && (v6365 <= UINT64_C(57)))) || (v6365 == UINT64_C(45))));
            if (!t6366) {
                t6366 = ((v6360 == UINT64_C(45)) && ((UINT64_C(61) == ((v6273 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(62) == v6239)));
            }
            t6367 = t6366;
        }
        int v6368 = t6367;
        uint64_t v6369 = (v6362 ? UINT64_C(62) : (v6363 ? UINT64_C(63) : v6205));
        uint64_t v6370 = (v6363 ? (((((uint64_t)(v6360 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(62)]))) : v6256);
        uint64_t v6371 = (v6364 ? ((v6222 + UINT64_C(1)) & UINT64_C(255)) : v6222);
        uint64_t v6372 = (v6364 ? UINT64_C(61) : v6273);
        uint64_t v6373 = (v6364 ? ((uint64_t)((UINT64_C(62) + v6360) & UINT64_C(255))) : v6239);
        uint64_t v6374 = ((v6362 || v6363) ? UINT64_C(1) : ((v6368 || (v6361 && (!v6364))) ? UINT64_C(2) : v6290));
        t6375 = v6372;
    } else {
        t6375 = v6273;
    }
    uint64_t v6376 = t6375;
    uint64_t t6392;
    if (v6291) {
        uint64_t v6377 = ((uint64_t)in_b[UINT64_C(61)]);
        int v6378 = ((v6290 == UINT64_C(0)) && (UINT64_C(61) == v6239));
        int v6379 = (v6378 && (v6377 == UINT64_C(0)));
        int v6380 = ((v6378 && ((v6377 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(62) < ((uint64_t)((uint64_t)in_b_len))));
        int v6381 = (((v6378 && (v6377 != UINT64_C(0))) && (v6377 < UINT64_C(64))) && (((uint64_t)((UINT64_C(61) + v6377) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6384 = ((v6290 == UINT64_C(0)) && (UINT64_C(61) != v6239));
        if (t6384) {
                uint64_t v6382 = v6377;
            int t6383 = (!(((((v6382 | UINT64_C(32)) >= UINT64_C(97)) && ((v6382 | UINT64_C(32)) <= UINT64_C(122))) || ((v6382 >= UINT64_C(48)) && (v6382 <= UINT64_C(57)))) || (v6382 == UINT64_C(45))));
            if (!t6383) {
                t6383 = ((v6377 == UINT64_C(45)) && ((UINT64_C(61) == ((v6273 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(62) == v6239)));
            }
            t6384 = t6383;
        }
        int v6385 = t6384;
        uint64_t v6386 = (v6379 ? UINT64_C(62) : (v6380 ? UINT64_C(63) : v6205));
        uint64_t v6387 = (v6380 ? (((((uint64_t)(v6377 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(62)]))) : v6256);
        uint64_t v6388 = (v6381 ? ((v6222 + UINT64_C(1)) & UINT64_C(255)) : v6222);
        uint64_t v6389 = (v6381 ? UINT64_C(61) : v6273);
        uint64_t v6390 = (v6381 ? ((uint64_t)((UINT64_C(62) + v6377) & UINT64_C(255))) : v6239);
        uint64_t v6391 = ((v6379 || v6380) ? UINT64_C(1) : ((v6385 || (v6378 && (!v6381))) ? UINT64_C(2) : v6290));
        t6392 = v6391;
    } else {
        t6392 = v6290;
    }
    uint64_t v6393 = t6392;
    int v6394 = (UINT64_C(62) < v7);
    uint64_t t6410;
    if (v6394) {
        uint64_t v6395 = ((uint64_t)in_b[UINT64_C(62)]);
        int v6396 = ((v6393 == UINT64_C(0)) && (UINT64_C(62) == v6342));
        int v6397 = (v6396 && (v6395 == UINT64_C(0)));
        int v6398 = ((v6396 && ((v6395 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(63) < ((uint64_t)((uint64_t)in_b_len))));
        int v6399 = (((v6396 && (v6395 != UINT64_C(0))) && (v6395 < UINT64_C(64))) && (((uint64_t)((UINT64_C(62) + v6395) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6402 = ((v6393 == UINT64_C(0)) && (UINT64_C(62) != v6342));
        if (t6402) {
                uint64_t v6400 = v6395;
            int t6401 = (!(((((v6400 | UINT64_C(32)) >= UINT64_C(97)) && ((v6400 | UINT64_C(32)) <= UINT64_C(122))) || ((v6400 >= UINT64_C(48)) && (v6400 <= UINT64_C(57)))) || (v6400 == UINT64_C(45))));
            if (!t6401) {
                t6401 = ((v6395 == UINT64_C(45)) && ((UINT64_C(62) == ((v6376 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(63) == v6342)));
            }
            t6402 = t6401;
        }
        int v6403 = t6402;
        uint64_t v6404 = (v6397 ? UINT64_C(63) : (v6398 ? UINT64_C(64) : v6308));
        uint64_t v6405 = (v6398 ? (((((uint64_t)(v6395 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(63)]))) : v6359);
        uint64_t v6406 = (v6399 ? ((v6325 + UINT64_C(1)) & UINT64_C(255)) : v6325);
        uint64_t v6407 = (v6399 ? UINT64_C(62) : v6376);
        uint64_t v6408 = (v6399 ? ((uint64_t)((UINT64_C(63) + v6395) & UINT64_C(255))) : v6342);
        uint64_t v6409 = ((v6397 || v6398) ? UINT64_C(1) : ((v6403 || (v6396 && (!v6399))) ? UINT64_C(2) : v6393));
        t6410 = v6404;
    } else {
        t6410 = v6308;
    }
    uint64_t v6411 = t6410;
    uint64_t t6427;
    if (v6394) {
        uint64_t v6412 = ((uint64_t)in_b[UINT64_C(62)]);
        int v6413 = ((v6393 == UINT64_C(0)) && (UINT64_C(62) == v6342));
        int v6414 = (v6413 && (v6412 == UINT64_C(0)));
        int v6415 = ((v6413 && ((v6412 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(63) < ((uint64_t)((uint64_t)in_b_len))));
        int v6416 = (((v6413 && (v6412 != UINT64_C(0))) && (v6412 < UINT64_C(64))) && (((uint64_t)((UINT64_C(62) + v6412) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6419 = ((v6393 == UINT64_C(0)) && (UINT64_C(62) != v6342));
        if (t6419) {
                uint64_t v6417 = v6412;
            int t6418 = (!(((((v6417 | UINT64_C(32)) >= UINT64_C(97)) && ((v6417 | UINT64_C(32)) <= UINT64_C(122))) || ((v6417 >= UINT64_C(48)) && (v6417 <= UINT64_C(57)))) || (v6417 == UINT64_C(45))));
            if (!t6418) {
                t6418 = ((v6412 == UINT64_C(45)) && ((UINT64_C(62) == ((v6376 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(63) == v6342)));
            }
            t6419 = t6418;
        }
        int v6420 = t6419;
        uint64_t v6421 = (v6414 ? UINT64_C(63) : (v6415 ? UINT64_C(64) : v6308));
        uint64_t v6422 = (v6415 ? (((((uint64_t)(v6412 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(63)]))) : v6359);
        uint64_t v6423 = (v6416 ? ((v6325 + UINT64_C(1)) & UINT64_C(255)) : v6325);
        uint64_t v6424 = (v6416 ? UINT64_C(62) : v6376);
        uint64_t v6425 = (v6416 ? ((uint64_t)((UINT64_C(63) + v6412) & UINT64_C(255))) : v6342);
        uint64_t v6426 = ((v6414 || v6415) ? UINT64_C(1) : ((v6420 || (v6413 && (!v6416))) ? UINT64_C(2) : v6393));
        t6427 = v6423;
    } else {
        t6427 = v6325;
    }
    uint64_t v6428 = t6427;
    uint64_t t6444;
    if (v6394) {
        uint64_t v6429 = ((uint64_t)in_b[UINT64_C(62)]);
        int v6430 = ((v6393 == UINT64_C(0)) && (UINT64_C(62) == v6342));
        int v6431 = (v6430 && (v6429 == UINT64_C(0)));
        int v6432 = ((v6430 && ((v6429 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(63) < ((uint64_t)((uint64_t)in_b_len))));
        int v6433 = (((v6430 && (v6429 != UINT64_C(0))) && (v6429 < UINT64_C(64))) && (((uint64_t)((UINT64_C(62) + v6429) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6436 = ((v6393 == UINT64_C(0)) && (UINT64_C(62) != v6342));
        if (t6436) {
                uint64_t v6434 = v6429;
            int t6435 = (!(((((v6434 | UINT64_C(32)) >= UINT64_C(97)) && ((v6434 | UINT64_C(32)) <= UINT64_C(122))) || ((v6434 >= UINT64_C(48)) && (v6434 <= UINT64_C(57)))) || (v6434 == UINT64_C(45))));
            if (!t6435) {
                t6435 = ((v6429 == UINT64_C(45)) && ((UINT64_C(62) == ((v6376 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(63) == v6342)));
            }
            t6436 = t6435;
        }
        int v6437 = t6436;
        uint64_t v6438 = (v6431 ? UINT64_C(63) : (v6432 ? UINT64_C(64) : v6308));
        uint64_t v6439 = (v6432 ? (((((uint64_t)(v6429 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(63)]))) : v6359);
        uint64_t v6440 = (v6433 ? ((v6325 + UINT64_C(1)) & UINT64_C(255)) : v6325);
        uint64_t v6441 = (v6433 ? UINT64_C(62) : v6376);
        uint64_t v6442 = (v6433 ? ((uint64_t)((UINT64_C(63) + v6429) & UINT64_C(255))) : v6342);
        uint64_t v6443 = ((v6431 || v6432) ? UINT64_C(1) : ((v6437 || (v6430 && (!v6433))) ? UINT64_C(2) : v6393));
        t6444 = v6442;
    } else {
        t6444 = v6342;
    }
    uint64_t v6445 = t6444;
    uint64_t t6461;
    if (v6394) {
        uint64_t v6446 = ((uint64_t)in_b[UINT64_C(62)]);
        int v6447 = ((v6393 == UINT64_C(0)) && (UINT64_C(62) == v6342));
        int v6448 = (v6447 && (v6446 == UINT64_C(0)));
        int v6449 = ((v6447 && ((v6446 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(63) < ((uint64_t)((uint64_t)in_b_len))));
        int v6450 = (((v6447 && (v6446 != UINT64_C(0))) && (v6446 < UINT64_C(64))) && (((uint64_t)((UINT64_C(62) + v6446) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6453 = ((v6393 == UINT64_C(0)) && (UINT64_C(62) != v6342));
        if (t6453) {
                uint64_t v6451 = v6446;
            int t6452 = (!(((((v6451 | UINT64_C(32)) >= UINT64_C(97)) && ((v6451 | UINT64_C(32)) <= UINT64_C(122))) || ((v6451 >= UINT64_C(48)) && (v6451 <= UINT64_C(57)))) || (v6451 == UINT64_C(45))));
            if (!t6452) {
                t6452 = ((v6446 == UINT64_C(45)) && ((UINT64_C(62) == ((v6376 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(63) == v6342)));
            }
            t6453 = t6452;
        }
        int v6454 = t6453;
        uint64_t v6455 = (v6448 ? UINT64_C(63) : (v6449 ? UINT64_C(64) : v6308));
        uint64_t v6456 = (v6449 ? (((((uint64_t)(v6446 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(63)]))) : v6359);
        uint64_t v6457 = (v6450 ? ((v6325 + UINT64_C(1)) & UINT64_C(255)) : v6325);
        uint64_t v6458 = (v6450 ? UINT64_C(62) : v6376);
        uint64_t v6459 = (v6450 ? ((uint64_t)((UINT64_C(63) + v6446) & UINT64_C(255))) : v6342);
        uint64_t v6460 = ((v6448 || v6449) ? UINT64_C(1) : ((v6454 || (v6447 && (!v6450))) ? UINT64_C(2) : v6393));
        t6461 = v6456;
    } else {
        t6461 = v6359;
    }
    uint64_t v6462 = t6461;
    uint64_t t6478;
    if (v6394) {
        uint64_t v6463 = ((uint64_t)in_b[UINT64_C(62)]);
        int v6464 = ((v6393 == UINT64_C(0)) && (UINT64_C(62) == v6342));
        int v6465 = (v6464 && (v6463 == UINT64_C(0)));
        int v6466 = ((v6464 && ((v6463 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(63) < ((uint64_t)((uint64_t)in_b_len))));
        int v6467 = (((v6464 && (v6463 != UINT64_C(0))) && (v6463 < UINT64_C(64))) && (((uint64_t)((UINT64_C(62) + v6463) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6470 = ((v6393 == UINT64_C(0)) && (UINT64_C(62) != v6342));
        if (t6470) {
                uint64_t v6468 = v6463;
            int t6469 = (!(((((v6468 | UINT64_C(32)) >= UINT64_C(97)) && ((v6468 | UINT64_C(32)) <= UINT64_C(122))) || ((v6468 >= UINT64_C(48)) && (v6468 <= UINT64_C(57)))) || (v6468 == UINT64_C(45))));
            if (!t6469) {
                t6469 = ((v6463 == UINT64_C(45)) && ((UINT64_C(62) == ((v6376 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(63) == v6342)));
            }
            t6470 = t6469;
        }
        int v6471 = t6470;
        uint64_t v6472 = (v6465 ? UINT64_C(63) : (v6466 ? UINT64_C(64) : v6308));
        uint64_t v6473 = (v6466 ? (((((uint64_t)(v6463 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(63)]))) : v6359);
        uint64_t v6474 = (v6467 ? ((v6325 + UINT64_C(1)) & UINT64_C(255)) : v6325);
        uint64_t v6475 = (v6467 ? UINT64_C(62) : v6376);
        uint64_t v6476 = (v6467 ? ((uint64_t)((UINT64_C(63) + v6463) & UINT64_C(255))) : v6342);
        uint64_t v6477 = ((v6465 || v6466) ? UINT64_C(1) : ((v6471 || (v6464 && (!v6467))) ? UINT64_C(2) : v6393));
        t6478 = v6475;
    } else {
        t6478 = v6376;
    }
    uint64_t v6479 = t6478;
    uint64_t t6495;
    if (v6394) {
        uint64_t v6480 = ((uint64_t)in_b[UINT64_C(62)]);
        int v6481 = ((v6393 == UINT64_C(0)) && (UINT64_C(62) == v6342));
        int v6482 = (v6481 && (v6480 == UINT64_C(0)));
        int v6483 = ((v6481 && ((v6480 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(63) < ((uint64_t)((uint64_t)in_b_len))));
        int v6484 = (((v6481 && (v6480 != UINT64_C(0))) && (v6480 < UINT64_C(64))) && (((uint64_t)((UINT64_C(62) + v6480) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6487 = ((v6393 == UINT64_C(0)) && (UINT64_C(62) != v6342));
        if (t6487) {
                uint64_t v6485 = v6480;
            int t6486 = (!(((((v6485 | UINT64_C(32)) >= UINT64_C(97)) && ((v6485 | UINT64_C(32)) <= UINT64_C(122))) || ((v6485 >= UINT64_C(48)) && (v6485 <= UINT64_C(57)))) || (v6485 == UINT64_C(45))));
            if (!t6486) {
                t6486 = ((v6480 == UINT64_C(45)) && ((UINT64_C(62) == ((v6376 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(63) == v6342)));
            }
            t6487 = t6486;
        }
        int v6488 = t6487;
        uint64_t v6489 = (v6482 ? UINT64_C(63) : (v6483 ? UINT64_C(64) : v6308));
        uint64_t v6490 = (v6483 ? (((((uint64_t)(v6480 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(63)]))) : v6359);
        uint64_t v6491 = (v6484 ? ((v6325 + UINT64_C(1)) & UINT64_C(255)) : v6325);
        uint64_t v6492 = (v6484 ? UINT64_C(62) : v6376);
        uint64_t v6493 = (v6484 ? ((uint64_t)((UINT64_C(63) + v6480) & UINT64_C(255))) : v6342);
        uint64_t v6494 = ((v6482 || v6483) ? UINT64_C(1) : ((v6488 || (v6481 && (!v6484))) ? UINT64_C(2) : v6393));
        t6495 = v6494;
    } else {
        t6495 = v6393;
    }
    uint64_t v6496 = t6495;
    int v6497 = (UINT64_C(63) < v7);
    uint64_t t6513;
    if (v6497) {
        uint64_t v6498 = ((uint64_t)in_b[UINT64_C(63)]);
        int v6499 = ((v6496 == UINT64_C(0)) && (UINT64_C(63) == v6445));
        int v6500 = (v6499 && (v6498 == UINT64_C(0)));
        int v6501 = ((v6499 && ((v6498 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(64) < ((uint64_t)((uint64_t)in_b_len))));
        int v6502 = (((v6499 && (v6498 != UINT64_C(0))) && (v6498 < UINT64_C(64))) && (((uint64_t)((UINT64_C(63) + v6498) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6505 = ((v6496 == UINT64_C(0)) && (UINT64_C(63) != v6445));
        if (t6505) {
                uint64_t v6503 = v6498;
            int t6504 = (!(((((v6503 | UINT64_C(32)) >= UINT64_C(97)) && ((v6503 | UINT64_C(32)) <= UINT64_C(122))) || ((v6503 >= UINT64_C(48)) && (v6503 <= UINT64_C(57)))) || (v6503 == UINT64_C(45))));
            if (!t6504) {
                t6504 = ((v6498 == UINT64_C(45)) && ((UINT64_C(63) == ((v6479 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(64) == v6445)));
            }
            t6505 = t6504;
        }
        int v6506 = t6505;
        uint64_t v6507 = (v6500 ? UINT64_C(64) : (v6501 ? UINT64_C(65) : v6411));
        uint64_t v6508 = (v6501 ? (((((uint64_t)(v6498 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(64)]))) : v6462);
        uint64_t v6509 = (v6502 ? ((v6428 + UINT64_C(1)) & UINT64_C(255)) : v6428);
        uint64_t v6510 = (v6502 ? UINT64_C(63) : v6479);
        uint64_t v6511 = (v6502 ? ((uint64_t)((UINT64_C(64) + v6498) & UINT64_C(255))) : v6445);
        uint64_t v6512 = ((v6500 || v6501) ? UINT64_C(1) : ((v6506 || (v6499 && (!v6502))) ? UINT64_C(2) : v6496));
        t6513 = v6507;
    } else {
        t6513 = v6411;
    }
    uint64_t v6514 = t6513;
    uint64_t t6530;
    if (v6497) {
        uint64_t v6515 = ((uint64_t)in_b[UINT64_C(63)]);
        int v6516 = ((v6496 == UINT64_C(0)) && (UINT64_C(63) == v6445));
        int v6517 = (v6516 && (v6515 == UINT64_C(0)));
        int v6518 = ((v6516 && ((v6515 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(64) < ((uint64_t)((uint64_t)in_b_len))));
        int v6519 = (((v6516 && (v6515 != UINT64_C(0))) && (v6515 < UINT64_C(64))) && (((uint64_t)((UINT64_C(63) + v6515) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6522 = ((v6496 == UINT64_C(0)) && (UINT64_C(63) != v6445));
        if (t6522) {
                uint64_t v6520 = v6515;
            int t6521 = (!(((((v6520 | UINT64_C(32)) >= UINT64_C(97)) && ((v6520 | UINT64_C(32)) <= UINT64_C(122))) || ((v6520 >= UINT64_C(48)) && (v6520 <= UINT64_C(57)))) || (v6520 == UINT64_C(45))));
            if (!t6521) {
                t6521 = ((v6515 == UINT64_C(45)) && ((UINT64_C(63) == ((v6479 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(64) == v6445)));
            }
            t6522 = t6521;
        }
        int v6523 = t6522;
        uint64_t v6524 = (v6517 ? UINT64_C(64) : (v6518 ? UINT64_C(65) : v6411));
        uint64_t v6525 = (v6518 ? (((((uint64_t)(v6515 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(64)]))) : v6462);
        uint64_t v6526 = (v6519 ? ((v6428 + UINT64_C(1)) & UINT64_C(255)) : v6428);
        uint64_t v6527 = (v6519 ? UINT64_C(63) : v6479);
        uint64_t v6528 = (v6519 ? ((uint64_t)((UINT64_C(64) + v6515) & UINT64_C(255))) : v6445);
        uint64_t v6529 = ((v6517 || v6518) ? UINT64_C(1) : ((v6523 || (v6516 && (!v6519))) ? UINT64_C(2) : v6496));
        t6530 = v6526;
    } else {
        t6530 = v6428;
    }
    uint64_t v6531 = t6530;
    uint64_t t6547;
    if (v6497) {
        uint64_t v6532 = ((uint64_t)in_b[UINT64_C(63)]);
        int v6533 = ((v6496 == UINT64_C(0)) && (UINT64_C(63) == v6445));
        int v6534 = (v6533 && (v6532 == UINT64_C(0)));
        int v6535 = ((v6533 && ((v6532 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(64) < ((uint64_t)((uint64_t)in_b_len))));
        int v6536 = (((v6533 && (v6532 != UINT64_C(0))) && (v6532 < UINT64_C(64))) && (((uint64_t)((UINT64_C(63) + v6532) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6539 = ((v6496 == UINT64_C(0)) && (UINT64_C(63) != v6445));
        if (t6539) {
                uint64_t v6537 = v6532;
            int t6538 = (!(((((v6537 | UINT64_C(32)) >= UINT64_C(97)) && ((v6537 | UINT64_C(32)) <= UINT64_C(122))) || ((v6537 >= UINT64_C(48)) && (v6537 <= UINT64_C(57)))) || (v6537 == UINT64_C(45))));
            if (!t6538) {
                t6538 = ((v6532 == UINT64_C(45)) && ((UINT64_C(63) == ((v6479 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(64) == v6445)));
            }
            t6539 = t6538;
        }
        int v6540 = t6539;
        uint64_t v6541 = (v6534 ? UINT64_C(64) : (v6535 ? UINT64_C(65) : v6411));
        uint64_t v6542 = (v6535 ? (((((uint64_t)(v6532 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(64)]))) : v6462);
        uint64_t v6543 = (v6536 ? ((v6428 + UINT64_C(1)) & UINT64_C(255)) : v6428);
        uint64_t v6544 = (v6536 ? UINT64_C(63) : v6479);
        uint64_t v6545 = (v6536 ? ((uint64_t)((UINT64_C(64) + v6532) & UINT64_C(255))) : v6445);
        uint64_t v6546 = ((v6534 || v6535) ? UINT64_C(1) : ((v6540 || (v6533 && (!v6536))) ? UINT64_C(2) : v6496));
        t6547 = v6545;
    } else {
        t6547 = v6445;
    }
    uint64_t v6548 = t6547;
    uint64_t t6564;
    if (v6497) {
        uint64_t v6549 = ((uint64_t)in_b[UINT64_C(63)]);
        int v6550 = ((v6496 == UINT64_C(0)) && (UINT64_C(63) == v6445));
        int v6551 = (v6550 && (v6549 == UINT64_C(0)));
        int v6552 = ((v6550 && ((v6549 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(64) < ((uint64_t)((uint64_t)in_b_len))));
        int v6553 = (((v6550 && (v6549 != UINT64_C(0))) && (v6549 < UINT64_C(64))) && (((uint64_t)((UINT64_C(63) + v6549) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6556 = ((v6496 == UINT64_C(0)) && (UINT64_C(63) != v6445));
        if (t6556) {
                uint64_t v6554 = v6549;
            int t6555 = (!(((((v6554 | UINT64_C(32)) >= UINT64_C(97)) && ((v6554 | UINT64_C(32)) <= UINT64_C(122))) || ((v6554 >= UINT64_C(48)) && (v6554 <= UINT64_C(57)))) || (v6554 == UINT64_C(45))));
            if (!t6555) {
                t6555 = ((v6549 == UINT64_C(45)) && ((UINT64_C(63) == ((v6479 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(64) == v6445)));
            }
            t6556 = t6555;
        }
        int v6557 = t6556;
        uint64_t v6558 = (v6551 ? UINT64_C(64) : (v6552 ? UINT64_C(65) : v6411));
        uint64_t v6559 = (v6552 ? (((((uint64_t)(v6549 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(64)]))) : v6462);
        uint64_t v6560 = (v6553 ? ((v6428 + UINT64_C(1)) & UINT64_C(255)) : v6428);
        uint64_t v6561 = (v6553 ? UINT64_C(63) : v6479);
        uint64_t v6562 = (v6553 ? ((uint64_t)((UINT64_C(64) + v6549) & UINT64_C(255))) : v6445);
        uint64_t v6563 = ((v6551 || v6552) ? UINT64_C(1) : ((v6557 || (v6550 && (!v6553))) ? UINT64_C(2) : v6496));
        t6564 = v6559;
    } else {
        t6564 = v6462;
    }
    uint64_t v6565 = t6564;
    uint64_t t6581;
    if (v6497) {
        uint64_t v6566 = ((uint64_t)in_b[UINT64_C(63)]);
        int v6567 = ((v6496 == UINT64_C(0)) && (UINT64_C(63) == v6445));
        int v6568 = (v6567 && (v6566 == UINT64_C(0)));
        int v6569 = ((v6567 && ((v6566 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(64) < ((uint64_t)((uint64_t)in_b_len))));
        int v6570 = (((v6567 && (v6566 != UINT64_C(0))) && (v6566 < UINT64_C(64))) && (((uint64_t)((UINT64_C(63) + v6566) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6573 = ((v6496 == UINT64_C(0)) && (UINT64_C(63) != v6445));
        if (t6573) {
                uint64_t v6571 = v6566;
            int t6572 = (!(((((v6571 | UINT64_C(32)) >= UINT64_C(97)) && ((v6571 | UINT64_C(32)) <= UINT64_C(122))) || ((v6571 >= UINT64_C(48)) && (v6571 <= UINT64_C(57)))) || (v6571 == UINT64_C(45))));
            if (!t6572) {
                t6572 = ((v6566 == UINT64_C(45)) && ((UINT64_C(63) == ((v6479 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(64) == v6445)));
            }
            t6573 = t6572;
        }
        int v6574 = t6573;
        uint64_t v6575 = (v6568 ? UINT64_C(64) : (v6569 ? UINT64_C(65) : v6411));
        uint64_t v6576 = (v6569 ? (((((uint64_t)(v6566 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(64)]))) : v6462);
        uint64_t v6577 = (v6570 ? ((v6428 + UINT64_C(1)) & UINT64_C(255)) : v6428);
        uint64_t v6578 = (v6570 ? UINT64_C(63) : v6479);
        uint64_t v6579 = (v6570 ? ((uint64_t)((UINT64_C(64) + v6566) & UINT64_C(255))) : v6445);
        uint64_t v6580 = ((v6568 || v6569) ? UINT64_C(1) : ((v6574 || (v6567 && (!v6570))) ? UINT64_C(2) : v6496));
        t6581 = v6578;
    } else {
        t6581 = v6479;
    }
    uint64_t v6582 = t6581;
    uint64_t t6598;
    if (v6497) {
        uint64_t v6583 = ((uint64_t)in_b[UINT64_C(63)]);
        int v6584 = ((v6496 == UINT64_C(0)) && (UINT64_C(63) == v6445));
        int v6585 = (v6584 && (v6583 == UINT64_C(0)));
        int v6586 = ((v6584 && ((v6583 & UINT64_C(192)) == UINT64_C(192))) && (UINT64_C(64) < ((uint64_t)((uint64_t)in_b_len))));
        int v6587 = (((v6584 && (v6583 != UINT64_C(0))) && (v6583 < UINT64_C(64))) && (((uint64_t)((UINT64_C(63) + v6583) & UINT64_C(255))) < ((uint64_t)((uint64_t)in_b_len))));
        int t6590 = ((v6496 == UINT64_C(0)) && (UINT64_C(63) != v6445));
        if (t6590) {
                uint64_t v6588 = v6583;
            int t6589 = (!(((((v6588 | UINT64_C(32)) >= UINT64_C(97)) && ((v6588 | UINT64_C(32)) <= UINT64_C(122))) || ((v6588 >= UINT64_C(48)) && (v6588 <= UINT64_C(57)))) || (v6588 == UINT64_C(45))));
            if (!t6589) {
                t6589 = ((v6583 == UINT64_C(45)) && ((UINT64_C(63) == ((v6479 + UINT64_C(1)) & UINT64_C(0xffff))) || (UINT64_C(64) == v6445)));
            }
            t6590 = t6589;
        }
        int v6591 = t6590;
        uint64_t v6592 = (v6585 ? UINT64_C(64) : (v6586 ? UINT64_C(65) : v6411));
        uint64_t v6593 = (v6586 ? (((((uint64_t)(v6583 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(64)]))) : v6462);
        uint64_t v6594 = (v6587 ? ((v6428 + UINT64_C(1)) & UINT64_C(255)) : v6428);
        uint64_t v6595 = (v6587 ? UINT64_C(63) : v6479);
        uint64_t v6596 = (v6587 ? ((uint64_t)((UINT64_C(64) + v6583) & UINT64_C(255))) : v6445);
        uint64_t v6597 = ((v6585 || v6586) ? UINT64_C(1) : ((v6591 || (v6584 && (!v6587))) ? UINT64_C(2) : v6496));
        t6598 = v6597;
    } else {
        t6598 = v6496;
    }
    uint64_t v6599 = t6598;
    int o6600_tag;
    uint64_t o6600_0 = 0;
    uint64_t o6600_1 = 0;
    uint64_t o6600_2 = 0;
    if ((v6599 == UINT64_C(1))) {
        o6600_tag = 1;
        o6600_0 = (((uint64_t)v6514) & UINT64_C(255));
        o6600_1 = v6531;
        o6600_2 = v6565;
    } else {
        o6600_tag = 0;
        o6600_0 = 0;
        o6600_1 = 0;
        o6600_2 = 0;
    }
    if (o6600_tag) {
        *out0 = (uint64_t)(o6600_0);
        *out1 = (uint64_t)(o6600_1);
        *out2 = (uint64_t)(o6600_2);
    }
    return o6600_tag;
}
