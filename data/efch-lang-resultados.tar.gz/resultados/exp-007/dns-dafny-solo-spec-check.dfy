// Nombre de host (RFC 1123 §2.1, RFC 952) en formato de cable DNS (RFC 1035 §3.1 y §4.1.4). EXP-007.

newtype u8 = x: int | 0 <= x < 256
datatype Option<T> = None | Some(value: T)

predicate IsLdh(c: u8) {
  (0x61 <= c <= 0x7a) || (0x41 <= c <= 0x5a) || (0x30 <= c <= 0x39) || c == 0x2d
}

predicate ValidLabel(b: seq<u8>, p: nat, l: nat)
  requires 1 <= l && p + l < |b|
{
  b[p + 1] != 0x2d && b[p + l] != 0x2d && forall j :: p < j <= p + l ==> IsLdh(b[j])
}

function Spec(b: seq<u8>, p: nat, labels: nat): Option<(nat, nat, nat)>
  decreases |b| - p
{
  if p >= |b| then None
  else if b[p] == 0 then Some((p + 1, labels, 0xffff))
  else if b[p] >= 0xc0 then
    if p + 1 < |b| then Some((p + 2, labels, (b[p] as nat - 0xc0) * 256 + b[p + 1] as nat)) else None
  else if b[p] >= 0x40 then None
  else if p + b[p] as nat < |b| && ValidLabel(b, p, b[p] as nat) then Spec(b, p + 1 + b[p] as nat, labels + 1)
  else None
}

method Check(b: seq<u8>) returns (r: Option<(nat, nat, nat)>)
  ensures r == Spec(b, 0, 0)
{
  return Spec(b, 0, 0);
}
