# EXP-007 (nombre DNS): EFCH Lang frente a Rust + Kani, Dafny, C y Go

Fecha: 2026-10-21T19:46:22Z. Intel Core Processor (Haswell, no TSX); gcc gcc (Ubuntu 15.2.0-16ubuntu1) 15.2.0 `-O3 -march=native`; rustc 1.93.1 (01f6ddf75 2026-02-11) (built from a source tarball); go version go1.26.8 linux/amd64; Dafny 4.11.0+fcb2042d6d043a2634f0854338c08feeaaaf4ae2; Kani Kani Rust Verifier 0.68.0 (standalone).

## Verificación (segundos de reloj, con arranque de cada herramienta)

| Función | EFCH | Kani | Dafny (anotaciones) |
|---|---|---|---|
| dns | error (timeout) (Z3) 900.13 | desconocido (143) 312.74 | probado 2.76 (5) |

## Esfuerzo (líneas escritas a mano para obtener la garantía; C y Go no la tienen)

| Función | EFCH (espec. + programa) | Rust + Kani | Dafny | C | Go |
|---|---|---|---|---|---|
| dns | 102 (75 + 27) | 90 | 49 | 28 | 35 |

## Variantes «solo especificación» (sensibilidad; no entra en la decisión)

| Función | EFCH espec. (líneas, s) | Dafny Spec + `return Spec(...)` (líneas, s) |
|---|---|---|
| dns | 75, 900.17 (desconocido (timeout)) | 26, 2.48 (probado) |

## Rendimiento (ns/op, media de las medianas por semilla)

| Función | EFCH Lang | C a mano | Rust | Go | C de la especificación |
|---|---|---|---|---|---|
| dns | 363.504 | 64.388 | 57.154 | 106.065 | 254.262 |

## Corrección experimental (fallos en vectores / pruebas diferenciales)

| Función | EFCH | C | Rust | Dafny | Go |
|---|---|---|---|---|---|
| dns | 0 / 0 de 8257 | 0 / 0 de 8257 | 0 / 0 de 8257 | 0 / 0 de 8257 | 0 / 0 de 8257 |

## Criterios registrados

```json
{
  "D0": {
    "cumple": true
  },
  "D1": {
    "valor": "expresada con un rodeo (if de expresión); ver la ficha",
    "cumple": true
  },
  "D2": {
    "valor": {
      "estado": "error (timeout)",
      "segundos": 900.13,
      "herramienta": "Z3"
    },
    "cumple": false
  },
  "D3": {
    "efch_lang_sobre_c": 5.646,
    "cumple": false
  },
  "D4": {
    "rust_kani": {
      "esfuerzo_relativo": 1.133,
      "a": false,
      "b": false,
      "c": false,
      "cumple": false
    },
    "dafny": {
      "esfuerzo_relativo": 2.082,
      "a": false,
      "b": false,
      "c": false,
      "cumple": false
    },
    "cumple": false
  },
  "D5": {
    "aplica": true,
    "lineas_dafny_spec": 26,
    "efch_lang_sobre_dafny_spec_go": 0.03,
    "cumple": true
  },
  "decision": "no cumplido"
}
```

Especificación de Dafny compilada a Go: 12103.211 ns/op.
