# EXP-005: EFCH Lang frente a Rust + Kani, Dafny, C y Go

Fecha: 2026-10-21T05:30:53Z. Intel Core Processor (Haswell, no TSX); gcc gcc (Ubuntu 15.2.0-16ubuntu1) 15.2.0 `-O3 -march=native`; rustc 1.93.1 (01f6ddf75 2026-02-11) (built from a source tarball); go version go1.26.8 linux/amd64; Dafny 4.11.0+fcb2042d6d043a2634f0854338c08feeaaaf4ae2; Kani Kani Rust Verifier 0.68.0 (standalone).

## Verificación (segundos de reloj, con arranque de cada herramienta)

| Función | EFCH | Kani | Dafny (anotaciones) |
|---|---|---|---|
| quic | probado (Z3) 0.31 | probado 4.45 | probado 2.48 (3) |
| hpack | probado (Z3) 0.38 | probado 8.18 | probado 2.83 (7) |
| cbor | probado (Z3) 0.34 | probado 6.07 | probado 2.23 (3) |
| utf8 | probado (Z3) 0.32 | probado 4.18 | probado 2.6 (5) |
| base64 | probado (Z3) 0.31 | probado 4.17 | probado 2.53 (0) |
| ipv4 | probado (CBMC) 70.22 | probado 57.61 | probado 2.56 (3) |
| compactsize | probado (Z3) 0.31 | probado 3.93 | probado 2.39 (3) |
| msgpack | probado (Z3) 0.35 | probado 5.19 | probado 2.75 (3) |

## Esfuerzo (líneas escritas a mano para obtener la garantía; C y Go no la tienen)

| Función | EFCH (espec. + programa) | Rust + Kani | Dafny | C | Go |
|---|---|---|---|---|---|
| quic | 25 (15 + 10) | 43 | 29 | 12 | 15 |
| hpack | 33 (18 + 15) | 54 | 53 | 19 | 22 |
| cbor | 34 (20 + 14) | 50 | 38 | 18 | 22 |
| utf8 | 47 (30 + 17) | 82 | 46 | 31 | 34 |
| base64 | 56 (27 + 29) | 77 | 40 | 36 | 43 |
| ipv4 | 34 (18 + 16) | 56 | 36 | 18 | 20 |
| compactsize | 31 (17 + 14) | 62 | 38 | 22 | 26 |
| msgpack | 40 (22 + 18) | 64 | 49 | 21 | 29 |

## Rendimiento (ns/op, media de las medianas por semilla)

| Función | EFCH Lang | C a mano | Rust | Go | C de la especificación |
|---|---|---|---|---|---|
| quic | 12.049 | 11.775 | 12.356 | 14.968 | 12.012 |
| hpack | 8.339 | 9.656 | 11.766 | 13.267 | 7.802 |
| cbor | 8.126 | 8.117 | 8.159 | 8.699 | 8.099 |
| utf8 | 11.063 | 13.43 | 11.534 | 13.327 | 11.377 |
| base64 | 11.368 | 11.709 | 9.938 | 14.127 | 19.36 |
| ipv4 | 6.827 | 9.402 | 8.207 | 8.612 | 6.487 |
| compactsize | 2.967 | 3.618 | 4.274 | 5.585 | 2.669 |
| msgpack | 9.174 | 8.868 | 10.662 | 12.291 | 9.887 |

## Corrección experimental (fallos en vectores / pruebas diferenciales)

| Función | EFCH | C | Rust | Dafny | Go |
|---|---|---|---|---|---|
| quic | 0 / 0 de 5033 | 0 / 0 de 5033 | 0 / 0 de 5033 | 0 / 0 de 5033 | 0 / 0 de 5033 |
| hpack | 0 / 0 de 5025 | 0 / 0 de 5025 | 0 / 0 de 5025 | 0 / 0 de 5025 | 0 / 0 de 5025 |
| cbor | 0 / 0 de 5037 | 0 / 0 de 5037 | 0 / 0 de 5037 | 0 / 0 de 5037 | 0 / 0 de 5037 |
| utf8 | 0 / 0 de 5017 | 0 / 0 de 5017 | 0 / 0 de 5017 | 0 / 0 de 5017 | 0 / 0 de 5017 |
| base64 | 0 / 0 de 5017 | 0 / 0 de 5017 | 0 / 0 de 5017 | 0 / 0 de 5017 | 0 / 0 de 5017 |
| ipv4 | 0 / 0 de 5241 | 0 / 0 de 5241 | 0 / 0 de 5241 | 0 / 0 de 5241 | 0 / 0 de 5241 |
| compactsize | 0 / 0 de 5037 | 0 / 0 de 5037 | 0 / 0 de 5037 | 0 / 0 de 5037 | 0 / 0 de 5037 |
| msgpack | 0 / 0 de 5037 | 0 / 0 de 5037 | 0 / 0 de 5037 | 0 / 0 de 5037 | 0 / 0 de 5037 |

## Criterios registrados

```json
{
  "V1": {
    "valor": "8/8",
    "cumple": true
  },
  "V2": {
    "valor": "8/8",
    "cumple": true
  },
  "V3": {
    "media_geometrica": 0.901,
    "maximo": 1.035,
    "por_funcion": {
      "quic": 1.023,
      "hpack": 0.864,
      "cbor": 1.001,
      "utf8": 0.824,
      "base64": 0.971,
      "ipv4": 0.726,
      "compactsize": 0.82,
      "msgpack": 1.035
    },
    "cumple": true
  },
  "V4": {
    "rust_kani": {
      "a_esfuerzo_relativo": 0.61,
      "a": true,
      "b_solo_efch": [],
      "b": false,
      "c_mas_rapido_x2": [
        "quic",
        "hpack",
        "cbor",
        "utf8",
        "base64",
        "compactsize",
        "msgpack"
      ],
      "c": true,
      "cumple": true
    },
    "dafny": {
      "a_esfuerzo_relativo": 0.9,
      "a": false,
      "b_solo_efch": [],
      "b": false,
      "c_mas_rapido_x2": [
        "quic",
        "hpack",
        "cbor",
        "utf8",
        "base64",
        "compactsize",
        "msgpack"
      ],
      "c": true,
      "cumple": true
    },
    "cumple": true
  },
  "decision": "viable"
}
```
