import sys
from typing import Callable, Any, TypeVar, NamedTuple
from math import floor
from itertools import count

import module_ as module_
import _dafny as _dafny
import System_ as System_

# Module: module_

class default__:
    def  __init__(self):
        pass

    @staticmethod
    def BE(s):
        if (len(s)) == (0):
            return 0
        elif True:
            return ((default__.BE(_dafny.SeqWithoutIsStrInference((s)[:(len(s)) - (1):]))) * (256)) + ((s)[(len(s)) - (1)])

    @staticmethod
    def Spec(buf):
        if (len(buf)) == (0):
            return Option_None()
        elif True:
            d_0_mt_ = _dafny.euclidian_division((buf)[0], 32)
            d_1_ai_ = _dafny.euclidian_modulus((buf)[0], 32)
            if (d_1_ai_) < (24):
                return Option_Some((d_0_mt_, d_1_ai_, 1))
            elif (d_1_ai_) > (27):
                return Option_None()
            elif True:
                d_2_k_ = (1 if (d_1_ai_) == (24) else (2 if (d_1_ai_) == (25) else (4 if (d_1_ai_) == (26) else 8)))
                if (len(buf)) < ((d_2_k_) + (1)):
                    return Option_None()
                elif True:
                    return Option_Some((d_0_mt_, default__.BE(_dafny.SeqWithoutIsStrInference((buf)[1:(d_2_k_) + (1):])), (d_2_k_) + (1)))

    @staticmethod
    def Decode(buf):
        r: Option = Option.default()()
        if (len(buf)) == (0):
            r = Option_None()
            return r
        d_0_major_: int
        d_0_major_ = _dafny.euclidian_division((buf)[0], 32)
        d_1_info_: int
        d_1_info_ = _dafny.euclidian_modulus((buf)[0], 32)
        if (d_1_info_) < (24):
            r = Option_Some((d_0_major_, d_1_info_, 1))
            return r
        if (d_1_info_) > (27):
            r = Option_None()
            return r
        d_2_k_: int
        if (d_1_info_) == (24):
            d_2_k_ = 1
        elif (d_1_info_) == (25):
            d_2_k_ = 2
        elif (d_1_info_) == (26):
            d_2_k_ = 4
        elif True:
            d_2_k_ = 8
        if (len(buf)) < ((d_2_k_) + (1)):
            r = Option_None()
            return r
        d_3_arg_: int
        d_3_arg_ = 0
        d_4_i_: int
        d_4_i_ = 1
        while (d_4_i_) <= (d_2_k_):
            d_3_arg_ = ((d_3_arg_) * (256)) + ((buf)[d_4_i_])
            d_4_i_ = (d_4_i_) + (1)
        r = Option_Some((d_0_major_, d_3_arg_, (d_2_k_) + (1)))
        return r
        return r


class u8:
    def  __init__(self):
        pass

    @staticmethod
    def default():
        return int(0)
    def _Is(source__):
        return True

class Option:
    @classmethod
    def default(cls, ):
        return lambda: Option_None()
    def __ne__(self, __o: object) -> bool:
        return not self.__eq__(__o)
    @property
    def is_None(self) -> bool:
        return isinstance(self, Option_None)
    @property
    def is_Some(self) -> bool:
        return isinstance(self, Option_Some)

class Option_None(Option, NamedTuple('None_', [])):
    def __dafnystr__(self) -> str:
        return f'Option.None'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, Option_None)
    def __hash__(self) -> int:
        return super().__hash__()

class Option_Some(Option, NamedTuple('Some', [('value', Any)])):
    def __dafnystr__(self) -> str:
        return f'Option.Some({_dafny.string_of(self.value)})'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, Option_Some) and self.value == __o.value
    def __hash__(self) -> int:
        return super().__hash__()

