#include <stddef.h>
#include <stdint.h>
#include <string.h>
typedef unsigned __int128 efch_u128;

/* Operaciones con signo sobre valores de w bits guardados sin signo y enmascarados. Solo usan
   aritmética sin signo: no hay comportamiento indefinido ni dependiente de la implementación. */
#define EFCH_SIGNED_OPS(T, SUF)                                                               \
static inline T efch_mask##SUF(unsigned w) { return w >= 8 * sizeof(T) ? (T)~(T)0 : (((T)1 << w) - 1); } \
static inline int efch_slt##SUF(T x, T y, unsigned w) { T s = (T)1 << (w - 1); return (x ^ s) < (y ^ s); } \
static inline T efch_sext##SUF(T x, unsigned w, unsigned n) {                                 \
    return (x & ((T)1 << (w - 1))) ? (x | (efch_mask##SUF(n) & ~efch_mask##SUF(w))) : x; }    \
static inline T efch_ashr##SUF(T x, T k, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int neg = (x >> (w - 1)) & 1;                                    \
    if (k >= w) return neg ? m : 0;                                                           \
    return (x >> k) | (neg ? (m & ~(m >> k)) : 0); }                                          \
static inline T efch_sdiv##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return nx ? 1 : m;                                                            \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, q = ax / ay;                     \
    return (nx != ny) ? ((T)-q & m) : q; }                                                    \
static inline T efch_srem##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return x;                                                                     \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, r = ax % ay;                     \
    return nx ? ((T)-r & m) : r; }
EFCH_SIGNED_OPS(uint64_t, 64)
EFCH_SIGNED_OPS(efch_u128, 128)

int efch_cbor_head_decode__lang(const uint8_t *in_buf, size_t in_buf_len, uint64_t *out0, uint64_t *out1, uint64_t *out2)
{
    int o1_tag;
    uint64_t o1_0 = 0;
    uint64_t o1_1 = 0;
    uint64_t o1_2 = 0;
    if ((((uint64_t)((uint64_t)in_buf_len)) == UINT64_C(0))) {
        o1_tag = 0;
        o1_0 = 0;
        o1_1 = 0;
        o1_2 = 0;
    } else {
        uint64_t v2 = (((uint64_t)in_buf[UINT64_C(0)]) >> 5);
        uint64_t v3 = (((uint64_t)in_buf[UINT64_C(0)]) & UINT64_C(31));
        int o4_tag;
        uint64_t o4_0 = 0;
        uint64_t o4_1 = 0;
        uint64_t o4_2 = 0;
        if ((v3 < UINT64_C(24))) {
            o4_tag = 1;
            o4_0 = v2;
            o4_1 = ((uint64_t)v3);
            o4_2 = UINT64_C(1);
        } else {
            int o5_tag;
            uint64_t o5_0 = 0;
            uint64_t o5_1 = 0;
            uint64_t o5_2 = 0;
            if ((v3 > UINT64_C(27))) {
                o5_tag = 0;
                o5_0 = 0;
                o5_1 = 0;
                o5_2 = 0;
            } else {
                uint64_t v6 = ((((v3 & UINT64_C(3)) >= 8 ? 0 : UINT64_C(1) << (v3 & UINT64_C(3)))) & UINT64_C(255));
                int o7_tag;
                uint64_t o7_0 = 0;
                uint64_t o7_1 = 0;
                uint64_t o7_2 = 0;
                if ((((uint64_t)((uint64_t)in_buf_len)) < ((uint64_t)((v6 + UINT64_C(1)) & UINT64_C(255))))) {
                    o7_tag = 0;
                    o7_0 = 0;
                    o7_1 = 0;
                    o7_2 = 0;
                } else {
                    uint64_t v8 = UINT64_C(0);
                    uint64_t v9 = v6;
                    int v10 = (UINT64_C(1) <= v9);
                    uint64_t t12;
                    if (v10) {
                        uint64_t v11 = ((v8 << 8) | ((uint64_t)((uint64_t)in_buf[UINT64_C(1)])));
                        t12 = v11;
                    } else {
                        t12 = v8;
                    }
                    uint64_t v13 = t12;
                    int v14 = (UINT64_C(2) <= v9);
                    uint64_t t16;
                    if (v14) {
                        uint64_t v15 = ((v13 << 8) | ((uint64_t)((uint64_t)in_buf[UINT64_C(2)])));
                        t16 = v15;
                    } else {
                        t16 = v13;
                    }
                    uint64_t v17 = t16;
                    int v18 = (UINT64_C(3) <= v9);
                    uint64_t t20;
                    if (v18) {
                        uint64_t v19 = ((v17 << 8) | ((uint64_t)((uint64_t)in_buf[UINT64_C(3)])));
                        t20 = v19;
                    } else {
                        t20 = v17;
                    }
                    uint64_t v21 = t20;
                    int v22 = (UINT64_C(4) <= v9);
                    uint64_t t24;
                    if (v22) {
                        uint64_t v23 = ((v21 << 8) | ((uint64_t)((uint64_t)in_buf[UINT64_C(4)])));
                        t24 = v23;
                    } else {
                        t24 = v21;
                    }
                    uint64_t v25 = t24;
                    int v26 = (UINT64_C(5) <= v9);
                    uint64_t t28;
                    if (v26) {
                        uint64_t v27 = ((v25 << 8) | ((uint64_t)((uint64_t)in_buf[UINT64_C(5)])));
                        t28 = v27;
                    } else {
                        t28 = v25;
                    }
                    uint64_t v29 = t28;
                    int v30 = (UINT64_C(6) <= v9);
                    uint64_t t32;
                    if (v30) {
                        uint64_t v31 = ((v29 << 8) | ((uint64_t)((uint64_t)in_buf[UINT64_C(6)])));
                        t32 = v31;
                    } else {
                        t32 = v29;
                    }
                    uint64_t v33 = t32;
                    int v34 = (UINT64_C(7) <= v9);
                    uint64_t t36;
                    if (v34) {
                        uint64_t v35 = ((v33 << 8) | ((uint64_t)((uint64_t)in_buf[UINT64_C(7)])));
                        t36 = v35;
                    } else {
                        t36 = v33;
                    }
                    uint64_t v37 = t36;
                    int v38 = (UINT64_C(8) <= v9);
                    uint64_t t40;
                    if (v38) {
                        uint64_t v39 = ((v37 << 8) | ((uint64_t)((uint64_t)in_buf[UINT64_C(8)])));
                        t40 = v39;
                    } else {
                        t40 = v37;
                    }
                    uint64_t v41 = t40;
                    o7_tag = 1;
                    o7_0 = v2;
                    o7_1 = v41;
                    o7_2 = ((v6 + UINT64_C(1)) & UINT64_C(255));
                }
                o5_tag = o7_tag;
                o5_0 = o7_0;
                o5_1 = o7_1;
                o5_2 = o7_2;
            }
            o4_tag = o5_tag;
            o4_0 = o5_0;
            o4_1 = o5_1;
            o4_2 = o5_2;
        }
        o1_tag = o4_tag;
        o1_0 = o4_0;
        o1_1 = o4_1;
        o1_2 = o4_2;
    }
    if (o1_tag) {
        *out0 = (uint64_t)(o1_0);
        *out1 = (uint64_t)(o1_1);
        *out2 = (uint64_t)(o1_2);
    }
    return o1_tag;
}
