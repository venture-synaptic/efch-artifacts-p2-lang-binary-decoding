#include <stddef.h>
#include <stdint.h>
#include <string.h>
typedef unsigned __int128 efch_u128;

/* Operaciones con signo sobre valores de w bits guardados sin signo y enmascarados. Solo usan
   aritmética sin signo: no hay comportamiento indefinido ni dependiente de la implementación. */
#define EFCH_SIGNED_OPS(T, SUF)                                                               \
static inline T efch_mask##SUF(unsigned w) { return w >= 8 * sizeof(T) ? (T)~(T)0 : (((T)1 << w) - 1); } \
static inline int efch_slt##SUF(T x, T y, unsigned w) { T s = (T)1 << (w - 1); return (x ^ s) < (y ^ s); } \
static inline T efch_sext##SUF(T x, unsigned w, unsigned n) {                                 \
    return (x & ((T)1 << (w - 1))) ? (x | (efch_mask##SUF(n) & ~efch_mask##SUF(w))) : x; }    \
static inline T efch_ashr##SUF(T x, T k, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int neg = (x >> (w - 1)) & 1;                                    \
    if (k >= w) return neg ? m : 0;                                                           \
    return (x >> k) | (neg ? (m & ~(m >> k)) : 0); }                                          \
static inline T efch_sdiv##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return nx ? 1 : m;                                                            \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, q = ax / ay;                     \
    return (nx != ny) ? ((T)-q & m) : q; }                                                    \
static inline T efch_srem##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return x;                                                                     \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, r = ax % ay;                     \
    return nx ? ((T)-r & m) : r; }
EFCH_SIGNED_OPS(uint64_t, 64)
EFCH_SIGNED_OPS(efch_u128, 128)

int efch_msgpack_int_decode(const uint8_t *in_buf, size_t in_buf_len, uint64_t *out0, uint64_t *out1, uint64_t *out2)
{
    int o1_tag;
    uint64_t o1_0 = 0;
    int o1_1 = 0;
    uint64_t o1_2 = 0;
    if ((((uint64_t)((uint64_t)in_buf_len)) == UINT64_C(0))) {
        o1_tag = 0;
        o1_0 = 0;
        o1_1 = 0;
        o1_2 = 0;
    } else {
        uint64_t v2 = ((uint64_t)in_buf[UINT64_C(0)]);
        int o3_tag;
        uint64_t o3_0 = 0;
        int o3_1 = 0;
        uint64_t o3_2 = 0;
        if ((v2 < UINT64_C(128))) {
            o3_tag = 1;
            o3_0 = ((uint64_t)v2);
            o3_1 = 0;
            o3_2 = UINT64_C(1);
        } else {
            int o4_tag;
            uint64_t o4_0 = 0;
            int o4_1 = 0;
            uint64_t o4_2 = 0;
            if ((v2 >= UINT64_C(224))) {
                o4_tag = 1;
                o4_0 = efch_sext64((uint64_t)v2, 8, 64);
                o4_1 = 1;
                o4_2 = UINT64_C(1);
            } else {
                int o5_tag;
                uint64_t o5_0 = 0;
                int o5_1 = 0;
                uint64_t o5_2 = 0;
                if (((v2 < UINT64_C(204)) || (v2 > UINT64_C(211)))) {
                    o5_tag = 0;
                    o5_0 = 0;
                    o5_1 = 0;
                    o5_2 = 0;
                } else {
                    int v6 = (v2 >= UINT64_C(208));
                    uint64_t v7 = ((((v2 & UINT64_C(3)) >= 8 ? 0 : UINT64_C(1) << (v2 & UINT64_C(3)))) & UINT64_C(255));
                    int o8_tag;
                    uint64_t o8_0 = 0;
                    int o8_1 = 0;
                    uint64_t o8_2 = 0;
                    if ((((uint64_t)((uint64_t)in_buf_len)) < ((((uint64_t)v7) + UINT64_C(1)) & UINT64_C(0xffff)))) {
                        o8_tag = 0;
                        o8_0 = 0;
                        o8_1 = 0;
                        o8_2 = 0;
                    } else {
                        uint64_t v9 = (((((((((UINT64_C(1) <= v7) ? ((((uint64_t)((UINT64_C(8) * ((v7 - UINT64_C(1)) & UINT64_C(255))) & UINT64_C(255))) >= 64 ? 0 : ((uint64_t)((uint64_t)in_buf[UINT64_C(1)])) << ((uint64_t)((UINT64_C(8) * ((v7 - UINT64_C(1)) & UINT64_C(255))) & UINT64_C(255))))) : UINT64_C(0)) | ((UINT64_C(2) <= v7) ? ((((uint64_t)((UINT64_C(8) * ((v7 - UINT64_C(2)) & UINT64_C(255))) & UINT64_C(255))) >= 64 ? 0 : ((uint64_t)((uint64_t)in_buf[UINT64_C(2)])) << ((uint64_t)((UINT64_C(8) * ((v7 - UINT64_C(2)) & UINT64_C(255))) & UINT64_C(255))))) : UINT64_C(0))) | ((UINT64_C(3) <= v7) ? ((((uint64_t)((UINT64_C(8) * ((v7 - UINT64_C(3)) & UINT64_C(255))) & UINT64_C(255))) >= 64 ? 0 : ((uint64_t)((uint64_t)in_buf[UINT64_C(3)])) << ((uint64_t)((UINT64_C(8) * ((v7 - UINT64_C(3)) & UINT64_C(255))) & UINT64_C(255))))) : UINT64_C(0))) | ((UINT64_C(4) <= v7) ? ((((uint64_t)((UINT64_C(8) * ((v7 - UINT64_C(4)) & UINT64_C(255))) & UINT64_C(255))) >= 64 ? 0 : ((uint64_t)((uint64_t)in_buf[UINT64_C(4)])) << ((uint64_t)((UINT64_C(8) * ((v7 - UINT64_C(4)) & UINT64_C(255))) & UINT64_C(255))))) : UINT64_C(0))) | ((UINT64_C(5) <= v7) ? ((((uint64_t)((UINT64_C(8) * ((v7 - UINT64_C(5)) & UINT64_C(255))) & UINT64_C(255))) >= 64 ? 0 : ((uint64_t)((uint64_t)in_buf[UINT64_C(5)])) << ((uint64_t)((UINT64_C(8) * ((v7 - UINT64_C(5)) & UINT64_C(255))) & UINT64_C(255))))) : UINT64_C(0))) | ((UINT64_C(6) <= v7) ? ((((uint64_t)((UINT64_C(8) * ((v7 - UINT64_C(6)) & UINT64_C(255))) & UINT64_C(255))) >= 64 ? 0 : ((uint64_t)((uint64_t)in_buf[UINT64_C(6)])) << ((uint64_t)((UINT64_C(8) * ((v7 - UINT64_C(6)) & UINT64_C(255))) & UINT64_C(255))))) : UINT64_C(0))) | ((UINT64_C(7) <= v7) ? ((((uint64_t)((UINT64_C(8) * ((v7 - UINT64_C(7)) & UINT64_C(255))) & UINT64_C(255))) >= 64 ? 0 : ((uint64_t)((uint64_t)in_buf[UINT64_C(7)])) << ((uint64_t)((UINT64_C(8) * ((v7 - UINT64_C(7)) & UINT64_C(255))) & UINT64_C(255))))) : UINT64_C(0))) | ((UINT64_C(8) <= v7) ? ((((uint64_t)((UINT64_C(8) * ((v7 - UINT64_C(8)) & UINT64_C(255))) & UINT64_C(255))) >= 64 ? 0 : ((uint64_t)((uint64_t)in_buf[UINT64_C(8)])) << ((uint64_t)((UINT64_C(8) * ((v7 - UINT64_C(8)) & UINT64_C(255))) & UINT64_C(255))))) : UINT64_C(0)));
                        uint64_t v10 = ((uint64_t)((UINT64_C(8) * ((UINT64_C(8) - v7) & UINT64_C(255))) & UINT64_C(255)));
                        o8_tag = 1;
                        o8_0 = (v6 ? efch_ashr64(((v10 >= 64 ? 0 : v9 << v10)), v10, 64) : v9);
                        o8_1 = v6;
                        o8_2 = ((v7 + UINT64_C(1)) & UINT64_C(255));
                    }
                    o5_tag = o8_tag;
                    o5_0 = o8_0;
                    o5_1 = o8_1;
                    o5_2 = o8_2;
                }
                o4_tag = o5_tag;
                o4_0 = o5_0;
                o4_1 = o5_1;
                o4_2 = o5_2;
            }
            o3_tag = o4_tag;
            o3_0 = o4_0;
            o3_1 = o4_1;
            o3_2 = o4_2;
        }
        o1_tag = o3_tag;
        o1_0 = o3_0;
        o1_1 = o3_1;
        o1_2 = o3_2;
    }
    if (o1_tag) {
        *out0 = (uint64_t)(o1_0);
        *out1 = (uint64_t)(o1_1);
        *out2 = (uint64_t)(o1_2);
    }
    return o1_tag;
}

int efch_msgpack_int_decode__lang(const uint8_t *in_buf, size_t in_buf_len, uint64_t *out0, uint64_t *out1, uint64_t *out2)
{
    int o1_tag;
    uint64_t o1_0 = 0;
    int o1_1 = 0;
    uint64_t o1_2 = 0;
    if ((((uint64_t)((uint64_t)in_buf_len)) == UINT64_C(0))) {
        o1_tag = 0;
        o1_0 = 0;
        o1_1 = 0;
        o1_2 = 0;
    } else {
        uint64_t v2 = ((uint64_t)in_buf[UINT64_C(0)]);
        int o3_tag;
        uint64_t o3_0 = 0;
        int o3_1 = 0;
        uint64_t o3_2 = 0;
        if ((v2 < UINT64_C(128))) {
            o3_tag = 1;
            o3_0 = ((uint64_t)v2);
            o3_1 = 0;
            o3_2 = UINT64_C(1);
        } else {
            int o4_tag;
            uint64_t o4_0 = 0;
            int o4_1 = 0;
            uint64_t o4_2 = 0;
            if ((v2 >= UINT64_C(224))) {
                o4_tag = 1;
                o4_0 = (UINT64_C(0xffffffffffffff00) | ((uint64_t)v2));
                o4_1 = 1;
                o4_2 = UINT64_C(1);
            } else {
                int o5_tag;
                uint64_t o5_0 = 0;
                int o5_1 = 0;
                uint64_t o5_2 = 0;
                if (((v2 < UINT64_C(204)) || (v2 > UINT64_C(211)))) {
                    o5_tag = 0;
                    o5_0 = 0;
                    o5_1 = 0;
                    o5_2 = 0;
                } else {
                    int v6 = (v2 >= UINT64_C(208));
                    uint64_t v7 = ((((v2 & UINT64_C(3)) >= 8 ? 0 : UINT64_C(1) << (v2 & UINT64_C(3)))) & UINT64_C(255));
                    int o8_tag;
                    uint64_t o8_0 = 0;
                    int o8_1 = 0;
                    uint64_t o8_2 = 0;
                    if ((((uint64_t)((uint64_t)in_buf_len)) < ((uint64_t)((v7 + UINT64_C(1)) & UINT64_C(255))))) {
                        o8_tag = 0;
                        o8_0 = 0;
                        o8_1 = 0;
                        o8_2 = 0;
                    } else {
                        uint64_t v9 = UINT64_C(0);
                        uint64_t v10 = v7;
                        int v11 = (UINT64_C(1) <= v10);
                        uint64_t t13;
                        if (v11) {
                            uint64_t v12 = ((v9 << 8) | ((uint64_t)((uint64_t)in_buf[UINT64_C(1)])));
                            t13 = v12;
                        } else {
                            t13 = v9;
                        }
                        uint64_t v14 = t13;
                        int v15 = (UINT64_C(2) <= v10);
                        uint64_t t17;
                        if (v15) {
                            uint64_t v16 = ((v14 << 8) | ((uint64_t)((uint64_t)in_buf[UINT64_C(2)])));
                            t17 = v16;
                        } else {
                            t17 = v14;
                        }
                        uint64_t v18 = t17;
                        int v19 = (UINT64_C(3) <= v10);
                        uint64_t t21;
                        if (v19) {
                            uint64_t v20 = ((v18 << 8) | ((uint64_t)((uint64_t)in_buf[UINT64_C(3)])));
                            t21 = v20;
                        } else {
                            t21 = v18;
                        }
                        uint64_t v22 = t21;
                        int v23 = (UINT64_C(4) <= v10);
                        uint64_t t25;
                        if (v23) {
                            uint64_t v24 = ((v22 << 8) | ((uint64_t)((uint64_t)in_buf[UINT64_C(4)])));
                            t25 = v24;
                        } else {
                            t25 = v22;
                        }
                        uint64_t v26 = t25;
                        int v27 = (UINT64_C(5) <= v10);
                        uint64_t t29;
                        if (v27) {
                            uint64_t v28 = ((v26 << 8) | ((uint64_t)((uint64_t)in_buf[UINT64_C(5)])));
                            t29 = v28;
                        } else {
                            t29 = v26;
                        }
                        uint64_t v30 = t29;
                        int v31 = (UINT64_C(6) <= v10);
                        uint64_t t33;
                        if (v31) {
                            uint64_t v32 = ((v30 << 8) | ((uint64_t)((uint64_t)in_buf[UINT64_C(6)])));
                            t33 = v32;
                        } else {
                            t33 = v30;
                        }
                        uint64_t v34 = t33;
                        int v35 = (UINT64_C(7) <= v10);
                        uint64_t t37;
                        if (v35) {
                            uint64_t v36 = ((v34 << 8) | ((uint64_t)((uint64_t)in_buf[UINT64_C(7)])));
                            t37 = v36;
                        } else {
                            t37 = v34;
                        }
                        uint64_t v38 = t37;
                        int v39 = (UINT64_C(8) <= v10);
                        uint64_t t41;
                        if (v39) {
                            uint64_t v40 = ((v38 << 8) | ((uint64_t)((uint64_t)in_buf[UINT64_C(8)])));
                            t41 = v40;
                        } else {
                            t41 = v38;
                        }
                        uint64_t v42 = t41;
                        int v43 = (v6 && (((uint64_t)in_buf[UINT64_C(1)]) >= UINT64_C(128)));
                        uint64_t t45;
                        if (v43) {
                            uint64_t v44 = (v42 | ((((uint64_t)((UINT64_C(8) * v7) & UINT64_C(255))) >= 64 ? 0 : UINT64_C(0xffffffffffffffff) << ((uint64_t)((UINT64_C(8) * v7) & UINT64_C(255))))));
                            t45 = v44;
                        } else {
                            t45 = v42;
                        }
                        uint64_t v46 = t45;
                        o8_tag = 1;
                        o8_0 = v46;
                        o8_1 = v6;
                        o8_2 = ((v7 + UINT64_C(1)) & UINT64_C(255));
                    }
                    o5_tag = o8_tag;
                    o5_0 = o8_0;
                    o5_1 = o8_1;
                    o5_2 = o8_2;
                }
                o4_tag = o5_tag;
                o4_0 = o5_0;
                o4_1 = o5_1;
                o4_2 = o5_2;
            }
            o3_tag = o4_tag;
            o3_0 = o4_0;
            o3_1 = o4_1;
            o3_2 = o4_2;
        }
        o1_tag = o3_tag;
        o1_0 = o3_0;
        o1_1 = o3_1;
        o1_2 = o3_2;
    }
    if (o1_tag) {
        *out0 = (uint64_t)(o1_0);
        *out1 = (uint64_t)(o1_1);
        *out2 = (uint64_t)(o1_2);
    }
    return o1_tag;
}
