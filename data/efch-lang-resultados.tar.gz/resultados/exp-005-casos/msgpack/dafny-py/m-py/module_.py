import sys
from typing import Callable, Any, TypeVar, NamedTuple
from math import floor
from itertools import count

import module_ as module_
import _dafny as _dafny
import System_ as System_

# Module: module_

class default__:
    def  __init__(self):
        pass

    @staticmethod
    def BE(s):
        if (len(s)) == (0):
            return 0
        elif True:
            return ((default__.BE(_dafny.SeqWithoutIsStrInference((s)[:(len(s)) - (1):]))) * (256)) + ((s)[(len(s)) - (1)])

    @staticmethod
    def Len(tag):
        if (_dafny.euclidian_modulus(tag, 4)) == (0):
            return 1
        elif (_dafny.euclidian_modulus(tag, 4)) == (1):
            return 2
        elif (_dafny.euclidian_modulus(tag, 4)) == (2):
            return 4
        elif True:
            return 8

    @staticmethod
    def Range(k):
        if (k) == (1):
            return 256
        elif (k) == (2):
            return 65536
        elif (k) == (4):
            return 4294967296
        elif True:
            return 18446744073709551616

    @staticmethod
    def Spec(buf):
        if (len(buf)) == (0):
            return Option_None()
        elif True:
            d_0_b0_ = (buf)[0]
            if (d_0_b0_) < (128):
                return Option_Some((d_0_b0_, False, 1))
            elif (d_0_b0_) >= (224):
                return Option_Some((((d_0_b0_) + (18446744073709551616)) - (256), True, 1))
            elif ((d_0_b0_) < (204)) or ((d_0_b0_) > (211)):
                return Option_None()
            elif True:
                d_1_sg_ = (d_0_b0_) >= (208)
                d_2_k_ = default__.Len(d_0_b0_)
                if (len(buf)) < ((d_2_k_) + (1)):
                    return Option_None()
                elif True:
                    d_3_u_ = default__.BE(_dafny.SeqWithoutIsStrInference((buf)[1:(d_2_k_) + (1):]))
                    d_4_v_ = (((d_3_u_) + (18446744073709551616)) - (default__.Range(d_2_k_)) if (d_1_sg_) and ((d_3_u_) >= (_dafny.euclidian_division(default__.Range(d_2_k_), 2))) else d_3_u_)
                    return Option_Some((d_4_v_, d_1_sg_, (d_2_k_) + (1)))

    @staticmethod
    def Decode(buf):
        r: Option = Option.default()()
        if (len(buf)) == (0):
            r = Option_None()
            return r
        d_0_tag_: int
        d_0_tag_ = (buf)[0]
        if (d_0_tag_) < (128):
            r = Option_Some((d_0_tag_, False, 1))
            return r
        if (d_0_tag_) >= (224):
            r = Option_Some((((d_0_tag_) + (18446744073709551616)) - (256), True, 1))
            return r
        if ((d_0_tag_) < (204)) or ((d_0_tag_) > (211)):
            r = Option_None()
            return r
        d_1_signed_: bool
        d_1_signed_ = (d_0_tag_) >= (208)
        d_2_k_: int
        d_2_k_ = default__.Len(d_0_tag_)
        if (len(buf)) < ((d_2_k_) + (1)):
            r = Option_None()
            return r
        d_3_u_: int
        d_3_u_ = 0
        d_4_i_: int
        d_4_i_ = 1
        while (d_4_i_) <= (d_2_k_):
            d_3_u_ = ((d_3_u_) * (256)) + ((buf)[d_4_i_])
            d_4_i_ = (d_4_i_) + (1)
        if (d_1_signed_) and ((d_3_u_) >= (_dafny.euclidian_division(default__.Range(d_2_k_), 2))):
            d_3_u_ = ((d_3_u_) + (18446744073709551616)) - (default__.Range(d_2_k_))
        r = Option_Some((d_3_u_, d_1_signed_, (d_2_k_) + (1)))
        return r
        return r


class u8:
    def  __init__(self):
        pass

    @staticmethod
    def default():
        return int(0)
    def _Is(source__):
        return True

class Option:
    @classmethod
    def default(cls, ):
        return lambda: Option_None()
    def __ne__(self, __o: object) -> bool:
        return not self.__eq__(__o)
    @property
    def is_None(self) -> bool:
        return isinstance(self, Option_None)
    @property
    def is_Some(self) -> bool:
        return isinstance(self, Option_Some)

class Option_None(Option, NamedTuple('None_', [])):
    def __dafnystr__(self) -> str:
        return f'Option.None'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, Option_None)
    def __hash__(self) -> int:
        return super().__hash__()

class Option_Some(Option, NamedTuple('Some', [('value', Any)])):
    def __dafnystr__(self) -> str:
        return f'Option.Some({_dafny.string_of(self.value)})'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, Option_Some) and self.value == __o.value
    def __hash__(self) -> int:
        return super().__hash__()

