#include <stddef.h>
#include <stdint.h>
#include <string.h>
typedef unsigned __int128 efch_u128;

/* Operaciones con signo sobre valores de w bits guardados sin signo y enmascarados. Solo usan
   aritmética sin signo: no hay comportamiento indefinido ni dependiente de la implementación. */
#define EFCH_SIGNED_OPS(T, SUF)                                                               \
static inline T efch_mask##SUF(unsigned w) { return w >= 8 * sizeof(T) ? (T)~(T)0 : (((T)1 << w) - 1); } \
static inline int efch_slt##SUF(T x, T y, unsigned w) { T s = (T)1 << (w - 1); return (x ^ s) < (y ^ s); } \
static inline T efch_sext##SUF(T x, unsigned w, unsigned n) {                                 \
    return (x & ((T)1 << (w - 1))) ? (x | (efch_mask##SUF(n) & ~efch_mask##SUF(w))) : x; }    \
static inline T efch_ashr##SUF(T x, T k, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int neg = (x >> (w - 1)) & 1;                                    \
    if (k >= w) return neg ? m : 0;                                                           \
    return (x >> k) | (neg ? (m & ~(m >> k)) : 0); }                                          \
static inline T efch_sdiv##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return nx ? 1 : m;                                                            \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, q = ax / ay;                     \
    return (nx != ny) ? ((T)-q & m) : q; }                                                    \
static inline T efch_srem##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return x;                                                                     \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, r = ax % ay;                     \
    return nx ? ((T)-r & m) : r; }
EFCH_SIGNED_OPS(uint64_t, 64)
EFCH_SIGNED_OPS(efch_u128, 128)

int efch_quic_varint_decode(const uint8_t *in_buf, size_t in_buf_len, uint64_t *out0, uint64_t *out1)
{
    int o1_tag;
    uint64_t o1_0 = 0;
    uint64_t o1_1 = 0;
    if ((((uint64_t)((uint64_t)in_buf_len)) == UINT64_C(0))) {
        o1_tag = 0;
        o1_0 = 0;
        o1_1 = 0;
    } else {
        uint64_t v2 = ((((((uint64_t)in_buf[UINT64_C(0)]) >> 6) >= 8 ? 0 : UINT64_C(1) << (((uint64_t)in_buf[UINT64_C(0)]) >> 6))) & UINT64_C(255));
        int o3_tag;
        uint64_t o3_0 = 0;
        uint64_t o3_1 = 0;
        if ((((uint64_t)((uint64_t)in_buf_len)) < ((uint64_t)v2))) {
            o3_tag = 0;
            o3_0 = 0;
            o3_1 = 0;
        } else {
            o3_tag = 1;
            o3_0 = (((((((((UINT64_C(0) < v2) ? ((((uint64_t)((UINT64_C(8) * ((((v2 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(0)) & UINT64_C(255))) & UINT64_C(255))) >= 64 ? 0 : ((uint64_t)((UINT64_C(0) == UINT64_C(0)) ? (((uint64_t)in_buf[UINT64_C(0)]) & UINT64_C(63)) : ((uint64_t)in_buf[UINT64_C(0)]))) << ((uint64_t)((UINT64_C(8) * ((((v2 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(0)) & UINT64_C(255))) & UINT64_C(255))))) : UINT64_C(0)) | ((UINT64_C(1) < v2) ? ((((uint64_t)((UINT64_C(8) * ((((v2 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(1)) & UINT64_C(255))) & UINT64_C(255))) >= 64 ? 0 : ((uint64_t)((UINT64_C(1) == UINT64_C(0)) ? (((uint64_t)in_buf[UINT64_C(0)]) & UINT64_C(63)) : ((uint64_t)in_buf[UINT64_C(1)]))) << ((uint64_t)((UINT64_C(8) * ((((v2 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(1)) & UINT64_C(255))) & UINT64_C(255))))) : UINT64_C(0))) | ((UINT64_C(2) < v2) ? ((((uint64_t)((UINT64_C(8) * ((((v2 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(2)) & UINT64_C(255))) & UINT64_C(255))) >= 64 ? 0 : ((uint64_t)((UINT64_C(2) == UINT64_C(0)) ? (((uint64_t)in_buf[UINT64_C(0)]) & UINT64_C(63)) : ((uint64_t)in_buf[UINT64_C(2)]))) << ((uint64_t)((UINT64_C(8) * ((((v2 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(2)) & UINT64_C(255))) & UINT64_C(255))))) : UINT64_C(0))) | ((UINT64_C(3) < v2) ? ((((uint64_t)((UINT64_C(8) * ((((v2 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(3)) & UINT64_C(255))) & UINT64_C(255))) >= 64 ? 0 : ((uint64_t)((UINT64_C(3) == UINT64_C(0)) ? (((uint64_t)in_buf[UINT64_C(0)]) & UINT64_C(63)) : ((uint64_t)in_buf[UINT64_C(3)]))) << ((uint64_t)((UINT64_C(8) * ((((v2 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(3)) & UINT64_C(255))) & UINT64_C(255))))) : UINT64_C(0))) | ((UINT64_C(4) < v2) ? ((((uint64_t)((UINT64_C(8) * ((((v2 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(4)) & UINT64_C(255))) & UINT64_C(255))) >= 64 ? 0 : ((uint64_t)((UINT64_C(4) == UINT64_C(0)) ? (((uint64_t)in_buf[UINT64_C(0)]) & UINT64_C(63)) : ((uint64_t)in_buf[UINT64_C(4)]))) << ((uint64_t)((UINT64_C(8) * ((((v2 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(4)) & UINT64_C(255))) & UINT64_C(255))))) : UINT64_C(0))) | ((UINT64_C(5) < v2) ? ((((uint64_t)((UINT64_C(8) * ((((v2 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(5)) & UINT64_C(255))) & UINT64_C(255))) >= 64 ? 0 : ((uint64_t)((UINT64_C(5) == UINT64_C(0)) ? (((uint64_t)in_buf[UINT64_C(0)]) & UINT64_C(63)) : ((uint64_t)in_buf[UINT64_C(5)]))) << ((uint64_t)((UINT64_C(8) * ((((v2 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(5)) & UINT64_C(255))) & UINT64_C(255))))) : UINT64_C(0))) | ((UINT64_C(6) < v2) ? ((((uint64_t)((UINT64_C(8) * ((((v2 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(6)) & UINT64_C(255))) & UINT64_C(255))) >= 64 ? 0 : ((uint64_t)((UINT64_C(6) == UINT64_C(0)) ? (((uint64_t)in_buf[UINT64_C(0)]) & UINT64_C(63)) : ((uint64_t)in_buf[UINT64_C(6)]))) << ((uint64_t)((UINT64_C(8) * ((((v2 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(6)) & UINT64_C(255))) & UINT64_C(255))))) : UINT64_C(0))) | ((UINT64_C(7) < v2) ? ((((uint64_t)((UINT64_C(8) * ((((v2 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(7)) & UINT64_C(255))) & UINT64_C(255))) >= 64 ? 0 : ((uint64_t)((UINT64_C(7) == UINT64_C(0)) ? (((uint64_t)in_buf[UINT64_C(0)]) & UINT64_C(63)) : ((uint64_t)in_buf[UINT64_C(7)]))) << ((uint64_t)((UINT64_C(8) * ((((v2 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(7)) & UINT64_C(255))) & UINT64_C(255))))) : UINT64_C(0)));
            o3_1 = v2;
        }
        o1_tag = o3_tag;
        o1_0 = o3_0;
        o1_1 = o3_1;
    }
    if (o1_tag) {
        *out0 = (uint64_t)(o1_0);
        *out1 = (uint64_t)(o1_1);
    }
    return o1_tag;
}

int efch_quic_varint_decode__lang(const uint8_t *in_buf, size_t in_buf_len, uint64_t *out0, uint64_t *out1)
{
    int o1_tag;
    uint64_t o1_0 = 0;
    uint64_t o1_1 = 0;
    if ((((uint64_t)((uint64_t)in_buf_len)) == UINT64_C(0))) {
        o1_tag = 0;
        o1_0 = 0;
        o1_1 = 0;
    } else {
        uint64_t v2 = ((((((uint64_t)in_buf[UINT64_C(0)]) >> 6) >= 8 ? 0 : UINT64_C(1) << (((uint64_t)in_buf[UINT64_C(0)]) >> 6))) & UINT64_C(255));
        int o3_tag;
        uint64_t o3_0 = 0;
        uint64_t o3_1 = 0;
        if ((((uint64_t)((uint64_t)in_buf_len)) < ((uint64_t)v2))) {
            o3_tag = 0;
            o3_0 = 0;
            o3_1 = 0;
        } else {
            uint64_t v4 = ((uint64_t)(((uint64_t)in_buf[UINT64_C(0)]) & UINT64_C(63)));
            uint64_t v5 = v2;
            int v6 = (UINT64_C(1) < v5);
            uint64_t t8;
            if (v6) {
                uint64_t v7 = ((v4 << 8) | ((uint64_t)((uint64_t)in_buf[UINT64_C(1)])));
                t8 = v7;
            } else {
                t8 = v4;
            }
            uint64_t v9 = t8;
            int v10 = (UINT64_C(2) < v5);
            uint64_t t12;
            if (v10) {
                uint64_t v11 = ((v9 << 8) | ((uint64_t)((uint64_t)in_buf[UINT64_C(2)])));
                t12 = v11;
            } else {
                t12 = v9;
            }
            uint64_t v13 = t12;
            int v14 = (UINT64_C(3) < v5);
            uint64_t t16;
            if (v14) {
                uint64_t v15 = ((v13 << 8) | ((uint64_t)((uint64_t)in_buf[UINT64_C(3)])));
                t16 = v15;
            } else {
                t16 = v13;
            }
            uint64_t v17 = t16;
            int v18 = (UINT64_C(4) < v5);
            uint64_t t20;
            if (v18) {
                uint64_t v19 = ((v17 << 8) | ((uint64_t)((uint64_t)in_buf[UINT64_C(4)])));
                t20 = v19;
            } else {
                t20 = v17;
            }
            uint64_t v21 = t20;
            int v22 = (UINT64_C(5) < v5);
            uint64_t t24;
            if (v22) {
                uint64_t v23 = ((v21 << 8) | ((uint64_t)((uint64_t)in_buf[UINT64_C(5)])));
                t24 = v23;
            } else {
                t24 = v21;
            }
            uint64_t v25 = t24;
            int v26 = (UINT64_C(6) < v5);
            uint64_t t28;
            if (v26) {
                uint64_t v27 = ((v25 << 8) | ((uint64_t)((uint64_t)in_buf[UINT64_C(6)])));
                t28 = v27;
            } else {
                t28 = v25;
            }
            uint64_t v29 = t28;
            int v30 = (UINT64_C(7) < v5);
            uint64_t t32;
            if (v30) {
                uint64_t v31 = ((v29 << 8) | ((uint64_t)((uint64_t)in_buf[UINT64_C(7)])));
                t32 = v31;
            } else {
                t32 = v29;
            }
            uint64_t v33 = t32;
            o3_tag = 1;
            o3_0 = v33;
            o3_1 = v2;
        }
        o1_tag = o3_tag;
        o1_0 = o3_0;
        o1_1 = o3_1;
    }
    if (o1_tag) {
        *out0 = (uint64_t)(o1_0);
        *out1 = (uint64_t)(o1_1);
    }
    return o1_tag;
}
