import sys
from typing import Callable, Any, TypeVar, NamedTuple
from math import floor
from itertools import count

import module_ as module_
import _dafny as _dafny
import System_ as System_

# Module: module_

class default__:
    def  __init__(self):
        pass

    @staticmethod
    def BE(s):
        if (len(s)) == (0):
            return 0
        elif True:
            return ((default__.BE(_dafny.SeqWithoutIsStrInference((s)[:(len(s)) - (1):]))) * (256)) + ((s)[(len(s)) - (1)])

    @staticmethod
    def Spec(buf):
        if (len(buf)) == (0):
            return Option_None()
        elif True:
            d_0_n_ = (1 if ((buf)[0]) < (64) else (2 if ((buf)[0]) < (128) else (4 if ((buf)[0]) < (192) else 8)))
            if (len(buf)) < (d_0_n_):
                return Option_None()
            elif True:
                return Option_Some((default__.BE((_dafny.SeqWithoutIsStrInference([_dafny.euclidian_modulus((buf)[0], 64)])) + (_dafny.SeqWithoutIsStrInference((buf)[1:d_0_n_:]))), d_0_n_))

    @staticmethod
    def Decode(buf):
        r: Option = Option.default()()
        if (len(buf)) == (0):
            r = Option_None()
            return r
        d_0_n_: int
        if ((buf)[0]) < (64):
            d_0_n_ = 1
        elif ((buf)[0]) < (128):
            d_0_n_ = 2
        elif ((buf)[0]) < (192):
            d_0_n_ = 4
        elif True:
            d_0_n_ = 8
        if (len(buf)) < (d_0_n_):
            r = Option_None()
            return r
        d_1_v_: int
        d_1_v_ = _dafny.euclidian_modulus((buf)[0], 64)
        d_2_i_: int
        d_2_i_ = 1
        while (d_2_i_) < (d_0_n_):
            d_1_v_ = ((d_1_v_) * (256)) + ((buf)[d_2_i_])
            d_2_i_ = (d_2_i_) + (1)
        r = Option_Some((d_1_v_, d_0_n_))
        return r
        return r


class u8:
    def  __init__(self):
        pass

    @staticmethod
    def default():
        return int(0)
    def _Is(source__):
        return True

class Option:
    @classmethod
    def default(cls, ):
        return lambda: Option_None()
    def __ne__(self, __o: object) -> bool:
        return not self.__eq__(__o)
    @property
    def is_None(self) -> bool:
        return isinstance(self, Option_None)
    @property
    def is_Some(self) -> bool:
        return isinstance(self, Option_Some)

class Option_None(Option, NamedTuple('None_', [])):
    def __dafnystr__(self) -> str:
        return f'Option.None'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, Option_None)
    def __hash__(self) -> int:
        return super().__hash__()

class Option_Some(Option, NamedTuple('Some', [('value', Any)])):
    def __dafnystr__(self) -> str:
        return f'Option.Some({_dafny.string_of(self.value)})'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, Option_Some) and self.value == __o.value
    def __hash__(self) -> int:
        return super().__hash__()

