# EXP-005: EFCH Lang frente a Rust + Kani, Dafny, C y Go

Fecha: 2026-10-21T05:58:07Z. Intel Core Processor (Haswell, no TSX); gcc gcc (Ubuntu 15.2.0-16ubuntu1) 15.2.0 `-O3 -march=native`; rustc 1.93.1 (01f6ddf75 2026-02-11) (built from a source tarball); go version go1.26.8 linux/amd64; Dafny 4.11.0+fcb2042d6d043a2634f0854338c08feeaaaf4ae2; Kani Kani Rust Verifier 0.68.0 (standalone).

## Verificación (segundos de reloj, con arranque de cada herramienta)

| Función | EFCH | Kani | Dafny (anotaciones) |
|---|---|---|---|
| quic | probado (Z3) 0.31 | probado 4.48 | probado 2.33 (3) |
| hpack | probado (Z3) 0.4 | probado 8.11 | probado 2.53 (7) |
| cbor | probado (Z3) 0.31 | probado 5.77 | probado 2.17 (3) |
| utf8 | probado (Z3) 0.3 | probado 4.21 | probado 2.82 (5) |
| base64 | probado (Z3) 0.38 | probado 3.67 | probado 2.36 (0) |
| ipv4 | probado (Z3) 7.4 | probado 58.22 | probado 2.85 (3) |
| compactsize | probado (Z3) 0.36 | probado 3.7 | probado 2.72 (3) |
| msgpack | probado (Z3) 0.4 | probado 4.51 | probado 2.56 (3) |

## Esfuerzo (líneas escritas a mano para obtener la garantía; C y Go no la tienen)

| Función | EFCH (espec. + programa) | Rust + Kani | Dafny | C | Go |
|---|---|---|---|---|---|
| quic | 25 (15 + 10) | 43 | 29 | 12 | 15 |
| hpack | 33 (18 + 15) | 54 | 53 | 19 | 22 |
| cbor | 34 (20 + 14) | 50 | 38 | 18 | 22 |
| utf8 | 47 (30 + 17) | 82 | 46 | 31 | 34 |
| base64 | 56 (27 + 29) | 77 | 40 | 36 | 43 |
| ipv4 | 34 (18 + 16) | 56 | 36 | 18 | 20 |
| compactsize | 31 (17 + 14) | 62 | 38 | 22 | 26 |
| msgpack | 40 (22 + 18) | 64 | 49 | 21 | 29 |

## Rendimiento (ns/op, media de las medianas por semilla)

| Función | EFCH Lang | C a mano | Rust | Go | C de la especificación |
|---|---|---|---|---|---|
| quic | 12.934 | 13.953 | 14.154 | 16.286 | 13.591 |
| hpack | 7.028 | 8.085 | 10.298 | 8.271 | 6.619 |
| cbor | 9.112 | 8.955 | 8.769 | 10.568 | 9.062 |
| utf8 | 11.7 | 12.894 | 11.242 | 13.238 | 11.845 |
| base64 | 11.194 | 10.826 | 9.909 | 16.343 | 19.216 |
| ipv4 | 7.87 | 11.721 | 9.947 | 8.695 | 7.225 |
| compactsize | 2.9 | 3.325 | 3.728 | 6.33 | 2.525 |
| msgpack | 10.917 | 9.592 | 12.291 | 12.491 | 10.72 |

## Corrección experimental (fallos en vectores / pruebas diferenciales)

| Función | EFCH | C | Rust | Dafny | Go |
|---|---|---|---|---|---|
| quic | 0 / 0 de 5033 | 0 / 0 de 5033 | 0 / 0 de 5033 | 0 / 0 de 5033 | 0 / 0 de 5033 |
| hpack | 0 / 0 de 5025 | 0 / 0 de 5025 | 0 / 0 de 5025 | 0 / 0 de 5025 | 0 / 0 de 5025 |
| cbor | 0 / 0 de 5037 | 0 / 0 de 5037 | 0 / 0 de 5037 | 0 / 0 de 5037 | 0 / 0 de 5037 |
| utf8 | 0 / 0 de 5017 | 0 / 0 de 5017 | 0 / 0 de 5017 | 0 / 0 de 5017 | 0 / 0 de 5017 |
| base64 | 0 / 0 de 5017 | 0 / 0 de 5017 | 0 / 0 de 5017 | 0 / 0 de 5017 | 0 / 0 de 5017 |
| ipv4 | 0 / 0 de 5241 | 0 / 0 de 5241 | 0 / 0 de 5241 | 0 / 0 de 5241 | 0 / 0 de 5241 |
| compactsize | 0 / 0 de 5037 | 0 / 0 de 5037 | 0 / 0 de 5037 | 0 / 0 de 5037 | 0 / 0 de 5037 |
| msgpack | 0 / 0 de 5037 | 0 / 0 de 5037 | 0 / 0 de 5037 | 0 / 0 de 5037 | 0 / 0 de 5037 |

## Criterios registrados

```json
{
  "V1": {
    "valor": "8/8",
    "cumple": true
  },
  "V2": {
    "valor": "8/8",
    "cumple": true
  },
  "V3": {
    "media_geometrica": 0.92,
    "maximo": 1.138,
    "por_funcion": {
      "quic": 0.927,
      "hpack": 0.869,
      "cbor": 1.018,
      "utf8": 0.907,
      "base64": 1.034,
      "ipv4": 0.671,
      "compactsize": 0.872,
      "msgpack": 1.138
    },
    "cumple": true
  },
  "V4": {
    "rust_kani": {
      "a_esfuerzo_relativo": 0.61,
      "a": true,
      "b_solo_efch": [],
      "b": false,
      "c_mas_rapido_x2": [
        "quic",
        "hpack",
        "cbor",
        "utf8",
        "base64",
        "ipv4",
        "compactsize",
        "msgpack"
      ],
      "c": true,
      "cumple": true
    },
    "dafny": {
      "a_esfuerzo_relativo": 0.9,
      "a": false,
      "b_solo_efch": [],
      "b": false,
      "c_mas_rapido_x2": [
        "quic",
        "hpack",
        "cbor",
        "utf8",
        "base64",
        "compactsize",
        "msgpack"
      ],
      "c": true,
      "cumple": true
    },
    "cumple": true
  },
  "decision": "viable"
}
```
