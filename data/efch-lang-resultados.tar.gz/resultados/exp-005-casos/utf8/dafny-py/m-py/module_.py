import sys
from typing import Callable, Any, TypeVar, NamedTuple
from math import floor
from itertools import count

import module_ as module_
import _dafny as _dafny
import System_ as System_

# Module: module_

class default__:
    def  __init__(self):
        pass

    @staticmethod
    def Cont(acc, s):
        if (len(s)) == (0):
            return acc
        elif True:
            return ((default__.Cont(acc, _dafny.SeqWithoutIsStrInference((s)[:(len(s)) - (1):]))) * (64)) + (_dafny.euclidian_modulus((s)[(len(s)) - (1)], 64))

    @staticmethod
    def Spec(buf):
        def lambda0_(exists_var_0_):
            d_2_j_: int = exists_var_0_
            return (((1) <= (d_2_j_)) and ((d_2_j_) < (d_1_n_))) and ((_dafny.euclidian_division((buf)[d_2_j_], 64)) != (2))

        if (len(buf)) == (0):
            return Option_None()
        elif True:
            d_0_b0_ = (buf)[0]
            d_1_n_ = (1 if (d_0_b0_) < (128) else (0 if (d_0_b0_) < (192) else (2 if (d_0_b0_) < (224) else (3 if (d_0_b0_) < (240) else (4 if (d_0_b0_) < (248) else 0)))))
            if (((d_1_n_) == (0)) or ((len(buf)) < (d_1_n_))) or (_dafny.quantifier(_dafny.IntegerRange(1, d_1_n_), False, lambda0_)):
                return Option_None()
            elif True:
                d_3_lead_ = (d_0_b0_ if (d_1_n_) == (1) else (_dafny.euclidian_modulus(d_0_b0_, 32) if (d_1_n_) == (2) else (_dafny.euclidian_modulus(d_0_b0_, 16) if (d_1_n_) == (3) else _dafny.euclidian_modulus(d_0_b0_, 8))))
                d_4_cp_ = default__.Cont(d_3_lead_, _dafny.SeqWithoutIsStrInference((buf)[1:d_1_n_:]))
                d_5_min_ = (0 if (d_1_n_) == (1) else (128 if (d_1_n_) == (2) else (2048 if (d_1_n_) == (3) else 65536)))
                if (((d_4_cp_) < (d_5_min_)) or (((55296) <= (d_4_cp_)) and ((d_4_cp_) <= (57343)))) or ((d_4_cp_) > (1114111)):
                    return Option_None()
                elif True:
                    return Option_Some((d_4_cp_, d_1_n_))

    @staticmethod
    def Decode(buf):
        r: Option = Option.default()()
        if (len(buf)) == (0):
            r = Option_None()
            return r
        d_0_b0_: int
        d_0_b0_ = (buf)[0]
        d_1_n_: int = int(0)
        d_2_min_: int = int(0)
        d_3_cp_: int = int(0)
        if (d_0_b0_) < (128):
            r = Option_Some((d_0_b0_, 1))
            return r
        elif (d_0_b0_) < (192):
            r = Option_None()
            return r
        elif (d_0_b0_) < (224):
            rhs0_ = 2
            rhs1_ = 128
            rhs2_ = _dafny.euclidian_modulus(d_0_b0_, 32)
            d_1_n_ = rhs0_
            d_2_min_ = rhs1_
            d_3_cp_ = rhs2_
        elif (d_0_b0_) < (240):
            rhs3_ = 3
            rhs4_ = 2048
            rhs5_ = _dafny.euclidian_modulus(d_0_b0_, 16)
            d_1_n_ = rhs3_
            d_2_min_ = rhs4_
            d_3_cp_ = rhs5_
        elif (d_0_b0_) < (248):
            rhs6_ = 4
            rhs7_ = 65536
            rhs8_ = _dafny.euclidian_modulus(d_0_b0_, 8)
            d_1_n_ = rhs6_
            d_2_min_ = rhs7_
            d_3_cp_ = rhs8_
        elif True:
            r = Option_None()
            return r
        if (len(buf)) < (d_1_n_):
            r = Option_None()
            return r
        d_4_i_: int
        d_4_i_ = 1
        while (d_4_i_) < (d_1_n_):
            if (_dafny.euclidian_division((buf)[d_4_i_], 64)) != (2):
                r = Option_None()
                return r
            d_3_cp_ = ((d_3_cp_) * (64)) + (_dafny.euclidian_modulus((buf)[d_4_i_], 64))
            d_4_i_ = (d_4_i_) + (1)
        if (((d_3_cp_) < (d_2_min_)) or (((55296) <= (d_3_cp_)) and ((d_3_cp_) <= (57343)))) or ((d_3_cp_) > (1114111)):
            r = Option_None()
            return r
        r = Option_Some((d_3_cp_, d_1_n_))
        return r
        return r


class u8:
    def  __init__(self):
        pass

    @staticmethod
    def default():
        return int(0)
    def _Is(source__):
        return True

class Option:
    @classmethod
    def default(cls, ):
        return lambda: Option_None()
    def __ne__(self, __o: object) -> bool:
        return not self.__eq__(__o)
    @property
    def is_None(self) -> bool:
        return isinstance(self, Option_None)
    @property
    def is_Some(self) -> bool:
        return isinstance(self, Option_Some)

class Option_None(Option, NamedTuple('None_', [])):
    def __dafnystr__(self) -> str:
        return f'Option.None'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, Option_None)
    def __hash__(self) -> int:
        return super().__hash__()

class Option_Some(Option, NamedTuple('Some', [('value', Any)])):
    def __dafnystr__(self) -> str:
        return f'Option.Some({_dafny.string_of(self.value)})'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, Option_Some) and self.value == __o.value
    def __hash__(self) -> int:
        return super().__hash__()

