package corpus

import (
	"bufio"
	"encoding/binary"
	"encoding/hex"
	"fmt"
	"os"
	"sort"
	"strconv"
	"strings"
	"time"
)

var fn = Utf8Decode

func Main() {
	if len(os.Args) == 4 && os.Args[1] == "bench" {
		bench(os.Args[2], os.Args[3])
		return
	}
	sc := bufio.NewScanner(os.Stdin)
	w := bufio.NewWriter(os.Stdout)
	defer w.Flush()
	for sc.Scan() {
		f := strings.Fields(sc.Text())
		n, _ := strconv.ParseUint(f[0], 10, 8)
		_ = n
		b, _ := hex.DecodeString(strings.TrimPrefix(f[1], "-"))
		o0, o1, ok := fn(b)
		if ok {
			fmt.Fprintln(w, o0, o1)
		} else {
			fmt.Fprintln(w, "null")
		}
	}
}

func bench(path, reps string) {
	data, err := os.ReadFile(path)
	if err != nil {
		panic(err)
	}
	count := int(binary.LittleEndian.Uint64(data))
	off := 8
	var ns []uint64
	if false {
		ns = make([]uint64, count)
		for i := range ns {
			ns[i] = binary.LittleEndian.Uint64(data[off:])
			off += 8
		}
	}
	lens := make([]int, count)
	for i := range lens {
		lens[i] = int(binary.LittleEndian.Uint64(data[off:]))
		off += 8
	}
	bufs := make([][]byte, count)
	for i := range bufs {
		bufs[i] = data[off+i*4 : off+i*4+lens[i]]
	}
	r, _ := strconv.Atoi(reps)
	samples := make([]float64, r)
	var sink uint64
	for k := 0; k < r; k++ {
		var acc uint64
		t0 := time.Now()
		for i := 0; i < count; i++ {
			b := bufs[i]
			n := uint64(0)
			if false {
				n = ns[i]
			}
			_ = n
			o0, _, ok := fn(b)
			if ok {
				acc += uint64(o0)
			}
		}
		samples[k] = float64(time.Since(t0).Nanoseconds()) / float64(count)
		sink += acc
	}
	sort.Float64s(samples)
	fmt.Printf("{\"mediana\": %.4f, \"min\": %.4f, \"max\": %.4f, \"sink\": %d}\n", samples[r/2], samples[0], samples[r-1], sink%2)
}
