#include <stddef.h>
#include <stdint.h>
#include <string.h>
typedef unsigned __int128 efch_u128;

/* Operaciones con signo sobre valores de w bits guardados sin signo y enmascarados. Solo usan
   aritmética sin signo: no hay comportamiento indefinido ni dependiente de la implementación. */
#define EFCH_SIGNED_OPS(T, SUF)                                                               \
static inline T efch_mask##SUF(unsigned w) { return w >= 8 * sizeof(T) ? (T)~(T)0 : (((T)1 << w) - 1); } \
static inline int efch_slt##SUF(T x, T y, unsigned w) { T s = (T)1 << (w - 1); return (x ^ s) < (y ^ s); } \
static inline T efch_sext##SUF(T x, unsigned w, unsigned n) {                                 \
    return (x & ((T)1 << (w - 1))) ? (x | (efch_mask##SUF(n) & ~efch_mask##SUF(w))) : x; }    \
static inline T efch_ashr##SUF(T x, T k, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int neg = (x >> (w - 1)) & 1;                                    \
    if (k >= w) return neg ? m : 0;                                                           \
    return (x >> k) | (neg ? (m & ~(m >> k)) : 0); }                                          \
static inline T efch_sdiv##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return nx ? 1 : m;                                                            \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, q = ax / ay;                     \
    return (nx != ny) ? ((T)-q & m) : q; }                                                    \
static inline T efch_srem##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return x;                                                                     \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, r = ax % ay;                     \
    return nx ? ((T)-r & m) : r; }
EFCH_SIGNED_OPS(uint64_t, 64)
EFCH_SIGNED_OPS(efch_u128, 128)

int efch_utf8_decode(const uint8_t *in_buf, size_t in_buf_len, uint64_t *out0, uint64_t *out1)
{
    int o1_tag;
    uint64_t o1_0 = 0;
    uint64_t o1_1 = 0;
    if ((((uint64_t)((uint64_t)in_buf_len)) == UINT64_C(0))) {
        o1_tag = 0;
        o1_0 = 0;
        o1_1 = 0;
    } else {
        uint64_t v2 = ((uint64_t)in_buf[UINT64_C(0)]);
        uint64_t v3 = ((v2 < UINT64_C(128)) ? UINT64_C(1) : ((v2 < UINT64_C(192)) ? UINT64_C(0) : ((v2 < UINT64_C(224)) ? UINT64_C(2) : ((v2 < UINT64_C(240)) ? UINT64_C(3) : ((v2 < UINT64_C(248)) ? UINT64_C(4) : UINT64_C(0))))));
        int o4_tag;
        uint64_t o4_0 = 0;
        uint64_t o4_1 = 0;
        if (((v3 == UINT64_C(0)) || (((uint64_t)((uint64_t)in_buf_len)) < ((uint64_t)v3)) || (!(((UINT64_C(1) >= v3) || ((((uint64_t)in_buf[UINT64_C(1)]) & UINT64_C(192)) == UINT64_C(128))) && ((UINT64_C(2) >= v3) || ((((uint64_t)in_buf[UINT64_C(2)]) & UINT64_C(192)) == UINT64_C(128))) && ((UINT64_C(3) >= v3) || ((((uint64_t)in_buf[UINT64_C(3)]) & UINT64_C(192)) == UINT64_C(128))))))) {
            o4_tag = 0;
            o4_0 = 0;
            o4_1 = 0;
        } else {
            uint64_t v5 = (((((UINT64_C(0) < v3) ? (((((uint64_t)((UINT64_C(6) * ((((v3 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(0)) & UINT64_C(255))) & UINT64_C(255))) >= 32 ? 0 : ((uint64_t)(((uint64_t)in_buf[UINT64_C(0)]) & ((UINT64_C(0) == UINT64_C(0)) ? ((((v3 == UINT64_C(1)) ? UINT64_C(1) : ((v3 + UINT64_C(1)) & UINT64_C(255))) >= 8 ? 0 : UINT64_C(255) >> ((v3 == UINT64_C(1)) ? UINT64_C(1) : ((v3 + UINT64_C(1)) & UINT64_C(255))))) : UINT64_C(63)))) << ((uint64_t)((UINT64_C(6) * ((((v3 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(0)) & UINT64_C(255))) & UINT64_C(255))))) & UINT64_C(0xffffffff)) : UINT64_C(0)) | ((UINT64_C(1) < v3) ? (((((uint64_t)((UINT64_C(6) * ((((v3 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(1)) & UINT64_C(255))) & UINT64_C(255))) >= 32 ? 0 : ((uint64_t)(((uint64_t)in_buf[UINT64_C(1)]) & ((UINT64_C(1) == UINT64_C(0)) ? ((((v3 == UINT64_C(1)) ? UINT64_C(1) : ((v3 + UINT64_C(1)) & UINT64_C(255))) >= 8 ? 0 : UINT64_C(255) >> ((v3 == UINT64_C(1)) ? UINT64_C(1) : ((v3 + UINT64_C(1)) & UINT64_C(255))))) : UINT64_C(63)))) << ((uint64_t)((UINT64_C(6) * ((((v3 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(1)) & UINT64_C(255))) & UINT64_C(255))))) & UINT64_C(0xffffffff)) : UINT64_C(0))) | ((UINT64_C(2) < v3) ? (((((uint64_t)((UINT64_C(6) * ((((v3 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(2)) & UINT64_C(255))) & UINT64_C(255))) >= 32 ? 0 : ((uint64_t)(((uint64_t)in_buf[UINT64_C(2)]) & ((UINT64_C(2) == UINT64_C(0)) ? ((((v3 == UINT64_C(1)) ? UINT64_C(1) : ((v3 + UINT64_C(1)) & UINT64_C(255))) >= 8 ? 0 : UINT64_C(255) >> ((v3 == UINT64_C(1)) ? UINT64_C(1) : ((v3 + UINT64_C(1)) & UINT64_C(255))))) : UINT64_C(63)))) << ((uint64_t)((UINT64_C(6) * ((((v3 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(2)) & UINT64_C(255))) & UINT64_C(255))))) & UINT64_C(0xffffffff)) : UINT64_C(0))) | ((UINT64_C(3) < v3) ? (((((uint64_t)((UINT64_C(6) * ((((v3 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(3)) & UINT64_C(255))) & UINT64_C(255))) >= 32 ? 0 : ((uint64_t)(((uint64_t)in_buf[UINT64_C(3)]) & ((UINT64_C(3) == UINT64_C(0)) ? ((((v3 == UINT64_C(1)) ? UINT64_C(1) : ((v3 + UINT64_C(1)) & UINT64_C(255))) >= 8 ? 0 : UINT64_C(255) >> ((v3 == UINT64_C(1)) ? UINT64_C(1) : ((v3 + UINT64_C(1)) & UINT64_C(255))))) : UINT64_C(63)))) << ((uint64_t)((UINT64_C(6) * ((((v3 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(3)) & UINT64_C(255))) & UINT64_C(255))))) & UINT64_C(0xffffffff)) : UINT64_C(0)));
            int o6_tag;
            uint64_t o6_0 = 0;
            uint64_t o6_1 = 0;
            if (((v5 < ((v3 == UINT64_C(1)) ? UINT64_C(0) : ((v3 == UINT64_C(2)) ? UINT64_C(128) : ((v3 == UINT64_C(3)) ? UINT64_C(0x800) : UINT64_C(0x10000))))) || ((v5 >= UINT64_C(0xd800)) && (v5 <= UINT64_C(0xdfff))) || (v5 > UINT64_C(0x10ffff)))) {
                o6_tag = 0;
                o6_0 = 0;
                o6_1 = 0;
            } else {
                o6_tag = 1;
                o6_0 = v5;
                o6_1 = v3;
            }
            o4_tag = o6_tag;
            o4_0 = o6_0;
            o4_1 = o6_1;
        }
        o1_tag = o4_tag;
        o1_0 = o4_0;
        o1_1 = o4_1;
    }
    if (o1_tag) {
        *out0 = (uint64_t)(o1_0);
        *out1 = (uint64_t)(o1_1);
    }
    return o1_tag;
}

int efch_utf8_decode__lang(const uint8_t *in_buf, size_t in_buf_len, uint64_t *out0, uint64_t *out1)
{
    int o1_tag;
    uint64_t o1_0 = 0;
    uint64_t o1_1 = 0;
    if ((((uint64_t)((uint64_t)in_buf_len)) == UINT64_C(0))) {
        o1_tag = 0;
        o1_0 = 0;
        o1_1 = 0;
    } else {
        uint64_t v2 = ((uint64_t)in_buf[UINT64_C(0)]);
        int o3_tag;
        uint64_t o3_0 = 0;
        uint64_t o3_1 = 0;
        if ((v2 < UINT64_C(128))) {
            o3_tag = 1;
            o3_0 = ((uint64_t)v2);
            o3_1 = UINT64_C(1);
        } else {
            int o4_tag;
            uint64_t o4_0 = 0;
            uint64_t o4_1 = 0;
            if (((v2 < UINT64_C(192)) || (v2 >= UINT64_C(248)))) {
                o4_tag = 0;
                o4_0 = 0;
                o4_1 = 0;
            } else {
                uint64_t v5 = ((v2 < UINT64_C(224)) ? UINT64_C(2) : ((v2 < UINT64_C(240)) ? UINT64_C(3) : UINT64_C(4)));
                int o6_tag;
                uint64_t o6_0 = 0;
                uint64_t o6_1 = 0;
                if ((((uint64_t)((uint64_t)in_buf_len)) < ((uint64_t)v5))) {
                    o6_tag = 0;
                    o6_0 = 0;
                    o6_1 = 0;
                } else {
                    uint64_t v7 = (((uint64_t)v2) & ((((uint64_t)v5) >= 32 ? 0 : UINT64_C(127) >> ((uint64_t)v5))));
                    uint64_t v8 = v5;
                    int o9_tag;
                    uint64_t o9_0 = 0;
                    uint64_t o9_1 = 0;
                    if ((UINT64_C(1) < v8)) {
                        uint64_t v10 = ((uint64_t)in_buf[UINT64_C(1)]);
                        int o11_tag;
                        uint64_t o11_0 = 0;
                        uint64_t o11_1 = 0;
                        if (((v10 & UINT64_C(192)) != UINT64_C(128))) {
                            o11_tag = 0;
                            o11_0 = 0;
                            o11_1 = 0;
                        } else {
                            uint64_t v12 = (((v7 << 6) & UINT64_C(0xffffffff)) | ((uint64_t)(v10 & UINT64_C(63))));
                            int o13_tag;
                            uint64_t o13_0 = 0;
                            uint64_t o13_1 = 0;
                            if ((UINT64_C(2) < v8)) {
                                uint64_t v14 = ((uint64_t)in_buf[UINT64_C(2)]);
                                int o15_tag;
                                uint64_t o15_0 = 0;
                                uint64_t o15_1 = 0;
                                if (((v14 & UINT64_C(192)) != UINT64_C(128))) {
                                    o15_tag = 0;
                                    o15_0 = 0;
                                    o15_1 = 0;
                                } else {
                                    uint64_t v16 = (((v12 << 6) & UINT64_C(0xffffffff)) | ((uint64_t)(v14 & UINT64_C(63))));
                                    int o17_tag;
                                    uint64_t o17_0 = 0;
                                    uint64_t o17_1 = 0;
                                    if ((UINT64_C(3) < v8)) {
                                        uint64_t v18 = ((uint64_t)in_buf[UINT64_C(3)]);
                                        int o19_tag;
                                        uint64_t o19_0 = 0;
                                        uint64_t o19_1 = 0;
                                        if (((v18 & UINT64_C(192)) != UINT64_C(128))) {
                                            o19_tag = 0;
                                            o19_0 = 0;
                                            o19_1 = 0;
                                        } else {
                                            uint64_t v20 = (((v16 << 6) & UINT64_C(0xffffffff)) | ((uint64_t)(v18 & UINT64_C(63))));
                                            uint64_t v21 = ((v5 == UINT64_C(2)) ? UINT64_C(128) : ((v5 == UINT64_C(3)) ? UINT64_C(0x800) : UINT64_C(0x10000)));
                                            int o22_tag;
                                            uint64_t o22_0 = 0;
                                            uint64_t o22_1 = 0;
                                            if ((((v20 < v21) || ((v20 >= UINT64_C(0xd800)) && (v20 <= UINT64_C(0xdfff)))) || (v20 > UINT64_C(0x10ffff)))) {
                                                o22_tag = 0;
                                                o22_0 = 0;
                                                o22_1 = 0;
                                            } else {
                                                o22_tag = 1;
                                                o22_0 = v20;
                                                o22_1 = v5;
                                            }
                                            o19_tag = o22_tag;
                                            o19_0 = o22_0;
                                            o19_1 = o22_1;
                                        }
                                        o17_tag = o19_tag;
                                        o17_0 = o19_0;
                                        o17_1 = o19_1;
                                    } else {
                                        uint64_t v23 = ((v5 == UINT64_C(2)) ? UINT64_C(128) : ((v5 == UINT64_C(3)) ? UINT64_C(0x800) : UINT64_C(0x10000)));
                                        int o24_tag;
                                        uint64_t o24_0 = 0;
                                        uint64_t o24_1 = 0;
                                        if ((((v16 < v23) || ((v16 >= UINT64_C(0xd800)) && (v16 <= UINT64_C(0xdfff)))) || (v16 > UINT64_C(0x10ffff)))) {
                                            o24_tag = 0;
                                            o24_0 = 0;
                                            o24_1 = 0;
                                        } else {
                                            o24_tag = 1;
                                            o24_0 = v16;
                                            o24_1 = v5;
                                        }
                                        o17_tag = o24_tag;
                                        o17_0 = o24_0;
                                        o17_1 = o24_1;
                                    }
                                    o15_tag = o17_tag;
                                    o15_0 = o17_0;
                                    o15_1 = o17_1;
                                }
                                o13_tag = o15_tag;
                                o13_0 = o15_0;
                                o13_1 = o15_1;
                            } else {
                                uint64_t v25 = ((v5 == UINT64_C(2)) ? UINT64_C(128) : ((v5 == UINT64_C(3)) ? UINT64_C(0x800) : UINT64_C(0x10000)));
                                int o26_tag;
                                uint64_t o26_0 = 0;
                                uint64_t o26_1 = 0;
                                if ((((v12 < v25) || ((v12 >= UINT64_C(0xd800)) && (v12 <= UINT64_C(0xdfff)))) || (v12 > UINT64_C(0x10ffff)))) {
                                    o26_tag = 0;
                                    o26_0 = 0;
                                    o26_1 = 0;
                                } else {
                                    o26_tag = 1;
                                    o26_0 = v12;
                                    o26_1 = v5;
                                }
                                o13_tag = o26_tag;
                                o13_0 = o26_0;
                                o13_1 = o26_1;
                            }
                            o11_tag = o13_tag;
                            o11_0 = o13_0;
                            o11_1 = o13_1;
                        }
                        o9_tag = o11_tag;
                        o9_0 = o11_0;
                        o9_1 = o11_1;
                    } else {
                        uint64_t v27 = ((v5 == UINT64_C(2)) ? UINT64_C(128) : ((v5 == UINT64_C(3)) ? UINT64_C(0x800) : UINT64_C(0x10000)));
                        int o28_tag;
                        uint64_t o28_0 = 0;
                        uint64_t o28_1 = 0;
                        if ((((v7 < v27) || ((v7 >= UINT64_C(0xd800)) && (v7 <= UINT64_C(0xdfff)))) || (v7 > UINT64_C(0x10ffff)))) {
                            o28_tag = 0;
                            o28_0 = 0;
                            o28_1 = 0;
                        } else {
                            o28_tag = 1;
                            o28_0 = v7;
                            o28_1 = v5;
                        }
                        o9_tag = o28_tag;
                        o9_0 = o28_0;
                        o9_1 = o28_1;
                    }
                    o6_tag = o9_tag;
                    o6_0 = o9_0;
                    o6_1 = o9_1;
                }
                o4_tag = o6_tag;
                o4_0 = o6_0;
                o4_1 = o6_1;
            }
            o3_tag = o4_tag;
            o3_0 = o4_0;
            o3_1 = o4_1;
        }
        o1_tag = o3_tag;
        o1_0 = o3_0;
        o1_1 = o3_1;
    }
    if (o1_tag) {
        *out0 = (uint64_t)(o1_0);
        *out1 = (uint64_t)(o1_1);
    }
    return o1_tag;
}
