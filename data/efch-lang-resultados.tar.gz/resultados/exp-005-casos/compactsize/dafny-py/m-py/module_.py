import sys
from typing import Callable, Any, TypeVar, NamedTuple
from math import floor
from itertools import count

import module_ as module_
import _dafny as _dafny
import System_ as System_

# Module: module_

class default__:
    def  __init__(self):
        pass

    @staticmethod
    def LE(s):
        if (len(s)) == (0):
            return 0
        elif True:
            return ((s)[0]) + ((256) * (default__.LE(_dafny.SeqWithoutIsStrInference((s)[1::]))))

    @staticmethod
    def Spec(buf):
        if (len(buf)) == (0):
            return Option_None()
        elif ((buf)[0]) < (253):
            return Option_Some(((buf)[0], 1))
        elif True:
            d_0_k_ = (2 if ((buf)[0]) == (253) else (4 if ((buf)[0]) == (254) else 8))
            d_1_min_ = (253 if (d_0_k_) == (2) else (65536 if (d_0_k_) == (4) else 4294967296))
            if (len(buf)) < ((d_0_k_) + (1)):
                return Option_None()
            elif True:
                d_2_v_ = default__.LE(_dafny.SeqWithoutIsStrInference((buf)[1:(d_0_k_) + (1):]))
                if (d_2_v_) < (d_1_min_):
                    return Option_None()
                elif True:
                    return Option_Some((d_2_v_, (d_0_k_) + (1)))

    @staticmethod
    def Decode(buf):
        r: Option = Option.default()()
        if (len(buf)) == (0):
            r = Option_None()
            return r
        if ((buf)[0]) < (253):
            r = Option_Some(((buf)[0], 1))
            return r
        d_0_k_: int = int(0)
        d_1_min_: int = int(0)
        if ((buf)[0]) == (253):
            rhs0_ = 2
            rhs1_ = 253
            d_0_k_ = rhs0_
            d_1_min_ = rhs1_
        elif ((buf)[0]) == (254):
            rhs2_ = 4
            rhs3_ = 65536
            d_0_k_ = rhs2_
            d_1_min_ = rhs3_
        elif True:
            rhs4_ = 8
            rhs5_ = 4294967296
            d_0_k_ = rhs4_
            d_1_min_ = rhs5_
        if (len(buf)) < ((d_0_k_) + (1)):
            r = Option_None()
            return r
        d_2_v_: int
        d_2_v_ = 0
        d_3_i_: int
        d_3_i_ = d_0_k_
        while (d_3_i_) >= (1):
            d_2_v_ = ((buf)[d_3_i_]) + ((256) * (d_2_v_))
            d_3_i_ = (d_3_i_) - (1)
        if (d_2_v_) < (d_1_min_):
            r = Option_None()
        elif True:
            r = Option_Some((d_2_v_, (d_0_k_) + (1)))
        return r
        return r


class u8:
    def  __init__(self):
        pass

    @staticmethod
    def default():
        return int(0)
    def _Is(source__):
        return True

class Option:
    @classmethod
    def default(cls, ):
        return lambda: Option_None()
    def __ne__(self, __o: object) -> bool:
        return not self.__eq__(__o)
    @property
    def is_None(self) -> bool:
        return isinstance(self, Option_None)
    @property
    def is_Some(self) -> bool:
        return isinstance(self, Option_Some)

class Option_None(Option, NamedTuple('None_', [])):
    def __dafnystr__(self) -> str:
        return f'Option.None'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, Option_None)
    def __hash__(self) -> int:
        return super().__hash__()

class Option_Some(Option, NamedTuple('Some', [('value', Any)])):
    def __dafnystr__(self) -> str:
        return f'Option.Some({_dafny.string_of(self.value)})'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, Option_Some) and self.value == __o.value
    def __hash__(self) -> int:
        return super().__hash__()

