#include <stddef.h>
#include <stdint.h>
#include <string.h>
typedef unsigned __int128 efch_u128;

/* Operaciones con signo sobre valores de w bits guardados sin signo y enmascarados. Solo usan
   aritmética sin signo: no hay comportamiento indefinido ni dependiente de la implementación. */
#define EFCH_SIGNED_OPS(T, SUF)                                                               \
static inline T efch_mask##SUF(unsigned w) { return w >= 8 * sizeof(T) ? (T)~(T)0 : (((T)1 << w) - 1); } \
static inline int efch_slt##SUF(T x, T y, unsigned w) { T s = (T)1 << (w - 1); return (x ^ s) < (y ^ s); } \
static inline T efch_sext##SUF(T x, unsigned w, unsigned n) {                                 \
    return (x & ((T)1 << (w - 1))) ? (x | (efch_mask##SUF(n) & ~efch_mask##SUF(w))) : x; }    \
static inline T efch_ashr##SUF(T x, T k, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int neg = (x >> (w - 1)) & 1;                                    \
    if (k >= w) return neg ? m : 0;                                                           \
    return (x >> k) | (neg ? (m & ~(m >> k)) : 0); }                                          \
static inline T efch_sdiv##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return nx ? 1 : m;                                                            \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, q = ax / ay;                     \
    return (nx != ny) ? ((T)-q & m) : q; }                                                    \
static inline T efch_srem##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return x;                                                                     \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, r = ax % ay;                     \
    return nx ? ((T)-r & m) : r; }
EFCH_SIGNED_OPS(uint64_t, 64)
EFCH_SIGNED_OPS(efch_u128, 128)

int efch_compactsize_decode__lang(const uint8_t *in_buf, size_t in_buf_len, uint64_t *out0, uint64_t *out1)
{
    int o1_tag;
    uint64_t o1_0 = 0;
    uint64_t o1_1 = 0;
    if ((((uint64_t)((uint64_t)in_buf_len)) == UINT64_C(0))) {
        o1_tag = 0;
        o1_0 = 0;
        o1_1 = 0;
    } else {
        uint64_t v2 = ((uint64_t)in_buf[UINT64_C(0)]);
        int o3_tag;
        uint64_t o3_0 = 0;
        uint64_t o3_1 = 0;
        if ((v2 < UINT64_C(253))) {
            o3_tag = 1;
            o3_0 = ((uint64_t)v2);
            o3_1 = UINT64_C(1);
        } else {
            uint64_t v4 = ((v2 == UINT64_C(253)) ? UINT64_C(2) : ((v2 == UINT64_C(254)) ? UINT64_C(4) : UINT64_C(8)));
            int o5_tag;
            uint64_t o5_0 = 0;
            uint64_t o5_1 = 0;
            if ((((uint64_t)((uint64_t)in_buf_len)) < ((uint64_t)((v4 + UINT64_C(1)) & UINT64_C(255))))) {
                o5_tag = 0;
                o5_0 = 0;
                o5_1 = 0;
            } else {
                uint64_t v6 = UINT64_C(0);
                uint64_t v7 = v4;
                int v8 = (UINT64_C(0) < v7);
                uint64_t t10;
                if (v8) {
                    uint64_t v9 = (v6 | (((uint64_t)((uint64_t)in_buf[UINT64_C(1)])) << 0));
                    t10 = v9;
                } else {
                    t10 = v6;
                }
                uint64_t v11 = t10;
                int v12 = (UINT64_C(1) < v7);
                uint64_t t14;
                if (v12) {
                    uint64_t v13 = (v11 | (((uint64_t)((uint64_t)in_buf[UINT64_C(2)])) << 8));
                    t14 = v13;
                } else {
                    t14 = v11;
                }
                uint64_t v15 = t14;
                int v16 = (UINT64_C(2) < v7);
                uint64_t t18;
                if (v16) {
                    uint64_t v17 = (v15 | (((uint64_t)((uint64_t)in_buf[UINT64_C(3)])) << 16));
                    t18 = v17;
                } else {
                    t18 = v15;
                }
                uint64_t v19 = t18;
                int v20 = (UINT64_C(3) < v7);
                uint64_t t22;
                if (v20) {
                    uint64_t v21 = (v19 | (((uint64_t)((uint64_t)in_buf[UINT64_C(4)])) << 24));
                    t22 = v21;
                } else {
                    t22 = v19;
                }
                uint64_t v23 = t22;
                int v24 = (UINT64_C(4) < v7);
                uint64_t t26;
                if (v24) {
                    uint64_t v25 = (v23 | (((uint64_t)((uint64_t)in_buf[UINT64_C(5)])) << 32));
                    t26 = v25;
                } else {
                    t26 = v23;
                }
                uint64_t v27 = t26;
                int v28 = (UINT64_C(5) < v7);
                uint64_t t30;
                if (v28) {
                    uint64_t v29 = (v27 | (((uint64_t)((uint64_t)in_buf[UINT64_C(6)])) << 40));
                    t30 = v29;
                } else {
                    t30 = v27;
                }
                uint64_t v31 = t30;
                int v32 = (UINT64_C(6) < v7);
                uint64_t t34;
                if (v32) {
                    uint64_t v33 = (v31 | (((uint64_t)((uint64_t)in_buf[UINT64_C(7)])) << 48));
                    t34 = v33;
                } else {
                    t34 = v31;
                }
                uint64_t v35 = t34;
                int v36 = (UINT64_C(7) < v7);
                uint64_t t38;
                if (v36) {
                    uint64_t v37 = (v35 | (((uint64_t)((uint64_t)in_buf[UINT64_C(8)])) << 56));
                    t38 = v37;
                } else {
                    t38 = v35;
                }
                uint64_t v39 = t38;
                uint64_t v40 = ((v4 == UINT64_C(2)) ? UINT64_C(253) : ((v4 == UINT64_C(4)) ? UINT64_C(0x10000) : UINT64_C(0x100000000)));
                int o41_tag;
                uint64_t o41_0 = 0;
                uint64_t o41_1 = 0;
                if ((v39 < v40)) {
                    o41_tag = 0;
                    o41_0 = 0;
                    o41_1 = 0;
                } else {
                    o41_tag = 1;
                    o41_0 = v39;
                    o41_1 = ((v4 + UINT64_C(1)) & UINT64_C(255));
                }
                o5_tag = o41_tag;
                o5_0 = o41_0;
                o5_1 = o41_1;
            }
            o3_tag = o5_tag;
            o3_0 = o5_0;
            o3_1 = o5_1;
        }
        o1_tag = o3_tag;
        o1_0 = o3_0;
        o1_1 = o3_1;
    }
    if (o1_tag) {
        *out0 = (uint64_t)(o1_0);
        *out1 = (uint64_t)(o1_1);
    }
    return o1_tag;
}
