import sys
from typing import Callable, Any, TypeVar, NamedTuple
from math import floor
from itertools import count

import module_ as module_
import _dafny as _dafny
import System_ as System_

# Module: module_

class default__:
    def  __init__(self):
        pass

    @staticmethod
    def Sum(h, k):
        if (k) == (0):
            return 0
        elif True:
            return ((default__.Sum(h, (k) - (1))) + (((h)[((2) * (k)) - (2)]) * (256))) + ((h)[((2) * (k)) - (1)])

    @staticmethod
    def Fold(s):
        return (_dafny.euclidian_modulus(s, 65536)) + (_dafny.euclidian_division(s, 65536))

    @staticmethod
    def Spec(h):
        if (len(h)) < (20):
            return Option_None()
        elif True:
            d_0_ver_ = _dafny.euclidian_division((h)[0], 16)
            d_1_ihl_ = _dafny.euclidian_modulus((h)[0], 16)
            d_2_tot_ = (((h)[2]) * (256)) + ((h)[3])
            if ((((d_0_ver_) != (4)) or ((d_1_ihl_) < (5))) or ((len(h)) < ((4) * (d_1_ihl_)))) or ((d_2_tot_) < ((4) * (d_1_ihl_))):
                return Option_None()
            elif (default__.Fold(default__.Fold(default__.Sum(h, (2) * (d_1_ihl_))))) == (65535):
                return Option_Some((d_1_ihl_, d_2_tot_))
            elif True:
                return Option_None()

    @staticmethod
    def Check(h):
        r: Option = Option.default()()
        if (len(h)) < (20):
            r = Option_None()
            return r
        d_0_version_: int
        d_1_ihl_: int
        rhs0_ = _dafny.euclidian_division((h)[0], 16)
        rhs1_ = _dafny.euclidian_modulus((h)[0], 16)
        d_0_version_ = rhs0_
        d_1_ihl_ = rhs1_
        d_2_total_: int
        d_2_total_ = (((h)[2]) * (256)) + ((h)[3])
        if ((((d_0_version_) != (4)) or ((d_1_ihl_) < (5))) or ((len(h)) < ((4) * (d_1_ihl_)))) or ((d_2_total_) < ((4) * (d_1_ihl_))):
            r = Option_None()
            return r
        d_3_sum_: int
        d_3_sum_ = 0
        d_4_i_: int
        d_4_i_ = 0
        while (d_4_i_) < ((2) * (d_1_ihl_)):
            d_3_sum_ = ((d_3_sum_) + (((h)[(2) * (d_4_i_)]) * (256))) + ((h)[((2) * (d_4_i_)) + (1)])
            d_4_i_ = (d_4_i_) + (1)
        d_3_sum_ = default__.Fold(default__.Fold(d_3_sum_))
        if (d_3_sum_) == (65535):
            r = Option_Some((d_1_ihl_, d_2_total_))
        elif True:
            r = Option_None()
        return r
        return r


class u8:
    def  __init__(self):
        pass

    @staticmethod
    def default():
        return int(0)
    def _Is(source__):
        return True

class Option:
    @classmethod
    def default(cls, ):
        return lambda: Option_None()
    def __ne__(self, __o: object) -> bool:
        return not self.__eq__(__o)
    @property
    def is_None(self) -> bool:
        return isinstance(self, Option_None)
    @property
    def is_Some(self) -> bool:
        return isinstance(self, Option_Some)

class Option_None(Option, NamedTuple('None_', [])):
    def __dafnystr__(self) -> str:
        return f'Option.None'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, Option_None)
    def __hash__(self) -> int:
        return super().__hash__()

class Option_Some(Option, NamedTuple('Some', [('value', Any)])):
    def __dafnystr__(self) -> str:
        return f'Option.Some({_dafny.string_of(self.value)})'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, Option_Some) and self.value == __o.value
    def __hash__(self) -> int:
        return super().__hash__()

