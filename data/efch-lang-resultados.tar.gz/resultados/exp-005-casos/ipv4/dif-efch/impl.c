#include <stddef.h>
#include <stdint.h>
#include <string.h>
typedef unsigned __int128 efch_u128;

/* Operaciones con signo sobre valores de w bits guardados sin signo y enmascarados. Solo usan
   aritmética sin signo: no hay comportamiento indefinido ni dependiente de la implementación. */
#define EFCH_SIGNED_OPS(T, SUF)                                                               \
static inline T efch_mask##SUF(unsigned w) { return w >= 8 * sizeof(T) ? (T)~(T)0 : (((T)1 << w) - 1); } \
static inline int efch_slt##SUF(T x, T y, unsigned w) { T s = (T)1 << (w - 1); return (x ^ s) < (y ^ s); } \
static inline T efch_sext##SUF(T x, unsigned w, unsigned n) {                                 \
    return (x & ((T)1 << (w - 1))) ? (x | (efch_mask##SUF(n) & ~efch_mask##SUF(w))) : x; }    \
static inline T efch_ashr##SUF(T x, T k, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int neg = (x >> (w - 1)) & 1;                                    \
    if (k >= w) return neg ? m : 0;                                                           \
    return (x >> k) | (neg ? (m & ~(m >> k)) : 0); }                                          \
static inline T efch_sdiv##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return nx ? 1 : m;                                                            \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, q = ax / ay;                     \
    return (nx != ny) ? ((T)-q & m) : q; }                                                    \
static inline T efch_srem##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return x;                                                                     \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, r = ax % ay;                     \
    return nx ? ((T)-r & m) : r; }
EFCH_SIGNED_OPS(uint64_t, 64)
EFCH_SIGNED_OPS(efch_u128, 128)

int efch_ipv4_header_check__lang(const uint8_t *in_h, size_t in_h_len, uint64_t *out0, uint64_t *out1)
{
    int o1_tag;
    uint64_t o1_0 = 0;
    uint64_t o1_1 = 0;
    if ((((uint64_t)((uint64_t)in_h_len)) < UINT64_C(20))) {
        o1_tag = 0;
        o1_0 = 0;
        o1_1 = 0;
    } else {
        uint64_t v2 = (((uint64_t)in_h[UINT64_C(0)]) >> 4);
        uint64_t v3 = (((uint64_t)in_h[UINT64_C(0)]) & UINT64_C(15));
        uint64_t v4 = ((((uint64_t)v3) * UINT64_C(4)) & UINT64_C(0xffff));
        uint64_t v5 = (((((uint64_t)((uint64_t)in_h[UINT64_C(2)])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(3)])));
        int o6_tag;
        uint64_t o6_0 = 0;
        uint64_t o6_1 = 0;
        if (((((v2 != UINT64_C(4)) || (v3 < UINT64_C(5))) || (((uint64_t)((uint64_t)in_h_len)) < v4)) || (v5 < v4))) {
            o6_tag = 0;
            o6_0 = 0;
            o6_1 = 0;
        } else {
            uint64_t v7 = UINT64_C(0);
            uint64_t v8 = ((v3 * UINT64_C(2)) & UINT64_C(255));
            int v9 = (UINT64_C(0) < v8);
            uint64_t t11;
            if (v9) {
                uint64_t v10 = ((v7 + (((((uint64_t)((uint64_t)in_h[UINT64_C(0)])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(1)])))) & UINT64_C(0xffffffff));
                t11 = v10;
            } else {
                t11 = v7;
            }
            uint64_t v12 = t11;
            int v13 = (UINT64_C(1) < v8);
            uint64_t t15;
            if (v13) {
                uint64_t v14 = ((v12 + (((((uint64_t)((uint64_t)in_h[UINT64_C(2)])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(3)])))) & UINT64_C(0xffffffff));
                t15 = v14;
            } else {
                t15 = v12;
            }
            uint64_t v16 = t15;
            int v17 = (UINT64_C(2) < v8);
            uint64_t t19;
            if (v17) {
                uint64_t v18 = ((v16 + (((((uint64_t)((uint64_t)in_h[UINT64_C(4)])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(5)])))) & UINT64_C(0xffffffff));
                t19 = v18;
            } else {
                t19 = v16;
            }
            uint64_t v20 = t19;
            int v21 = (UINT64_C(3) < v8);
            uint64_t t23;
            if (v21) {
                uint64_t v22 = ((v20 + (((((uint64_t)((uint64_t)in_h[UINT64_C(6)])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(7)])))) & UINT64_C(0xffffffff));
                t23 = v22;
            } else {
                t23 = v20;
            }
            uint64_t v24 = t23;
            int v25 = (UINT64_C(4) < v8);
            uint64_t t27;
            if (v25) {
                uint64_t v26 = ((v24 + (((((uint64_t)((uint64_t)in_h[UINT64_C(8)])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(9)])))) & UINT64_C(0xffffffff));
                t27 = v26;
            } else {
                t27 = v24;
            }
            uint64_t v28 = t27;
            int v29 = (UINT64_C(5) < v8);
            uint64_t t31;
            if (v29) {
                uint64_t v30 = ((v28 + (((((uint64_t)((uint64_t)in_h[UINT64_C(10)])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(11)])))) & UINT64_C(0xffffffff));
                t31 = v30;
            } else {
                t31 = v28;
            }
            uint64_t v32 = t31;
            int v33 = (UINT64_C(6) < v8);
            uint64_t t35;
            if (v33) {
                uint64_t v34 = ((v32 + (((((uint64_t)((uint64_t)in_h[UINT64_C(12)])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(13)])))) & UINT64_C(0xffffffff));
                t35 = v34;
            } else {
                t35 = v32;
            }
            uint64_t v36 = t35;
            int v37 = (UINT64_C(7) < v8);
            uint64_t t39;
            if (v37) {
                uint64_t v38 = ((v36 + (((((uint64_t)((uint64_t)in_h[UINT64_C(14)])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(15)])))) & UINT64_C(0xffffffff));
                t39 = v38;
            } else {
                t39 = v36;
            }
            uint64_t v40 = t39;
            int v41 = (UINT64_C(8) < v8);
            uint64_t t43;
            if (v41) {
                uint64_t v42 = ((v40 + (((((uint64_t)((uint64_t)in_h[UINT64_C(16)])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(17)])))) & UINT64_C(0xffffffff));
                t43 = v42;
            } else {
                t43 = v40;
            }
            uint64_t v44 = t43;
            int v45 = (UINT64_C(9) < v8);
            uint64_t t47;
            if (v45) {
                uint64_t v46 = ((v44 + (((((uint64_t)((uint64_t)in_h[UINT64_C(18)])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(19)])))) & UINT64_C(0xffffffff));
                t47 = v46;
            } else {
                t47 = v44;
            }
            uint64_t v48 = t47;
            int v49 = (UINT64_C(10) < v8);
            uint64_t t51;
            if (v49) {
                uint64_t v50 = ((v48 + (((((uint64_t)((uint64_t)in_h[UINT64_C(20)])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(21)])))) & UINT64_C(0xffffffff));
                t51 = v50;
            } else {
                t51 = v48;
            }
            uint64_t v52 = t51;
            int v53 = (UINT64_C(11) < v8);
            uint64_t t55;
            if (v53) {
                uint64_t v54 = ((v52 + (((((uint64_t)((uint64_t)in_h[UINT64_C(22)])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(23)])))) & UINT64_C(0xffffffff));
                t55 = v54;
            } else {
                t55 = v52;
            }
            uint64_t v56 = t55;
            int v57 = (UINT64_C(12) < v8);
            uint64_t t59;
            if (v57) {
                uint64_t v58 = ((v56 + (((((uint64_t)((uint64_t)in_h[UINT64_C(24)])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(25)])))) & UINT64_C(0xffffffff));
                t59 = v58;
            } else {
                t59 = v56;
            }
            uint64_t v60 = t59;
            int v61 = (UINT64_C(13) < v8);
            uint64_t t63;
            if (v61) {
                uint64_t v62 = ((v60 + (((((uint64_t)((uint64_t)in_h[UINT64_C(26)])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(27)])))) & UINT64_C(0xffffffff));
                t63 = v62;
            } else {
                t63 = v60;
            }
            uint64_t v64 = t63;
            int v65 = (UINT64_C(14) < v8);
            uint64_t t67;
            if (v65) {
                uint64_t v66 = ((v64 + (((((uint64_t)((uint64_t)in_h[UINT64_C(28)])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(29)])))) & UINT64_C(0xffffffff));
                t67 = v66;
            } else {
                t67 = v64;
            }
            uint64_t v68 = t67;
            int v69 = (UINT64_C(15) < v8);
            uint64_t t71;
            if (v69) {
                uint64_t v70 = ((v68 + (((((uint64_t)((uint64_t)in_h[UINT64_C(30)])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(31)])))) & UINT64_C(0xffffffff));
                t71 = v70;
            } else {
                t71 = v68;
            }
            uint64_t v72 = t71;
            int v73 = (UINT64_C(16) < v8);
            uint64_t t75;
            if (v73) {
                uint64_t v74 = ((v72 + (((((uint64_t)((uint64_t)in_h[UINT64_C(32)])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(33)])))) & UINT64_C(0xffffffff));
                t75 = v74;
            } else {
                t75 = v72;
            }
            uint64_t v76 = t75;
            int v77 = (UINT64_C(17) < v8);
            uint64_t t79;
            if (v77) {
                uint64_t v78 = ((v76 + (((((uint64_t)((uint64_t)in_h[UINT64_C(34)])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(35)])))) & UINT64_C(0xffffffff));
                t79 = v78;
            } else {
                t79 = v76;
            }
            uint64_t v80 = t79;
            int v81 = (UINT64_C(18) < v8);
            uint64_t t83;
            if (v81) {
                uint64_t v82 = ((v80 + (((((uint64_t)((uint64_t)in_h[UINT64_C(36)])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(37)])))) & UINT64_C(0xffffffff));
                t83 = v82;
            } else {
                t83 = v80;
            }
            uint64_t v84 = t83;
            int v85 = (UINT64_C(19) < v8);
            uint64_t t87;
            if (v85) {
                uint64_t v86 = ((v84 + (((((uint64_t)((uint64_t)in_h[UINT64_C(38)])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(39)])))) & UINT64_C(0xffffffff));
                t87 = v86;
            } else {
                t87 = v84;
            }
            uint64_t v88 = t87;
            int v89 = (UINT64_C(20) < v8);
            uint64_t t91;
            if (v89) {
                uint64_t v90 = ((v88 + (((((uint64_t)((uint64_t)in_h[UINT64_C(40)])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(41)])))) & UINT64_C(0xffffffff));
                t91 = v90;
            } else {
                t91 = v88;
            }
            uint64_t v92 = t91;
            int v93 = (UINT64_C(21) < v8);
            uint64_t t95;
            if (v93) {
                uint64_t v94 = ((v92 + (((((uint64_t)((uint64_t)in_h[UINT64_C(42)])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(43)])))) & UINT64_C(0xffffffff));
                t95 = v94;
            } else {
                t95 = v92;
            }
            uint64_t v96 = t95;
            int v97 = (UINT64_C(22) < v8);
            uint64_t t99;
            if (v97) {
                uint64_t v98 = ((v96 + (((((uint64_t)((uint64_t)in_h[UINT64_C(44)])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(45)])))) & UINT64_C(0xffffffff));
                t99 = v98;
            } else {
                t99 = v96;
            }
            uint64_t v100 = t99;
            int v101 = (UINT64_C(23) < v8);
            uint64_t t103;
            if (v101) {
                uint64_t v102 = ((v100 + (((((uint64_t)((uint64_t)in_h[UINT64_C(46)])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(47)])))) & UINT64_C(0xffffffff));
                t103 = v102;
            } else {
                t103 = v100;
            }
            uint64_t v104 = t103;
            int v105 = (UINT64_C(24) < v8);
            uint64_t t107;
            if (v105) {
                uint64_t v106 = ((v104 + (((((uint64_t)((uint64_t)in_h[UINT64_C(48)])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(49)])))) & UINT64_C(0xffffffff));
                t107 = v106;
            } else {
                t107 = v104;
            }
            uint64_t v108 = t107;
            int v109 = (UINT64_C(25) < v8);
            uint64_t t111;
            if (v109) {
                uint64_t v110 = ((v108 + (((((uint64_t)((uint64_t)in_h[UINT64_C(50)])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(51)])))) & UINT64_C(0xffffffff));
                t111 = v110;
            } else {
                t111 = v108;
            }
            uint64_t v112 = t111;
            int v113 = (UINT64_C(26) < v8);
            uint64_t t115;
            if (v113) {
                uint64_t v114 = ((v112 + (((((uint64_t)((uint64_t)in_h[UINT64_C(52)])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(53)])))) & UINT64_C(0xffffffff));
                t115 = v114;
            } else {
                t115 = v112;
            }
            uint64_t v116 = t115;
            int v117 = (UINT64_C(27) < v8);
            uint64_t t119;
            if (v117) {
                uint64_t v118 = ((v116 + (((((uint64_t)((uint64_t)in_h[UINT64_C(54)])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(55)])))) & UINT64_C(0xffffffff));
                t119 = v118;
            } else {
                t119 = v116;
            }
            uint64_t v120 = t119;
            int v121 = (UINT64_C(28) < v8);
            uint64_t t123;
            if (v121) {
                uint64_t v122 = ((v120 + (((((uint64_t)((uint64_t)in_h[UINT64_C(56)])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(57)])))) & UINT64_C(0xffffffff));
                t123 = v122;
            } else {
                t123 = v120;
            }
            uint64_t v124 = t123;
            int v125 = (UINT64_C(29) < v8);
            uint64_t t127;
            if (v125) {
                uint64_t v126 = ((v124 + (((((uint64_t)((uint64_t)in_h[UINT64_C(58)])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(59)])))) & UINT64_C(0xffffffff));
                t127 = v126;
            } else {
                t127 = v124;
            }
            uint64_t v128 = t127;
            uint64_t v129 = (((v128 & UINT64_C(0xffff)) + (v128 >> 16)) & UINT64_C(0xffffffff));
            uint64_t v130 = (((v129 & UINT64_C(0xffff)) + (v129 >> 16)) & UINT64_C(0xffffffff));
            int o131_tag;
            uint64_t o131_0 = 0;
            uint64_t o131_1 = 0;
            if ((v130 != UINT64_C(0xffff))) {
                o131_tag = 0;
                o131_0 = 0;
                o131_1 = 0;
            } else {
                o131_tag = 1;
                o131_0 = v3;
                o131_1 = v5;
            }
            o6_tag = o131_tag;
            o6_0 = o131_0;
            o6_1 = o131_1;
        }
        o1_tag = o6_tag;
        o1_0 = o6_0;
        o1_1 = o6_1;
    }
    if (o1_tag) {
        *out0 = (uint64_t)(o1_0);
        *out1 = (uint64_t)(o1_1);
    }
    return o1_tag;
}
