module exp005

go 1.26
