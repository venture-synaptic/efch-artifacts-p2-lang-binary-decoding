package main

import "exp005/corpus"

func main() { corpus.Main() }
