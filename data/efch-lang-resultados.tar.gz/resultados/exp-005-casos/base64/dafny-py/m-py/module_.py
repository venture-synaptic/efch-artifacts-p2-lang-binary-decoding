import sys
from typing import Callable, Any, TypeVar, NamedTuple
from math import floor
from itertools import count

import module_ as module_
import _dafny as _dafny
import System_ as System_

# Module: module_

class default__:
    def  __init__(self):
        pass

    @staticmethod
    def Sextet(c):
        if ((65) <= (c)) and ((c) <= (90)):
            return (c) - (65)
        elif ((97) <= (c)) and ((c) <= (122)):
            return (c) - (71)
        elif ((48) <= (c)) and ((c) <= (57)):
            return (c) + (4)
        elif (c) == (43):
            return 62
        elif (c) == (47):
            return 63
        elif True:
            return 64

    @staticmethod
    def Spec(s):
        if (len(s)) != (4):
            return Option_None()
        elif True:
            d_0_v0_ = default__.Sextet((s)[0])
            d_1_v1_ = default__.Sextet((s)[1])
            d_2_v2_ = default__.Sextet((s)[2])
            d_3_v3_ = default__.Sextet((s)[3])
            d_4_p2_ = ((s)[2]) == (61)
            d_5_p3_ = ((s)[3]) == (61)
            if (((((d_0_v0_) == (64)) or ((d_1_v1_) == (64))) or ((d_4_p2_) and (not(d_5_p3_)))) or ((not(d_4_p2_)) and ((d_2_v2_) == (64)))) or ((not(d_5_p3_)) and ((d_3_v3_) == (64))):
                return Option_None()
            elif True:
                d_6_w_ = ((((d_0_v0_) * (262144)) + ((d_1_v1_) * (4096))) + (((0 if d_4_p2_ else d_2_v2_)) * (64))) + ((0 if d_5_p3_ else d_3_v3_))
                if d_4_p2_:
                    if (_dafny.euclidian_modulus(d_6_w_, 65536)) != (0):
                        return Option_None()
                    elif True:
                        return Option_Some((_dafny.euclidian_division(d_6_w_, 65536), 1))
                elif d_5_p3_:
                    if (_dafny.euclidian_modulus(d_6_w_, 256)) != (0):
                        return Option_None()
                    elif True:
                        return Option_Some((_dafny.euclidian_division(d_6_w_, 256), 2))
                elif True:
                    return Option_Some((d_6_w_, 3))

    @staticmethod
    def Decode(s):
        r: Option = Option.default()()
        if (len(s)) != (4):
            r = Option_None()
            return r
        d_0_a_: int
        d_1_b_: int
        rhs0_ = default__.Sextet((s)[0])
        rhs1_ = default__.Sextet((s)[1])
        d_0_a_ = rhs0_
        d_1_b_ = rhs1_
        if ((d_0_a_) == (64)) or ((d_1_b_) == (64)):
            r = Option_None()
            return r
        d_2_w_: int
        d_2_w_ = ((d_0_a_) * (262144)) + ((d_1_b_) * (4096))
        if (((s)[2]) == (61)) and (((s)[3]) == (61)):
            if (_dafny.euclidian_modulus(d_2_w_, 65536)) == (0):
                r = Option_Some((_dafny.euclidian_division(d_2_w_, 65536), 1))
            elif True:
                r = Option_None()
            return r
        d_3_c_: int
        d_3_c_ = default__.Sextet((s)[2])
        if (d_3_c_) == (64):
            r = Option_None()
            return r
        d_2_w_ = (d_2_w_) + ((d_3_c_) * (64))
        if ((s)[3]) == (61):
            if (_dafny.euclidian_modulus(d_2_w_, 256)) == (0):
                r = Option_Some((_dafny.euclidian_division(d_2_w_, 256), 2))
            elif True:
                r = Option_None()
            return r
        d_4_d_: int
        d_4_d_ = default__.Sextet((s)[3])
        if (d_4_d_) == (64):
            r = Option_None()
            return r
        r = Option_Some(((d_2_w_) + (d_4_d_), 3))
        return r
        return r


class u8:
    def  __init__(self):
        pass

    @staticmethod
    def default():
        return int(0)
    def _Is(source__):
        return True

class Option:
    @classmethod
    def default(cls, ):
        return lambda: Option_None()
    def __ne__(self, __o: object) -> bool:
        return not self.__eq__(__o)
    @property
    def is_None(self) -> bool:
        return isinstance(self, Option_None)
    @property
    def is_Some(self) -> bool:
        return isinstance(self, Option_Some)

class Option_None(Option, NamedTuple('None_', [])):
    def __dafnystr__(self) -> str:
        return f'Option.None'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, Option_None)
    def __hash__(self) -> int:
        return super().__hash__()

class Option_Some(Option, NamedTuple('Some', [('value', Any)])):
    def __dafnystr__(self) -> str:
        return f'Option.Some({_dafny.string_of(self.value)})'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, Option_Some) and self.value == __o.value
    def __hash__(self) -> int:
        return super().__hash__()

