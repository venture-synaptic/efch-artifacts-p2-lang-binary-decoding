#include <stddef.h>
#include <stdint.h>
#include <string.h>
typedef unsigned __int128 efch_u128;

/* Operaciones con signo sobre valores de w bits guardados sin signo y enmascarados. Solo usan
   aritmética sin signo: no hay comportamiento indefinido ni dependiente de la implementación. */
#define EFCH_SIGNED_OPS(T, SUF)                                                               \
static inline T efch_mask##SUF(unsigned w) { return w >= 8 * sizeof(T) ? (T)~(T)0 : (((T)1 << w) - 1); } \
static inline int efch_slt##SUF(T x, T y, unsigned w) { T s = (T)1 << (w - 1); return (x ^ s) < (y ^ s); } \
static inline T efch_sext##SUF(T x, unsigned w, unsigned n) {                                 \
    return (x & ((T)1 << (w - 1))) ? (x | (efch_mask##SUF(n) & ~efch_mask##SUF(w))) : x; }    \
static inline T efch_ashr##SUF(T x, T k, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int neg = (x >> (w - 1)) & 1;                                    \
    if (k >= w) return neg ? m : 0;                                                           \
    return (x >> k) | (neg ? (m & ~(m >> k)) : 0); }                                          \
static inline T efch_sdiv##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return nx ? 1 : m;                                                            \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, q = ax / ay;                     \
    return (nx != ny) ? ((T)-q & m) : q; }                                                    \
static inline T efch_srem##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return x;                                                                     \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, r = ax % ay;                     \
    return nx ? ((T)-r & m) : r; }
EFCH_SIGNED_OPS(uint64_t, 64)
EFCH_SIGNED_OPS(efch_u128, 128)

int efch_base64_block_decode__lang(const uint8_t *in_s, size_t in_s_len, uint64_t *out0, uint64_t *out1)
{
    int o1_tag;
    uint64_t o1_0 = 0;
    uint64_t o1_1 = 0;
    if ((((uint64_t)((uint64_t)in_s_len)) != UINT64_C(4))) {
        o1_tag = 0;
        o1_0 = 0;
        o1_1 = 0;
    } else {
        uint64_t v2 = ((uint64_t)in_s[UINT64_C(0)]);
        uint64_t v3 = (((v2 >= UINT64_C(65)) && (v2 <= UINT64_C(90))) ? ((v2 - UINT64_C(65)) & UINT64_C(255)) : (((v2 >= UINT64_C(97)) && (v2 <= UINT64_C(122))) ? ((((v2 - UINT64_C(97)) & UINT64_C(255)) + UINT64_C(26)) & UINT64_C(255)) : (((v2 >= UINT64_C(48)) && (v2 <= UINT64_C(57))) ? ((((v2 - UINT64_C(48)) & UINT64_C(255)) + UINT64_C(52)) & UINT64_C(255)) : ((v2 == UINT64_C(43)) ? UINT64_C(62) : ((v2 == UINT64_C(47)) ? UINT64_C(63) : UINT64_C(64))))));
        uint64_t v4 = ((uint64_t)in_s[UINT64_C(1)]);
        uint64_t v5 = (((v4 >= UINT64_C(65)) && (v4 <= UINT64_C(90))) ? ((v4 - UINT64_C(65)) & UINT64_C(255)) : (((v4 >= UINT64_C(97)) && (v4 <= UINT64_C(122))) ? ((((v4 - UINT64_C(97)) & UINT64_C(255)) + UINT64_C(26)) & UINT64_C(255)) : (((v4 >= UINT64_C(48)) && (v4 <= UINT64_C(57))) ? ((((v4 - UINT64_C(48)) & UINT64_C(255)) + UINT64_C(52)) & UINT64_C(255)) : ((v4 == UINT64_C(43)) ? UINT64_C(62) : ((v4 == UINT64_C(47)) ? UINT64_C(63) : UINT64_C(64))))));
        int o6_tag;
        uint64_t o6_0 = 0;
        uint64_t o6_1 = 0;
        if (((v3 == UINT64_C(64)) || (v5 == UINT64_C(64)))) {
            o6_tag = 0;
            o6_0 = 0;
            o6_1 = 0;
        } else {
            uint64_t v7 = (((((uint64_t)v3) << 18) & UINT64_C(0xffffffff)) | ((((uint64_t)v5) << 12) & UINT64_C(0xffffffff)));
            int o8_tag;
            uint64_t o8_0 = 0;
            uint64_t o8_1 = 0;
            if (((((uint64_t)in_s[UINT64_C(2)]) == UINT64_C(61)) && (((uint64_t)in_s[UINT64_C(3)]) == UINT64_C(61)))) {
                int o9_tag;
                uint64_t o9_0 = 0;
                uint64_t o9_1 = 0;
                if (((v7 & UINT64_C(0xffff)) != UINT64_C(0))) {
                    o9_tag = 0;
                    o9_0 = 0;
                    o9_1 = 0;
                } else {
                    o9_tag = 1;
                    o9_0 = (v7 >> 16);
                    o9_1 = UINT64_C(1);
                }
                o8_tag = o9_tag;
                o8_0 = o9_0;
                o8_1 = o9_1;
            } else {
                uint64_t v10 = ((uint64_t)in_s[UINT64_C(2)]);
                uint64_t v11 = (((v10 >= UINT64_C(65)) && (v10 <= UINT64_C(90))) ? ((v10 - UINT64_C(65)) & UINT64_C(255)) : (((v10 >= UINT64_C(97)) && (v10 <= UINT64_C(122))) ? ((((v10 - UINT64_C(97)) & UINT64_C(255)) + UINT64_C(26)) & UINT64_C(255)) : (((v10 >= UINT64_C(48)) && (v10 <= UINT64_C(57))) ? ((((v10 - UINT64_C(48)) & UINT64_C(255)) + UINT64_C(52)) & UINT64_C(255)) : ((v10 == UINT64_C(43)) ? UINT64_C(62) : ((v10 == UINT64_C(47)) ? UINT64_C(63) : UINT64_C(64))))));
                int o12_tag;
                uint64_t o12_0 = 0;
                uint64_t o12_1 = 0;
                if ((v11 == UINT64_C(64))) {
                    o12_tag = 0;
                    o12_0 = 0;
                    o12_1 = 0;
                } else {
                    uint64_t v13 = (v7 | ((((uint64_t)v11) << 6) & UINT64_C(0xffffffff)));
                    int o14_tag;
                    uint64_t o14_0 = 0;
                    uint64_t o14_1 = 0;
                    if ((((uint64_t)in_s[UINT64_C(3)]) == UINT64_C(61))) {
                        int o15_tag;
                        uint64_t o15_0 = 0;
                        uint64_t o15_1 = 0;
                        if (((v13 & UINT64_C(255)) != UINT64_C(0))) {
                            o15_tag = 0;
                            o15_0 = 0;
                            o15_1 = 0;
                        } else {
                            o15_tag = 1;
                            o15_0 = (v13 >> 8);
                            o15_1 = UINT64_C(2);
                        }
                        o14_tag = o15_tag;
                        o14_0 = o15_0;
                        o14_1 = o15_1;
                    } else {
                        uint64_t v16 = ((uint64_t)in_s[UINT64_C(3)]);
                        uint64_t v17 = (((v16 >= UINT64_C(65)) && (v16 <= UINT64_C(90))) ? ((v16 - UINT64_C(65)) & UINT64_C(255)) : (((v16 >= UINT64_C(97)) && (v16 <= UINT64_C(122))) ? ((((v16 - UINT64_C(97)) & UINT64_C(255)) + UINT64_C(26)) & UINT64_C(255)) : (((v16 >= UINT64_C(48)) && (v16 <= UINT64_C(57))) ? ((((v16 - UINT64_C(48)) & UINT64_C(255)) + UINT64_C(52)) & UINT64_C(255)) : ((v16 == UINT64_C(43)) ? UINT64_C(62) : ((v16 == UINT64_C(47)) ? UINT64_C(63) : UINT64_C(64))))));
                        int o18_tag;
                        uint64_t o18_0 = 0;
                        uint64_t o18_1 = 0;
                        if ((v17 == UINT64_C(64))) {
                            o18_tag = 0;
                            o18_0 = 0;
                            o18_1 = 0;
                        } else {
                            o18_tag = 1;
                            o18_0 = (v13 | ((uint64_t)v17));
                            o18_1 = UINT64_C(3);
                        }
                        o14_tag = o18_tag;
                        o14_0 = o18_0;
                        o14_1 = o18_1;
                    }
                    o12_tag = o14_tag;
                    o12_0 = o14_0;
                    o12_1 = o14_1;
                }
                o8_tag = o12_tag;
                o8_0 = o12_0;
                o8_1 = o12_1;
            }
            o6_tag = o8_tag;
            o6_0 = o8_0;
            o6_1 = o8_1;
        }
        o1_tag = o6_tag;
        o1_0 = o6_0;
        o1_1 = o6_1;
    }
    if (o1_tag) {
        *out0 = (uint64_t)(o1_0);
        *out1 = (uint64_t)(o1_1);
    }
    return o1_tag;
}
