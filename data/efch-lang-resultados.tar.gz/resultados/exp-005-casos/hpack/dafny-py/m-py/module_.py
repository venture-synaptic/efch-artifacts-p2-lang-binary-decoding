import sys
from typing import Callable, Any, TypeVar, NamedTuple
from math import floor
from itertools import count

import module_ as module_
import _dafny as _dafny
import System_ as System_

# Module: module_

class default__:
    def  __init__(self):
        pass

    @staticmethod
    def Pow(b, e):
        d_0___accumulator_ = 1
        while True:
            with _dafny.label():
                if (e) == (0):
                    return (1) * (d_0___accumulator_)
                elif True:
                    d_0___accumulator_ = (d_0___accumulator_) * (b)
                    in0_ = b
                    in1_ = (e) - (1)
                    b = in0_
                    e = in1_
                    raise _dafny.TailCall()
                break

    @staticmethod
    def LE7(s):
        d_0___accumulator_ = 0
        while True:
            with _dafny.label():
                if (len(s)) == (0):
                    return (0) + (d_0___accumulator_)
                elif True:
                    d_0___accumulator_ = ((_dafny.euclidian_modulus((s)[(len(s)) - (1)], 128)) * (default__.Pow(128, (len(s)) - (1)))) + (d_0___accumulator_)
                    in0_ = _dafny.SeqWithoutIsStrInference((s)[:(len(s)) - (1):])
                    s = in0_
                    raise _dafny.TailCall()
                break

    @staticmethod
    def Term(buf, t):
        while True:
            with _dafny.label():
                if ((t) >= (6)) or ((t) >= (len(buf))):
                    return Option_None()
                elif ((buf)[t]) < (128):
                    return Option_Some(t)
                elif True:
                    in0_ = buf
                    in1_ = (t) + (1)
                    buf = in0_
                    t = in1_
                    raise _dafny.TailCall()
                break

    @staticmethod
    def Spec(n, buf):
        if (((n) < (1)) or ((n) > (8))) or ((len(buf)) == (0)):
            return Option_None()
        elif True:
            d_0_mask_ = (default__.Pow(2, n)) - (1)
            d_1_p_ = _dafny.euclidian_modulus((buf)[0], default__.Pow(2, n))
            if (d_1_p_) < (d_0_mask_):
                return Option_Some((d_1_p_, 1))
            elif True:
                source0_ = default__.Term(buf, 1)
                if True:
                    if source0_.is_None:
                        return Option_None()
                if True:
                    d_2_t_ = source0_.value
                    d_3_v_ = (d_0_mask_) + (default__.LE7(_dafny.SeqWithoutIsStrInference((buf)[1:(d_2_t_) + (1):])))
                    if (d_3_v_) > (4294967295):
                        return Option_None()
                    elif True:
                        return Option_Some((d_3_v_, (d_2_t_) + (1)))

    @staticmethod
    def Decode(n, buf):
        r: Option = Option.default()()
        if (((n) < (1)) or ((n) > (8))) or ((len(buf)) == (0)):
            r = Option_None()
            return r
        d_0_mask_: int
        d_0_mask_ = (default__.Pow(2, n)) - (1)
        d_1_v_: int
        d_1_v_ = _dafny.euclidian_modulus((buf)[0], default__.Pow(2, n))
        if (d_1_v_) < (d_0_mask_):
            r = Option_Some((d_1_v_, 1))
            return r
        d_2_i_: int
        d_2_i_ = 1
        d_3_m_: int
        d_3_m_ = 1
        while ((d_2_i_) < (len(buf))) and ((d_2_i_) < (6)):
            d_1_v_ = (d_1_v_) + ((_dafny.euclidian_modulus((buf)[d_2_i_], 128)) * (d_3_m_))
            if ((buf)[d_2_i_]) < (128):
                if (d_1_v_) > (4294967295):
                    r = Option_None()
                    return r
                r = Option_Some((d_1_v_, (d_2_i_) + (1)))
                return r
            d_3_m_ = (d_3_m_) * (128)
            d_2_i_ = (d_2_i_) + (1)
        r = Option_None()
        return r
        return r


class u8:
    def  __init__(self):
        pass

    @staticmethod
    def default():
        return int(0)
    def _Is(source__):
        return True

class Option:
    @classmethod
    def default(cls, ):
        return lambda: Option_None()
    def __ne__(self, __o: object) -> bool:
        return not self.__eq__(__o)
    @property
    def is_None(self) -> bool:
        return isinstance(self, Option_None)
    @property
    def is_Some(self) -> bool:
        return isinstance(self, Option_Some)

class Option_None(Option, NamedTuple('None_', [])):
    def __dafnystr__(self) -> str:
        return f'Option.None'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, Option_None)
    def __hash__(self) -> int:
        return super().__hash__()

class Option_Some(Option, NamedTuple('Some', [('value', Any)])):
    def __dafnystr__(self) -> str:
        return f'Option.Some({_dafny.string_of(self.value)})'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, Option_Some) and self.value == __o.value
    def __hash__(self) -> int:
        return super().__hash__()

