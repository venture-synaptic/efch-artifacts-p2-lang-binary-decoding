#include <stddef.h>
#include <stdint.h>
#include <string.h>
typedef unsigned __int128 efch_u128;

/* Operaciones con signo sobre valores de w bits guardados sin signo y enmascarados. Solo usan
   aritmética sin signo: no hay comportamiento indefinido ni dependiente de la implementación. */
#define EFCH_SIGNED_OPS(T, SUF)                                                               \
static inline T efch_mask##SUF(unsigned w) { return w >= 8 * sizeof(T) ? (T)~(T)0 : (((T)1 << w) - 1); } \
static inline int efch_slt##SUF(T x, T y, unsigned w) { T s = (T)1 << (w - 1); return (x ^ s) < (y ^ s); } \
static inline T efch_sext##SUF(T x, unsigned w, unsigned n) {                                 \
    return (x & ((T)1 << (w - 1))) ? (x | (efch_mask##SUF(n) & ~efch_mask##SUF(w))) : x; }    \
static inline T efch_ashr##SUF(T x, T k, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int neg = (x >> (w - 1)) & 1;                                    \
    if (k >= w) return neg ? m : 0;                                                           \
    return (x >> k) | (neg ? (m & ~(m >> k)) : 0); }                                          \
static inline T efch_sdiv##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return nx ? 1 : m;                                                            \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, q = ax / ay;                     \
    return (nx != ny) ? ((T)-q & m) : q; }                                                    \
static inline T efch_srem##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return x;                                                                     \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, r = ax % ay;                     \
    return nx ? ((T)-r & m) : r; }
EFCH_SIGNED_OPS(uint64_t, 64)
EFCH_SIGNED_OPS(efch_u128, 128)

int efch_hpack_int_decode__lang(uint64_t in_n, const uint8_t *in_buf, size_t in_buf_len, uint64_t *out0, uint64_t *out1)
{
    int o1_tag;
    uint64_t o1_0 = 0;
    uint64_t o1_1 = 0;
    if ((((in_n < UINT64_C(1)) || (in_n > UINT64_C(8))) || (((uint64_t)((uint64_t)in_buf_len)) == UINT64_C(0)))) {
        o1_tag = 0;
        o1_0 = 0;
        o1_1 = 0;
    } else {
        uint64_t v2 = (((uint64_t)(((((((uint64_t)in_n) >= 16 ? 0 : UINT64_C(1) << ((uint64_t)in_n))) & UINT64_C(0xffff)) - UINT64_C(1)) & UINT64_C(0xffff))) & UINT64_C(255));
        uint64_t v3 = ((uint64_t)(((uint64_t)in_buf[UINT64_C(0)]) & v2));
        int o4_tag;
        uint64_t o4_0 = 0;
        uint64_t o4_1 = 0;
        if ((v3 < ((uint64_t)v2))) {
            o4_tag = 1;
            o4_0 = (((uint64_t)v3) & UINT64_C(0xffffffff));
            o4_1 = UINT64_C(1);
        } else {
            uint64_t v5 = ((((uint64_t)((uint64_t)in_buf_len)) < UINT64_C(6)) ? ((uint64_t)((uint64_t)in_buf_len)) : UINT64_C(6));
            int o6_tag;
            uint64_t o6_0 = 0;
            uint64_t o6_1 = 0;
            if ((UINT64_C(1) < v5)) {
                uint64_t v7 = ((uint64_t)in_buf[UINT64_C(1)]);
                uint64_t v8 = (v3 + (((uint64_t)(v7 & UINT64_C(127))) << 0));
                int o9_tag;
                uint64_t o9_0 = 0;
                uint64_t o9_1 = 0;
                if (((v7 & UINT64_C(128)) == UINT64_C(0))) {
                    int o10_tag;
                    uint64_t o10_0 = 0;
                    uint64_t o10_1 = 0;
                    if ((v8 > UINT64_C(0xffffffff))) {
                        o10_tag = 0;
                        o10_0 = 0;
                        o10_1 = 0;
                    } else {
                        o10_tag = 1;
                        o10_0 = (((uint64_t)v8) & UINT64_C(0xffffffff));
                        o10_1 = UINT64_C(2);
                    }
                    o9_tag = o10_tag;
                    o9_0 = o10_0;
                    o9_1 = o10_1;
                } else {
                    int o11_tag;
                    uint64_t o11_0 = 0;
                    uint64_t o11_1 = 0;
                    if ((UINT64_C(2) < v5)) {
                        uint64_t v12 = ((uint64_t)in_buf[UINT64_C(2)]);
                        uint64_t v13 = (v8 + (((uint64_t)(v12 & UINT64_C(127))) << 7));
                        int o14_tag;
                        uint64_t o14_0 = 0;
                        uint64_t o14_1 = 0;
                        if (((v12 & UINT64_C(128)) == UINT64_C(0))) {
                            int o15_tag;
                            uint64_t o15_0 = 0;
                            uint64_t o15_1 = 0;
                            if ((v13 > UINT64_C(0xffffffff))) {
                                o15_tag = 0;
                                o15_0 = 0;
                                o15_1 = 0;
                            } else {
                                o15_tag = 1;
                                o15_0 = (((uint64_t)v13) & UINT64_C(0xffffffff));
                                o15_1 = UINT64_C(3);
                            }
                            o14_tag = o15_tag;
                            o14_0 = o15_0;
                            o14_1 = o15_1;
                        } else {
                            int o16_tag;
                            uint64_t o16_0 = 0;
                            uint64_t o16_1 = 0;
                            if ((UINT64_C(3) < v5)) {
                                uint64_t v17 = ((uint64_t)in_buf[UINT64_C(3)]);
                                uint64_t v18 = (v13 + (((uint64_t)(v17 & UINT64_C(127))) << 14));
                                int o19_tag;
                                uint64_t o19_0 = 0;
                                uint64_t o19_1 = 0;
                                if (((v17 & UINT64_C(128)) == UINT64_C(0))) {
                                    int o20_tag;
                                    uint64_t o20_0 = 0;
                                    uint64_t o20_1 = 0;
                                    if ((v18 > UINT64_C(0xffffffff))) {
                                        o20_tag = 0;
                                        o20_0 = 0;
                                        o20_1 = 0;
                                    } else {
                                        o20_tag = 1;
                                        o20_0 = (((uint64_t)v18) & UINT64_C(0xffffffff));
                                        o20_1 = UINT64_C(4);
                                    }
                                    o19_tag = o20_tag;
                                    o19_0 = o20_0;
                                    o19_1 = o20_1;
                                } else {
                                    int o21_tag;
                                    uint64_t o21_0 = 0;
                                    uint64_t o21_1 = 0;
                                    if ((UINT64_C(4) < v5)) {
                                        uint64_t v22 = ((uint64_t)in_buf[UINT64_C(4)]);
                                        uint64_t v23 = (v18 + (((uint64_t)(v22 & UINT64_C(127))) << 21));
                                        int o24_tag;
                                        uint64_t o24_0 = 0;
                                        uint64_t o24_1 = 0;
                                        if (((v22 & UINT64_C(128)) == UINT64_C(0))) {
                                            int o25_tag;
                                            uint64_t o25_0 = 0;
                                            uint64_t o25_1 = 0;
                                            if ((v23 > UINT64_C(0xffffffff))) {
                                                o25_tag = 0;
                                                o25_0 = 0;
                                                o25_1 = 0;
                                            } else {
                                                o25_tag = 1;
                                                o25_0 = (((uint64_t)v23) & UINT64_C(0xffffffff));
                                                o25_1 = UINT64_C(5);
                                            }
                                            o24_tag = o25_tag;
                                            o24_0 = o25_0;
                                            o24_1 = o25_1;
                                        } else {
                                            int o26_tag;
                                            uint64_t o26_0 = 0;
                                            uint64_t o26_1 = 0;
                                            if ((UINT64_C(5) < v5)) {
                                                uint64_t v27 = ((uint64_t)in_buf[UINT64_C(5)]);
                                                uint64_t v28 = (v23 + (((uint64_t)(v27 & UINT64_C(127))) << 28));
                                                int o29_tag;
                                                uint64_t o29_0 = 0;
                                                uint64_t o29_1 = 0;
                                                if (((v27 & UINT64_C(128)) == UINT64_C(0))) {
                                                    int o30_tag;
                                                    uint64_t o30_0 = 0;
                                                    uint64_t o30_1 = 0;
                                                    if ((v28 > UINT64_C(0xffffffff))) {
                                                        o30_tag = 0;
                                                        o30_0 = 0;
                                                        o30_1 = 0;
                                                    } else {
                                                        o30_tag = 1;
                                                        o30_0 = (((uint64_t)v28) & UINT64_C(0xffffffff));
                                                        o30_1 = UINT64_C(6);
                                                    }
                                                    o29_tag = o30_tag;
                                                    o29_0 = o30_0;
                                                    o29_1 = o30_1;
                                                } else {
                                                    o29_tag = 0;
                                                    o29_0 = 0;
                                                    o29_1 = 0;
                                                }
                                                o26_tag = o29_tag;
                                                o26_0 = o29_0;
                                                o26_1 = o29_1;
                                            } else {
                                                o26_tag = 0;
                                                o26_0 = 0;
                                                o26_1 = 0;
                                            }
                                            o24_tag = o26_tag;
                                            o24_0 = o26_0;
                                            o24_1 = o26_1;
                                        }
                                        o21_tag = o24_tag;
                                        o21_0 = o24_0;
                                        o21_1 = o24_1;
                                    } else {
                                        o21_tag = 0;
                                        o21_0 = 0;
                                        o21_1 = 0;
                                    }
                                    o19_tag = o21_tag;
                                    o19_0 = o21_0;
                                    o19_1 = o21_1;
                                }
                                o16_tag = o19_tag;
                                o16_0 = o19_0;
                                o16_1 = o19_1;
                            } else {
                                o16_tag = 0;
                                o16_0 = 0;
                                o16_1 = 0;
                            }
                            o14_tag = o16_tag;
                            o14_0 = o16_0;
                            o14_1 = o16_1;
                        }
                        o11_tag = o14_tag;
                        o11_0 = o14_0;
                        o11_1 = o14_1;
                    } else {
                        o11_tag = 0;
                        o11_0 = 0;
                        o11_1 = 0;
                    }
                    o9_tag = o11_tag;
                    o9_0 = o11_0;
                    o9_1 = o11_1;
                }
                o6_tag = o9_tag;
                o6_0 = o9_0;
                o6_1 = o9_1;
            } else {
                o6_tag = 0;
                o6_0 = 0;
                o6_1 = 0;
            }
            o4_tag = o6_tag;
            o4_0 = o6_0;
            o4_1 = o6_1;
        }
        o1_tag = o4_tag;
        o1_0 = o4_0;
        o1_1 = o4_1;
    }
    if (o1_tag) {
        *out0 = (uint64_t)(o1_0);
        *out1 = (uint64_t)(o1_1);
    }
    return o1_tag;
}
