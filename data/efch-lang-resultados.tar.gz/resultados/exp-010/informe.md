# EXP-010 (opciones TCP con fold)

- ns_op: {"especificacion": 39.192, "efch_lang": 39.404, "c_a_mano": 32.559, "rust": 33.2, "go": 33.065}
- ns_op_por_estrato: {"aleatorio": {"especificacion": 15.776, "efch_lang": 15.722, "c_a_mano": 14.418, "rust": 12.417, "go": 17.876}, "validas": {"especificacion": 49.136, "efch_lang": 46.89, "c_a_mano": 39.923, "rust": 40.893, "go": 48.12}, "alteradas": {"especificacion": 32.998, "efch_lang": 32.696, "c_a_mano": 28.31, "rust": 27.832, "go": 28.646}}
```json
{
  "D0": {
    "cumple": true,
    "indefinidas": {
      "diferencial_nativo": 0,
      "diferencial_externo": 0
    },
    "especificacion_vectores_fallidos": []
  },
  "D1": {
    "valor": "revisión manual: ver la ficha (estado empaquetado y límite de recursión)",
    "cumple": null
  },
  "D2": {
    "valor": {
      "estado": "probado",
      "segundos": 0.61,
      "codigo": 0,
      "detalle": null,
      "herramienta": "Z3"
    },
    "cumple": true
  },
  "D3": {
    "efch_lang_sobre_c": 1.21,
    "cumple": true
  },
  "D4": {
    "rust_kani": {
      "esfuerzo_relativo": 0.808,
      "a": false,
      "b": true,
      "c": false,
      "cumple": true
    },
    "dafny": {
      "esfuerzo_relativo": 1.59,
      "a": false,
      "b": false,
      "c": true,
      "cumple": true
    },
    "cumple": true
  },
  "D5": {
    "aplica": true,
    "lineas_dafny_spec": 35,
    "efch_lang_sobre_dafny_spec_go": 0.011,
    "cumple": true
  },
  "decision": "pendiente de D1 (revisión manual)"
}
```
