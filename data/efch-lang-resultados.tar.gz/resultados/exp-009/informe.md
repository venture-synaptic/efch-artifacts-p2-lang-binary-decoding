# EXP-009 (nombre DNS con fold)

- ns_op: {"especificacion": 223.733, "efch_lang": 130.623, "c_a_mano": 128.328, "rust": 126.143, "go": 189.942}
- ns_op_por_estrato: {"aleatorio": {"especificacion": 11.567, "efch_lang": 12.305, "c_a_mano": 11.605, "rust": 11.425, "go": 13.762}, "cortos": {"especificacion": 131.183, "efch_lang": 106.077, "c_a_mano": 113.408, "rust": 103.945, "go": 193.368}, "largos": {"especificacion": 383.183, "efch_lang": 211.156, "c_a_mano": 215.006, "rust": 218.307, "go": 358.284}}
- especificacion_equivale_exp007: {"estado": "desconocido", "via": "diferencial en el intérprete (evidencia, no prueba)", "casos": 20000, "diferencias": 0}
- esfuerzos_exp007_contadores_f4: {"efch_total": 102, "c_lineas": 34, "dafny_lineas": 49, "dafny_anotaciones": 6}
```json
{
  "D0": {
    "cumple": true,
    "indefinidas": {
      "diferencial_nativo": 0,
      "diferencial_externo": 0
    },
    "especificacion_vectores_fallidos": []
  },
  "D1": {
    "valor": "revisión manual: ver la ficha (estado empaquetado y límite de recursión)",
    "cumple": null
  },
  "D2": {
    "valor": {
      "estado": "probado",
      "segundos": 16.93,
      "codigo": 0,
      "detalle": null,
      "herramienta": "Z3"
    },
    "cumple": true
  },
  "D3": {
    "efch_lang_sobre_c": 1.018,
    "cumple": true
  },
  "D4": {
    "rust_kani": {
      "esfuerzo_relativo": 0.789,
      "a": true,
      "b": true,
      "c": false,
      "cumple": true
    },
    "dafny": {
      "esfuerzo_relativo": 1.449,
      "a": false,
      "b": false,
      "c": false,
      "cumple": false
    },
    "cumple": false
  },
  "D5": {
    "aplica": true,
    "lineas_dafny_spec": 26,
    "efch_lang_sobre_dafny_spec_go": 0.005,
    "cumple": true
  },
  "decision": "no cumplido"
}
```
