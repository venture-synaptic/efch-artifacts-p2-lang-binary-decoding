#include <stddef.h>
#include <stdint.h>
#include <string.h>
typedef unsigned __int128 efch_u128;

/* Operaciones con signo sobre valores de w bits guardados sin signo y enmascarados. Solo usan
   aritmética sin signo: no hay comportamiento indefinido ni dependiente de la implementación. */
#define EFCH_SIGNED_OPS(T, SUF)                                                               \
static inline T efch_mask##SUF(unsigned w) { return w >= 8 * sizeof(T) ? (T)~(T)0 : (((T)1 << w) - 1); } \
static inline int efch_slt##SUF(T x, T y, unsigned w) { T s = (T)1 << (w - 1); return (x ^ s) < (y ^ s); } \
static inline T efch_sext##SUF(T x, unsigned w, unsigned n) {                                 \
    return (x & ((T)1 << (w - 1))) ? (x | (efch_mask##SUF(n) & ~efch_mask##SUF(w))) : x; }    \
static inline T efch_ashr##SUF(T x, T k, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int neg = (x >> (w - 1)) & 1;                                    \
    if (k >= w) return neg ? m : 0;                                                           \
    return (x >> k) | (neg ? (m & ~(m >> k)) : 0); }                                          \
static inline T efch_sdiv##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return nx ? 1 : m;                                                            \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, q = ax / ay;                     \
    return (nx != ny) ? ((T)-q & m) : q; }                                                    \
static inline T efch_srem##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return x;                                                                     \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, r = ax % ay;                     \
    return nx ? ((T)-r & m) : r; }
EFCH_SIGNED_OPS(uint64_t, 64)
EFCH_SIGNED_OPS(efch_u128, 128)

int efch_dns_hostname_wire(const uint8_t *in_b, size_t in_b_len, uint64_t *out0, uint64_t *out1, uint64_t *out2)
{
    uint64_t f1 = UINT64_C(0);
    for (int k2 = 0; k2 < 32; k2++) {
        uint64_t v3_n = ((uint64_t)in_b_len);
        const uint8_t *v3 = in_b;
        uint64_t v4 = f1;
        uint64_t v5 = (v4 & UINT64_C(255));
        uint64_t v6_n = v3_n;
        const uint8_t *v6 = v3;
        uint64_t v7 = v5;
        int t135 = (v7 < ((uint64_t)v6_n));
        if (t135) {
            t135 = (((uint64_t)v6[v7]) >= UINT64_C(1));
        }
        if (t135) {
            t135 = (((uint64_t)v6[v7]) <= UINT64_C(63));
        }
        if (t135) {
            t135 = (((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)) < ((uint64_t)v6_n));
        }
        if (t135) {
            t135 = (((uint64_t)v6[((v7 + UINT64_C(1)) & UINT64_C(0xffff))]) != UINT64_C(45));
        }
        if (t135) {
            t135 = (((uint64_t)v6[((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff))]) != UINT64_C(45));
        }
        if (t135) {
                int t9 = (UINT64_C(1) <= v7);
                if (!t9) {
                    t9 = (UINT64_C(1) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t9) {
                    uint64_t v8 = ((uint64_t)v6[UINT64_C(1)]);
                    t9 = ((((v8 | UINT64_C(32)) >= UINT64_C(97)) && ((v8 | UINT64_C(32)) <= UINT64_C(122))) || ((v8 >= UINT64_C(48)) && (v8 <= UINT64_C(57))) || (v8 == UINT64_C(45)));
                }
            int t134 = t9;
            if (t134) {
                int t11 = (UINT64_C(2) <= v7);
                if (!t11) {
                    t11 = (UINT64_C(2) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t11) {
                    uint64_t v10 = ((uint64_t)v6[UINT64_C(2)]);
                    t11 = ((((v10 | UINT64_C(32)) >= UINT64_C(97)) && ((v10 | UINT64_C(32)) <= UINT64_C(122))) || ((v10 >= UINT64_C(48)) && (v10 <= UINT64_C(57))) || (v10 == UINT64_C(45)));
                }
                t134 = t11;
            }
            if (t134) {
                int t13 = (UINT64_C(3) <= v7);
                if (!t13) {
                    t13 = (UINT64_C(3) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t13) {
                    uint64_t v12 = ((uint64_t)v6[UINT64_C(3)]);
                    t13 = ((((v12 | UINT64_C(32)) >= UINT64_C(97)) && ((v12 | UINT64_C(32)) <= UINT64_C(122))) || ((v12 >= UINT64_C(48)) && (v12 <= UINT64_C(57))) || (v12 == UINT64_C(45)));
                }
                t134 = t13;
            }
            if (t134) {
                int t15 = (UINT64_C(4) <= v7);
                if (!t15) {
                    t15 = (UINT64_C(4) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t15) {
                    uint64_t v14 = ((uint64_t)v6[UINT64_C(4)]);
                    t15 = ((((v14 | UINT64_C(32)) >= UINT64_C(97)) && ((v14 | UINT64_C(32)) <= UINT64_C(122))) || ((v14 >= UINT64_C(48)) && (v14 <= UINT64_C(57))) || (v14 == UINT64_C(45)));
                }
                t134 = t15;
            }
            if (t134) {
                int t17 = (UINT64_C(5) <= v7);
                if (!t17) {
                    t17 = (UINT64_C(5) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t17) {
                    uint64_t v16 = ((uint64_t)v6[UINT64_C(5)]);
                    t17 = ((((v16 | UINT64_C(32)) >= UINT64_C(97)) && ((v16 | UINT64_C(32)) <= UINT64_C(122))) || ((v16 >= UINT64_C(48)) && (v16 <= UINT64_C(57))) || (v16 == UINT64_C(45)));
                }
                t134 = t17;
            }
            if (t134) {
                int t19 = (UINT64_C(6) <= v7);
                if (!t19) {
                    t19 = (UINT64_C(6) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t19) {
                    uint64_t v18 = ((uint64_t)v6[UINT64_C(6)]);
                    t19 = ((((v18 | UINT64_C(32)) >= UINT64_C(97)) && ((v18 | UINT64_C(32)) <= UINT64_C(122))) || ((v18 >= UINT64_C(48)) && (v18 <= UINT64_C(57))) || (v18 == UINT64_C(45)));
                }
                t134 = t19;
            }
            if (t134) {
                int t21 = (UINT64_C(7) <= v7);
                if (!t21) {
                    t21 = (UINT64_C(7) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t21) {
                    uint64_t v20 = ((uint64_t)v6[UINT64_C(7)]);
                    t21 = ((((v20 | UINT64_C(32)) >= UINT64_C(97)) && ((v20 | UINT64_C(32)) <= UINT64_C(122))) || ((v20 >= UINT64_C(48)) && (v20 <= UINT64_C(57))) || (v20 == UINT64_C(45)));
                }
                t134 = t21;
            }
            if (t134) {
                int t23 = (UINT64_C(8) <= v7);
                if (!t23) {
                    t23 = (UINT64_C(8) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t23) {
                    uint64_t v22 = ((uint64_t)v6[UINT64_C(8)]);
                    t23 = ((((v22 | UINT64_C(32)) >= UINT64_C(97)) && ((v22 | UINT64_C(32)) <= UINT64_C(122))) || ((v22 >= UINT64_C(48)) && (v22 <= UINT64_C(57))) || (v22 == UINT64_C(45)));
                }
                t134 = t23;
            }
            if (t134) {
                int t25 = (UINT64_C(9) <= v7);
                if (!t25) {
                    t25 = (UINT64_C(9) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t25) {
                    uint64_t v24 = ((uint64_t)v6[UINT64_C(9)]);
                    t25 = ((((v24 | UINT64_C(32)) >= UINT64_C(97)) && ((v24 | UINT64_C(32)) <= UINT64_C(122))) || ((v24 >= UINT64_C(48)) && (v24 <= UINT64_C(57))) || (v24 == UINT64_C(45)));
                }
                t134 = t25;
            }
            if (t134) {
                int t27 = (UINT64_C(10) <= v7);
                if (!t27) {
                    t27 = (UINT64_C(10) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t27) {
                    uint64_t v26 = ((uint64_t)v6[UINT64_C(10)]);
                    t27 = ((((v26 | UINT64_C(32)) >= UINT64_C(97)) && ((v26 | UINT64_C(32)) <= UINT64_C(122))) || ((v26 >= UINT64_C(48)) && (v26 <= UINT64_C(57))) || (v26 == UINT64_C(45)));
                }
                t134 = t27;
            }
            if (t134) {
                int t29 = (UINT64_C(11) <= v7);
                if (!t29) {
                    t29 = (UINT64_C(11) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t29) {
                    uint64_t v28 = ((uint64_t)v6[UINT64_C(11)]);
                    t29 = ((((v28 | UINT64_C(32)) >= UINT64_C(97)) && ((v28 | UINT64_C(32)) <= UINT64_C(122))) || ((v28 >= UINT64_C(48)) && (v28 <= UINT64_C(57))) || (v28 == UINT64_C(45)));
                }
                t134 = t29;
            }
            if (t134) {
                int t31 = (UINT64_C(12) <= v7);
                if (!t31) {
                    t31 = (UINT64_C(12) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t31) {
                    uint64_t v30 = ((uint64_t)v6[UINT64_C(12)]);
                    t31 = ((((v30 | UINT64_C(32)) >= UINT64_C(97)) && ((v30 | UINT64_C(32)) <= UINT64_C(122))) || ((v30 >= UINT64_C(48)) && (v30 <= UINT64_C(57))) || (v30 == UINT64_C(45)));
                }
                t134 = t31;
            }
            if (t134) {
                int t33 = (UINT64_C(13) <= v7);
                if (!t33) {
                    t33 = (UINT64_C(13) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t33) {
                    uint64_t v32 = ((uint64_t)v6[UINT64_C(13)]);
                    t33 = ((((v32 | UINT64_C(32)) >= UINT64_C(97)) && ((v32 | UINT64_C(32)) <= UINT64_C(122))) || ((v32 >= UINT64_C(48)) && (v32 <= UINT64_C(57))) || (v32 == UINT64_C(45)));
                }
                t134 = t33;
            }
            if (t134) {
                int t35 = (UINT64_C(14) <= v7);
                if (!t35) {
                    t35 = (UINT64_C(14) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t35) {
                    uint64_t v34 = ((uint64_t)v6[UINT64_C(14)]);
                    t35 = ((((v34 | UINT64_C(32)) >= UINT64_C(97)) && ((v34 | UINT64_C(32)) <= UINT64_C(122))) || ((v34 >= UINT64_C(48)) && (v34 <= UINT64_C(57))) || (v34 == UINT64_C(45)));
                }
                t134 = t35;
            }
            if (t134) {
                int t37 = (UINT64_C(15) <= v7);
                if (!t37) {
                    t37 = (UINT64_C(15) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t37) {
                    uint64_t v36 = ((uint64_t)v6[UINT64_C(15)]);
                    t37 = ((((v36 | UINT64_C(32)) >= UINT64_C(97)) && ((v36 | UINT64_C(32)) <= UINT64_C(122))) || ((v36 >= UINT64_C(48)) && (v36 <= UINT64_C(57))) || (v36 == UINT64_C(45)));
                }
                t134 = t37;
            }
            if (t134) {
                int t39 = (UINT64_C(16) <= v7);
                if (!t39) {
                    t39 = (UINT64_C(16) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t39) {
                    uint64_t v38 = ((uint64_t)v6[UINT64_C(16)]);
                    t39 = ((((v38 | UINT64_C(32)) >= UINT64_C(97)) && ((v38 | UINT64_C(32)) <= UINT64_C(122))) || ((v38 >= UINT64_C(48)) && (v38 <= UINT64_C(57))) || (v38 == UINT64_C(45)));
                }
                t134 = t39;
            }
            if (t134) {
                int t41 = (UINT64_C(17) <= v7);
                if (!t41) {
                    t41 = (UINT64_C(17) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t41) {
                    uint64_t v40 = ((uint64_t)v6[UINT64_C(17)]);
                    t41 = ((((v40 | UINT64_C(32)) >= UINT64_C(97)) && ((v40 | UINT64_C(32)) <= UINT64_C(122))) || ((v40 >= UINT64_C(48)) && (v40 <= UINT64_C(57))) || (v40 == UINT64_C(45)));
                }
                t134 = t41;
            }
            if (t134) {
                int t43 = (UINT64_C(18) <= v7);
                if (!t43) {
                    t43 = (UINT64_C(18) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t43) {
                    uint64_t v42 = ((uint64_t)v6[UINT64_C(18)]);
                    t43 = ((((v42 | UINT64_C(32)) >= UINT64_C(97)) && ((v42 | UINT64_C(32)) <= UINT64_C(122))) || ((v42 >= UINT64_C(48)) && (v42 <= UINT64_C(57))) || (v42 == UINT64_C(45)));
                }
                t134 = t43;
            }
            if (t134) {
                int t45 = (UINT64_C(19) <= v7);
                if (!t45) {
                    t45 = (UINT64_C(19) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t45) {
                    uint64_t v44 = ((uint64_t)v6[UINT64_C(19)]);
                    t45 = ((((v44 | UINT64_C(32)) >= UINT64_C(97)) && ((v44 | UINT64_C(32)) <= UINT64_C(122))) || ((v44 >= UINT64_C(48)) && (v44 <= UINT64_C(57))) || (v44 == UINT64_C(45)));
                }
                t134 = t45;
            }
            if (t134) {
                int t47 = (UINT64_C(20) <= v7);
                if (!t47) {
                    t47 = (UINT64_C(20) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t47) {
                    uint64_t v46 = ((uint64_t)v6[UINT64_C(20)]);
                    t47 = ((((v46 | UINT64_C(32)) >= UINT64_C(97)) && ((v46 | UINT64_C(32)) <= UINT64_C(122))) || ((v46 >= UINT64_C(48)) && (v46 <= UINT64_C(57))) || (v46 == UINT64_C(45)));
                }
                t134 = t47;
            }
            if (t134) {
                int t49 = (UINT64_C(21) <= v7);
                if (!t49) {
                    t49 = (UINT64_C(21) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t49) {
                    uint64_t v48 = ((uint64_t)v6[UINT64_C(21)]);
                    t49 = ((((v48 | UINT64_C(32)) >= UINT64_C(97)) && ((v48 | UINT64_C(32)) <= UINT64_C(122))) || ((v48 >= UINT64_C(48)) && (v48 <= UINT64_C(57))) || (v48 == UINT64_C(45)));
                }
                t134 = t49;
            }
            if (t134) {
                int t51 = (UINT64_C(22) <= v7);
                if (!t51) {
                    t51 = (UINT64_C(22) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t51) {
                    uint64_t v50 = ((uint64_t)v6[UINT64_C(22)]);
                    t51 = ((((v50 | UINT64_C(32)) >= UINT64_C(97)) && ((v50 | UINT64_C(32)) <= UINT64_C(122))) || ((v50 >= UINT64_C(48)) && (v50 <= UINT64_C(57))) || (v50 == UINT64_C(45)));
                }
                t134 = t51;
            }
            if (t134) {
                int t53 = (UINT64_C(23) <= v7);
                if (!t53) {
                    t53 = (UINT64_C(23) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t53) {
                    uint64_t v52 = ((uint64_t)v6[UINT64_C(23)]);
                    t53 = ((((v52 | UINT64_C(32)) >= UINT64_C(97)) && ((v52 | UINT64_C(32)) <= UINT64_C(122))) || ((v52 >= UINT64_C(48)) && (v52 <= UINT64_C(57))) || (v52 == UINT64_C(45)));
                }
                t134 = t53;
            }
            if (t134) {
                int t55 = (UINT64_C(24) <= v7);
                if (!t55) {
                    t55 = (UINT64_C(24) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t55) {
                    uint64_t v54 = ((uint64_t)v6[UINT64_C(24)]);
                    t55 = ((((v54 | UINT64_C(32)) >= UINT64_C(97)) && ((v54 | UINT64_C(32)) <= UINT64_C(122))) || ((v54 >= UINT64_C(48)) && (v54 <= UINT64_C(57))) || (v54 == UINT64_C(45)));
                }
                t134 = t55;
            }
            if (t134) {
                int t57 = (UINT64_C(25) <= v7);
                if (!t57) {
                    t57 = (UINT64_C(25) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t57) {
                    uint64_t v56 = ((uint64_t)v6[UINT64_C(25)]);
                    t57 = ((((v56 | UINT64_C(32)) >= UINT64_C(97)) && ((v56 | UINT64_C(32)) <= UINT64_C(122))) || ((v56 >= UINT64_C(48)) && (v56 <= UINT64_C(57))) || (v56 == UINT64_C(45)));
                }
                t134 = t57;
            }
            if (t134) {
                int t59 = (UINT64_C(26) <= v7);
                if (!t59) {
                    t59 = (UINT64_C(26) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t59) {
                    uint64_t v58 = ((uint64_t)v6[UINT64_C(26)]);
                    t59 = ((((v58 | UINT64_C(32)) >= UINT64_C(97)) && ((v58 | UINT64_C(32)) <= UINT64_C(122))) || ((v58 >= UINT64_C(48)) && (v58 <= UINT64_C(57))) || (v58 == UINT64_C(45)));
                }
                t134 = t59;
            }
            if (t134) {
                int t61 = (UINT64_C(27) <= v7);
                if (!t61) {
                    t61 = (UINT64_C(27) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t61) {
                    uint64_t v60 = ((uint64_t)v6[UINT64_C(27)]);
                    t61 = ((((v60 | UINT64_C(32)) >= UINT64_C(97)) && ((v60 | UINT64_C(32)) <= UINT64_C(122))) || ((v60 >= UINT64_C(48)) && (v60 <= UINT64_C(57))) || (v60 == UINT64_C(45)));
                }
                t134 = t61;
            }
            if (t134) {
                int t63 = (UINT64_C(28) <= v7);
                if (!t63) {
                    t63 = (UINT64_C(28) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t63) {
                    uint64_t v62 = ((uint64_t)v6[UINT64_C(28)]);
                    t63 = ((((v62 | UINT64_C(32)) >= UINT64_C(97)) && ((v62 | UINT64_C(32)) <= UINT64_C(122))) || ((v62 >= UINT64_C(48)) && (v62 <= UINT64_C(57))) || (v62 == UINT64_C(45)));
                }
                t134 = t63;
            }
            if (t134) {
                int t65 = (UINT64_C(29) <= v7);
                if (!t65) {
                    t65 = (UINT64_C(29) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t65) {
                    uint64_t v64 = ((uint64_t)v6[UINT64_C(29)]);
                    t65 = ((((v64 | UINT64_C(32)) >= UINT64_C(97)) && ((v64 | UINT64_C(32)) <= UINT64_C(122))) || ((v64 >= UINT64_C(48)) && (v64 <= UINT64_C(57))) || (v64 == UINT64_C(45)));
                }
                t134 = t65;
            }
            if (t134) {
                int t67 = (UINT64_C(30) <= v7);
                if (!t67) {
                    t67 = (UINT64_C(30) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t67) {
                    uint64_t v66 = ((uint64_t)v6[UINT64_C(30)]);
                    t67 = ((((v66 | UINT64_C(32)) >= UINT64_C(97)) && ((v66 | UINT64_C(32)) <= UINT64_C(122))) || ((v66 >= UINT64_C(48)) && (v66 <= UINT64_C(57))) || (v66 == UINT64_C(45)));
                }
                t134 = t67;
            }
            if (t134) {
                int t69 = (UINT64_C(31) <= v7);
                if (!t69) {
                    t69 = (UINT64_C(31) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t69) {
                    uint64_t v68 = ((uint64_t)v6[UINT64_C(31)]);
                    t69 = ((((v68 | UINT64_C(32)) >= UINT64_C(97)) && ((v68 | UINT64_C(32)) <= UINT64_C(122))) || ((v68 >= UINT64_C(48)) && (v68 <= UINT64_C(57))) || (v68 == UINT64_C(45)));
                }
                t134 = t69;
            }
            if (t134) {
                int t71 = (UINT64_C(32) <= v7);
                if (!t71) {
                    t71 = (UINT64_C(32) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t71) {
                    uint64_t v70 = ((uint64_t)v6[UINT64_C(32)]);
                    t71 = ((((v70 | UINT64_C(32)) >= UINT64_C(97)) && ((v70 | UINT64_C(32)) <= UINT64_C(122))) || ((v70 >= UINT64_C(48)) && (v70 <= UINT64_C(57))) || (v70 == UINT64_C(45)));
                }
                t134 = t71;
            }
            if (t134) {
                int t73 = (UINT64_C(33) <= v7);
                if (!t73) {
                    t73 = (UINT64_C(33) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t73) {
                    uint64_t v72 = ((uint64_t)v6[UINT64_C(33)]);
                    t73 = ((((v72 | UINT64_C(32)) >= UINT64_C(97)) && ((v72 | UINT64_C(32)) <= UINT64_C(122))) || ((v72 >= UINT64_C(48)) && (v72 <= UINT64_C(57))) || (v72 == UINT64_C(45)));
                }
                t134 = t73;
            }
            if (t134) {
                int t75 = (UINT64_C(34) <= v7);
                if (!t75) {
                    t75 = (UINT64_C(34) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t75) {
                    uint64_t v74 = ((uint64_t)v6[UINT64_C(34)]);
                    t75 = ((((v74 | UINT64_C(32)) >= UINT64_C(97)) && ((v74 | UINT64_C(32)) <= UINT64_C(122))) || ((v74 >= UINT64_C(48)) && (v74 <= UINT64_C(57))) || (v74 == UINT64_C(45)));
                }
                t134 = t75;
            }
            if (t134) {
                int t77 = (UINT64_C(35) <= v7);
                if (!t77) {
                    t77 = (UINT64_C(35) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t77) {
                    uint64_t v76 = ((uint64_t)v6[UINT64_C(35)]);
                    t77 = ((((v76 | UINT64_C(32)) >= UINT64_C(97)) && ((v76 | UINT64_C(32)) <= UINT64_C(122))) || ((v76 >= UINT64_C(48)) && (v76 <= UINT64_C(57))) || (v76 == UINT64_C(45)));
                }
                t134 = t77;
            }
            if (t134) {
                int t79 = (UINT64_C(36) <= v7);
                if (!t79) {
                    t79 = (UINT64_C(36) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t79) {
                    uint64_t v78 = ((uint64_t)v6[UINT64_C(36)]);
                    t79 = ((((v78 | UINT64_C(32)) >= UINT64_C(97)) && ((v78 | UINT64_C(32)) <= UINT64_C(122))) || ((v78 >= UINT64_C(48)) && (v78 <= UINT64_C(57))) || (v78 == UINT64_C(45)));
                }
                t134 = t79;
            }
            if (t134) {
                int t81 = (UINT64_C(37) <= v7);
                if (!t81) {
                    t81 = (UINT64_C(37) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t81) {
                    uint64_t v80 = ((uint64_t)v6[UINT64_C(37)]);
                    t81 = ((((v80 | UINT64_C(32)) >= UINT64_C(97)) && ((v80 | UINT64_C(32)) <= UINT64_C(122))) || ((v80 >= UINT64_C(48)) && (v80 <= UINT64_C(57))) || (v80 == UINT64_C(45)));
                }
                t134 = t81;
            }
            if (t134) {
                int t83 = (UINT64_C(38) <= v7);
                if (!t83) {
                    t83 = (UINT64_C(38) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t83) {
                    uint64_t v82 = ((uint64_t)v6[UINT64_C(38)]);
                    t83 = ((((v82 | UINT64_C(32)) >= UINT64_C(97)) && ((v82 | UINT64_C(32)) <= UINT64_C(122))) || ((v82 >= UINT64_C(48)) && (v82 <= UINT64_C(57))) || (v82 == UINT64_C(45)));
                }
                t134 = t83;
            }
            if (t134) {
                int t85 = (UINT64_C(39) <= v7);
                if (!t85) {
                    t85 = (UINT64_C(39) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t85) {
                    uint64_t v84 = ((uint64_t)v6[UINT64_C(39)]);
                    t85 = ((((v84 | UINT64_C(32)) >= UINT64_C(97)) && ((v84 | UINT64_C(32)) <= UINT64_C(122))) || ((v84 >= UINT64_C(48)) && (v84 <= UINT64_C(57))) || (v84 == UINT64_C(45)));
                }
                t134 = t85;
            }
            if (t134) {
                int t87 = (UINT64_C(40) <= v7);
                if (!t87) {
                    t87 = (UINT64_C(40) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t87) {
                    uint64_t v86 = ((uint64_t)v6[UINT64_C(40)]);
                    t87 = ((((v86 | UINT64_C(32)) >= UINT64_C(97)) && ((v86 | UINT64_C(32)) <= UINT64_C(122))) || ((v86 >= UINT64_C(48)) && (v86 <= UINT64_C(57))) || (v86 == UINT64_C(45)));
                }
                t134 = t87;
            }
            if (t134) {
                int t89 = (UINT64_C(41) <= v7);
                if (!t89) {
                    t89 = (UINT64_C(41) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t89) {
                    uint64_t v88 = ((uint64_t)v6[UINT64_C(41)]);
                    t89 = ((((v88 | UINT64_C(32)) >= UINT64_C(97)) && ((v88 | UINT64_C(32)) <= UINT64_C(122))) || ((v88 >= UINT64_C(48)) && (v88 <= UINT64_C(57))) || (v88 == UINT64_C(45)));
                }
                t134 = t89;
            }
            if (t134) {
                int t91 = (UINT64_C(42) <= v7);
                if (!t91) {
                    t91 = (UINT64_C(42) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t91) {
                    uint64_t v90 = ((uint64_t)v6[UINT64_C(42)]);
                    t91 = ((((v90 | UINT64_C(32)) >= UINT64_C(97)) && ((v90 | UINT64_C(32)) <= UINT64_C(122))) || ((v90 >= UINT64_C(48)) && (v90 <= UINT64_C(57))) || (v90 == UINT64_C(45)));
                }
                t134 = t91;
            }
            if (t134) {
                int t93 = (UINT64_C(43) <= v7);
                if (!t93) {
                    t93 = (UINT64_C(43) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t93) {
                    uint64_t v92 = ((uint64_t)v6[UINT64_C(43)]);
                    t93 = ((((v92 | UINT64_C(32)) >= UINT64_C(97)) && ((v92 | UINT64_C(32)) <= UINT64_C(122))) || ((v92 >= UINT64_C(48)) && (v92 <= UINT64_C(57))) || (v92 == UINT64_C(45)));
                }
                t134 = t93;
            }
            if (t134) {
                int t95 = (UINT64_C(44) <= v7);
                if (!t95) {
                    t95 = (UINT64_C(44) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t95) {
                    uint64_t v94 = ((uint64_t)v6[UINT64_C(44)]);
                    t95 = ((((v94 | UINT64_C(32)) >= UINT64_C(97)) && ((v94 | UINT64_C(32)) <= UINT64_C(122))) || ((v94 >= UINT64_C(48)) && (v94 <= UINT64_C(57))) || (v94 == UINT64_C(45)));
                }
                t134 = t95;
            }
            if (t134) {
                int t97 = (UINT64_C(45) <= v7);
                if (!t97) {
                    t97 = (UINT64_C(45) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t97) {
                    uint64_t v96 = ((uint64_t)v6[UINT64_C(45)]);
                    t97 = ((((v96 | UINT64_C(32)) >= UINT64_C(97)) && ((v96 | UINT64_C(32)) <= UINT64_C(122))) || ((v96 >= UINT64_C(48)) && (v96 <= UINT64_C(57))) || (v96 == UINT64_C(45)));
                }
                t134 = t97;
            }
            if (t134) {
                int t99 = (UINT64_C(46) <= v7);
                if (!t99) {
                    t99 = (UINT64_C(46) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t99) {
                    uint64_t v98 = ((uint64_t)v6[UINT64_C(46)]);
                    t99 = ((((v98 | UINT64_C(32)) >= UINT64_C(97)) && ((v98 | UINT64_C(32)) <= UINT64_C(122))) || ((v98 >= UINT64_C(48)) && (v98 <= UINT64_C(57))) || (v98 == UINT64_C(45)));
                }
                t134 = t99;
            }
            if (t134) {
                int t101 = (UINT64_C(47) <= v7);
                if (!t101) {
                    t101 = (UINT64_C(47) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t101) {
                    uint64_t v100 = ((uint64_t)v6[UINT64_C(47)]);
                    t101 = ((((v100 | UINT64_C(32)) >= UINT64_C(97)) && ((v100 | UINT64_C(32)) <= UINT64_C(122))) || ((v100 >= UINT64_C(48)) && (v100 <= UINT64_C(57))) || (v100 == UINT64_C(45)));
                }
                t134 = t101;
            }
            if (t134) {
                int t103 = (UINT64_C(48) <= v7);
                if (!t103) {
                    t103 = (UINT64_C(48) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t103) {
                    uint64_t v102 = ((uint64_t)v6[UINT64_C(48)]);
                    t103 = ((((v102 | UINT64_C(32)) >= UINT64_C(97)) && ((v102 | UINT64_C(32)) <= UINT64_C(122))) || ((v102 >= UINT64_C(48)) && (v102 <= UINT64_C(57))) || (v102 == UINT64_C(45)));
                }
                t134 = t103;
            }
            if (t134) {
                int t105 = (UINT64_C(49) <= v7);
                if (!t105) {
                    t105 = (UINT64_C(49) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t105) {
                    uint64_t v104 = ((uint64_t)v6[UINT64_C(49)]);
                    t105 = ((((v104 | UINT64_C(32)) >= UINT64_C(97)) && ((v104 | UINT64_C(32)) <= UINT64_C(122))) || ((v104 >= UINT64_C(48)) && (v104 <= UINT64_C(57))) || (v104 == UINT64_C(45)));
                }
                t134 = t105;
            }
            if (t134) {
                int t107 = (UINT64_C(50) <= v7);
                if (!t107) {
                    t107 = (UINT64_C(50) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t107) {
                    uint64_t v106 = ((uint64_t)v6[UINT64_C(50)]);
                    t107 = ((((v106 | UINT64_C(32)) >= UINT64_C(97)) && ((v106 | UINT64_C(32)) <= UINT64_C(122))) || ((v106 >= UINT64_C(48)) && (v106 <= UINT64_C(57))) || (v106 == UINT64_C(45)));
                }
                t134 = t107;
            }
            if (t134) {
                int t109 = (UINT64_C(51) <= v7);
                if (!t109) {
                    t109 = (UINT64_C(51) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t109) {
                    uint64_t v108 = ((uint64_t)v6[UINT64_C(51)]);
                    t109 = ((((v108 | UINT64_C(32)) >= UINT64_C(97)) && ((v108 | UINT64_C(32)) <= UINT64_C(122))) || ((v108 >= UINT64_C(48)) && (v108 <= UINT64_C(57))) || (v108 == UINT64_C(45)));
                }
                t134 = t109;
            }
            if (t134) {
                int t111 = (UINT64_C(52) <= v7);
                if (!t111) {
                    t111 = (UINT64_C(52) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t111) {
                    uint64_t v110 = ((uint64_t)v6[UINT64_C(52)]);
                    t111 = ((((v110 | UINT64_C(32)) >= UINT64_C(97)) && ((v110 | UINT64_C(32)) <= UINT64_C(122))) || ((v110 >= UINT64_C(48)) && (v110 <= UINT64_C(57))) || (v110 == UINT64_C(45)));
                }
                t134 = t111;
            }
            if (t134) {
                int t113 = (UINT64_C(53) <= v7);
                if (!t113) {
                    t113 = (UINT64_C(53) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t113) {
                    uint64_t v112 = ((uint64_t)v6[UINT64_C(53)]);
                    t113 = ((((v112 | UINT64_C(32)) >= UINT64_C(97)) && ((v112 | UINT64_C(32)) <= UINT64_C(122))) || ((v112 >= UINT64_C(48)) && (v112 <= UINT64_C(57))) || (v112 == UINT64_C(45)));
                }
                t134 = t113;
            }
            if (t134) {
                int t115 = (UINT64_C(54) <= v7);
                if (!t115) {
                    t115 = (UINT64_C(54) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t115) {
                    uint64_t v114 = ((uint64_t)v6[UINT64_C(54)]);
                    t115 = ((((v114 | UINT64_C(32)) >= UINT64_C(97)) && ((v114 | UINT64_C(32)) <= UINT64_C(122))) || ((v114 >= UINT64_C(48)) && (v114 <= UINT64_C(57))) || (v114 == UINT64_C(45)));
                }
                t134 = t115;
            }
            if (t134) {
                int t117 = (UINT64_C(55) <= v7);
                if (!t117) {
                    t117 = (UINT64_C(55) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t117) {
                    uint64_t v116 = ((uint64_t)v6[UINT64_C(55)]);
                    t117 = ((((v116 | UINT64_C(32)) >= UINT64_C(97)) && ((v116 | UINT64_C(32)) <= UINT64_C(122))) || ((v116 >= UINT64_C(48)) && (v116 <= UINT64_C(57))) || (v116 == UINT64_C(45)));
                }
                t134 = t117;
            }
            if (t134) {
                int t119 = (UINT64_C(56) <= v7);
                if (!t119) {
                    t119 = (UINT64_C(56) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t119) {
                    uint64_t v118 = ((uint64_t)v6[UINT64_C(56)]);
                    t119 = ((((v118 | UINT64_C(32)) >= UINT64_C(97)) && ((v118 | UINT64_C(32)) <= UINT64_C(122))) || ((v118 >= UINT64_C(48)) && (v118 <= UINT64_C(57))) || (v118 == UINT64_C(45)));
                }
                t134 = t119;
            }
            if (t134) {
                int t121 = (UINT64_C(57) <= v7);
                if (!t121) {
                    t121 = (UINT64_C(57) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t121) {
                    uint64_t v120 = ((uint64_t)v6[UINT64_C(57)]);
                    t121 = ((((v120 | UINT64_C(32)) >= UINT64_C(97)) && ((v120 | UINT64_C(32)) <= UINT64_C(122))) || ((v120 >= UINT64_C(48)) && (v120 <= UINT64_C(57))) || (v120 == UINT64_C(45)));
                }
                t134 = t121;
            }
            if (t134) {
                int t123 = (UINT64_C(58) <= v7);
                if (!t123) {
                    t123 = (UINT64_C(58) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t123) {
                    uint64_t v122 = ((uint64_t)v6[UINT64_C(58)]);
                    t123 = ((((v122 | UINT64_C(32)) >= UINT64_C(97)) && ((v122 | UINT64_C(32)) <= UINT64_C(122))) || ((v122 >= UINT64_C(48)) && (v122 <= UINT64_C(57))) || (v122 == UINT64_C(45)));
                }
                t134 = t123;
            }
            if (t134) {
                int t125 = (UINT64_C(59) <= v7);
                if (!t125) {
                    t125 = (UINT64_C(59) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t125) {
                    uint64_t v124 = ((uint64_t)v6[UINT64_C(59)]);
                    t125 = ((((v124 | UINT64_C(32)) >= UINT64_C(97)) && ((v124 | UINT64_C(32)) <= UINT64_C(122))) || ((v124 >= UINT64_C(48)) && (v124 <= UINT64_C(57))) || (v124 == UINT64_C(45)));
                }
                t134 = t125;
            }
            if (t134) {
                int t127 = (UINT64_C(60) <= v7);
                if (!t127) {
                    t127 = (UINT64_C(60) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t127) {
                    uint64_t v126 = ((uint64_t)v6[UINT64_C(60)]);
                    t127 = ((((v126 | UINT64_C(32)) >= UINT64_C(97)) && ((v126 | UINT64_C(32)) <= UINT64_C(122))) || ((v126 >= UINT64_C(48)) && (v126 <= UINT64_C(57))) || (v126 == UINT64_C(45)));
                }
                t134 = t127;
            }
            if (t134) {
                int t129 = (UINT64_C(61) <= v7);
                if (!t129) {
                    t129 = (UINT64_C(61) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t129) {
                    uint64_t v128 = ((uint64_t)v6[UINT64_C(61)]);
                    t129 = ((((v128 | UINT64_C(32)) >= UINT64_C(97)) && ((v128 | UINT64_C(32)) <= UINT64_C(122))) || ((v128 >= UINT64_C(48)) && (v128 <= UINT64_C(57))) || (v128 == UINT64_C(45)));
                }
                t134 = t129;
            }
            if (t134) {
                int t131 = (UINT64_C(62) <= v7);
                if (!t131) {
                    t131 = (UINT64_C(62) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t131) {
                    uint64_t v130 = ((uint64_t)v6[UINT64_C(62)]);
                    t131 = ((((v130 | UINT64_C(32)) >= UINT64_C(97)) && ((v130 | UINT64_C(32)) <= UINT64_C(122))) || ((v130 >= UINT64_C(48)) && (v130 <= UINT64_C(57))) || (v130 == UINT64_C(45)));
                }
                t134 = t131;
            }
            if (t134) {
                int t133 = (UINT64_C(63) <= v7);
                if (!t133) {
                    t133 = (UINT64_C(63) > ((v7 + ((uint64_t)((uint64_t)v6[v7]))) & UINT64_C(0xffff)));
                }
                if (!t133) {
                    uint64_t v132 = ((uint64_t)v6[UINT64_C(63)]);
                    t133 = ((((v132 | UINT64_C(32)) >= UINT64_C(97)) && ((v132 | UINT64_C(32)) <= UINT64_C(122))) || ((v132 >= UINT64_C(48)) && (v132 <= UINT64_C(57))) || (v132 == UINT64_C(45)));
                }
                t134 = t133;
            }
            t135 = t134;
        }
        uint64_t n136 = (t135 ? ((((((v4 >> 8) + UINT64_C(1)) & UINT64_C(0xffff)) << 8) & UINT64_C(0xffff)) | ((((v5 + UINT64_C(1)) & UINT64_C(0xffff)) + ((uint64_t)((uint64_t)v3[v5]))) & UINT64_C(0xffff))) : v4);
        if (n136 == f1) break;
        f1 = n136;
    }
    uint64_t v137 = f1;
    uint64_t v138 = (v137 & UINT64_C(255));
    uint64_t v139 = (((uint64_t)(v137 >> 8)) & UINT64_C(255));
    int o140_tag;
    uint64_t o140_0 = 0;
    uint64_t o140_1 = 0;
    uint64_t o140_2 = 0;
    if ((v138 >= ((uint64_t)((uint64_t)in_b_len)))) {
        o140_tag = 0;
        o140_0 = 0;
        o140_1 = 0;
        o140_2 = 0;
    } else {
        uint64_t v141 = ((uint64_t)in_b[v138]);
        int o142_tag;
        uint64_t o142_0 = 0;
        uint64_t o142_1 = 0;
        uint64_t o142_2 = 0;
        if ((v141 == UINT64_C(0))) {
            o142_tag = 1;
            o142_0 = (((uint64_t)((v138 + UINT64_C(1)) & UINT64_C(0xffff))) & UINT64_C(255));
            o142_1 = v139;
            o142_2 = UINT64_C(0xffff);
        } else {
            int o143_tag;
            uint64_t o143_0 = 0;
            uint64_t o143_1 = 0;
            uint64_t o143_2 = 0;
            if ((((v141 & UINT64_C(192)) == UINT64_C(192)) && (((v138 + UINT64_C(1)) & UINT64_C(0xffff)) < ((uint64_t)((uint64_t)in_b_len))))) {
                o143_tag = 1;
                o143_0 = (((uint64_t)((v138 + UINT64_C(2)) & UINT64_C(0xffff))) & UINT64_C(255));
                o143_1 = v139;
                o143_2 = (((((uint64_t)(v141 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[((v138 + UINT64_C(1)) & UINT64_C(0xffff))])));
            } else {
                o143_tag = 0;
                o143_0 = 0;
                o143_1 = 0;
                o143_2 = 0;
            }
            o142_tag = o143_tag;
            o142_0 = o143_0;
            o142_1 = o143_1;
            o142_2 = o143_2;
        }
        o140_tag = o142_tag;
        o140_0 = o142_0;
        o140_1 = o142_1;
        o140_2 = o142_2;
    }
    if (o140_tag) {
        *out0 = (uint64_t)(o140_0);
        *out1 = (uint64_t)(o140_1);
        *out2 = (uint64_t)(o140_2);
    }
    return o140_tag;
}

int efch_dns_hostname_wire__lang(const uint8_t *in_b, size_t in_b_len, uint64_t *out0, uint64_t *out1, uint64_t *out2)
{
    uint64_t f1 = UINT64_C(0);
    for (int k2 = 0; k2 < 32; k2++) {
        uint64_t v3_n = ((uint64_t)in_b_len);
        const uint8_t *v3 = in_b;
        uint64_t v4 = f1;
        uint64_t v5 = (v4 & UINT64_C(255));
        uint64_t t198;
        if ((v5 >= ((uint64_t)v3_n))) {
            t198 = v4;
        } else {
            uint64_t v6 = ((uint64_t)v3[v5]);
            uint64_t t197;
            if ((((v6 < UINT64_C(1)) || (v6 > UINT64_C(63))) || (((v5 + ((uint64_t)v6)) & UINT64_C(0xffff)) >= ((uint64_t)v3_n)))) {
                t197 = v4;
            } else {
                uint64_t t196;
                if (((((uint64_t)v3[((v5 + UINT64_C(1)) & UINT64_C(0xffff))]) == UINT64_C(45)) || (((uint64_t)v3[((v5 + ((uint64_t)v6)) & UINT64_C(0xffff))]) == UINT64_C(45)))) {
                    t196 = v4;
                } else {
                    uint64_t v7 = ((((((v4 >> 8) + UINT64_C(1)) & UINT64_C(0xffff)) << 8) & UINT64_C(0xffff)) | ((((v5 + UINT64_C(1)) & UINT64_C(0xffff)) + ((uint64_t)v6)) & UINT64_C(0xffff)));
                    uint64_t t195;
                    if ((UINT64_C(1) > v6)) {
                        t195 = v7;
                    } else {
                        uint64_t v8 = ((uint64_t)v3[((v5 + UINT64_C(1)) & UINT64_C(0xffff))]);
                        uint64_t t194;
                        if ((!(((((v8 | UINT64_C(32)) >= UINT64_C(97)) && ((v8 | UINT64_C(32)) <= UINT64_C(122))) || ((v8 >= UINT64_C(48)) && (v8 <= UINT64_C(57)))) || (v8 == UINT64_C(45))))) {
                            t194 = v4;
                        } else {
                            uint64_t t193;
                            if ((UINT64_C(2) > v6)) {
                                t193 = v7;
                            } else {
                                uint64_t v9 = ((uint64_t)v3[((v5 + UINT64_C(2)) & UINT64_C(0xffff))]);
                                uint64_t t192;
                                if ((!(((((v9 | UINT64_C(32)) >= UINT64_C(97)) && ((v9 | UINT64_C(32)) <= UINT64_C(122))) || ((v9 >= UINT64_C(48)) && (v9 <= UINT64_C(57)))) || (v9 == UINT64_C(45))))) {
                                    t192 = v4;
                                } else {
                                    uint64_t t191;
                                    if ((UINT64_C(3) > v6)) {
                                        t191 = v7;
                                    } else {
                                        uint64_t v10 = ((uint64_t)v3[((v5 + UINT64_C(3)) & UINT64_C(0xffff))]);
                                        uint64_t t190;
                                        if ((!(((((v10 | UINT64_C(32)) >= UINT64_C(97)) && ((v10 | UINT64_C(32)) <= UINT64_C(122))) || ((v10 >= UINT64_C(48)) && (v10 <= UINT64_C(57)))) || (v10 == UINT64_C(45))))) {
                                            t190 = v4;
                                        } else {
                                            uint64_t t189;
                                            if ((UINT64_C(4) > v6)) {
                                                t189 = v7;
                                            } else {
                                                uint64_t v11 = ((uint64_t)v3[((v5 + UINT64_C(4)) & UINT64_C(0xffff))]);
                                                uint64_t t188;
                                                if ((!(((((v11 | UINT64_C(32)) >= UINT64_C(97)) && ((v11 | UINT64_C(32)) <= UINT64_C(122))) || ((v11 >= UINT64_C(48)) && (v11 <= UINT64_C(57)))) || (v11 == UINT64_C(45))))) {
                                                    t188 = v4;
                                                } else {
                                                    uint64_t t187;
                                                    if ((UINT64_C(5) > v6)) {
                                                        t187 = v7;
                                                    } else {
                                                        uint64_t v12 = ((uint64_t)v3[((v5 + UINT64_C(5)) & UINT64_C(0xffff))]);
                                                        uint64_t t186;
                                                        if ((!(((((v12 | UINT64_C(32)) >= UINT64_C(97)) && ((v12 | UINT64_C(32)) <= UINT64_C(122))) || ((v12 >= UINT64_C(48)) && (v12 <= UINT64_C(57)))) || (v12 == UINT64_C(45))))) {
                                                            t186 = v4;
                                                        } else {
                                                            uint64_t t185;
                                                            if ((UINT64_C(6) > v6)) {
                                                                t185 = v7;
                                                            } else {
                                                                uint64_t v13 = ((uint64_t)v3[((v5 + UINT64_C(6)) & UINT64_C(0xffff))]);
                                                                uint64_t t184;
                                                                if ((!(((((v13 | UINT64_C(32)) >= UINT64_C(97)) && ((v13 | UINT64_C(32)) <= UINT64_C(122))) || ((v13 >= UINT64_C(48)) && (v13 <= UINT64_C(57)))) || (v13 == UINT64_C(45))))) {
                                                                    t184 = v4;
                                                                } else {
                                                                    uint64_t t183;
                                                                    if ((UINT64_C(7) > v6)) {
                                                                        t183 = v7;
                                                                    } else {
                                                                        uint64_t v14 = ((uint64_t)v3[((v5 + UINT64_C(7)) & UINT64_C(0xffff))]);
                                                                        uint64_t t182;
                                                                        if ((!(((((v14 | UINT64_C(32)) >= UINT64_C(97)) && ((v14 | UINT64_C(32)) <= UINT64_C(122))) || ((v14 >= UINT64_C(48)) && (v14 <= UINT64_C(57)))) || (v14 == UINT64_C(45))))) {
                                                                            t182 = v4;
                                                                        } else {
                                                                            uint64_t t181;
                                                                            if ((UINT64_C(8) > v6)) {
                                                                                t181 = v7;
                                                                            } else {
                                                                                uint64_t v15 = ((uint64_t)v3[((v5 + UINT64_C(8)) & UINT64_C(0xffff))]);
                                                                                uint64_t t180;
                                                                                if ((!(((((v15 | UINT64_C(32)) >= UINT64_C(97)) && ((v15 | UINT64_C(32)) <= UINT64_C(122))) || ((v15 >= UINT64_C(48)) && (v15 <= UINT64_C(57)))) || (v15 == UINT64_C(45))))) {
                                                                                    t180 = v4;
                                                                                } else {
                                                                                    uint64_t t179;
                                                                                    if ((UINT64_C(9) > v6)) {
                                                                                        t179 = v7;
                                                                                    } else {
                                                                                        uint64_t v16 = ((uint64_t)v3[((v5 + UINT64_C(9)) & UINT64_C(0xffff))]);
                                                                                        uint64_t t178;
                                                                                        if ((!(((((v16 | UINT64_C(32)) >= UINT64_C(97)) && ((v16 | UINT64_C(32)) <= UINT64_C(122))) || ((v16 >= UINT64_C(48)) && (v16 <= UINT64_C(57)))) || (v16 == UINT64_C(45))))) {
                                                                                            t178 = v4;
                                                                                        } else {
                                                                                            uint64_t t177;
                                                                                            if ((UINT64_C(10) > v6)) {
                                                                                                t177 = v7;
                                                                                            } else {
                                                                                                uint64_t v17 = ((uint64_t)v3[((v5 + UINT64_C(10)) & UINT64_C(0xffff))]);
                                                                                                uint64_t t176;
                                                                                                if ((!(((((v17 | UINT64_C(32)) >= UINT64_C(97)) && ((v17 | UINT64_C(32)) <= UINT64_C(122))) || ((v17 >= UINT64_C(48)) && (v17 <= UINT64_C(57)))) || (v17 == UINT64_C(45))))) {
                                                                                                    t176 = v4;
                                                                                                } else {
                                                                                                    uint64_t t175;
                                                                                                    if ((UINT64_C(11) > v6)) {
                                                                                                        t175 = v7;
                                                                                                    } else {
                                                                                                        uint64_t v18 = ((uint64_t)v3[((v5 + UINT64_C(11)) & UINT64_C(0xffff))]);
                                                                                                        uint64_t t174;
                                                                                                        if ((!(((((v18 | UINT64_C(32)) >= UINT64_C(97)) && ((v18 | UINT64_C(32)) <= UINT64_C(122))) || ((v18 >= UINT64_C(48)) && (v18 <= UINT64_C(57)))) || (v18 == UINT64_C(45))))) {
                                                                                                            t174 = v4;
                                                                                                        } else {
                                                                                                            uint64_t t173;
                                                                                                            if ((UINT64_C(12) > v6)) {
                                                                                                                t173 = v7;
                                                                                                            } else {
                                                                                                                uint64_t v19 = ((uint64_t)v3[((v5 + UINT64_C(12)) & UINT64_C(0xffff))]);
                                                                                                                uint64_t t172;
                                                                                                                if ((!(((((v19 | UINT64_C(32)) >= UINT64_C(97)) && ((v19 | UINT64_C(32)) <= UINT64_C(122))) || ((v19 >= UINT64_C(48)) && (v19 <= UINT64_C(57)))) || (v19 == UINT64_C(45))))) {
                                                                                                                    t172 = v4;
                                                                                                                } else {
                                                                                                                    uint64_t t171;
                                                                                                                    if ((UINT64_C(13) > v6)) {
                                                                                                                        t171 = v7;
                                                                                                                    } else {
                                                                                                                        uint64_t v20 = ((uint64_t)v3[((v5 + UINT64_C(13)) & UINT64_C(0xffff))]);
                                                                                                                        uint64_t t170;
                                                                                                                        if ((!(((((v20 | UINT64_C(32)) >= UINT64_C(97)) && ((v20 | UINT64_C(32)) <= UINT64_C(122))) || ((v20 >= UINT64_C(48)) && (v20 <= UINT64_C(57)))) || (v20 == UINT64_C(45))))) {
                                                                                                                            t170 = v4;
                                                                                                                        } else {
                                                                                                                            uint64_t t169;
                                                                                                                            if ((UINT64_C(14) > v6)) {
                                                                                                                                t169 = v7;
                                                                                                                            } else {
                                                                                                                                uint64_t v21 = ((uint64_t)v3[((v5 + UINT64_C(14)) & UINT64_C(0xffff))]);
                                                                                                                                uint64_t t168;
                                                                                                                                if ((!(((((v21 | UINT64_C(32)) >= UINT64_C(97)) && ((v21 | UINT64_C(32)) <= UINT64_C(122))) || ((v21 >= UINT64_C(48)) && (v21 <= UINT64_C(57)))) || (v21 == UINT64_C(45))))) {
                                                                                                                                    t168 = v4;
                                                                                                                                } else {
                                                                                                                                    uint64_t t167;
                                                                                                                                    if ((UINT64_C(15) > v6)) {
                                                                                                                                        t167 = v7;
                                                                                                                                    } else {
                                                                                                                                        uint64_t v22 = ((uint64_t)v3[((v5 + UINT64_C(15)) & UINT64_C(0xffff))]);
                                                                                                                                        uint64_t t166;
                                                                                                                                        if ((!(((((v22 | UINT64_C(32)) >= UINT64_C(97)) && ((v22 | UINT64_C(32)) <= UINT64_C(122))) || ((v22 >= UINT64_C(48)) && (v22 <= UINT64_C(57)))) || (v22 == UINT64_C(45))))) {
                                                                                                                                            t166 = v4;
                                                                                                                                        } else {
                                                                                                                                            uint64_t t165;
                                                                                                                                            if ((UINT64_C(16) > v6)) {
                                                                                                                                                t165 = v7;
                                                                                                                                            } else {
                                                                                                                                                uint64_t v23 = ((uint64_t)v3[((v5 + UINT64_C(16)) & UINT64_C(0xffff))]);
                                                                                                                                                uint64_t t164;
                                                                                                                                                if ((!(((((v23 | UINT64_C(32)) >= UINT64_C(97)) && ((v23 | UINT64_C(32)) <= UINT64_C(122))) || ((v23 >= UINT64_C(48)) && (v23 <= UINT64_C(57)))) || (v23 == UINT64_C(45))))) {
                                                                                                                                                    t164 = v4;
                                                                                                                                                } else {
                                                                                                                                                    uint64_t t163;
                                                                                                                                                    if ((UINT64_C(17) > v6)) {
                                                                                                                                                        t163 = v7;
                                                                                                                                                    } else {
                                                                                                                                                        uint64_t v24 = ((uint64_t)v3[((v5 + UINT64_C(17)) & UINT64_C(0xffff))]);
                                                                                                                                                        uint64_t t162;
                                                                                                                                                        if ((!(((((v24 | UINT64_C(32)) >= UINT64_C(97)) && ((v24 | UINT64_C(32)) <= UINT64_C(122))) || ((v24 >= UINT64_C(48)) && (v24 <= UINT64_C(57)))) || (v24 == UINT64_C(45))))) {
                                                                                                                                                            t162 = v4;
                                                                                                                                                        } else {
                                                                                                                                                            uint64_t t161;
                                                                                                                                                            if ((UINT64_C(18) > v6)) {
                                                                                                                                                                t161 = v7;
                                                                                                                                                            } else {
                                                                                                                                                                uint64_t v25 = ((uint64_t)v3[((v5 + UINT64_C(18)) & UINT64_C(0xffff))]);
                                                                                                                                                                uint64_t t160;
                                                                                                                                                                if ((!(((((v25 | UINT64_C(32)) >= UINT64_C(97)) && ((v25 | UINT64_C(32)) <= UINT64_C(122))) || ((v25 >= UINT64_C(48)) && (v25 <= UINT64_C(57)))) || (v25 == UINT64_C(45))))) {
                                                                                                                                                                    t160 = v4;
                                                                                                                                                                } else {
                                                                                                                                                                    uint64_t t159;
                                                                                                                                                                    if ((UINT64_C(19) > v6)) {
                                                                                                                                                                        t159 = v7;
                                                                                                                                                                    } else {
                                                                                                                                                                        uint64_t v26 = ((uint64_t)v3[((v5 + UINT64_C(19)) & UINT64_C(0xffff))]);
                                                                                                                                                                        uint64_t t158;
                                                                                                                                                                        if ((!(((((v26 | UINT64_C(32)) >= UINT64_C(97)) && ((v26 | UINT64_C(32)) <= UINT64_C(122))) || ((v26 >= UINT64_C(48)) && (v26 <= UINT64_C(57)))) || (v26 == UINT64_C(45))))) {
                                                                                                                                                                            t158 = v4;
                                                                                                                                                                        } else {
                                                                                                                                                                            uint64_t t157;
                                                                                                                                                                            if ((UINT64_C(20) > v6)) {
                                                                                                                                                                                t157 = v7;
                                                                                                                                                                            } else {
                                                                                                                                                                                uint64_t v27 = ((uint64_t)v3[((v5 + UINT64_C(20)) & UINT64_C(0xffff))]);
                                                                                                                                                                                uint64_t t156;
                                                                                                                                                                                if ((!(((((v27 | UINT64_C(32)) >= UINT64_C(97)) && ((v27 | UINT64_C(32)) <= UINT64_C(122))) || ((v27 >= UINT64_C(48)) && (v27 <= UINT64_C(57)))) || (v27 == UINT64_C(45))))) {
                                                                                                                                                                                    t156 = v4;
                                                                                                                                                                                } else {
                                                                                                                                                                                    uint64_t t155;
                                                                                                                                                                                    if ((UINT64_C(21) > v6)) {
                                                                                                                                                                                        t155 = v7;
                                                                                                                                                                                    } else {
                                                                                                                                                                                        uint64_t v28 = ((uint64_t)v3[((v5 + UINT64_C(21)) & UINT64_C(0xffff))]);
                                                                                                                                                                                        uint64_t t154;
                                                                                                                                                                                        if ((!(((((v28 | UINT64_C(32)) >= UINT64_C(97)) && ((v28 | UINT64_C(32)) <= UINT64_C(122))) || ((v28 >= UINT64_C(48)) && (v28 <= UINT64_C(57)))) || (v28 == UINT64_C(45))))) {
                                                                                                                                                                                            t154 = v4;
                                                                                                                                                                                        } else {
                                                                                                                                                                                            uint64_t t153;
                                                                                                                                                                                            if ((UINT64_C(22) > v6)) {
                                                                                                                                                                                                t153 = v7;
                                                                                                                                                                                            } else {
                                                                                                                                                                                                uint64_t v29 = ((uint64_t)v3[((v5 + UINT64_C(22)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                uint64_t t152;
                                                                                                                                                                                                if ((!(((((v29 | UINT64_C(32)) >= UINT64_C(97)) && ((v29 | UINT64_C(32)) <= UINT64_C(122))) || ((v29 >= UINT64_C(48)) && (v29 <= UINT64_C(57)))) || (v29 == UINT64_C(45))))) {
                                                                                                                                                                                                    t152 = v4;
                                                                                                                                                                                                } else {
                                                                                                                                                                                                    uint64_t t151;
                                                                                                                                                                                                    if ((UINT64_C(23) > v6)) {
                                                                                                                                                                                                        t151 = v7;
                                                                                                                                                                                                    } else {
                                                                                                                                                                                                        uint64_t v30 = ((uint64_t)v3[((v5 + UINT64_C(23)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                        uint64_t t150;
                                                                                                                                                                                                        if ((!(((((v30 | UINT64_C(32)) >= UINT64_C(97)) && ((v30 | UINT64_C(32)) <= UINT64_C(122))) || ((v30 >= UINT64_C(48)) && (v30 <= UINT64_C(57)))) || (v30 == UINT64_C(45))))) {
                                                                                                                                                                                                            t150 = v4;
                                                                                                                                                                                                        } else {
                                                                                                                                                                                                            uint64_t t149;
                                                                                                                                                                                                            if ((UINT64_C(24) > v6)) {
                                                                                                                                                                                                                t149 = v7;
                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                uint64_t v31 = ((uint64_t)v3[((v5 + UINT64_C(24)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                uint64_t t148;
                                                                                                                                                                                                                if ((!(((((v31 | UINT64_C(32)) >= UINT64_C(97)) && ((v31 | UINT64_C(32)) <= UINT64_C(122))) || ((v31 >= UINT64_C(48)) && (v31 <= UINT64_C(57)))) || (v31 == UINT64_C(45))))) {
                                                                                                                                                                                                                    t148 = v4;
                                                                                                                                                                                                                } else {
                                                                                                                                                                                                                    uint64_t t147;
                                                                                                                                                                                                                    if ((UINT64_C(25) > v6)) {
                                                                                                                                                                                                                        t147 = v7;
                                                                                                                                                                                                                    } else {
                                                                                                                                                                                                                        uint64_t v32 = ((uint64_t)v3[((v5 + UINT64_C(25)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                        uint64_t t146;
                                                                                                                                                                                                                        if ((!(((((v32 | UINT64_C(32)) >= UINT64_C(97)) && ((v32 | UINT64_C(32)) <= UINT64_C(122))) || ((v32 >= UINT64_C(48)) && (v32 <= UINT64_C(57)))) || (v32 == UINT64_C(45))))) {
                                                                                                                                                                                                                            t146 = v4;
                                                                                                                                                                                                                        } else {
                                                                                                                                                                                                                            uint64_t t145;
                                                                                                                                                                                                                            if ((UINT64_C(26) > v6)) {
                                                                                                                                                                                                                                t145 = v7;
                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                uint64_t v33 = ((uint64_t)v3[((v5 + UINT64_C(26)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                uint64_t t144;
                                                                                                                                                                                                                                if ((!(((((v33 | UINT64_C(32)) >= UINT64_C(97)) && ((v33 | UINT64_C(32)) <= UINT64_C(122))) || ((v33 >= UINT64_C(48)) && (v33 <= UINT64_C(57)))) || (v33 == UINT64_C(45))))) {
                                                                                                                                                                                                                                    t144 = v4;
                                                                                                                                                                                                                                } else {
                                                                                                                                                                                                                                    uint64_t t143;
                                                                                                                                                                                                                                    if ((UINT64_C(27) > v6)) {
                                                                                                                                                                                                                                        t143 = v7;
                                                                                                                                                                                                                                    } else {
                                                                                                                                                                                                                                        uint64_t v34 = ((uint64_t)v3[((v5 + UINT64_C(27)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                        uint64_t t142;
                                                                                                                                                                                                                                        if ((!(((((v34 | UINT64_C(32)) >= UINT64_C(97)) && ((v34 | UINT64_C(32)) <= UINT64_C(122))) || ((v34 >= UINT64_C(48)) && (v34 <= UINT64_C(57)))) || (v34 == UINT64_C(45))))) {
                                                                                                                                                                                                                                            t142 = v4;
                                                                                                                                                                                                                                        } else {
                                                                                                                                                                                                                                            uint64_t t141;
                                                                                                                                                                                                                                            if ((UINT64_C(28) > v6)) {
                                                                                                                                                                                                                                                t141 = v7;
                                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                                uint64_t v35 = ((uint64_t)v3[((v5 + UINT64_C(28)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                uint64_t t140;
                                                                                                                                                                                                                                                if ((!(((((v35 | UINT64_C(32)) >= UINT64_C(97)) && ((v35 | UINT64_C(32)) <= UINT64_C(122))) || ((v35 >= UINT64_C(48)) && (v35 <= UINT64_C(57)))) || (v35 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                    t140 = v4;
                                                                                                                                                                                                                                                } else {
                                                                                                                                                                                                                                                    uint64_t t139;
                                                                                                                                                                                                                                                    if ((UINT64_C(29) > v6)) {
                                                                                                                                                                                                                                                        t139 = v7;
                                                                                                                                                                                                                                                    } else {
                                                                                                                                                                                                                                                        uint64_t v36 = ((uint64_t)v3[((v5 + UINT64_C(29)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                        uint64_t t138;
                                                                                                                                                                                                                                                        if ((!(((((v36 | UINT64_C(32)) >= UINT64_C(97)) && ((v36 | UINT64_C(32)) <= UINT64_C(122))) || ((v36 >= UINT64_C(48)) && (v36 <= UINT64_C(57)))) || (v36 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                            t138 = v4;
                                                                                                                                                                                                                                                        } else {
                                                                                                                                                                                                                                                            uint64_t t137;
                                                                                                                                                                                                                                                            if ((UINT64_C(30) > v6)) {
                                                                                                                                                                                                                                                                t137 = v7;
                                                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                                                uint64_t v37 = ((uint64_t)v3[((v5 + UINT64_C(30)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                uint64_t t136;
                                                                                                                                                                                                                                                                if ((!(((((v37 | UINT64_C(32)) >= UINT64_C(97)) && ((v37 | UINT64_C(32)) <= UINT64_C(122))) || ((v37 >= UINT64_C(48)) && (v37 <= UINT64_C(57)))) || (v37 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                    t136 = v4;
                                                                                                                                                                                                                                                                } else {
                                                                                                                                                                                                                                                                    uint64_t t135;
                                                                                                                                                                                                                                                                    if ((UINT64_C(31) > v6)) {
                                                                                                                                                                                                                                                                        t135 = v7;
                                                                                                                                                                                                                                                                    } else {
                                                                                                                                                                                                                                                                        uint64_t v38 = ((uint64_t)v3[((v5 + UINT64_C(31)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                        uint64_t t134;
                                                                                                                                                                                                                                                                        if ((!(((((v38 | UINT64_C(32)) >= UINT64_C(97)) && ((v38 | UINT64_C(32)) <= UINT64_C(122))) || ((v38 >= UINT64_C(48)) && (v38 <= UINT64_C(57)))) || (v38 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                            t134 = v4;
                                                                                                                                                                                                                                                                        } else {
                                                                                                                                                                                                                                                                            uint64_t t133;
                                                                                                                                                                                                                                                                            if ((UINT64_C(32) > v6)) {
                                                                                                                                                                                                                                                                                t133 = v7;
                                                                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                                                                uint64_t v39 = ((uint64_t)v3[((v5 + UINT64_C(32)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                uint64_t t132;
                                                                                                                                                                                                                                                                                if ((!(((((v39 | UINT64_C(32)) >= UINT64_C(97)) && ((v39 | UINT64_C(32)) <= UINT64_C(122))) || ((v39 >= UINT64_C(48)) && (v39 <= UINT64_C(57)))) || (v39 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                                    t132 = v4;
                                                                                                                                                                                                                                                                                } else {
                                                                                                                                                                                                                                                                                    uint64_t t131;
                                                                                                                                                                                                                                                                                    if ((UINT64_C(33) > v6)) {
                                                                                                                                                                                                                                                                                        t131 = v7;
                                                                                                                                                                                                                                                                                    } else {
                                                                                                                                                                                                                                                                                        uint64_t v40 = ((uint64_t)v3[((v5 + UINT64_C(33)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                        uint64_t t130;
                                                                                                                                                                                                                                                                                        if ((!(((((v40 | UINT64_C(32)) >= UINT64_C(97)) && ((v40 | UINT64_C(32)) <= UINT64_C(122))) || ((v40 >= UINT64_C(48)) && (v40 <= UINT64_C(57)))) || (v40 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                                            t130 = v4;
                                                                                                                                                                                                                                                                                        } else {
                                                                                                                                                                                                                                                                                            uint64_t t129;
                                                                                                                                                                                                                                                                                            if ((UINT64_C(34) > v6)) {
                                                                                                                                                                                                                                                                                                t129 = v7;
                                                                                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                                                                                uint64_t v41 = ((uint64_t)v3[((v5 + UINT64_C(34)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                                uint64_t t128;
                                                                                                                                                                                                                                                                                                if ((!(((((v41 | UINT64_C(32)) >= UINT64_C(97)) && ((v41 | UINT64_C(32)) <= UINT64_C(122))) || ((v41 >= UINT64_C(48)) && (v41 <= UINT64_C(57)))) || (v41 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                                                    t128 = v4;
                                                                                                                                                                                                                                                                                                } else {
                                                                                                                                                                                                                                                                                                    uint64_t t127;
                                                                                                                                                                                                                                                                                                    if ((UINT64_C(35) > v6)) {
                                                                                                                                                                                                                                                                                                        t127 = v7;
                                                                                                                                                                                                                                                                                                    } else {
                                                                                                                                                                                                                                                                                                        uint64_t v42 = ((uint64_t)v3[((v5 + UINT64_C(35)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                                        uint64_t t126;
                                                                                                                                                                                                                                                                                                        if ((!(((((v42 | UINT64_C(32)) >= UINT64_C(97)) && ((v42 | UINT64_C(32)) <= UINT64_C(122))) || ((v42 >= UINT64_C(48)) && (v42 <= UINT64_C(57)))) || (v42 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                                                            t126 = v4;
                                                                                                                                                                                                                                                                                                        } else {
                                                                                                                                                                                                                                                                                                            uint64_t t125;
                                                                                                                                                                                                                                                                                                            if ((UINT64_C(36) > v6)) {
                                                                                                                                                                                                                                                                                                                t125 = v7;
                                                                                                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                                                                                                uint64_t v43 = ((uint64_t)v3[((v5 + UINT64_C(36)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                                                uint64_t t124;
                                                                                                                                                                                                                                                                                                                if ((!(((((v43 | UINT64_C(32)) >= UINT64_C(97)) && ((v43 | UINT64_C(32)) <= UINT64_C(122))) || ((v43 >= UINT64_C(48)) && (v43 <= UINT64_C(57)))) || (v43 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                                                                    t124 = v4;
                                                                                                                                                                                                                                                                                                                } else {
                                                                                                                                                                                                                                                                                                                    uint64_t t123;
                                                                                                                                                                                                                                                                                                                    if ((UINT64_C(37) > v6)) {
                                                                                                                                                                                                                                                                                                                        t123 = v7;
                                                                                                                                                                                                                                                                                                                    } else {
                                                                                                                                                                                                                                                                                                                        uint64_t v44 = ((uint64_t)v3[((v5 + UINT64_C(37)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                                                        uint64_t t122;
                                                                                                                                                                                                                                                                                                                        if ((!(((((v44 | UINT64_C(32)) >= UINT64_C(97)) && ((v44 | UINT64_C(32)) <= UINT64_C(122))) || ((v44 >= UINT64_C(48)) && (v44 <= UINT64_C(57)))) || (v44 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                                                                            t122 = v4;
                                                                                                                                                                                                                                                                                                                        } else {
                                                                                                                                                                                                                                                                                                                            uint64_t t121;
                                                                                                                                                                                                                                                                                                                            if ((UINT64_C(38) > v6)) {
                                                                                                                                                                                                                                                                                                                                t121 = v7;
                                                                                                                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                                                                                                                uint64_t v45 = ((uint64_t)v3[((v5 + UINT64_C(38)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                                                                uint64_t t120;
                                                                                                                                                                                                                                                                                                                                if ((!(((((v45 | UINT64_C(32)) >= UINT64_C(97)) && ((v45 | UINT64_C(32)) <= UINT64_C(122))) || ((v45 >= UINT64_C(48)) && (v45 <= UINT64_C(57)))) || (v45 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                                                                                    t120 = v4;
                                                                                                                                                                                                                                                                                                                                } else {
                                                                                                                                                                                                                                                                                                                                    uint64_t t119;
                                                                                                                                                                                                                                                                                                                                    if ((UINT64_C(39) > v6)) {
                                                                                                                                                                                                                                                                                                                                        t119 = v7;
                                                                                                                                                                                                                                                                                                                                    } else {
                                                                                                                                                                                                                                                                                                                                        uint64_t v46 = ((uint64_t)v3[((v5 + UINT64_C(39)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                                                                        uint64_t t118;
                                                                                                                                                                                                                                                                                                                                        if ((!(((((v46 | UINT64_C(32)) >= UINT64_C(97)) && ((v46 | UINT64_C(32)) <= UINT64_C(122))) || ((v46 >= UINT64_C(48)) && (v46 <= UINT64_C(57)))) || (v46 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                                                                                            t118 = v4;
                                                                                                                                                                                                                                                                                                                                        } else {
                                                                                                                                                                                                                                                                                                                                            uint64_t t117;
                                                                                                                                                                                                                                                                                                                                            if ((UINT64_C(40) > v6)) {
                                                                                                                                                                                                                                                                                                                                                t117 = v7;
                                                                                                                                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                                                                                                                                uint64_t v47 = ((uint64_t)v3[((v5 + UINT64_C(40)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                                                                                uint64_t t116;
                                                                                                                                                                                                                                                                                                                                                if ((!(((((v47 | UINT64_C(32)) >= UINT64_C(97)) && ((v47 | UINT64_C(32)) <= UINT64_C(122))) || ((v47 >= UINT64_C(48)) && (v47 <= UINT64_C(57)))) || (v47 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                                                                                                    t116 = v4;
                                                                                                                                                                                                                                                                                                                                                } else {
                                                                                                                                                                                                                                                                                                                                                    uint64_t t115;
                                                                                                                                                                                                                                                                                                                                                    if ((UINT64_C(41) > v6)) {
                                                                                                                                                                                                                                                                                                                                                        t115 = v7;
                                                                                                                                                                                                                                                                                                                                                    } else {
                                                                                                                                                                                                                                                                                                                                                        uint64_t v48 = ((uint64_t)v3[((v5 + UINT64_C(41)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                                                                                        uint64_t t114;
                                                                                                                                                                                                                                                                                                                                                        if ((!(((((v48 | UINT64_C(32)) >= UINT64_C(97)) && ((v48 | UINT64_C(32)) <= UINT64_C(122))) || ((v48 >= UINT64_C(48)) && (v48 <= UINT64_C(57)))) || (v48 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                                                                                                            t114 = v4;
                                                                                                                                                                                                                                                                                                                                                        } else {
                                                                                                                                                                                                                                                                                                                                                            uint64_t t113;
                                                                                                                                                                                                                                                                                                                                                            if ((UINT64_C(42) > v6)) {
                                                                                                                                                                                                                                                                                                                                                                t113 = v7;
                                                                                                                                                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                                                                                                                                                uint64_t v49 = ((uint64_t)v3[((v5 + UINT64_C(42)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                                                                                                uint64_t t112;
                                                                                                                                                                                                                                                                                                                                                                if ((!(((((v49 | UINT64_C(32)) >= UINT64_C(97)) && ((v49 | UINT64_C(32)) <= UINT64_C(122))) || ((v49 >= UINT64_C(48)) && (v49 <= UINT64_C(57)))) || (v49 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                                                                                                                    t112 = v4;
                                                                                                                                                                                                                                                                                                                                                                } else {
                                                                                                                                                                                                                                                                                                                                                                    uint64_t t111;
                                                                                                                                                                                                                                                                                                                                                                    if ((UINT64_C(43) > v6)) {
                                                                                                                                                                                                                                                                                                                                                                        t111 = v7;
                                                                                                                                                                                                                                                                                                                                                                    } else {
                                                                                                                                                                                                                                                                                                                                                                        uint64_t v50 = ((uint64_t)v3[((v5 + UINT64_C(43)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                                                                                                        uint64_t t110;
                                                                                                                                                                                                                                                                                                                                                                        if ((!(((((v50 | UINT64_C(32)) >= UINT64_C(97)) && ((v50 | UINT64_C(32)) <= UINT64_C(122))) || ((v50 >= UINT64_C(48)) && (v50 <= UINT64_C(57)))) || (v50 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                                                                                                                            t110 = v4;
                                                                                                                                                                                                                                                                                                                                                                        } else {
                                                                                                                                                                                                                                                                                                                                                                            uint64_t t109;
                                                                                                                                                                                                                                                                                                                                                                            if ((UINT64_C(44) > v6)) {
                                                                                                                                                                                                                                                                                                                                                                                t109 = v7;
                                                                                                                                                                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                                                                                                                                                                uint64_t v51 = ((uint64_t)v3[((v5 + UINT64_C(44)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                                                                                                                uint64_t t108;
                                                                                                                                                                                                                                                                                                                                                                                if ((!(((((v51 | UINT64_C(32)) >= UINT64_C(97)) && ((v51 | UINT64_C(32)) <= UINT64_C(122))) || ((v51 >= UINT64_C(48)) && (v51 <= UINT64_C(57)))) || (v51 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                                                                                                                                    t108 = v4;
                                                                                                                                                                                                                                                                                                                                                                                } else {
                                                                                                                                                                                                                                                                                                                                                                                    uint64_t t107;
                                                                                                                                                                                                                                                                                                                                                                                    if ((UINT64_C(45) > v6)) {
                                                                                                                                                                                                                                                                                                                                                                                        t107 = v7;
                                                                                                                                                                                                                                                                                                                                                                                    } else {
                                                                                                                                                                                                                                                                                                                                                                                        uint64_t v52 = ((uint64_t)v3[((v5 + UINT64_C(45)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                                                                                                                        uint64_t t106;
                                                                                                                                                                                                                                                                                                                                                                                        if ((!(((((v52 | UINT64_C(32)) >= UINT64_C(97)) && ((v52 | UINT64_C(32)) <= UINT64_C(122))) || ((v52 >= UINT64_C(48)) && (v52 <= UINT64_C(57)))) || (v52 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                                                                                                                                            t106 = v4;
                                                                                                                                                                                                                                                                                                                                                                                        } else {
                                                                                                                                                                                                                                                                                                                                                                                            uint64_t t105;
                                                                                                                                                                                                                                                                                                                                                                                            if ((UINT64_C(46) > v6)) {
                                                                                                                                                                                                                                                                                                                                                                                                t105 = v7;
                                                                                                                                                                                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                                                                                                                                                                                uint64_t v53 = ((uint64_t)v3[((v5 + UINT64_C(46)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                                                                                                                                uint64_t t104;
                                                                                                                                                                                                                                                                                                                                                                                                if ((!(((((v53 | UINT64_C(32)) >= UINT64_C(97)) && ((v53 | UINT64_C(32)) <= UINT64_C(122))) || ((v53 >= UINT64_C(48)) && (v53 <= UINT64_C(57)))) || (v53 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                                                                                                                                                    t104 = v4;
                                                                                                                                                                                                                                                                                                                                                                                                } else {
                                                                                                                                                                                                                                                                                                                                                                                                    uint64_t t103;
                                                                                                                                                                                                                                                                                                                                                                                                    if ((UINT64_C(47) > v6)) {
                                                                                                                                                                                                                                                                                                                                                                                                        t103 = v7;
                                                                                                                                                                                                                                                                                                                                                                                                    } else {
                                                                                                                                                                                                                                                                                                                                                                                                        uint64_t v54 = ((uint64_t)v3[((v5 + UINT64_C(47)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                                                                                                                                        uint64_t t102;
                                                                                                                                                                                                                                                                                                                                                                                                        if ((!(((((v54 | UINT64_C(32)) >= UINT64_C(97)) && ((v54 | UINT64_C(32)) <= UINT64_C(122))) || ((v54 >= UINT64_C(48)) && (v54 <= UINT64_C(57)))) || (v54 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                                                                                                                                                            t102 = v4;
                                                                                                                                                                                                                                                                                                                                                                                                        } else {
                                                                                                                                                                                                                                                                                                                                                                                                            uint64_t t101;
                                                                                                                                                                                                                                                                                                                                                                                                            if ((UINT64_C(48) > v6)) {
                                                                                                                                                                                                                                                                                                                                                                                                                t101 = v7;
                                                                                                                                                                                                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                                                                                                                                                                                                uint64_t v55 = ((uint64_t)v3[((v5 + UINT64_C(48)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                                                                                                                                                uint64_t t100;
                                                                                                                                                                                                                                                                                                                                                                                                                if ((!(((((v55 | UINT64_C(32)) >= UINT64_C(97)) && ((v55 | UINT64_C(32)) <= UINT64_C(122))) || ((v55 >= UINT64_C(48)) && (v55 <= UINT64_C(57)))) || (v55 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                                                                                                                                                                    t100 = v4;
                                                                                                                                                                                                                                                                                                                                                                                                                } else {
                                                                                                                                                                                                                                                                                                                                                                                                                    uint64_t t99;
                                                                                                                                                                                                                                                                                                                                                                                                                    if ((UINT64_C(49) > v6)) {
                                                                                                                                                                                                                                                                                                                                                                                                                        t99 = v7;
                                                                                                                                                                                                                                                                                                                                                                                                                    } else {
                                                                                                                                                                                                                                                                                                                                                                                                                        uint64_t v56 = ((uint64_t)v3[((v5 + UINT64_C(49)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                                                                                                                                                        uint64_t t98;
                                                                                                                                                                                                                                                                                                                                                                                                                        if ((!(((((v56 | UINT64_C(32)) >= UINT64_C(97)) && ((v56 | UINT64_C(32)) <= UINT64_C(122))) || ((v56 >= UINT64_C(48)) && (v56 <= UINT64_C(57)))) || (v56 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                                                                                                                                                                            t98 = v4;
                                                                                                                                                                                                                                                                                                                                                                                                                        } else {
                                                                                                                                                                                                                                                                                                                                                                                                                            uint64_t t97;
                                                                                                                                                                                                                                                                                                                                                                                                                            if ((UINT64_C(50) > v6)) {
                                                                                                                                                                                                                                                                                                                                                                                                                                t97 = v7;
                                                                                                                                                                                                                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                                                                                                                                                                                                                uint64_t v57 = ((uint64_t)v3[((v5 + UINT64_C(50)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                                                                                                                                                                uint64_t t96;
                                                                                                                                                                                                                                                                                                                                                                                                                                if ((!(((((v57 | UINT64_C(32)) >= UINT64_C(97)) && ((v57 | UINT64_C(32)) <= UINT64_C(122))) || ((v57 >= UINT64_C(48)) && (v57 <= UINT64_C(57)))) || (v57 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                                                                                                                                                                                    t96 = v4;
                                                                                                                                                                                                                                                                                                                                                                                                                                } else {
                                                                                                                                                                                                                                                                                                                                                                                                                                    uint64_t t95;
                                                                                                                                                                                                                                                                                                                                                                                                                                    if ((UINT64_C(51) > v6)) {
                                                                                                                                                                                                                                                                                                                                                                                                                                        t95 = v7;
                                                                                                                                                                                                                                                                                                                                                                                                                                    } else {
                                                                                                                                                                                                                                                                                                                                                                                                                                        uint64_t v58 = ((uint64_t)v3[((v5 + UINT64_C(51)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                                                                                                                                                                        uint64_t t94;
                                                                                                                                                                                                                                                                                                                                                                                                                                        if ((!(((((v58 | UINT64_C(32)) >= UINT64_C(97)) && ((v58 | UINT64_C(32)) <= UINT64_C(122))) || ((v58 >= UINT64_C(48)) && (v58 <= UINT64_C(57)))) || (v58 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                                                                                                                                                                                            t94 = v4;
                                                                                                                                                                                                                                                                                                                                                                                                                                        } else {
                                                                                                                                                                                                                                                                                                                                                                                                                                            uint64_t t93;
                                                                                                                                                                                                                                                                                                                                                                                                                                            if ((UINT64_C(52) > v6)) {
                                                                                                                                                                                                                                                                                                                                                                                                                                                t93 = v7;
                                                                                                                                                                                                                                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                                                                                                                                                                                                                                uint64_t v59 = ((uint64_t)v3[((v5 + UINT64_C(52)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                                                                                                                                                                                uint64_t t92;
                                                                                                                                                                                                                                                                                                                                                                                                                                                if ((!(((((v59 | UINT64_C(32)) >= UINT64_C(97)) && ((v59 | UINT64_C(32)) <= UINT64_C(122))) || ((v59 >= UINT64_C(48)) && (v59 <= UINT64_C(57)))) || (v59 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                                                                                                                                                                                                    t92 = v4;
                                                                                                                                                                                                                                                                                                                                                                                                                                                } else {
                                                                                                                                                                                                                                                                                                                                                                                                                                                    uint64_t t91;
                                                                                                                                                                                                                                                                                                                                                                                                                                                    if ((UINT64_C(53) > v6)) {
                                                                                                                                                                                                                                                                                                                                                                                                                                                        t91 = v7;
                                                                                                                                                                                                                                                                                                                                                                                                                                                    } else {
                                                                                                                                                                                                                                                                                                                                                                                                                                                        uint64_t v60 = ((uint64_t)v3[((v5 + UINT64_C(53)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                                                                                                                                                                                        uint64_t t90;
                                                                                                                                                                                                                                                                                                                                                                                                                                                        if ((!(((((v60 | UINT64_C(32)) >= UINT64_C(97)) && ((v60 | UINT64_C(32)) <= UINT64_C(122))) || ((v60 >= UINT64_C(48)) && (v60 <= UINT64_C(57)))) || (v60 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                                                                                                                                                                                                            t90 = v4;
                                                                                                                                                                                                                                                                                                                                                                                                                                                        } else {
                                                                                                                                                                                                                                                                                                                                                                                                                                                            uint64_t t89;
                                                                                                                                                                                                                                                                                                                                                                                                                                                            if ((UINT64_C(54) > v6)) {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                t89 = v7;
                                                                                                                                                                                                                                                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                uint64_t v61 = ((uint64_t)v3[((v5 + UINT64_C(54)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                                                                                                                                                                                                uint64_t t88;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                if ((!(((((v61 | UINT64_C(32)) >= UINT64_C(97)) && ((v61 | UINT64_C(32)) <= UINT64_C(122))) || ((v61 >= UINT64_C(48)) && (v61 <= UINT64_C(57)))) || (v61 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                    t88 = v4;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                } else {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                    uint64_t t87;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                    if ((UINT64_C(55) > v6)) {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                        t87 = v7;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                    } else {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                        uint64_t v62 = ((uint64_t)v3[((v5 + UINT64_C(55)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                                                                                                                                                                                                        uint64_t t86;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                        if ((!(((((v62 | UINT64_C(32)) >= UINT64_C(97)) && ((v62 | UINT64_C(32)) <= UINT64_C(122))) || ((v62 >= UINT64_C(48)) && (v62 <= UINT64_C(57)))) || (v62 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                            t86 = v4;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                        } else {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                            uint64_t t85;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                            if ((UINT64_C(56) > v6)) {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                t85 = v7;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                uint64_t v63 = ((uint64_t)v3[((v5 + UINT64_C(56)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                uint64_t t84;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                if ((!(((((v63 | UINT64_C(32)) >= UINT64_C(97)) && ((v63 | UINT64_C(32)) <= UINT64_C(122))) || ((v63 >= UINT64_C(48)) && (v63 <= UINT64_C(57)))) || (v63 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    t84 = v4;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                } else {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    uint64_t t83;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    if ((UINT64_C(57) > v6)) {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        t83 = v7;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    } else {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        uint64_t v64 = ((uint64_t)v3[((v5 + UINT64_C(57)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        uint64_t t82;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        if ((!(((((v64 | UINT64_C(32)) >= UINT64_C(97)) && ((v64 | UINT64_C(32)) <= UINT64_C(122))) || ((v64 >= UINT64_C(48)) && (v64 <= UINT64_C(57)))) || (v64 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            t82 = v4;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        } else {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            uint64_t t81;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            if ((UINT64_C(58) > v6)) {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                t81 = v7;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                uint64_t v65 = ((uint64_t)v3[((v5 + UINT64_C(58)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                uint64_t t80;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                if ((!(((((v65 | UINT64_C(32)) >= UINT64_C(97)) && ((v65 | UINT64_C(32)) <= UINT64_C(122))) || ((v65 >= UINT64_C(48)) && (v65 <= UINT64_C(57)))) || (v65 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    t80 = v4;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                } else {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    uint64_t t79;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    if ((UINT64_C(59) > v6)) {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        t79 = v7;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    } else {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        uint64_t v66 = ((uint64_t)v3[((v5 + UINT64_C(59)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        uint64_t t78;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        if ((!(((((v66 | UINT64_C(32)) >= UINT64_C(97)) && ((v66 | UINT64_C(32)) <= UINT64_C(122))) || ((v66 >= UINT64_C(48)) && (v66 <= UINT64_C(57)))) || (v66 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            t78 = v4;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        } else {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            uint64_t t77;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            if ((UINT64_C(60) > v6)) {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                t77 = v7;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                uint64_t v67 = ((uint64_t)v3[((v5 + UINT64_C(60)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                uint64_t t76;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                if ((!(((((v67 | UINT64_C(32)) >= UINT64_C(97)) && ((v67 | UINT64_C(32)) <= UINT64_C(122))) || ((v67 >= UINT64_C(48)) && (v67 <= UINT64_C(57)))) || (v67 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    t76 = v4;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                } else {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    uint64_t t75;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    if ((UINT64_C(61) > v6)) {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        t75 = v7;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    } else {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        uint64_t v68 = ((uint64_t)v3[((v5 + UINT64_C(61)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        uint64_t t74;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        if ((!(((((v68 | UINT64_C(32)) >= UINT64_C(97)) && ((v68 | UINT64_C(32)) <= UINT64_C(122))) || ((v68 >= UINT64_C(48)) && (v68 <= UINT64_C(57)))) || (v68 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            t74 = v4;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        } else {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            uint64_t t73;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            if ((UINT64_C(62) > v6)) {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                t73 = v7;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                uint64_t v69 = ((uint64_t)v3[((v5 + UINT64_C(62)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                uint64_t t72;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                if ((!(((((v69 | UINT64_C(32)) >= UINT64_C(97)) && ((v69 | UINT64_C(32)) <= UINT64_C(122))) || ((v69 >= UINT64_C(48)) && (v69 <= UINT64_C(57)))) || (v69 == UINT64_C(45))))) {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    t72 = v4;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                } else {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    uint64_t t71;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    if ((UINT64_C(63) > v6)) {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        t71 = v7;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    } else {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        uint64_t v70 = ((uint64_t)v3[((v5 + UINT64_C(63)) & UINT64_C(0xffff))]);
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        t71 = ((!(((((v70 | UINT64_C(32)) >= UINT64_C(97)) && ((v70 | UINT64_C(32)) <= UINT64_C(122))) || ((v70 >= UINT64_C(48)) && (v70 <= UINT64_C(57)))) || (v70 == UINT64_C(45)))) ? v4 : v7);
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    t72 = t71;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                t73 = t72;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            t74 = t73;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        t75 = t74;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    t76 = t75;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                t77 = t76;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            t78 = t77;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        t79 = t78;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    t80 = t79;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                t81 = t80;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            t82 = t81;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        t83 = t82;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    t84 = t83;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                t85 = t84;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                            t86 = t85;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                        t87 = t86;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                    t88 = t87;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                t89 = t88;
                                                                                                                                                                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                                                                                                                                                                            t90 = t89;
                                                                                                                                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                                                                                                                                        t91 = t90;
                                                                                                                                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                                                                                                                                    t92 = t91;
                                                                                                                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                                                                                                                t93 = t92;
                                                                                                                                                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                                                                                                                                                            t94 = t93;
                                                                                                                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                                                                                                                        t95 = t94;
                                                                                                                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                                                                                                                    t96 = t95;
                                                                                                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                                                                                                t97 = t96;
                                                                                                                                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                                                                                                                                            t98 = t97;
                                                                                                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                                                                                                        t99 = t98;
                                                                                                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                                                                                                    t100 = t99;
                                                                                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                                                                                t101 = t100;
                                                                                                                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                                                                                                                            t102 = t101;
                                                                                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                                                                                        t103 = t102;
                                                                                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                                                                                    t104 = t103;
                                                                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                                                                t105 = t104;
                                                                                                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                                                                                                            t106 = t105;
                                                                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                                                                        t107 = t106;
                                                                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                                                                    t108 = t107;
                                                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                                                t109 = t108;
                                                                                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                                                                                            t110 = t109;
                                                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                                                        t111 = t110;
                                                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                                                    t112 = t111;
                                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                                t113 = t112;
                                                                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                                                                            t114 = t113;
                                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                                        t115 = t114;
                                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                                    t116 = t115;
                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                t117 = t116;
                                                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                                                            t118 = t117;
                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                        t119 = t118;
                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                    t120 = t119;
                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                t121 = t120;
                                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                                            t122 = t121;
                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                        t123 = t122;
                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                    t124 = t123;
                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                t125 = t124;
                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                            t126 = t125;
                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                        t127 = t126;
                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                    t128 = t127;
                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                t129 = t128;
                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                            t130 = t129;
                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                        t131 = t130;
                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                    t132 = t131;
                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                t133 = t132;
                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                            t134 = t133;
                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                        t135 = t134;
                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                    t136 = t135;
                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                t137 = t136;
                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                            t138 = t137;
                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                        t139 = t138;
                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                    t140 = t139;
                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                t141 = t140;
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                            t142 = t141;
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                        t143 = t142;
                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                    t144 = t143;
                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                t145 = t144;
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                            t146 = t145;
                                                                                                                                                                                                                        }
                                                                                                                                                                                                                        t147 = t146;
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                    t148 = t147;
                                                                                                                                                                                                                }
                                                                                                                                                                                                                t149 = t148;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            t150 = t149;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        t151 = t150;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    t152 = t151;
                                                                                                                                                                                                }
                                                                                                                                                                                                t153 = t152;
                                                                                                                                                                                            }
                                                                                                                                                                                            t154 = t153;
                                                                                                                                                                                        }
                                                                                                                                                                                        t155 = t154;
                                                                                                                                                                                    }
                                                                                                                                                                                    t156 = t155;
                                                                                                                                                                                }
                                                                                                                                                                                t157 = t156;
                                                                                                                                                                            }
                                                                                                                                                                            t158 = t157;
                                                                                                                                                                        }
                                                                                                                                                                        t159 = t158;
                                                                                                                                                                    }
                                                                                                                                                                    t160 = t159;
                                                                                                                                                                }
                                                                                                                                                                t161 = t160;
                                                                                                                                                            }
                                                                                                                                                            t162 = t161;
                                                                                                                                                        }
                                                                                                                                                        t163 = t162;
                                                                                                                                                    }
                                                                                                                                                    t164 = t163;
                                                                                                                                                }
                                                                                                                                                t165 = t164;
                                                                                                                                            }
                                                                                                                                            t166 = t165;
                                                                                                                                        }
                                                                                                                                        t167 = t166;
                                                                                                                                    }
                                                                                                                                    t168 = t167;
                                                                                                                                }
                                                                                                                                t169 = t168;
                                                                                                                            }
                                                                                                                            t170 = t169;
                                                                                                                        }
                                                                                                                        t171 = t170;
                                                                                                                    }
                                                                                                                    t172 = t171;
                                                                                                                }
                                                                                                                t173 = t172;
                                                                                                            }
                                                                                                            t174 = t173;
                                                                                                        }
                                                                                                        t175 = t174;
                                                                                                    }
                                                                                                    t176 = t175;
                                                                                                }
                                                                                                t177 = t176;
                                                                                            }
                                                                                            t178 = t177;
                                                                                        }
                                                                                        t179 = t178;
                                                                                    }
                                                                                    t180 = t179;
                                                                                }
                                                                                t181 = t180;
                                                                            }
                                                                            t182 = t181;
                                                                        }
                                                                        t183 = t182;
                                                                    }
                                                                    t184 = t183;
                                                                }
                                                                t185 = t184;
                                                            }
                                                            t186 = t185;
                                                        }
                                                        t187 = t186;
                                                    }
                                                    t188 = t187;
                                                }
                                                t189 = t188;
                                            }
                                            t190 = t189;
                                        }
                                        t191 = t190;
                                    }
                                    t192 = t191;
                                }
                                t193 = t192;
                            }
                            t194 = t193;
                        }
                        t195 = t194;
                    }
                    t196 = t195;
                }
                t197 = t196;
            }
            t198 = t197;
        }
        uint64_t n199 = t198;
        if (n199 == f1) break;
        f1 = n199;
    }
    uint64_t v200 = f1;
    uint64_t v201 = (v200 & UINT64_C(255));
    uint64_t v202 = (v200 >> 8);
    int o203_tag;
    uint64_t o203_0 = 0;
    uint64_t o203_1 = 0;
    uint64_t o203_2 = 0;
    if ((v201 >= ((uint64_t)((uint64_t)in_b_len)))) {
        o203_tag = 0;
        o203_0 = 0;
        o203_1 = 0;
        o203_2 = 0;
    } else {
        uint64_t v204 = ((uint64_t)in_b[v201]);
        int o205_tag;
        uint64_t o205_0 = 0;
        uint64_t o205_1 = 0;
        uint64_t o205_2 = 0;
        if ((v204 == UINT64_C(0))) {
            o205_tag = 1;
            o205_0 = (((uint64_t)((v201 + UINT64_C(1)) & UINT64_C(0xffff))) & UINT64_C(255));
            o205_1 = (((uint64_t)v202) & UINT64_C(255));
            o205_2 = UINT64_C(0xffff);
        } else {
            int o206_tag;
            uint64_t o206_0 = 0;
            uint64_t o206_1 = 0;
            uint64_t o206_2 = 0;
            if ((((v204 & UINT64_C(192)) == UINT64_C(192)) && (((v201 + UINT64_C(1)) & UINT64_C(0xffff)) < ((uint64_t)((uint64_t)in_b_len))))) {
                o206_tag = 1;
                o206_0 = (((uint64_t)((v201 + UINT64_C(2)) & UINT64_C(0xffff))) & UINT64_C(255));
                o206_1 = (((uint64_t)v202) & UINT64_C(255));
                o206_2 = (((((uint64_t)(v204 & UINT64_C(63))) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[((v201 + UINT64_C(1)) & UINT64_C(0xffff))])));
            } else {
                o206_tag = 0;
                o206_0 = 0;
                o206_1 = 0;
                o206_2 = 0;
            }
            o205_tag = o206_tag;
            o205_0 = o206_0;
            o205_1 = o206_1;
            o205_2 = o206_2;
        }
        o203_tag = o205_tag;
        o203_0 = o205_0;
        o203_1 = o205_1;
        o203_2 = o205_2;
    }
    if (o203_tag) {
        *out0 = (uint64_t)(o203_0);
        *out1 = (uint64_t)(o203_1);
        *out2 = (uint64_t)(o203_2);
    }
    return o203_tag;
}
