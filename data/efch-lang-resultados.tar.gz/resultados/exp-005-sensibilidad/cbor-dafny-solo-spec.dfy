// Cabecera de un elemento CBOR (RFC 8949, §3); información adicional 28..31 es error. EXP-005.

newtype u8 = x: int | 0 <= x < 256
datatype Option<T> = None | Some(value: T)

function BE(s: seq<u8>): nat {
  if |s| == 0 then 0 else BE(s[..|s| - 1]) * 256 + s[|s| - 1] as nat
}

function Spec(buf: seq<u8>): Option<(nat, nat, nat)> {
  if |buf| == 0 then None
  else
    var mt := buf[0] as nat / 32;
    var ai := buf[0] as nat % 32;
    if ai < 24 then Some((mt, ai, 1))
    else if ai > 27 then None
    else
      var k := if ai == 24 then 1 else if ai == 25 then 2 else if ai == 26 then 4 else 8;
      if |buf| < k + 1 then None
      else if mt == 7 && ai == 24 && BE(buf[1..k + 1]) < 32 then None
      else Some((mt, BE(buf[1..k + 1]), k + 1))
}

method Decode(buf: seq<u8>) returns (r: Option<(nat, nat, nat)>)
  ensures r == Spec(buf)
{
  return Spec(buf);
}
