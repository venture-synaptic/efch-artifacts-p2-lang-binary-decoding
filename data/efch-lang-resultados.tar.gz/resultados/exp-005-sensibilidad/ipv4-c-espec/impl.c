#include <stddef.h>
#include <stdint.h>
#include <string.h>
typedef unsigned __int128 efch_u128;

/* Operaciones con signo sobre valores de w bits guardados sin signo y enmascarados. Solo usan
   aritmética sin signo: no hay comportamiento indefinido ni dependiente de la implementación. */
#define EFCH_SIGNED_OPS(T, SUF)                                                               \
static inline T efch_mask##SUF(unsigned w) { return w >= 8 * sizeof(T) ? (T)~(T)0 : (((T)1 << w) - 1); } \
static inline int efch_slt##SUF(T x, T y, unsigned w) { T s = (T)1 << (w - 1); return (x ^ s) < (y ^ s); } \
static inline T efch_sext##SUF(T x, unsigned w, unsigned n) {                                 \
    return (x & ((T)1 << (w - 1))) ? (x | (efch_mask##SUF(n) & ~efch_mask##SUF(w))) : x; }    \
static inline T efch_ashr##SUF(T x, T k, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int neg = (x >> (w - 1)) & 1;                                    \
    if (k >= w) return neg ? m : 0;                                                           \
    return (x >> k) | (neg ? (m & ~(m >> k)) : 0); }                                          \
static inline T efch_sdiv##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return nx ? 1 : m;                                                            \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, q = ax / ay;                     \
    return (nx != ny) ? ((T)-q & m) : q; }                                                    \
static inline T efch_srem##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return x;                                                                     \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, r = ax % ay;                     \
    return nx ? ((T)-r & m) : r; }
EFCH_SIGNED_OPS(uint64_t, 64)
EFCH_SIGNED_OPS(efch_u128, 128)

int efch_ipv4_header_check(const uint8_t *in_h, size_t in_h_len, uint64_t *out0, uint64_t *out1)
{
    int o1_tag;
    uint64_t o1_0 = 0;
    uint64_t o1_1 = 0;
    if ((((uint64_t)((uint64_t)in_h_len)) < UINT64_C(20))) {
        o1_tag = 0;
        o1_0 = 0;
        o1_1 = 0;
    } else {
        uint64_t v2 = (((uint64_t)in_h[UINT64_C(0)]) >> 4);
        uint64_t v3 = (((uint64_t)in_h[UINT64_C(0)]) & UINT64_C(15));
        uint64_t v4 = ((((uint64_t)v3) << 2) & UINT64_C(0xffff));
        uint64_t v5 = (((((uint64_t)((uint64_t)in_h[UINT64_C(2)])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_h[UINT64_C(3)])));
        int o6_tag;
        uint64_t o6_0 = 0;
        uint64_t o6_1 = 0;
        if (((v2 != UINT64_C(4)) || (v3 < UINT64_C(5)) || (((uint64_t)((uint64_t)in_h_len)) < v4) || (v5 < v4))) {
            o6_tag = 0;
            o6_0 = 0;
            o6_1 = 0;
        } else {
            uint64_t v7 = ((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((UINT64_C(0) < ((((uint64_t)v3) << 1) & UINT64_C(0xffff))) ? (((((uint64_t)((uint64_t)in_h[((UINT64_C(2) * UINT64_C(0)) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[((((UINT64_C(2) * UINT64_C(0)) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))) : UINT64_C(0)) + ((UINT64_C(1) < ((((uint64_t)v3) << 1) & UINT64_C(0xffff))) ? (((((uint64_t)((uint64_t)in_h[((UINT64_C(2) * UINT64_C(1)) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[((((UINT64_C(2) * UINT64_C(1)) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))) : UINT64_C(0))) & UINT64_C(0xffffffff)) + ((UINT64_C(2) < ((((uint64_t)v3) << 1) & UINT64_C(0xffff))) ? (((((uint64_t)((uint64_t)in_h[((UINT64_C(2) * UINT64_C(2)) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[((((UINT64_C(2) * UINT64_C(2)) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))) : UINT64_C(0))) & UINT64_C(0xffffffff)) + ((UINT64_C(3) < ((((uint64_t)v3) << 1) & UINT64_C(0xffff))) ? (((((uint64_t)((uint64_t)in_h[((UINT64_C(2) * UINT64_C(3)) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[((((UINT64_C(2) * UINT64_C(3)) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))) : UINT64_C(0))) & UINT64_C(0xffffffff)) + ((UINT64_C(4) < ((((uint64_t)v3) << 1) & UINT64_C(0xffff))) ? (((((uint64_t)((uint64_t)in_h[((UINT64_C(2) * UINT64_C(4)) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[((((UINT64_C(2) * UINT64_C(4)) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))) : UINT64_C(0))) & UINT64_C(0xffffffff)) + ((UINT64_C(5) < ((((uint64_t)v3) << 1) & UINT64_C(0xffff))) ? (((((uint64_t)((uint64_t)in_h[((UINT64_C(2) * UINT64_C(5)) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[((((UINT64_C(2) * UINT64_C(5)) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))) : UINT64_C(0))) & UINT64_C(0xffffffff)) + ((UINT64_C(6) < ((((uint64_t)v3) << 1) & UINT64_C(0xffff))) ? (((((uint64_t)((uint64_t)in_h[((UINT64_C(2) * UINT64_C(6)) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[((((UINT64_C(2) * UINT64_C(6)) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))) : UINT64_C(0))) & UINT64_C(0xffffffff)) + ((UINT64_C(7) < ((((uint64_t)v3) << 1) & UINT64_C(0xffff))) ? (((((uint64_t)((uint64_t)in_h[((UINT64_C(2) * UINT64_C(7)) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[((((UINT64_C(2) * UINT64_C(7)) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))) : UINT64_C(0))) & UINT64_C(0xffffffff)) + ((UINT64_C(8) < ((((uint64_t)v3) << 1) & UINT64_C(0xffff))) ? (((((uint64_t)((uint64_t)in_h[((UINT64_C(2) * UINT64_C(8)) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[((((UINT64_C(2) * UINT64_C(8)) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))) : UINT64_C(0))) & UINT64_C(0xffffffff)) + ((UINT64_C(9) < ((((uint64_t)v3) << 1) & UINT64_C(0xffff))) ? (((((uint64_t)((uint64_t)in_h[((UINT64_C(2) * UINT64_C(9)) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[((((UINT64_C(2) * UINT64_C(9)) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))) : UINT64_C(0))) & UINT64_C(0xffffffff)) + ((UINT64_C(10) < ((((uint64_t)v3) << 1) & UINT64_C(0xffff))) ? (((((uint64_t)((uint64_t)in_h[((UINT64_C(2) * UINT64_C(10)) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[((((UINT64_C(2) * UINT64_C(10)) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))) : UINT64_C(0))) & UINT64_C(0xffffffff)) + ((UINT64_C(11) < ((((uint64_t)v3) << 1) & UINT64_C(0xffff))) ? (((((uint64_t)((uint64_t)in_h[((UINT64_C(2) * UINT64_C(11)) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[((((UINT64_C(2) * UINT64_C(11)) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))) : UINT64_C(0))) & UINT64_C(0xffffffff)) + ((UINT64_C(12) < ((((uint64_t)v3) << 1) & UINT64_C(0xffff))) ? (((((uint64_t)((uint64_t)in_h[((UINT64_C(2) * UINT64_C(12)) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[((((UINT64_C(2) * UINT64_C(12)) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))) : UINT64_C(0))) & UINT64_C(0xffffffff)) + ((UINT64_C(13) < ((((uint64_t)v3) << 1) & UINT64_C(0xffff))) ? (((((uint64_t)((uint64_t)in_h[((UINT64_C(2) * UINT64_C(13)) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[((((UINT64_C(2) * UINT64_C(13)) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))) : UINT64_C(0))) & UINT64_C(0xffffffff)) + ((UINT64_C(14) < ((((uint64_t)v3) << 1) & UINT64_C(0xffff))) ? (((((uint64_t)((uint64_t)in_h[((UINT64_C(2) * UINT64_C(14)) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[((((UINT64_C(2) * UINT64_C(14)) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))) : UINT64_C(0))) & UINT64_C(0xffffffff)) + ((UINT64_C(15) < ((((uint64_t)v3) << 1) & UINT64_C(0xffff))) ? (((((uint64_t)((uint64_t)in_h[((UINT64_C(2) * UINT64_C(15)) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[((((UINT64_C(2) * UINT64_C(15)) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))) : UINT64_C(0))) & UINT64_C(0xffffffff)) + ((UINT64_C(16) < ((((uint64_t)v3) << 1) & UINT64_C(0xffff))) ? (((((uint64_t)((uint64_t)in_h[((UINT64_C(2) * UINT64_C(16)) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[((((UINT64_C(2) * UINT64_C(16)) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))) : UINT64_C(0))) & UINT64_C(0xffffffff)) + ((UINT64_C(17) < ((((uint64_t)v3) << 1) & UINT64_C(0xffff))) ? (((((uint64_t)((uint64_t)in_h[((UINT64_C(2) * UINT64_C(17)) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[((((UINT64_C(2) * UINT64_C(17)) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))) : UINT64_C(0))) & UINT64_C(0xffffffff)) + ((UINT64_C(18) < ((((uint64_t)v3) << 1) & UINT64_C(0xffff))) ? (((((uint64_t)((uint64_t)in_h[((UINT64_C(2) * UINT64_C(18)) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[((((UINT64_C(2) * UINT64_C(18)) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))) : UINT64_C(0))) & UINT64_C(0xffffffff)) + ((UINT64_C(19) < ((((uint64_t)v3) << 1) & UINT64_C(0xffff))) ? (((((uint64_t)((uint64_t)in_h[((UINT64_C(2) * UINT64_C(19)) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[((((UINT64_C(2) * UINT64_C(19)) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))) : UINT64_C(0))) & UINT64_C(0xffffffff)) + ((UINT64_C(20) < ((((uint64_t)v3) << 1) & UINT64_C(0xffff))) ? (((((uint64_t)((uint64_t)in_h[((UINT64_C(2) * UINT64_C(20)) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[((((UINT64_C(2) * UINT64_C(20)) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))) : UINT64_C(0))) & UINT64_C(0xffffffff)) + ((UINT64_C(21) < ((((uint64_t)v3) << 1) & UINT64_C(0xffff))) ? (((((uint64_t)((uint64_t)in_h[((UINT64_C(2) * UINT64_C(21)) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[((((UINT64_C(2) * UINT64_C(21)) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))) : UINT64_C(0))) & UINT64_C(0xffffffff)) + ((UINT64_C(22) < ((((uint64_t)v3) << 1) & UINT64_C(0xffff))) ? (((((uint64_t)((uint64_t)in_h[((UINT64_C(2) * UINT64_C(22)) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[((((UINT64_C(2) * UINT64_C(22)) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))) : UINT64_C(0))) & UINT64_C(0xffffffff)) + ((UINT64_C(23) < ((((uint64_t)v3) << 1) & UINT64_C(0xffff))) ? (((((uint64_t)((uint64_t)in_h[((UINT64_C(2) * UINT64_C(23)) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[((((UINT64_C(2) * UINT64_C(23)) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))) : UINT64_C(0))) & UINT64_C(0xffffffff)) + ((UINT64_C(24) < ((((uint64_t)v3) << 1) & UINT64_C(0xffff))) ? (((((uint64_t)((uint64_t)in_h[((UINT64_C(2) * UINT64_C(24)) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[((((UINT64_C(2) * UINT64_C(24)) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))) : UINT64_C(0))) & UINT64_C(0xffffffff)) + ((UINT64_C(25) < ((((uint64_t)v3) << 1) & UINT64_C(0xffff))) ? (((((uint64_t)((uint64_t)in_h[((UINT64_C(2) * UINT64_C(25)) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[((((UINT64_C(2) * UINT64_C(25)) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))) : UINT64_C(0))) & UINT64_C(0xffffffff)) + ((UINT64_C(26) < ((((uint64_t)v3) << 1) & UINT64_C(0xffff))) ? (((((uint64_t)((uint64_t)in_h[((UINT64_C(2) * UINT64_C(26)) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[((((UINT64_C(2) * UINT64_C(26)) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))) : UINT64_C(0))) & UINT64_C(0xffffffff)) + ((UINT64_C(27) < ((((uint64_t)v3) << 1) & UINT64_C(0xffff))) ? (((((uint64_t)((uint64_t)in_h[((UINT64_C(2) * UINT64_C(27)) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[((((UINT64_C(2) * UINT64_C(27)) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))) : UINT64_C(0))) & UINT64_C(0xffffffff)) + ((UINT64_C(28) < ((((uint64_t)v3) << 1) & UINT64_C(0xffff))) ? (((((uint64_t)((uint64_t)in_h[((UINT64_C(2) * UINT64_C(28)) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[((((UINT64_C(2) * UINT64_C(28)) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))) : UINT64_C(0))) & UINT64_C(0xffffffff)) + ((UINT64_C(29) < ((((uint64_t)v3) << 1) & UINT64_C(0xffff))) ? (((((uint64_t)((uint64_t)in_h[((UINT64_C(2) * UINT64_C(29)) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffffffff)) | ((uint64_t)((uint64_t)in_h[((((UINT64_C(2) * UINT64_C(29)) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))) : UINT64_C(0))) & UINT64_C(0xffffffff));
            uint64_t v8 = (((v7 & UINT64_C(0xffff)) + (v7 >> 16)) & UINT64_C(0xffffffff));
            uint64_t v9 = (((v8 & UINT64_C(0xffff)) + (v8 >> 16)) & UINT64_C(0xffffffff));
            int o10_tag;
            uint64_t o10_0 = 0;
            uint64_t o10_1 = 0;
            if ((v9 == UINT64_C(0xffff))) {
                o10_tag = 1;
                o10_0 = v3;
                o10_1 = v5;
            } else {
                o10_tag = 0;
                o10_0 = 0;
                o10_1 = 0;
            }
            o6_tag = o10_tag;
            o6_0 = o10_0;
            o6_1 = o10_1;
        }
        o1_tag = o6_tag;
        o1_0 = o6_0;
        o1_1 = o6_1;
    }
    if (o1_tag) {
        *out0 = (uint64_t)(o1_0);
        *out1 = (uint64_t)(o1_1);
    }
    return o1_tag;
}
