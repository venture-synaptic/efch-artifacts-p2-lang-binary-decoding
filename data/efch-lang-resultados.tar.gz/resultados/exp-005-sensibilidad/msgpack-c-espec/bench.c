#define _POSIX_C_SOURCE 199309L
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
typedef unsigned __int128 efch_u128;
int efch_msgpack_int_decode(const uint8_t *in_buf, size_t in_buf_len, uint64_t *out0, uint64_t *out1, uint64_t *out2);
static uint64_t *in0_n; static uint8_t *in0_b;
static volatile uint64_t sink;
static double now_ns(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1e9 + ts.tv_nsec; }
int main(int argc, char **argv) {
    if (argc != 2) return 2;
    FILE *f = fopen(argv[1], "rb"); if (!f) return 1;
    uint64_t count64; if (fread(&count64, 8, 1, f) != 1) return 1;
    size_t count = (size_t)count64;
    in0_n = malloc(count * 8); in0_b = malloc(count * 9); if (fread(in0_n, 8, count, f) != count || fread(in0_b, 9, count, f) != count) return 1;
    fclose(f);
    uint64_t o0 = 0, o1 = 0, o2 = 0;
    static double samples[1][15];
    const char *names[] = {"efch_msgpack_int_decode"};
    for (int r = 0; r < 15; r++) {
        
            {
                uint64_t acc = 0;
                double t0 = now_ns();
                for (size_t i = 0; i < count; i++) { acc += (uint64_t)efch_msgpack_int_decode(in0_b + (size_t)i * 9, (size_t)in0_n[i], &o0, &o1, &o2) + o0; }
                samples[0][r] = (now_ns() - t0) / count;
                sink += acc;
            }
    }
    printf("{");
    for (int j = 0; j < 1; j++) {
        printf("%s\"%s\": [", j ? ", " : "", names[j]);
        for (int r = 0; r < 15; r++) printf("%s%.4f", r ? ", " : "", samples[j][r]);
        printf("]");
    }
    printf("}\n");
    return 0;
}
