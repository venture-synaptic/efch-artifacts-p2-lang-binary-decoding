#include <stddef.h>
#include <stdint.h>
#include <string.h>
typedef unsigned __int128 efch_u128;

/* Operaciones con signo sobre valores de w bits guardados sin signo y enmascarados. Solo usan
   aritmética sin signo: no hay comportamiento indefinido ni dependiente de la implementación. */
#define EFCH_SIGNED_OPS(T, SUF)                                                               \
static inline T efch_mask##SUF(unsigned w) { return w >= 8 * sizeof(T) ? (T)~(T)0 : (((T)1 << w) - 1); } \
static inline int efch_slt##SUF(T x, T y, unsigned w) { T s = (T)1 << (w - 1); return (x ^ s) < (y ^ s); } \
static inline T efch_sext##SUF(T x, unsigned w, unsigned n) {                                 \
    return (x & ((T)1 << (w - 1))) ? (x | (efch_mask##SUF(n) & ~efch_mask##SUF(w))) : x; }    \
static inline T efch_ashr##SUF(T x, T k, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int neg = (x >> (w - 1)) & 1;                                    \
    if (k >= w) return neg ? m : 0;                                                           \
    return (x >> k) | (neg ? (m & ~(m >> k)) : 0); }                                          \
static inline T efch_sdiv##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return nx ? 1 : m;                                                            \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, q = ax / ay;                     \
    return (nx != ny) ? ((T)-q & m) : q; }                                                    \
static inline T efch_srem##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return x;                                                                     \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, r = ax % ay;                     \
    return nx ? ((T)-r & m) : r; }
EFCH_SIGNED_OPS(uint64_t, 64)
EFCH_SIGNED_OPS(efch_u128, 128)

int efch_utf8_decode(const uint8_t *in_buf, size_t in_buf_len, uint64_t *out0, uint64_t *out1)
{
    int o1_tag;
    uint64_t o1_0 = 0;
    uint64_t o1_1 = 0;
    if ((((uint64_t)((uint64_t)in_buf_len)) == UINT64_C(0))) {
        o1_tag = 0;
        o1_0 = 0;
        o1_1 = 0;
    } else {
        uint64_t v2 = ((uint64_t)in_buf[UINT64_C(0)]);
        uint64_t v3 = ((v2 < UINT64_C(128)) ? UINT64_C(1) : ((v2 < UINT64_C(192)) ? UINT64_C(0) : ((v2 < UINT64_C(224)) ? UINT64_C(2) : ((v2 < UINT64_C(240)) ? UINT64_C(3) : ((v2 < UINT64_C(248)) ? UINT64_C(4) : UINT64_C(0))))));
        int o4_tag;
        uint64_t o4_0 = 0;
        uint64_t o4_1 = 0;
        if (((v3 == UINT64_C(0)) || (((uint64_t)((uint64_t)in_buf_len)) < ((uint64_t)v3)) || (!(((UINT64_C(1) >= v3) || ((((uint64_t)in_buf[UINT64_C(1)]) & UINT64_C(192)) == UINT64_C(128))) && ((UINT64_C(2) >= v3) || ((((uint64_t)in_buf[UINT64_C(2)]) & UINT64_C(192)) == UINT64_C(128))) && ((UINT64_C(3) >= v3) || ((((uint64_t)in_buf[UINT64_C(3)]) & UINT64_C(192)) == UINT64_C(128))))))) {
            o4_tag = 0;
            o4_0 = 0;
            o4_1 = 0;
        } else {
            uint64_t v5 = (((((UINT64_C(0) < v3) ? (((((uint64_t)((UINT64_C(6) * ((((v3 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(0)) & UINT64_C(255))) & UINT64_C(255))) >= 32 ? 0 : ((uint64_t)(((uint64_t)in_buf[UINT64_C(0)]) & ((UINT64_C(0) == UINT64_C(0)) ? ((((v3 == UINT64_C(1)) ? UINT64_C(1) : ((v3 + UINT64_C(1)) & UINT64_C(255))) >= 8 ? 0 : UINT64_C(255) >> ((v3 == UINT64_C(1)) ? UINT64_C(1) : ((v3 + UINT64_C(1)) & UINT64_C(255))))) : UINT64_C(63)))) << ((uint64_t)((UINT64_C(6) * ((((v3 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(0)) & UINT64_C(255))) & UINT64_C(255))))) & UINT64_C(0xffffffff)) : UINT64_C(0)) | ((UINT64_C(1) < v3) ? (((((uint64_t)((UINT64_C(6) * ((((v3 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(1)) & UINT64_C(255))) & UINT64_C(255))) >= 32 ? 0 : ((uint64_t)(((uint64_t)in_buf[UINT64_C(1)]) & ((UINT64_C(1) == UINT64_C(0)) ? ((((v3 == UINT64_C(1)) ? UINT64_C(1) : ((v3 + UINT64_C(1)) & UINT64_C(255))) >= 8 ? 0 : UINT64_C(255) >> ((v3 == UINT64_C(1)) ? UINT64_C(1) : ((v3 + UINT64_C(1)) & UINT64_C(255))))) : UINT64_C(63)))) << ((uint64_t)((UINT64_C(6) * ((((v3 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(1)) & UINT64_C(255))) & UINT64_C(255))))) & UINT64_C(0xffffffff)) : UINT64_C(0))) | ((UINT64_C(2) < v3) ? (((((uint64_t)((UINT64_C(6) * ((((v3 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(2)) & UINT64_C(255))) & UINT64_C(255))) >= 32 ? 0 : ((uint64_t)(((uint64_t)in_buf[UINT64_C(2)]) & ((UINT64_C(2) == UINT64_C(0)) ? ((((v3 == UINT64_C(1)) ? UINT64_C(1) : ((v3 + UINT64_C(1)) & UINT64_C(255))) >= 8 ? 0 : UINT64_C(255) >> ((v3 == UINT64_C(1)) ? UINT64_C(1) : ((v3 + UINT64_C(1)) & UINT64_C(255))))) : UINT64_C(63)))) << ((uint64_t)((UINT64_C(6) * ((((v3 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(2)) & UINT64_C(255))) & UINT64_C(255))))) & UINT64_C(0xffffffff)) : UINT64_C(0))) | ((UINT64_C(3) < v3) ? (((((uint64_t)((UINT64_C(6) * ((((v3 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(3)) & UINT64_C(255))) & UINT64_C(255))) >= 32 ? 0 : ((uint64_t)(((uint64_t)in_buf[UINT64_C(3)]) & ((UINT64_C(3) == UINT64_C(0)) ? ((((v3 == UINT64_C(1)) ? UINT64_C(1) : ((v3 + UINT64_C(1)) & UINT64_C(255))) >= 8 ? 0 : UINT64_C(255) >> ((v3 == UINT64_C(1)) ? UINT64_C(1) : ((v3 + UINT64_C(1)) & UINT64_C(255))))) : UINT64_C(63)))) << ((uint64_t)((UINT64_C(6) * ((((v3 - UINT64_C(1)) & UINT64_C(255)) - UINT64_C(3)) & UINT64_C(255))) & UINT64_C(255))))) & UINT64_C(0xffffffff)) : UINT64_C(0)));
            int o6_tag;
            uint64_t o6_0 = 0;
            uint64_t o6_1 = 0;
            if (((v5 < ((v3 == UINT64_C(1)) ? UINT64_C(0) : ((v3 == UINT64_C(2)) ? UINT64_C(128) : ((v3 == UINT64_C(3)) ? UINT64_C(0x800) : UINT64_C(0x10000))))) || ((v5 >= UINT64_C(0xd800)) && (v5 <= UINT64_C(0xdfff))) || (v5 > UINT64_C(0x10ffff)))) {
                o6_tag = 0;
                o6_0 = 0;
                o6_1 = 0;
            } else {
                o6_tag = 1;
                o6_0 = v5;
                o6_1 = v3;
            }
            o4_tag = o6_tag;
            o4_0 = o6_0;
            o4_1 = o6_1;
        }
        o1_tag = o4_tag;
        o1_0 = o4_0;
        o1_1 = o4_1;
    }
    if (o1_tag) {
        *out0 = (uint64_t)(o1_0);
        *out1 = (uint64_t)(o1_1);
    }
    return o1_tag;
}
