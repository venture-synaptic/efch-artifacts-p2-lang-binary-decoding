package main

import (
	"encoding/binary"
	"fmt"
	"os"
	"sort"
	"strconv"
	"time"

	_dafny "dafny"
	m "m"
)

func main() {
	data, err := os.ReadFile(os.Args[1])
	if err != nil {
		panic(err)
	}
	reps, _ := strconv.Atoi(os.Args[2])
	count := int(binary.LittleEndian.Uint64(data))
	off := 8
	ns := make([]uint64, count)
	if false {
		for i := range ns {
			ns[i] = binary.LittleEndian.Uint64(data[off:])
			off += 8
		}
	}
	lens := make([]int, count)
	for i := range lens {
		lens[i] = int(binary.LittleEndian.Uint64(data[off:]))
		off += 8
	}
	seqs := make([]_dafny.Sequence, count)
	nint := make([]_dafny.Int, count)
	for i := range seqs {
		seqs[i] = _dafny.SeqOfBytes(data[off+i*8 : off+i*8+lens[i]])
		nint[i] = _dafny.IntOfUint64(ns[i])
	}
	samples := make([]float64, reps)
	var sink uint64
	for k := 0; k < reps; k++ {
		var acc uint64
		t0 := time.Now()
		for i := 0; i < count; i++ {
			_ = nint[i]
			r := m.Companion_Default___.Decode(seqs[i])
			if r.Is_Some() {
				acc++
			}
		}
		samples[k] = float64(time.Since(t0).Nanoseconds()) / float64(count)
		sink += acc
	}
	sort.Float64s(samples)
	fmt.Printf("{\"mediana\": %.4f, \"min\": %.4f, \"max\": %.4f, \"sink\": %d}\n", samples[reps/2], samples[0], samples[reps-1], sink%2)
}
