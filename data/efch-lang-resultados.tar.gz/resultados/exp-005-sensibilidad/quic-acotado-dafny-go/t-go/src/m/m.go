// Dafny program impl_acotado.dfy compiled into Go
package impl_acotado

import (
  os "os"
  _dafny "dafny"
  m__System "System_"
)
var _ = os.Args
var _ _dafny.Dummy__
var _ m__System.Dummy__

// Definition of class Default__
type Default__ struct {
  dummy byte
}

func New_Default___() *Default__ {
  _this := Default__{}

  return &_this
}

type CompanionStruct_Default___ struct {
}
var Companion_Default___ = CompanionStruct_Default___ {
}

func (_this *Default__) Equals(other *Default__) bool {
  return _this == other
}

func (_this *Default__) EqualsGeneric(x interface{}) bool {
  other, ok := x.(*Default__)
  return ok && _this.Equals(other)
}

func (*Default__) String() string {
  return "_module.Default__"
}
func (_this *Default__) ParentTraits_() []*_dafny.TraitID {
  return [](*_dafny.TraitID){};
}
var _ _dafny.TraitOffspring = &Default__{}

func (_static *CompanionStruct_Default___) Decode(buf _dafny.Sequence) Option {
  var r Option = Companion_Option_.Default()
  _ = r
  if ((_dafny.IntOfUint32((buf).Cardinality())).Sign() == 0) {
    r = Companion_Option_.Create_None_()
    return r
  }
  var _0_n uint8
  _ = _0_n
  if (((buf).Select(0).(uint8)) < (uint8(64))) {
    _0_n = uint8(1)
  } else if (((buf).Select(0).(uint8)) < (uint8(128))) {
    _0_n = uint8(2)
  } else if (((buf).Select(0).(uint8)) < (uint8(192))) {
    _0_n = uint8(4)
  } else {
    _0_n = uint8(8)
  }
  if ((uint8((buf).Cardinality())) < (_0_n)) {
    r = Companion_Option_.Create_None_()
    return r
  }
  var _1_v uint64
  _ = _1_v
  _1_v = uint64(((buf).Select(0).(uint8)) % (uint8(64)))
  var _2_i uint8
  _ = _2_i
  _2_i = uint8(1)
  for (_2_i) < (_0_n) {
    _1_v = ((_1_v) * (uint64(256))) + (uint64((buf).Select(uint32(_2_i)).(uint8)))
    _2_i = (_2_i) + (uint8(1))
  }
  r = Companion_Option_.Create_Some_(_dafny.TupleOf(_1_v, _0_n))
  return r
  return r
}
// End of class Default__

// Definition of class U8
type U8 struct {
}

func New_U8_() *U8 {
  _this := U8{}

  return &_this
}

type CompanionStruct_U8_ struct {
}
var Companion_U8_ = CompanionStruct_U8_ {
}

func (*U8) String() string {
  return "_module.U8"
}
func (_this *U8) ParentTraits_() []*_dafny.TraitID {
  return [](*_dafny.TraitID){};
}
var _ _dafny.TraitOffspring = &U8{}

func (_this *CompanionStruct_U8_) IntegerRange(lo _dafny.Int, hi _dafny.Int) _dafny.Iterator {
  iter := _dafny.IntegerRange(lo, hi)
  return func() (interface{}, bool) {
    next, ok := iter()
    if !ok { return uint8(0), false }
    return next.(_dafny.Int).Uint8(), true
  }
}
// End of class U8

func Type_U8_() _dafny.TypeDescriptor {
  return type_U8_{}
}

type type_U8_ struct {
}

func (_this type_U8_) Default() interface{} {
  return uint8(0)
}

func (_this type_U8_) String() string {
  return "impl_acotado.U8"
}
func (_this *CompanionStruct_U8_) Is_(__source uint8) bool {
  return true
}

// Definition of class U64
type U64 struct {
}

func New_U64_() *U64 {
  _this := U64{}

  return &_this
}

type CompanionStruct_U64_ struct {
}
var Companion_U64_ = CompanionStruct_U64_ {
}

func (*U64) String() string {
  return "_module.U64"
}
func (_this *U64) ParentTraits_() []*_dafny.TraitID {
  return [](*_dafny.TraitID){};
}
var _ _dafny.TraitOffspring = &U64{}

func (_this *CompanionStruct_U64_) IntegerRange(lo _dafny.Int, hi _dafny.Int) _dafny.Iterator {
  iter := _dafny.IntegerRange(lo, hi)
  return func() (interface{}, bool) {
    next, ok := iter()
    if !ok { return uint64(0), false }
    return next.(_dafny.Int).Uint64(), true
  }
}
// End of class U64

func Type_U64_() _dafny.TypeDescriptor {
  return type_U64_{}
}

type type_U64_ struct {
}

func (_this type_U64_) Default() interface{} {
  return uint64(0)
}

func (_this type_U64_) String() string {
  return "impl_acotado.U64"
}
func (_this *CompanionStruct_U64_) Is_(__source uint64) bool {
  return true
}

// Definition of datatype Option
type Option struct {
  Data_Option_
}

func (_this Option) Get_() Data_Option_ {
  return _this.Data_Option_
}

type Data_Option_ interface {
  isOption()
}

type CompanionStruct_Option_ struct {
}
var Companion_Option_ = CompanionStruct_Option_ {
}

type Option_None struct {
}

func (Option_None) isOption() {}

func (CompanionStruct_Option_) Create_None_() Option {
  return Option{Option_None{}}
}

func (_this Option) Is_None() bool {
  _, ok := _this.Get_().(Option_None)
  return ok
}

type Option_Some struct {
  Value interface{}
}

func (Option_Some) isOption() {}

func (CompanionStruct_Option_) Create_Some_(Value interface{}) Option {
  return Option{Option_Some{Value}}
}

func (_this Option) Is_Some() bool {
  _, ok := _this.Get_().(Option_Some)
  return ok
}

func (CompanionStruct_Option_) Default() Option {
  return Companion_Option_.Create_None_()
}

func (_this Option) Dtor_value() interface{} {
  return _this.Get_().(Option_Some).Value
}

func (_this Option) String() string {
  switch data := _this.Get_().(type) {
    case nil: return "null"
    case Option_None: {
      return "Option.None"
    }
    case Option_Some: {
      return "Option.Some" + "(" + _dafny.String(data.Value) + ")"
    }
    default: {
      return "<unexpected>"
    }
  }
}

func (_this Option) Equals(other Option) bool {
  switch data1 := _this.Get_().(type) {
    case Option_None: {
      _, ok := other.Get_().(Option_None)
      return ok
    }
    case Option_Some: {
      data2, ok := other.Get_().(Option_Some)
      return ok && _dafny.AreEqual(data1.Value, data2.Value)
    }
    default: {
      return false; // unexpected
    }
  }
}

func (_this Option) EqualsGeneric(other interface{}) bool {
  typed, ok := other.(Option)
  return ok && _this.Equals(typed)
}

func Type_Option_() _dafny.TypeDescriptor {
  return type_Option_{}
}

type type_Option_ struct {
}

func (_this type_Option_) Default() interface{} {
  return Companion_Option_.Default();
}

func (_this type_Option_) String() string {
  return "impl_acotado.Option"
}
func (_this Option) ParentTraits_() []*_dafny.TraitID {
  return [](*_dafny.TraitID){};
}
var _ _dafny.TraitOffspring = Option{}

// End of datatype Option
