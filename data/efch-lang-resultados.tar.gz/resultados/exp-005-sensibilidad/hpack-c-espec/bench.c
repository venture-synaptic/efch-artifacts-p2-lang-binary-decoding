#define _POSIX_C_SOURCE 199309L
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
typedef unsigned __int128 efch_u128;
int efch_hpack_int_decode(uint64_t in_n, const uint8_t *in_buf, size_t in_buf_len, uint64_t *out0, uint64_t *out1);
static uint64_t *in0;
static uint64_t *in1_n; static uint8_t *in1_b;
static volatile uint64_t sink;
static double now_ns(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1e9 + ts.tv_nsec; }
int main(int argc, char **argv) {
    if (argc != 2) return 2;
    FILE *f = fopen(argv[1], "rb"); if (!f) return 1;
    uint64_t count64; if (fread(&count64, 8, 1, f) != 1) return 1;
    size_t count = (size_t)count64;
    in0 = malloc(count * 8); if (fread(in0, 8, count, f) != count) return 1; in1_n = malloc(count * 8); in1_b = malloc(count * 6); if (fread(in1_n, 8, count, f) != count || fread(in1_b, 6, count, f) != count) return 1;
    fclose(f);
    uint64_t o0 = 0, o1 = 0;
    static double samples[1][15];
    const char *names[] = {"efch_hpack_int_decode"};
    for (int r = 0; r < 15; r++) {
        
            {
                uint64_t acc = 0;
                double t0 = now_ns();
                for (size_t i = 0; i < count; i++) { acc += (uint64_t)efch_hpack_int_decode((uint64_t)in0[i], in1_b + (size_t)i * 6, (size_t)in1_n[i], &o0, &o1) + o0; }
                samples[0][r] = (now_ns() - t0) / count;
                sink += acc;
            }
    }
    printf("{");
    for (int j = 0; j < 1; j++) {
        printf("%s\"%s\": [", j ? ", " : "", names[j]);
        for (int r = 0; r < 15; r++) printf("%s%.4f", r ? ", " : "", samples[j][r]);
        printf("]");
    }
    printf("}\n");
    return 0;
}
