#include <stddef.h>
#include <stdint.h>
#include <string.h>
typedef unsigned __int128 efch_u128;

/* Operaciones con signo sobre valores de w bits guardados sin signo y enmascarados. Solo usan
   aritmética sin signo: no hay comportamiento indefinido ni dependiente de la implementación. */
#define EFCH_SIGNED_OPS(T, SUF)                                                               \
static inline T efch_mask##SUF(unsigned w) { return w >= 8 * sizeof(T) ? (T)~(T)0 : (((T)1 << w) - 1); } \
static inline int efch_slt##SUF(T x, T y, unsigned w) { T s = (T)1 << (w - 1); return (x ^ s) < (y ^ s); } \
static inline T efch_sext##SUF(T x, unsigned w, unsigned n) {                                 \
    return (x & ((T)1 << (w - 1))) ? (x | (efch_mask##SUF(n) & ~efch_mask##SUF(w))) : x; }    \
static inline T efch_ashr##SUF(T x, T k, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int neg = (x >> (w - 1)) & 1;                                    \
    if (k >= w) return neg ? m : 0;                                                           \
    return (x >> k) | (neg ? (m & ~(m >> k)) : 0); }                                          \
static inline T efch_sdiv##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return nx ? 1 : m;                                                            \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, q = ax / ay;                     \
    return (nx != ny) ? ((T)-q & m) : q; }                                                    \
static inline T efch_srem##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return x;                                                                     \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, r = ax % ay;                     \
    return nx ? ((T)-r & m) : r; }
EFCH_SIGNED_OPS(uint64_t, 64)
EFCH_SIGNED_OPS(efch_u128, 128)

int efch_hpack_int_decode(uint64_t in_n, const uint8_t *in_buf, size_t in_buf_len, uint64_t *out0, uint64_t *out1)
{
    int o1_tag;
    uint64_t o1_0 = 0;
    uint64_t o1_1 = 0;
    if (((in_n == UINT64_C(0)) || (in_n > UINT64_C(8)) || (((uint64_t)((uint64_t)in_buf_len)) == UINT64_C(0)))) {
        o1_tag = 0;
        o1_0 = 0;
        o1_1 = 0;
    } else {
        uint64_t v2 = (((uint64_t)(((((((uint64_t)in_n) >= 16 ? 0 : UINT64_C(1) << ((uint64_t)in_n))) & UINT64_C(0xffff)) - UINT64_C(1)) & UINT64_C(0xffff))) & UINT64_C(255));
        uint64_t v3 = (((uint64_t)in_buf[UINT64_C(0)]) & v2);
        int o4_tag;
        uint64_t o4_0 = 0;
        uint64_t o4_1 = 0;
        if ((v3 < v2)) {
            o4_tag = 1;
            o4_0 = ((uint64_t)v3);
            o4_1 = UINT64_C(1);
        } else {
            int o5_tag;
            uint64_t o5_0 = 0;
            uint64_t o5_1 = 0;
            if (((UINT64_C(1) < ((uint64_t)((uint64_t)in_buf_len))) && (((uint64_t)in_buf[UINT64_C(1)]) < UINT64_C(128)))) {
                uint64_t v6 = (((uint64_t)v2) + (((UINT64_C(7) * (UINT64_C(1) - UINT64_C(1))) >= 64 ? 0 : ((uint64_t)(((uint64_t)in_buf[UINT64_C(1)]) & UINT64_C(127))) << (UINT64_C(7) * (UINT64_C(1) - UINT64_C(1))))));
                int o7_tag;
                uint64_t o7_0 = 0;
                uint64_t o7_1 = 0;
                if ((v6 > UINT64_C(0xffffffff))) {
                    o7_tag = 0;
                    o7_0 = 0;
                    o7_1 = 0;
                } else {
                    o7_tag = 1;
                    o7_0 = (((uint64_t)v6) & UINT64_C(0xffffffff));
                    o7_1 = ((UINT64_C(1) + UINT64_C(1)) & UINT64_C(255));
                }
                o5_tag = o7_tag;
                o5_0 = o7_0;
                o5_1 = o7_1;
            } else {
                int o8_tag;
                uint64_t o8_0 = 0;
                uint64_t o8_1 = 0;
                if (((UINT64_C(2) < ((uint64_t)((uint64_t)in_buf_len))) && (((uint64_t)in_buf[UINT64_C(2)]) < UINT64_C(128)))) {
                    uint64_t v9 = (((uint64_t)v2) + ((((UINT64_C(7) * (UINT64_C(1) - UINT64_C(1))) >= 64 ? 0 : ((uint64_t)(((uint64_t)in_buf[UINT64_C(1)]) & UINT64_C(127))) << (UINT64_C(7) * (UINT64_C(1) - UINT64_C(1))))) + (((UINT64_C(7) * (UINT64_C(2) - UINT64_C(1))) >= 64 ? 0 : ((uint64_t)(((uint64_t)in_buf[UINT64_C(2)]) & UINT64_C(127))) << (UINT64_C(7) * (UINT64_C(2) - UINT64_C(1)))))));
                    int o10_tag;
                    uint64_t o10_0 = 0;
                    uint64_t o10_1 = 0;
                    if ((v9 > UINT64_C(0xffffffff))) {
                        o10_tag = 0;
                        o10_0 = 0;
                        o10_1 = 0;
                    } else {
                        o10_tag = 1;
                        o10_0 = (((uint64_t)v9) & UINT64_C(0xffffffff));
                        o10_1 = ((UINT64_C(2) + UINT64_C(1)) & UINT64_C(255));
                    }
                    o8_tag = o10_tag;
                    o8_0 = o10_0;
                    o8_1 = o10_1;
                } else {
                    int o11_tag;
                    uint64_t o11_0 = 0;
                    uint64_t o11_1 = 0;
                    if (((UINT64_C(3) < ((uint64_t)((uint64_t)in_buf_len))) && (((uint64_t)in_buf[UINT64_C(3)]) < UINT64_C(128)))) {
                        uint64_t v12 = (((uint64_t)v2) + (((((UINT64_C(7) * (UINT64_C(1) - UINT64_C(1))) >= 64 ? 0 : ((uint64_t)(((uint64_t)in_buf[UINT64_C(1)]) & UINT64_C(127))) << (UINT64_C(7) * (UINT64_C(1) - UINT64_C(1))))) + (((UINT64_C(7) * (UINT64_C(2) - UINT64_C(1))) >= 64 ? 0 : ((uint64_t)(((uint64_t)in_buf[UINT64_C(2)]) & UINT64_C(127))) << (UINT64_C(7) * (UINT64_C(2) - UINT64_C(1)))))) + (((UINT64_C(7) * (UINT64_C(3) - UINT64_C(1))) >= 64 ? 0 : ((uint64_t)(((uint64_t)in_buf[UINT64_C(3)]) & UINT64_C(127))) << (UINT64_C(7) * (UINT64_C(3) - UINT64_C(1)))))));
                        int o13_tag;
                        uint64_t o13_0 = 0;
                        uint64_t o13_1 = 0;
                        if ((v12 > UINT64_C(0xffffffff))) {
                            o13_tag = 0;
                            o13_0 = 0;
                            o13_1 = 0;
                        } else {
                            o13_tag = 1;
                            o13_0 = (((uint64_t)v12) & UINT64_C(0xffffffff));
                            o13_1 = ((UINT64_C(3) + UINT64_C(1)) & UINT64_C(255));
                        }
                        o11_tag = o13_tag;
                        o11_0 = o13_0;
                        o11_1 = o13_1;
                    } else {
                        int o14_tag;
                        uint64_t o14_0 = 0;
                        uint64_t o14_1 = 0;
                        if (((UINT64_C(4) < ((uint64_t)((uint64_t)in_buf_len))) && (((uint64_t)in_buf[UINT64_C(4)]) < UINT64_C(128)))) {
                            uint64_t v15 = (((uint64_t)v2) + ((((((UINT64_C(7) * (UINT64_C(1) - UINT64_C(1))) >= 64 ? 0 : ((uint64_t)(((uint64_t)in_buf[UINT64_C(1)]) & UINT64_C(127))) << (UINT64_C(7) * (UINT64_C(1) - UINT64_C(1))))) + (((UINT64_C(7) * (UINT64_C(2) - UINT64_C(1))) >= 64 ? 0 : ((uint64_t)(((uint64_t)in_buf[UINT64_C(2)]) & UINT64_C(127))) << (UINT64_C(7) * (UINT64_C(2) - UINT64_C(1)))))) + (((UINT64_C(7) * (UINT64_C(3) - UINT64_C(1))) >= 64 ? 0 : ((uint64_t)(((uint64_t)in_buf[UINT64_C(3)]) & UINT64_C(127))) << (UINT64_C(7) * (UINT64_C(3) - UINT64_C(1)))))) + (((UINT64_C(7) * (UINT64_C(4) - UINT64_C(1))) >= 64 ? 0 : ((uint64_t)(((uint64_t)in_buf[UINT64_C(4)]) & UINT64_C(127))) << (UINT64_C(7) * (UINT64_C(4) - UINT64_C(1)))))));
                            int o16_tag;
                            uint64_t o16_0 = 0;
                            uint64_t o16_1 = 0;
                            if ((v15 > UINT64_C(0xffffffff))) {
                                o16_tag = 0;
                                o16_0 = 0;
                                o16_1 = 0;
                            } else {
                                o16_tag = 1;
                                o16_0 = (((uint64_t)v15) & UINT64_C(0xffffffff));
                                o16_1 = ((UINT64_C(4) + UINT64_C(1)) & UINT64_C(255));
                            }
                            o14_tag = o16_tag;
                            o14_0 = o16_0;
                            o14_1 = o16_1;
                        } else {
                            int o17_tag;
                            uint64_t o17_0 = 0;
                            uint64_t o17_1 = 0;
                            if (((UINT64_C(5) < ((uint64_t)((uint64_t)in_buf_len))) && (((uint64_t)in_buf[UINT64_C(5)]) < UINT64_C(128)))) {
                                uint64_t v18 = (((uint64_t)v2) + (((((((UINT64_C(7) * (UINT64_C(1) - UINT64_C(1))) >= 64 ? 0 : ((uint64_t)(((uint64_t)in_buf[UINT64_C(1)]) & UINT64_C(127))) << (UINT64_C(7) * (UINT64_C(1) - UINT64_C(1))))) + (((UINT64_C(7) * (UINT64_C(2) - UINT64_C(1))) >= 64 ? 0 : ((uint64_t)(((uint64_t)in_buf[UINT64_C(2)]) & UINT64_C(127))) << (UINT64_C(7) * (UINT64_C(2) - UINT64_C(1)))))) + (((UINT64_C(7) * (UINT64_C(3) - UINT64_C(1))) >= 64 ? 0 : ((uint64_t)(((uint64_t)in_buf[UINT64_C(3)]) & UINT64_C(127))) << (UINT64_C(7) * (UINT64_C(3) - UINT64_C(1)))))) + (((UINT64_C(7) * (UINT64_C(4) - UINT64_C(1))) >= 64 ? 0 : ((uint64_t)(((uint64_t)in_buf[UINT64_C(4)]) & UINT64_C(127))) << (UINT64_C(7) * (UINT64_C(4) - UINT64_C(1)))))) + (((UINT64_C(7) * (UINT64_C(5) - UINT64_C(1))) >= 64 ? 0 : ((uint64_t)(((uint64_t)in_buf[UINT64_C(5)]) & UINT64_C(127))) << (UINT64_C(7) * (UINT64_C(5) - UINT64_C(1)))))));
                                int o19_tag;
                                uint64_t o19_0 = 0;
                                uint64_t o19_1 = 0;
                                if ((v18 > UINT64_C(0xffffffff))) {
                                    o19_tag = 0;
                                    o19_0 = 0;
                                    o19_1 = 0;
                                } else {
                                    o19_tag = 1;
                                    o19_0 = (((uint64_t)v18) & UINT64_C(0xffffffff));
                                    o19_1 = ((UINT64_C(5) + UINT64_C(1)) & UINT64_C(255));
                                }
                                o17_tag = o19_tag;
                                o17_0 = o19_0;
                                o17_1 = o19_1;
                            } else {
                                o17_tag = 0;
                                o17_0 = 0;
                                o17_1 = 0;
                            }
                            o14_tag = o17_tag;
                            o14_0 = o17_0;
                            o14_1 = o17_1;
                        }
                        o11_tag = o14_tag;
                        o11_0 = o14_0;
                        o11_1 = o14_1;
                    }
                    o8_tag = o11_tag;
                    o8_0 = o11_0;
                    o8_1 = o11_1;
                }
                o5_tag = o8_tag;
                o5_0 = o8_0;
                o5_1 = o8_1;
            }
            o4_tag = o5_tag;
            o4_0 = o5_0;
            o4_1 = o5_1;
        }
        o1_tag = o4_tag;
        o1_0 = o4_0;
        o1_1 = o4_1;
    }
    if (o1_tag) {
        *out0 = (uint64_t)(o1_0);
        *out1 = (uint64_t)(o1_1);
    }
    return o1_tag;
}
