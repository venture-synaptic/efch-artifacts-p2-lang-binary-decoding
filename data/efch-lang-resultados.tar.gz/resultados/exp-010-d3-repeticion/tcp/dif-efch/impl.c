#include <stddef.h>
#include <stdint.h>
#include <string.h>
typedef unsigned __int128 efch_u128;

/* Operaciones con signo sobre valores de w bits guardados sin signo y enmascarados. Solo usan
   aritmética sin signo: no hay comportamiento indefinido ni dependiente de la implementación. */
#define EFCH_SIGNED_OPS(T, SUF)                                                               \
static inline T efch_mask##SUF(unsigned w) { return w >= 8 * sizeof(T) ? (T)~(T)0 : (((T)1 << w) - 1); } \
static inline int efch_slt##SUF(T x, T y, unsigned w) { T s = (T)1 << (w - 1); return (x ^ s) < (y ^ s); } \
static inline T efch_sext##SUF(T x, unsigned w, unsigned n) {                                 \
    return (x & ((T)1 << (w - 1))) ? (x | (efch_mask##SUF(n) & ~efch_mask##SUF(w))) : x; }    \
static inline T efch_ashr##SUF(T x, T k, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int neg = (x >> (w - 1)) & 1;                                    \
    if (k >= w) return neg ? m : 0;                                                           \
    return (x >> k) | (neg ? (m & ~(m >> k)) : 0); }                                          \
static inline T efch_sdiv##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return nx ? 1 : m;                                                            \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, q = ax / ay;                     \
    return (nx != ny) ? ((T)-q & m) : q; }                                                    \
static inline T efch_srem##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return x;                                                                     \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, r = ax % ay;                     \
    return nx ? ((T)-r & m) : r; }
EFCH_SIGNED_OPS(uint64_t, 64)
EFCH_SIGNED_OPS(efch_u128, 128)

int efch_tcp_options__lang(const uint8_t *in_b, size_t in_b_len, uint64_t *out0, uint64_t *out1, uint64_t *out2, uint64_t *out3)
{
    int o1_tag;
    uint64_t o1_0 = 0;
    uint64_t o1_1 = 0;
    uint64_t o1_2 = 0;
    int o1_3 = 0;
    if ((((uint64_t)((uint64_t)in_b_len)) < UINT64_C(20))) {
        o1_tag = 0;
        o1_0 = 0;
        o1_1 = 0;
        o1_2 = 0;
        o1_3 = 0;
    } else {
        uint64_t v2_n = ((uint64_t)in_b_len);
        const uint8_t *v2 = in_b;
        uint64_t v3 = ((((uint64_t)v2_n) < UINT64_C(20)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v2[UINT64_C(12)]) >> 4)) * UINT64_C(4)) & UINT64_C(0xffff)));
        int o4_tag;
        uint64_t o4_0 = 0;
        uint64_t o4_1 = 0;
        uint64_t o4_2 = 0;
        int o4_3 = 0;
        if ((((((uint64_t)in_b[UINT64_C(12)]) >> 4) < UINT64_C(5)) || (v3 > ((uint64_t)((uint64_t)in_b_len))))) {
            o4_tag = 0;
            o4_0 = 0;
            o4_1 = 0;
            o4_2 = 0;
            o4_3 = 0;
        } else {
            uint64_t f5 = UINT64_C(20);
            for (int k6 = 0; k6 < 40; k6++) {
                uint64_t v7_n = ((uint64_t)in_b_len);
                const uint8_t *v7 = in_b;
                uint64_t v8 = f5;
                uint64_t v9_n = v7_n;
                const uint8_t *v9 = v7;
                uint64_t v10 = ((((uint64_t)v9_n) < UINT64_C(20)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v9[UINT64_C(12)]) >> 4)) * UINT64_C(4)) & UINT64_C(0xffff)));
                uint64_t v11 = (((uint64_t)(v8 & UINT64_C(255))) & UINT64_C(0xffff));
                uint64_t t20;
                if (((((v8 & UINT64_C(0x300)) != UINT64_C(0)) || (v11 >= v10)) || (v10 > ((uint64_t)v7_n)))) {
                    t20 = v8;
                } else {
                    uint64_t v12 = ((uint64_t)v7[v11]);
                    uint64_t t19;
                    if ((v12 == UINT64_C(0))) {
                        t19 = (v8 | UINT64_C(0x100));
                    } else {
                        uint64_t t18;
                        if ((v12 == UINT64_C(1))) {
                            t18 = (v8 + UINT64_C(1));
                        } else {
                            uint64_t v13 = (v8 | UINT64_C(0x200));
                            uint64_t t17;
                            if ((((v11 + UINT64_C(1)) & UINT64_C(0xffff)) >= v10)) {
                                t17 = v13;
                            } else {
                                uint64_t v14 = ((uint64_t)v7[((v11 + UINT64_C(1)) & UINT64_C(0xffff))]);
                                uint64_t t16;
                                if (((v14 < UINT64_C(2)) || (((v11 + ((uint64_t)v14)) & UINT64_C(0xffff)) > v10))) {
                                    t16 = v13;
                                } else {
                                    uint64_t v15 = ((v8 & UINT64_C(0xffffffffffffff00)) | ((uint64_t)((v11 + ((uint64_t)v14)) & UINT64_C(0xffff))));
                                    t16 = ((v12 == UINT64_C(2)) ? (((v14 != UINT64_C(4)) || ((v8 & UINT64_C(0x100000000)) != UINT64_C(0))) ? v13 : (((v15 | (((uint64_t)((uint64_t)v7[((v11 + UINT64_C(2)) & UINT64_C(0xffff))])) << 24)) | (((uint64_t)((uint64_t)v7[((v11 + UINT64_C(3)) & UINT64_C(0xffff))])) << 16)) | UINT64_C(0x100000000))) : ((v12 == UINT64_C(3)) ? (((v14 != UINT64_C(3)) || ((v8 & UINT64_C(0x1000000000000)) != UINT64_C(0))) ? v13 : ((v15 | (((uint64_t)((((uint64_t)v7[((v11 + UINT64_C(2)) & UINT64_C(0xffff))]) < UINT64_C(14)) ? ((uint64_t)v7[((v11 + UINT64_C(2)) & UINT64_C(0xffff))]) : UINT64_C(14))) << 40)) | UINT64_C(0x1000000000000))) : ((v12 == UINT64_C(4)) ? (((v14 != UINT64_C(2)) || ((v8 & UINT64_C(0x2000000000000)) != UINT64_C(0))) ? v13 : (v15 | UINT64_C(0x2000000000000))) : v15)));
                                }
                                t17 = t16;
                            }
                            t18 = t17;
                        }
                        t19 = t18;
                    }
                    t20 = t19;
                }
                uint64_t n21 = t20;
                if (n21 == f5) break;
                f5 = n21;
            }
            uint64_t v22 = f5;
            int o23_tag;
            uint64_t o23_0 = 0;
            uint64_t o23_1 = 0;
            uint64_t o23_2 = 0;
            int o23_3 = 0;
            if (((v22 & UINT64_C(0x200)) != UINT64_C(0))) {
                o23_tag = 0;
                o23_0 = 0;
                o23_1 = 0;
                o23_2 = 0;
                o23_3 = 0;
            } else {
                uint64_t v24 = (((v22 & UINT64_C(0x100000000)) == UINT64_C(0)) ? UINT64_C(0xffff) : (((uint64_t)(v22 >> 16)) & UINT64_C(0xffff)));
                uint64_t v25 = (((v22 & UINT64_C(0x1000000000000)) == UINT64_C(0)) ? UINT64_C(255) : (((uint64_t)(v22 >> 40)) & UINT64_C(255)));
                o23_tag = 1;
                o23_0 = (((uint64_t)v3) & UINT64_C(255));
                o23_1 = v24;
                o23_2 = v25;
                o23_3 = ((v22 & UINT64_C(0x2000000000000)) != UINT64_C(0));
            }
            o4_tag = o23_tag;
            o4_0 = o23_0;
            o4_1 = o23_1;
            o4_2 = o23_2;
            o4_3 = o23_3;
        }
        o1_tag = o4_tag;
        o1_0 = o4_0;
        o1_1 = o4_1;
        o1_2 = o4_2;
        o1_3 = o4_3;
    }
    if (o1_tag) {
        *out0 = (uint64_t)(o1_0);
        *out1 = (uint64_t)(o1_1);
        *out2 = (uint64_t)(o1_2);
        *out3 = (uint64_t)(o1_3);
    }
    return o1_tag;
}
