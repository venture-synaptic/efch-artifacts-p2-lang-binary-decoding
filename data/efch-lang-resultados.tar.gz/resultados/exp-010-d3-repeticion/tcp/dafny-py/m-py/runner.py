import sys
sys.path.insert(0, '/home/ubuntu/projects/efch/resultados/exp-010-d3-repeticion/tcp/dafny-py/m-py')
import _dafny, module_
from module_ import default__
two = False
for line in sys.stdin:
    n, h = line.split()
    buf = _dafny.Seq(list(bytes.fromhex('' if h == '-' else h)))
    r = default__.Parse(int(n), buf) if two else default__.Parse(buf)
    if r.is_None:
        print("null")
    else:
        print(" ".join(("true" if x else "false") if isinstance(x, bool) else str(int(x)) for x in r.value))
