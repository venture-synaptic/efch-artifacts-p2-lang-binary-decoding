import sys
from typing import Callable, Any, TypeVar, NamedTuple
from math import floor
from itertools import count

import module_ as module_
import _dafny as _dafny
import System_ as System_

# Module: module_

class default__:
    def  __init__(self):
        pass

    @staticmethod
    def Walk(b, hl, p, mss, ws, sack):
        while True:
            with _dafny.label():
                d_0_done_ = Option_Some((hl, (65535 if (mss) < (0) else mss), (255 if (ws) < (0) else ws), sack))
                if ((p) == (hl)) or (((b)[p]) == (0)):
                    return d_0_done_
                elif ((b)[p]) == (1):
                    in0_ = b
                    in1_ = hl
                    in2_ = (p) + (1)
                    in3_ = mss
                    in4_ = ws
                    in5_ = sack
                    b = in0_
                    hl = in1_
                    p = in2_
                    mss = in3_
                    ws = in4_
                    sack = in5_
                    raise _dafny.TailCall()
                elif ((p) + (1)) >= (hl):
                    return Option_None()
                elif True:
                    d_1_l_ = (b)[(p) + (1)]
                    if ((d_1_l_) < (2)) or (((p) + (d_1_l_)) > (hl)):
                        return Option_None()
                    elif ((b)[p]) == (2):
                        if ((d_1_l_) != (4)) or ((mss) >= (0)):
                            return Option_None()
                        elif True:
                            in6_ = b
                            in7_ = hl
                            in8_ = (p) + (d_1_l_)
                            in9_ = (((b)[(p) + (2)]) * (256)) + ((b)[(p) + (3)])
                            in10_ = ws
                            in11_ = sack
                            b = in6_
                            hl = in7_
                            p = in8_
                            mss = in9_
                            ws = in10_
                            sack = in11_
                            raise _dafny.TailCall()
                    elif ((b)[p]) == (3):
                        if ((d_1_l_) != (3)) or ((ws) >= (0)):
                            return Option_None()
                        elif True:
                            in12_ = b
                            in13_ = hl
                            in14_ = (p) + (d_1_l_)
                            in15_ = mss
                            in16_ = (14 if ((b)[(p) + (2)]) > (14) else (b)[(p) + (2)])
                            in17_ = sack
                            b = in12_
                            hl = in13_
                            p = in14_
                            mss = in15_
                            ws = in16_
                            sack = in17_
                            raise _dafny.TailCall()
                    elif ((b)[p]) == (4):
                        if ((d_1_l_) != (2)) or (sack):
                            return Option_None()
                        elif True:
                            in18_ = b
                            in19_ = hl
                            in20_ = (p) + (d_1_l_)
                            in21_ = mss
                            in22_ = ws
                            in23_ = True
                            b = in18_
                            hl = in19_
                            p = in20_
                            mss = in21_
                            ws = in22_
                            sack = in23_
                            raise _dafny.TailCall()
                    elif True:
                        in24_ = b
                        in25_ = hl
                        in26_ = (p) + (d_1_l_)
                        in27_ = mss
                        in28_ = ws
                        in29_ = sack
                        b = in24_
                        hl = in25_
                        p = in26_
                        mss = in27_
                        ws = in28_
                        sack = in29_
                        raise _dafny.TailCall()
                break

    @staticmethod
    def Spec(b):
        if (len(b)) < (20):
            return Option_None()
        elif (((b)[12]) < (80)) or (((4) * (_dafny.euclidian_division((b)[12], 16))) > (len(b))):
            return Option_None()
        elif True:
            return default__.Walk(b, (4) * (_dafny.euclidian_division((b)[12], 16)), 20, -1, -1, False)

    @staticmethod
    def Parse(b):
        r: Option = Option.default()()
        if (len(b)) < (20):
            r = Option_None()
            return r
        d_0_hl_: int
        d_0_hl_ = (4) * (_dafny.euclidian_division((b)[12], 16))
        if (((b)[12]) < (80)) or ((d_0_hl_) > (len(b))):
            r = Option_None()
            return r
        d_1_p_: int
        d_2_mss_: int
        d_3_ws_: int
        d_4_sack_: bool
        rhs0_ = 20
        rhs1_ = -1
        rhs2_ = -1
        rhs3_ = False
        d_1_p_ = rhs0_
        d_2_mss_ = rhs1_
        d_3_ws_ = rhs2_
        d_4_sack_ = rhs3_
        with _dafny.label("0"):
            while (d_1_p_) < (d_0_hl_):
                with _dafny.c_label("0"):
                    if ((b)[d_1_p_]) == (0):
                        raise _dafny.Break("0")
                    if ((b)[d_1_p_]) == (1):
                        d_1_p_ = (d_1_p_) + (1)
                        raise _dafny.Continue("0")
                    if ((d_1_p_) + (1)) >= (d_0_hl_):
                        r = Option_None()
                        return r
                    d_5_l_: int
                    d_5_l_ = (b)[(d_1_p_) + (1)]
                    if ((d_5_l_) < (2)) or (((d_1_p_) + (d_5_l_)) > (d_0_hl_)):
                        r = Option_None()
                        return r
                    if ((b)[d_1_p_]) == (2):
                        if ((d_5_l_) != (4)) or ((d_2_mss_) >= (0)):
                            r = Option_None()
                            return r
                        d_2_mss_ = (((b)[(d_1_p_) + (2)]) * (256)) + ((b)[(d_1_p_) + (3)])
                    elif ((b)[d_1_p_]) == (3):
                        if ((d_5_l_) != (3)) or ((d_3_ws_) >= (0)):
                            r = Option_None()
                            return r
                        if ((b)[(d_1_p_) + (2)]) > (14):
                            d_3_ws_ = 14
                        elif True:
                            d_3_ws_ = (b)[(d_1_p_) + (2)]
                    elif ((b)[d_1_p_]) == (4):
                        if ((d_5_l_) != (2)) or (d_4_sack_):
                            r = Option_None()
                            return r
                        d_4_sack_ = True
                    d_1_p_ = (d_1_p_) + (d_5_l_)
                    pass
            pass
        r = Option_Some((d_0_hl_, (65535 if (d_2_mss_) < (0) else d_2_mss_), (255 if (d_3_ws_) < (0) else d_3_ws_), d_4_sack_))
        return r
        return r


class u8:
    def  __init__(self):
        pass

    @staticmethod
    def default():
        return int(0)
    def _Is(source__):
        return True

class Option:
    @classmethod
    def default(cls, ):
        return lambda: Option_None()
    def __ne__(self, __o: object) -> bool:
        return not self.__eq__(__o)
    @property
    def is_None(self) -> bool:
        return isinstance(self, Option_None)
    @property
    def is_Some(self) -> bool:
        return isinstance(self, Option_Some)

class Option_None(Option, NamedTuple('None_', [])):
    def __dafnystr__(self) -> str:
        return f'Option.None'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, Option_None)
    def __hash__(self) -> int:
        return super().__hash__()

class Option_Some(Option, NamedTuple('Some', [('value', Any)])):
    def __dafnystr__(self) -> str:
        return f'Option.Some({_dafny.string_of(self.value)})'
    def __eq__(self, __o: object) -> bool:
        return isinstance(__o, Option_Some) and self.value == __o.value
    def __hash__(self) -> int:
        return super().__hash__()

