# EXP-010 (opciones TCP con fold)

- ns_op: {"especificacion": 30.617, "efch_lang": 33.051, "c_a_mano": 26.838, "rust": 27.031, "go": 29.339}
- ns_op_por_estrato: {"aleatorio": {"especificacion": 14.412, "efch_lang": 14.57, "c_a_mano": 13.013, "rust": 11.584, "go": 14.142}, "validas": {"especificacion": 53.217, "efch_lang": 52.061, "c_a_mano": 44.439, "rust": 46.247, "go": 41.761}, "alteradas": {"especificacion": 29.22, "efch_lang": 30.947, "c_a_mano": 26.294, "rust": 25.24, "go": 27.152}}
```json
{
  "D0": {
    "cumple": true,
    "indefinidas": {
      "diferencial_nativo": 0,
      "diferencial_externo": 0
    },
    "especificacion_vectores_fallidos": []
  },
  "D1": {
    "valor": "revisión manual: ver la ficha (estado empaquetado y límite de recursión)",
    "cumple": null
  },
  "D2": {
    "valor": {
      "estado": "probado",
      "segundos": 0.79,
      "codigo": 0,
      "detalle": null,
      "herramienta": "Z3"
    },
    "cumple": true
  },
  "D3": {
    "efch_lang_sobre_c": 1.232,
    "cumple": true
  },
  "D4": {
    "rust_kani": {
      "esfuerzo_relativo": 0.808,
      "a": false,
      "b": true,
      "c": false,
      "cumple": true
    },
    "dafny": {
      "esfuerzo_relativo": 1.59,
      "a": false,
      "b": false,
      "c": true,
      "cumple": true
    },
    "cumple": true
  },
  "D5": {
    "aplica": true,
    "lineas_dafny_spec": 35,
    "efch_lang_sobre_dafny_spec_go": 0.012,
    "cumple": true
  },
  "decision": "pendiente de D1 (revisión manual)"
}
```
