# Re-ejecución de EXP-004 y EXP-015 con el código actual (02/11/2026)

**[Experimento]** Re-ejecución informada, no confirmatoria: mismas cargas, corpus y scripts; código de `main`
26315176 (01/11/2026), que difiere del usado el 21–24/10. Máquina: la misma (Haswell, 4 núcleos, gcc 15.2),
reservada con `maquina.py`. Sin LLM. Script: `reejecutar.sh`; registros: `reejecucion.log` y `reintento-m9.log`.

**Incidente propio.** El primer intento de M9 omitió `--definicion/--computacion` (la interfaz por defecto es TCP):
varint falló al leer la carga e IPv4 midió con una firma que, por coincidencia, es idéntica. Esos directorios se
conservan como `d3-*-intento1-sin-definicion/`; los resultados válidos son los del reintento.

| | Archivado (21–24/10) | Re-ejecución (02/11) |
|---|---|---|
| EXP-004 equivalencias | 2/2 `probado` | 2/2 `probado` |
| EXP-004 C generado | — | varint idéntico; trama: núcleo y C más compactos, **objeto `.o` idéntico** |
| EXP-004 EFCH/C a mano, `-O3 -march=native` | varint 1,016; trama 1,017 | varint 0,961; trama 1,051 (una medición, sin bandas) |
| EXP-015 cargas | — | idénticas byte a byte (6/6) |
| EXP-015 C generado | — | idéntico (4/4 fuentes) |
| EXP-015 D0 | 67/67, 58/58; 110 000 entradas, 0 fallos | igual |
| EXP-015 D2 IPv4 `check`/`verify` | 1,2 s / 1,4 s | 1,16 s / 1,32 s |
| EXP-015 D2 varint `check`/`verify` | 0,28 s / 0,42 s | 0,35 s / 0,49 s |
| EXP-015 D3 IPv4 (M9) | 1,027 [0,96; 1,12] cumple | 1,030 [0,95; 1,13] cumple |
| EXP-015 D3 varint (M9) | 0,966 [0,90; 1,03] cumple | 0,965 [0,90; 1,03] cumple |

**[Resultado]** Los resultados de EXP-015 se reproducen con el código actual. En EXP-004, la diferencia de tiempos
con el `.o` idéntico indica variación de medida del harness sencillo de `lang01.py` (sin M9), no un cambio del
código generado. No se re-ejecutaron EXP-005 ni EXP-007–010.
