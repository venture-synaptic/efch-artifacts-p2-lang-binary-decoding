#include <stddef.h>
#include <stdint.h>
#include <string.h>
typedef unsigned __int128 efch_u128;

/* Operaciones con signo sobre valores de w bits guardados sin signo y enmascarados. Solo usan
   aritmética sin signo: no hay comportamiento indefinido ni dependiente de la implementación. */
#define EFCH_SIGNED_OPS(T, SUF)                                                               \
static inline T efch_mask##SUF(unsigned w) { return w >= 8 * sizeof(T) ? (T)~(T)0 : (((T)1 << w) - 1); } \
static inline int efch_slt##SUF(T x, T y, unsigned w) { T s = (T)1 << (w - 1); return (x ^ s) < (y ^ s); } \
static inline T efch_sext##SUF(T x, unsigned w, unsigned n) {                                 \
    return (x & ((T)1 << (w - 1))) ? (x | (efch_mask##SUF(n) & ~efch_mask##SUF(w))) : x; }    \
static inline T efch_ashr##SUF(T x, T k, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int neg = (x >> (w - 1)) & 1;                                    \
    if (k >= w) return neg ? m : 0;                                                           \
    return (x >> k) | (neg ? (m & ~(m >> k)) : 0); }                                          \
static inline T efch_sdiv##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return nx ? 1 : m;                                                            \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, q = ax / ay;                     \
    return (nx != ny) ? ((T)-q & m) : q; }                                                    \
static inline T efch_srem##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return x;                                                                     \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, r = ax % ay;                     \
    return nx ? ((T)-r & m) : r; }
EFCH_SIGNED_OPS(uint64_t, 64)
EFCH_SIGNED_OPS(efch_u128, 128)

int efch_varint_u64__lang(const uint8_t *in_b, size_t in_b_len, uint64_t *out0, uint64_t *out1)
{
    uint64_t v1 = UINT64_C(0);
    uint64_t v2 = ((((uint64_t)((uint64_t)in_b_len)) < UINT64_C(10)) ? ((uint64_t)((uint64_t)in_b_len)) : UINT64_C(10));
    int o3_tag;
    uint64_t o3_0 = 0;
    uint64_t o3_1 = 0;
    if ((UINT64_C(0) < v2)) {
        uint64_t v4 = ((uint64_t)in_b[UINT64_C(0)]);
        int o5_tag;
        uint64_t o5_0 = 0;
        uint64_t o5_1 = 0;
        if ((v4 < UINT64_C(128))) {
            int o6_tag;
            uint64_t o6_0 = 0;
            uint64_t o6_1 = 0;
            if ((0 && (v4 > UINT64_C(1)))) {
                o6_tag = 0;
                o6_0 = 0;
                o6_1 = 0;
            } else {
                o6_tag = 1;
                o6_0 = (v1 | (((uint64_t)v4) << 0));
                o6_1 = UINT64_C(1);
            }
            o5_tag = o6_tag;
            o5_0 = o6_0;
            o5_1 = o6_1;
        } else {
            uint64_t v7 = (v1 | (((uint64_t)(v4 & UINT64_C(127))) << 0));
            int o8_tag;
            uint64_t o8_0 = 0;
            uint64_t o8_1 = 0;
            if ((UINT64_C(1) < v2)) {
                uint64_t v9 = ((uint64_t)in_b[UINT64_C(1)]);
                int o10_tag;
                uint64_t o10_0 = 0;
                uint64_t o10_1 = 0;
                if ((v9 < UINT64_C(128))) {
                    int o11_tag;
                    uint64_t o11_0 = 0;
                    uint64_t o11_1 = 0;
                    if ((0 && (v9 > UINT64_C(1)))) {
                        o11_tag = 0;
                        o11_0 = 0;
                        o11_1 = 0;
                    } else {
                        o11_tag = 1;
                        o11_0 = (v7 | (((uint64_t)v9) << 7));
                        o11_1 = UINT64_C(2);
                    }
                    o10_tag = o11_tag;
                    o10_0 = o11_0;
                    o10_1 = o11_1;
                } else {
                    uint64_t v12 = (v7 | (((uint64_t)(v9 & UINT64_C(127))) << 7));
                    int o13_tag;
                    uint64_t o13_0 = 0;
                    uint64_t o13_1 = 0;
                    if ((UINT64_C(2) < v2)) {
                        uint64_t v14 = ((uint64_t)in_b[UINT64_C(2)]);
                        int o15_tag;
                        uint64_t o15_0 = 0;
                        uint64_t o15_1 = 0;
                        if ((v14 < UINT64_C(128))) {
                            int o16_tag;
                            uint64_t o16_0 = 0;
                            uint64_t o16_1 = 0;
                            if ((0 && (v14 > UINT64_C(1)))) {
                                o16_tag = 0;
                                o16_0 = 0;
                                o16_1 = 0;
                            } else {
                                o16_tag = 1;
                                o16_0 = (v12 | (((uint64_t)v14) << 14));
                                o16_1 = UINT64_C(3);
                            }
                            o15_tag = o16_tag;
                            o15_0 = o16_0;
                            o15_1 = o16_1;
                        } else {
                            uint64_t v17 = (v12 | (((uint64_t)(v14 & UINT64_C(127))) << 14));
                            int o18_tag;
                            uint64_t o18_0 = 0;
                            uint64_t o18_1 = 0;
                            if ((UINT64_C(3) < v2)) {
                                uint64_t v19 = ((uint64_t)in_b[UINT64_C(3)]);
                                int o20_tag;
                                uint64_t o20_0 = 0;
                                uint64_t o20_1 = 0;
                                if ((v19 < UINT64_C(128))) {
                                    int o21_tag;
                                    uint64_t o21_0 = 0;
                                    uint64_t o21_1 = 0;
                                    if ((0 && (v19 > UINT64_C(1)))) {
                                        o21_tag = 0;
                                        o21_0 = 0;
                                        o21_1 = 0;
                                    } else {
                                        o21_tag = 1;
                                        o21_0 = (v17 | (((uint64_t)v19) << 21));
                                        o21_1 = UINT64_C(4);
                                    }
                                    o20_tag = o21_tag;
                                    o20_0 = o21_0;
                                    o20_1 = o21_1;
                                } else {
                                    uint64_t v22 = (v17 | (((uint64_t)(v19 & UINT64_C(127))) << 21));
                                    int o23_tag;
                                    uint64_t o23_0 = 0;
                                    uint64_t o23_1 = 0;
                                    if ((UINT64_C(4) < v2)) {
                                        uint64_t v24 = ((uint64_t)in_b[UINT64_C(4)]);
                                        int o25_tag;
                                        uint64_t o25_0 = 0;
                                        uint64_t o25_1 = 0;
                                        if ((v24 < UINT64_C(128))) {
                                            int o26_tag;
                                            uint64_t o26_0 = 0;
                                            uint64_t o26_1 = 0;
                                            if ((0 && (v24 > UINT64_C(1)))) {
                                                o26_tag = 0;
                                                o26_0 = 0;
                                                o26_1 = 0;
                                            } else {
                                                o26_tag = 1;
                                                o26_0 = (v22 | (((uint64_t)v24) << 28));
                                                o26_1 = UINT64_C(5);
                                            }
                                            o25_tag = o26_tag;
                                            o25_0 = o26_0;
                                            o25_1 = o26_1;
                                        } else {
                                            uint64_t v27 = (v22 | (((uint64_t)(v24 & UINT64_C(127))) << 28));
                                            int o28_tag;
                                            uint64_t o28_0 = 0;
                                            uint64_t o28_1 = 0;
                                            if ((UINT64_C(5) < v2)) {
                                                uint64_t v29 = ((uint64_t)in_b[UINT64_C(5)]);
                                                int o30_tag;
                                                uint64_t o30_0 = 0;
                                                uint64_t o30_1 = 0;
                                                if ((v29 < UINT64_C(128))) {
                                                    int o31_tag;
                                                    uint64_t o31_0 = 0;
                                                    uint64_t o31_1 = 0;
                                                    if ((0 && (v29 > UINT64_C(1)))) {
                                                        o31_tag = 0;
                                                        o31_0 = 0;
                                                        o31_1 = 0;
                                                    } else {
                                                        o31_tag = 1;
                                                        o31_0 = (v27 | (((uint64_t)v29) << 35));
                                                        o31_1 = UINT64_C(6);
                                                    }
                                                    o30_tag = o31_tag;
                                                    o30_0 = o31_0;
                                                    o30_1 = o31_1;
                                                } else {
                                                    uint64_t v32 = (v27 | (((uint64_t)(v29 & UINT64_C(127))) << 35));
                                                    int o33_tag;
                                                    uint64_t o33_0 = 0;
                                                    uint64_t o33_1 = 0;
                                                    if ((UINT64_C(6) < v2)) {
                                                        uint64_t v34 = ((uint64_t)in_b[UINT64_C(6)]);
                                                        int o35_tag;
                                                        uint64_t o35_0 = 0;
                                                        uint64_t o35_1 = 0;
                                                        if ((v34 < UINT64_C(128))) {
                                                            int o36_tag;
                                                            uint64_t o36_0 = 0;
                                                            uint64_t o36_1 = 0;
                                                            if ((0 && (v34 > UINT64_C(1)))) {
                                                                o36_tag = 0;
                                                                o36_0 = 0;
                                                                o36_1 = 0;
                                                            } else {
                                                                o36_tag = 1;
                                                                o36_0 = (v32 | (((uint64_t)v34) << 42));
                                                                o36_1 = UINT64_C(7);
                                                            }
                                                            o35_tag = o36_tag;
                                                            o35_0 = o36_0;
                                                            o35_1 = o36_1;
                                                        } else {
                                                            uint64_t v37 = (v32 | (((uint64_t)(v34 & UINT64_C(127))) << 42));
                                                            int o38_tag;
                                                            uint64_t o38_0 = 0;
                                                            uint64_t o38_1 = 0;
                                                            if ((UINT64_C(7) < v2)) {
                                                                uint64_t v39 = ((uint64_t)in_b[UINT64_C(7)]);
                                                                int o40_tag;
                                                                uint64_t o40_0 = 0;
                                                                uint64_t o40_1 = 0;
                                                                if ((v39 < UINT64_C(128))) {
                                                                    int o41_tag;
                                                                    uint64_t o41_0 = 0;
                                                                    uint64_t o41_1 = 0;
                                                                    if ((0 && (v39 > UINT64_C(1)))) {
                                                                        o41_tag = 0;
                                                                        o41_0 = 0;
                                                                        o41_1 = 0;
                                                                    } else {
                                                                        o41_tag = 1;
                                                                        o41_0 = (v37 | (((uint64_t)v39) << 49));
                                                                        o41_1 = UINT64_C(8);
                                                                    }
                                                                    o40_tag = o41_tag;
                                                                    o40_0 = o41_0;
                                                                    o40_1 = o41_1;
                                                                } else {
                                                                    uint64_t v42 = (v37 | (((uint64_t)(v39 & UINT64_C(127))) << 49));
                                                                    int o43_tag;
                                                                    uint64_t o43_0 = 0;
                                                                    uint64_t o43_1 = 0;
                                                                    if ((UINT64_C(8) < v2)) {
                                                                        uint64_t v44 = ((uint64_t)in_b[UINT64_C(8)]);
                                                                        int o45_tag;
                                                                        uint64_t o45_0 = 0;
                                                                        uint64_t o45_1 = 0;
                                                                        if ((v44 < UINT64_C(128))) {
                                                                            int o46_tag;
                                                                            uint64_t o46_0 = 0;
                                                                            uint64_t o46_1 = 0;
                                                                            if ((0 && (v44 > UINT64_C(1)))) {
                                                                                o46_tag = 0;
                                                                                o46_0 = 0;
                                                                                o46_1 = 0;
                                                                            } else {
                                                                                o46_tag = 1;
                                                                                o46_0 = (v42 | (((uint64_t)v44) << 56));
                                                                                o46_1 = UINT64_C(9);
                                                                            }
                                                                            o45_tag = o46_tag;
                                                                            o45_0 = o46_0;
                                                                            o45_1 = o46_1;
                                                                        } else {
                                                                            uint64_t v47 = (v42 | (((uint64_t)(v44 & UINT64_C(127))) << 56));
                                                                            int o48_tag;
                                                                            uint64_t o48_0 = 0;
                                                                            uint64_t o48_1 = 0;
                                                                            if ((UINT64_C(9) < v2)) {
                                                                                uint64_t v49 = ((uint64_t)in_b[UINT64_C(9)]);
                                                                                int o50_tag;
                                                                                uint64_t o50_0 = 0;
                                                                                uint64_t o50_1 = 0;
                                                                                if ((v49 < UINT64_C(128))) {
                                                                                    int o51_tag;
                                                                                    uint64_t o51_0 = 0;
                                                                                    uint64_t o51_1 = 0;
                                                                                    if ((1 && (v49 > UINT64_C(1)))) {
                                                                                        o51_tag = 0;
                                                                                        o51_0 = 0;
                                                                                        o51_1 = 0;
                                                                                    } else {
                                                                                        o51_tag = 1;
                                                                                        o51_0 = (v47 | (((uint64_t)v49) << 63));
                                                                                        o51_1 = UINT64_C(10);
                                                                                    }
                                                                                    o50_tag = o51_tag;
                                                                                    o50_0 = o51_0;
                                                                                    o50_1 = o51_1;
                                                                                } else {
                                                                                    uint64_t v52 = (v47 | (((uint64_t)(v49 & UINT64_C(127))) << 63));
                                                                                    o50_tag = 0;
                                                                                    o50_0 = 0;
                                                                                    o50_1 = 0;
                                                                                }
                                                                                o48_tag = o50_tag;
                                                                                o48_0 = o50_0;
                                                                                o48_1 = o50_1;
                                                                            } else {
                                                                                o48_tag = 0;
                                                                                o48_0 = 0;
                                                                                o48_1 = 0;
                                                                            }
                                                                            o45_tag = o48_tag;
                                                                            o45_0 = o48_0;
                                                                            o45_1 = o48_1;
                                                                        }
                                                                        o43_tag = o45_tag;
                                                                        o43_0 = o45_0;
                                                                        o43_1 = o45_1;
                                                                    } else {
                                                                        o43_tag = 0;
                                                                        o43_0 = 0;
                                                                        o43_1 = 0;
                                                                    }
                                                                    o40_tag = o43_tag;
                                                                    o40_0 = o43_0;
                                                                    o40_1 = o43_1;
                                                                }
                                                                o38_tag = o40_tag;
                                                                o38_0 = o40_0;
                                                                o38_1 = o40_1;
                                                            } else {
                                                                o38_tag = 0;
                                                                o38_0 = 0;
                                                                o38_1 = 0;
                                                            }
                                                            o35_tag = o38_tag;
                                                            o35_0 = o38_0;
                                                            o35_1 = o38_1;
                                                        }
                                                        o33_tag = o35_tag;
                                                        o33_0 = o35_0;
                                                        o33_1 = o35_1;
                                                    } else {
                                                        o33_tag = 0;
                                                        o33_0 = 0;
                                                        o33_1 = 0;
                                                    }
                                                    o30_tag = o33_tag;
                                                    o30_0 = o33_0;
                                                    o30_1 = o33_1;
                                                }
                                                o28_tag = o30_tag;
                                                o28_0 = o30_0;
                                                o28_1 = o30_1;
                                            } else {
                                                o28_tag = 0;
                                                o28_0 = 0;
                                                o28_1 = 0;
                                            }
                                            o25_tag = o28_tag;
                                            o25_0 = o28_0;
                                            o25_1 = o28_1;
                                        }
                                        o23_tag = o25_tag;
                                        o23_0 = o25_0;
                                        o23_1 = o25_1;
                                    } else {
                                        o23_tag = 0;
                                        o23_0 = 0;
                                        o23_1 = 0;
                                    }
                                    o20_tag = o23_tag;
                                    o20_0 = o23_0;
                                    o20_1 = o23_1;
                                }
                                o18_tag = o20_tag;
                                o18_0 = o20_0;
                                o18_1 = o20_1;
                            } else {
                                o18_tag = 0;
                                o18_0 = 0;
                                o18_1 = 0;
                            }
                            o15_tag = o18_tag;
                            o15_0 = o18_0;
                            o15_1 = o18_1;
                        }
                        o13_tag = o15_tag;
                        o13_0 = o15_0;
                        o13_1 = o15_1;
                    } else {
                        o13_tag = 0;
                        o13_0 = 0;
                        o13_1 = 0;
                    }
                    o10_tag = o13_tag;
                    o10_0 = o13_0;
                    o10_1 = o13_1;
                }
                o8_tag = o10_tag;
                o8_0 = o10_0;
                o8_1 = o10_1;
            } else {
                o8_tag = 0;
                o8_0 = 0;
                o8_1 = 0;
            }
            o5_tag = o8_tag;
            o5_0 = o8_0;
            o5_1 = o8_1;
        }
        o3_tag = o5_tag;
        o3_0 = o5_0;
        o3_1 = o5_1;
    } else {
        o3_tag = 0;
        o3_0 = 0;
        o3_1 = 0;
    }
    if (o3_tag) {
        *out0 = (uint64_t)(o3_0);
        *out1 = (uint64_t)(o3_1);
    }
    return o3_tag;
}
