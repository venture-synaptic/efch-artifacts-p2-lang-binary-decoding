.section .text,"ax",@progbits
.balign 256
.skip 112, 0xcc
