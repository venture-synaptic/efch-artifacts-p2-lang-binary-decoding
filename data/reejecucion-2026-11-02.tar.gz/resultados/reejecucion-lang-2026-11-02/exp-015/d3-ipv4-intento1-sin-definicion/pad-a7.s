.section .text,"ax",@progbits
.balign 256
.skip 224, 0xcc
