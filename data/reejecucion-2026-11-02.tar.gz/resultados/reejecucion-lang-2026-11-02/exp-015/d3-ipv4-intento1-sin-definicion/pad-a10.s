.section .text,"ax",@progbits
.balign 256
