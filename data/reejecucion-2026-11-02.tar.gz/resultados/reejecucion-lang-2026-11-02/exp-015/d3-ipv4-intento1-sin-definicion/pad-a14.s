.section .text,"ax",@progbits
.balign 256
.skip 176, 0xcc
