.section .text,"ax",@progbits
.balign 256
.skip 96, 0xcc
