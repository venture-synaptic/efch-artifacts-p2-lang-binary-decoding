.section .text,"ax",@progbits
.balign 256
.skip 240, 0xcc
