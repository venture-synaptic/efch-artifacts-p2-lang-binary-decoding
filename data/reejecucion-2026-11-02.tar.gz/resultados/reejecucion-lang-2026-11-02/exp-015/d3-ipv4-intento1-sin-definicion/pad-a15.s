.section .text,"ax",@progbits
.balign 256
.skip 80, 0xcc
