.section .text,"ax",@progbits
.balign 256
.skip 208, 0xcc
