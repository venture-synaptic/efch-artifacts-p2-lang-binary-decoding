.section .text,"ax",@progbits
.balign 256
.skip 144, 0xcc
