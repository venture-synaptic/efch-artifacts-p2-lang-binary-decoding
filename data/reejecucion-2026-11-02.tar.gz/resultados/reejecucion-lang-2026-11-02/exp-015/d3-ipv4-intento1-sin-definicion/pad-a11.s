.section .text,"ax",@progbits
.balign 256
.skip 160, 0xcc
