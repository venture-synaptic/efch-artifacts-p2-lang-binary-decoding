.section .text,"ax",@progbits
.balign 256
.skip 32, 0xcc
