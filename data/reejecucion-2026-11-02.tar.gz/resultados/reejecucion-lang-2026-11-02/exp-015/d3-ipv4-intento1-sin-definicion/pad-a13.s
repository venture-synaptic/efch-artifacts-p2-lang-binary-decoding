.section .text,"ax",@progbits
.balign 256
.skip 16, 0xcc
