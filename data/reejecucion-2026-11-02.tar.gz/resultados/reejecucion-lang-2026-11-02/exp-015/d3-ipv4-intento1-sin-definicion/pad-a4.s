.section .text,"ax",@progbits
.balign 256
.skip 192, 0xcc
