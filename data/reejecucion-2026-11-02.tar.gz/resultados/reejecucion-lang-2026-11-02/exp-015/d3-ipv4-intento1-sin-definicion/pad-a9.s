.section .text,"ax",@progbits
.balign 256
.skip 48, 0xcc
