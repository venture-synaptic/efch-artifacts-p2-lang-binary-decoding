.section .text,"ax",@progbits
.balign 256
.skip 64, 0xcc
