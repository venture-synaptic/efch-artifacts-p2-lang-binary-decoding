#include <stddef.h>
#include <stdint.h>
#include <string.h>
typedef unsigned __int128 efch_u128;

/* Operaciones con signo sobre valores de w bits guardados sin signo y enmascarados. Solo usan
   aritmética sin signo: no hay comportamiento indefinido ni dependiente de la implementación. */
#define EFCH_SIGNED_OPS(T, SUF)                                                               \
static inline T efch_mask##SUF(unsigned w) { return w >= 8 * sizeof(T) ? (T)~(T)0 : (((T)1 << w) - 1); } \
static inline int efch_slt##SUF(T x, T y, unsigned w) { T s = (T)1 << (w - 1); return (x ^ s) < (y ^ s); } \
static inline T efch_sext##SUF(T x, unsigned w, unsigned n) {                                 \
    return (x & ((T)1 << (w - 1))) ? (x | (efch_mask##SUF(n) & ~efch_mask##SUF(w))) : x; }    \
static inline T efch_ashr##SUF(T x, T k, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int neg = (x >> (w - 1)) & 1;                                    \
    if (k >= w) return neg ? m : 0;                                                           \
    return (x >> k) | (neg ? (m & ~(m >> k)) : 0); }                                          \
static inline T efch_sdiv##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return nx ? 1 : m;                                                            \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, q = ax / ay;                     \
    return (nx != ny) ? ((T)-q & m) : q; }                                                    \
static inline T efch_srem##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return x;                                                                     \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, r = ax % ay;                     \
    return nx ? ((T)-r & m) : r; }
EFCH_SIGNED_OPS(uint64_t, 64)
EFCH_SIGNED_OPS(efch_u128, 128)

int efch_ipv4_header__lang(const uint8_t *in_b, size_t in_b_len, uint64_t *out0, uint64_t *out1, uint64_t *out2, uint64_t *out3)
{
    int o1_tag;
    uint64_t o1_0 = 0;
    uint64_t o1_1 = 0;
    int o1_2 = 0;
    uint64_t o1_3 = 0;
    if ((((uint64_t)((uint64_t)in_b_len)) < UINT64_C(20))) {
        o1_tag = 0;
        o1_0 = 0;
        o1_1 = 0;
        o1_2 = 0;
        o1_3 = 0;
    } else {
        uint64_t v2_n = ((uint64_t)in_b_len);
        const uint8_t *v2 = in_b;
        uint64_t v3 = ((((uint64_t)v2_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v2[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
        uint64_t v4 = (((((uint64_t)((uint64_t)in_b[UINT64_C(2)])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)in_b[UINT64_C(3)])));
        int o5_tag;
        uint64_t o5_0 = 0;
        uint64_t o5_1 = 0;
        int o5_2 = 0;
        uint64_t o5_3 = 0;
        if ((((((((uint64_t)in_b[UINT64_C(0)]) >> 4) != UINT64_C(4)) || ((((uint64_t)in_b[UINT64_C(0)]) & UINT64_C(15)) < UINT64_C(5))) || (v3 > ((uint64_t)((uint64_t)in_b_len)))) || (v4 < v3))) {
            o5_tag = 0;
            o5_0 = 0;
            o5_1 = 0;
            o5_2 = 0;
            o5_3 = 0;
        } else {
            uint64_t f6 = UINT64_C(0);
            uint64_t v7_n = ((uint64_t)in_b_len);
            const uint8_t *v7 = in_b;
            uint64_t v8 = UINT64_C(0);
            uint64_t v9_n = v7_n;
            const uint8_t *v9 = v7;
            uint64_t v10 = ((((uint64_t)v9_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v9[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
            f6 = (((((((UINT64_C(2) * v8) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff)) < v10) && (v10 <= ((uint64_t)v7_n))) ? ((f6 + ((uint64_t)(((((uint64_t)((uint64_t)v7[((UINT64_C(2) * v8) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)v7[((((UINT64_C(2) * v8) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))))) & UINT64_C(0xffffffff)) : f6);
            uint64_t v11_n = ((uint64_t)in_b_len);
            const uint8_t *v11 = in_b;
            uint64_t v12 = UINT64_C(1);
            uint64_t v13_n = v11_n;
            const uint8_t *v13 = v11;
            uint64_t v14 = ((((uint64_t)v13_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v13[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
            f6 = (((((((UINT64_C(2) * v12) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff)) < v14) && (v14 <= ((uint64_t)v11_n))) ? ((f6 + ((uint64_t)(((((uint64_t)((uint64_t)v11[((UINT64_C(2) * v12) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)v11[((((UINT64_C(2) * v12) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))))) & UINT64_C(0xffffffff)) : f6);
            uint64_t v15_n = ((uint64_t)in_b_len);
            const uint8_t *v15 = in_b;
            uint64_t v16 = UINT64_C(2);
            uint64_t v17_n = v15_n;
            const uint8_t *v17 = v15;
            uint64_t v18 = ((((uint64_t)v17_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v17[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
            f6 = (((((((UINT64_C(2) * v16) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff)) < v18) && (v18 <= ((uint64_t)v15_n))) ? ((f6 + ((uint64_t)(((((uint64_t)((uint64_t)v15[((UINT64_C(2) * v16) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)v15[((((UINT64_C(2) * v16) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))))) & UINT64_C(0xffffffff)) : f6);
            uint64_t v19_n = ((uint64_t)in_b_len);
            const uint8_t *v19 = in_b;
            uint64_t v20 = UINT64_C(3);
            uint64_t v21_n = v19_n;
            const uint8_t *v21 = v19;
            uint64_t v22 = ((((uint64_t)v21_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v21[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
            f6 = (((((((UINT64_C(2) * v20) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff)) < v22) && (v22 <= ((uint64_t)v19_n))) ? ((f6 + ((uint64_t)(((((uint64_t)((uint64_t)v19[((UINT64_C(2) * v20) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)v19[((((UINT64_C(2) * v20) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))))) & UINT64_C(0xffffffff)) : f6);
            uint64_t v23_n = ((uint64_t)in_b_len);
            const uint8_t *v23 = in_b;
            uint64_t v24 = UINT64_C(4);
            uint64_t v25_n = v23_n;
            const uint8_t *v25 = v23;
            uint64_t v26 = ((((uint64_t)v25_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v25[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
            f6 = (((((((UINT64_C(2) * v24) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff)) < v26) && (v26 <= ((uint64_t)v23_n))) ? ((f6 + ((uint64_t)(((((uint64_t)((uint64_t)v23[((UINT64_C(2) * v24) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)v23[((((UINT64_C(2) * v24) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))))) & UINT64_C(0xffffffff)) : f6);
            uint64_t v27_n = ((uint64_t)in_b_len);
            const uint8_t *v27 = in_b;
            uint64_t v28 = UINT64_C(5);
            uint64_t v29_n = v27_n;
            const uint8_t *v29 = v27;
            uint64_t v30 = ((((uint64_t)v29_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v29[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
            f6 = (((((((UINT64_C(2) * v28) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff)) < v30) && (v30 <= ((uint64_t)v27_n))) ? ((f6 + ((uint64_t)(((((uint64_t)((uint64_t)v27[((UINT64_C(2) * v28) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)v27[((((UINT64_C(2) * v28) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))))) & UINT64_C(0xffffffff)) : f6);
            uint64_t v31_n = ((uint64_t)in_b_len);
            const uint8_t *v31 = in_b;
            uint64_t v32 = UINT64_C(6);
            uint64_t v33_n = v31_n;
            const uint8_t *v33 = v31;
            uint64_t v34 = ((((uint64_t)v33_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v33[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
            f6 = (((((((UINT64_C(2) * v32) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff)) < v34) && (v34 <= ((uint64_t)v31_n))) ? ((f6 + ((uint64_t)(((((uint64_t)((uint64_t)v31[((UINT64_C(2) * v32) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)v31[((((UINT64_C(2) * v32) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))))) & UINT64_C(0xffffffff)) : f6);
            uint64_t v35_n = ((uint64_t)in_b_len);
            const uint8_t *v35 = in_b;
            uint64_t v36 = UINT64_C(7);
            uint64_t v37_n = v35_n;
            const uint8_t *v37 = v35;
            uint64_t v38 = ((((uint64_t)v37_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v37[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
            f6 = (((((((UINT64_C(2) * v36) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff)) < v38) && (v38 <= ((uint64_t)v35_n))) ? ((f6 + ((uint64_t)(((((uint64_t)((uint64_t)v35[((UINT64_C(2) * v36) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)v35[((((UINT64_C(2) * v36) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))))) & UINT64_C(0xffffffff)) : f6);
            uint64_t v39_n = ((uint64_t)in_b_len);
            const uint8_t *v39 = in_b;
            uint64_t v40 = UINT64_C(8);
            uint64_t v41_n = v39_n;
            const uint8_t *v41 = v39;
            uint64_t v42 = ((((uint64_t)v41_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v41[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
            f6 = (((((((UINT64_C(2) * v40) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff)) < v42) && (v42 <= ((uint64_t)v39_n))) ? ((f6 + ((uint64_t)(((((uint64_t)((uint64_t)v39[((UINT64_C(2) * v40) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)v39[((((UINT64_C(2) * v40) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))))) & UINT64_C(0xffffffff)) : f6);
            uint64_t v43_n = ((uint64_t)in_b_len);
            const uint8_t *v43 = in_b;
            uint64_t v44 = UINT64_C(9);
            uint64_t v45_n = v43_n;
            const uint8_t *v45 = v43;
            uint64_t v46 = ((((uint64_t)v45_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v45[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
            f6 = (((((((UINT64_C(2) * v44) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff)) < v46) && (v46 <= ((uint64_t)v43_n))) ? ((f6 + ((uint64_t)(((((uint64_t)((uint64_t)v43[((UINT64_C(2) * v44) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)v43[((((UINT64_C(2) * v44) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))))) & UINT64_C(0xffffffff)) : f6);
            uint64_t v47_n = ((uint64_t)in_b_len);
            const uint8_t *v47 = in_b;
            uint64_t v48 = UINT64_C(10);
            uint64_t v49_n = v47_n;
            const uint8_t *v49 = v47;
            uint64_t v50 = ((((uint64_t)v49_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v49[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
            f6 = (((((((UINT64_C(2) * v48) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff)) < v50) && (v50 <= ((uint64_t)v47_n))) ? ((f6 + ((uint64_t)(((((uint64_t)((uint64_t)v47[((UINT64_C(2) * v48) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)v47[((((UINT64_C(2) * v48) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))))) & UINT64_C(0xffffffff)) : f6);
            uint64_t v51_n = ((uint64_t)in_b_len);
            const uint8_t *v51 = in_b;
            uint64_t v52 = UINT64_C(11);
            uint64_t v53_n = v51_n;
            const uint8_t *v53 = v51;
            uint64_t v54 = ((((uint64_t)v53_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v53[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
            f6 = (((((((UINT64_C(2) * v52) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff)) < v54) && (v54 <= ((uint64_t)v51_n))) ? ((f6 + ((uint64_t)(((((uint64_t)((uint64_t)v51[((UINT64_C(2) * v52) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)v51[((((UINT64_C(2) * v52) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))))) & UINT64_C(0xffffffff)) : f6);
            uint64_t v55_n = ((uint64_t)in_b_len);
            const uint8_t *v55 = in_b;
            uint64_t v56 = UINT64_C(12);
            uint64_t v57_n = v55_n;
            const uint8_t *v57 = v55;
            uint64_t v58 = ((((uint64_t)v57_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v57[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
            f6 = (((((((UINT64_C(2) * v56) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff)) < v58) && (v58 <= ((uint64_t)v55_n))) ? ((f6 + ((uint64_t)(((((uint64_t)((uint64_t)v55[((UINT64_C(2) * v56) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)v55[((((UINT64_C(2) * v56) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))))) & UINT64_C(0xffffffff)) : f6);
            uint64_t v59_n = ((uint64_t)in_b_len);
            const uint8_t *v59 = in_b;
            uint64_t v60 = UINT64_C(13);
            uint64_t v61_n = v59_n;
            const uint8_t *v61 = v59;
            uint64_t v62 = ((((uint64_t)v61_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v61[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
            f6 = (((((((UINT64_C(2) * v60) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff)) < v62) && (v62 <= ((uint64_t)v59_n))) ? ((f6 + ((uint64_t)(((((uint64_t)((uint64_t)v59[((UINT64_C(2) * v60) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)v59[((((UINT64_C(2) * v60) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))))) & UINT64_C(0xffffffff)) : f6);
            uint64_t v63_n = ((uint64_t)in_b_len);
            const uint8_t *v63 = in_b;
            uint64_t v64 = UINT64_C(14);
            uint64_t v65_n = v63_n;
            const uint8_t *v65 = v63;
            uint64_t v66 = ((((uint64_t)v65_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v65[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
            f6 = (((((((UINT64_C(2) * v64) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff)) < v66) && (v66 <= ((uint64_t)v63_n))) ? ((f6 + ((uint64_t)(((((uint64_t)((uint64_t)v63[((UINT64_C(2) * v64) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)v63[((((UINT64_C(2) * v64) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))))) & UINT64_C(0xffffffff)) : f6);
            uint64_t v67_n = ((uint64_t)in_b_len);
            const uint8_t *v67 = in_b;
            uint64_t v68 = UINT64_C(15);
            uint64_t v69_n = v67_n;
            const uint8_t *v69 = v67;
            uint64_t v70 = ((((uint64_t)v69_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v69[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
            f6 = (((((((UINT64_C(2) * v68) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff)) < v70) && (v70 <= ((uint64_t)v67_n))) ? ((f6 + ((uint64_t)(((((uint64_t)((uint64_t)v67[((UINT64_C(2) * v68) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)v67[((((UINT64_C(2) * v68) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))))) & UINT64_C(0xffffffff)) : f6);
            uint64_t v71_n = ((uint64_t)in_b_len);
            const uint8_t *v71 = in_b;
            uint64_t v72 = UINT64_C(16);
            uint64_t v73_n = v71_n;
            const uint8_t *v73 = v71;
            uint64_t v74 = ((((uint64_t)v73_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v73[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
            f6 = (((((((UINT64_C(2) * v72) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff)) < v74) && (v74 <= ((uint64_t)v71_n))) ? ((f6 + ((uint64_t)(((((uint64_t)((uint64_t)v71[((UINT64_C(2) * v72) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)v71[((((UINT64_C(2) * v72) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))))) & UINT64_C(0xffffffff)) : f6);
            uint64_t v75_n = ((uint64_t)in_b_len);
            const uint8_t *v75 = in_b;
            uint64_t v76 = UINT64_C(17);
            uint64_t v77_n = v75_n;
            const uint8_t *v77 = v75;
            uint64_t v78 = ((((uint64_t)v77_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v77[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
            f6 = (((((((UINT64_C(2) * v76) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff)) < v78) && (v78 <= ((uint64_t)v75_n))) ? ((f6 + ((uint64_t)(((((uint64_t)((uint64_t)v75[((UINT64_C(2) * v76) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)v75[((((UINT64_C(2) * v76) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))))) & UINT64_C(0xffffffff)) : f6);
            uint64_t v79_n = ((uint64_t)in_b_len);
            const uint8_t *v79 = in_b;
            uint64_t v80 = UINT64_C(18);
            uint64_t v81_n = v79_n;
            const uint8_t *v81 = v79;
            uint64_t v82 = ((((uint64_t)v81_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v81[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
            f6 = (((((((UINT64_C(2) * v80) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff)) < v82) && (v82 <= ((uint64_t)v79_n))) ? ((f6 + ((uint64_t)(((((uint64_t)((uint64_t)v79[((UINT64_C(2) * v80) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)v79[((((UINT64_C(2) * v80) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))))) & UINT64_C(0xffffffff)) : f6);
            uint64_t v83_n = ((uint64_t)in_b_len);
            const uint8_t *v83 = in_b;
            uint64_t v84 = UINT64_C(19);
            uint64_t v85_n = v83_n;
            const uint8_t *v85 = v83;
            uint64_t v86 = ((((uint64_t)v85_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v85[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
            f6 = (((((((UINT64_C(2) * v84) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff)) < v86) && (v86 <= ((uint64_t)v83_n))) ? ((f6 + ((uint64_t)(((((uint64_t)((uint64_t)v83[((UINT64_C(2) * v84) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)v83[((((UINT64_C(2) * v84) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))))) & UINT64_C(0xffffffff)) : f6);
            uint64_t v87_n = ((uint64_t)in_b_len);
            const uint8_t *v87 = in_b;
            uint64_t v88 = UINT64_C(20);
            uint64_t v89_n = v87_n;
            const uint8_t *v89 = v87;
            uint64_t v90 = ((((uint64_t)v89_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v89[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
            f6 = (((((((UINT64_C(2) * v88) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff)) < v90) && (v90 <= ((uint64_t)v87_n))) ? ((f6 + ((uint64_t)(((((uint64_t)((uint64_t)v87[((UINT64_C(2) * v88) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)v87[((((UINT64_C(2) * v88) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))))) & UINT64_C(0xffffffff)) : f6);
            uint64_t v91_n = ((uint64_t)in_b_len);
            const uint8_t *v91 = in_b;
            uint64_t v92 = UINT64_C(21);
            uint64_t v93_n = v91_n;
            const uint8_t *v93 = v91;
            uint64_t v94 = ((((uint64_t)v93_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v93[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
            f6 = (((((((UINT64_C(2) * v92) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff)) < v94) && (v94 <= ((uint64_t)v91_n))) ? ((f6 + ((uint64_t)(((((uint64_t)((uint64_t)v91[((UINT64_C(2) * v92) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)v91[((((UINT64_C(2) * v92) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))))) & UINT64_C(0xffffffff)) : f6);
            uint64_t v95_n = ((uint64_t)in_b_len);
            const uint8_t *v95 = in_b;
            uint64_t v96 = UINT64_C(22);
            uint64_t v97_n = v95_n;
            const uint8_t *v97 = v95;
            uint64_t v98 = ((((uint64_t)v97_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v97[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
            f6 = (((((((UINT64_C(2) * v96) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff)) < v98) && (v98 <= ((uint64_t)v95_n))) ? ((f6 + ((uint64_t)(((((uint64_t)((uint64_t)v95[((UINT64_C(2) * v96) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)v95[((((UINT64_C(2) * v96) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))))) & UINT64_C(0xffffffff)) : f6);
            uint64_t v99_n = ((uint64_t)in_b_len);
            const uint8_t *v99 = in_b;
            uint64_t v100 = UINT64_C(23);
            uint64_t v101_n = v99_n;
            const uint8_t *v101 = v99;
            uint64_t v102 = ((((uint64_t)v101_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v101[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
            f6 = (((((((UINT64_C(2) * v100) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff)) < v102) && (v102 <= ((uint64_t)v99_n))) ? ((f6 + ((uint64_t)(((((uint64_t)((uint64_t)v99[((UINT64_C(2) * v100) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)v99[((((UINT64_C(2) * v100) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))))) & UINT64_C(0xffffffff)) : f6);
            uint64_t v103_n = ((uint64_t)in_b_len);
            const uint8_t *v103 = in_b;
            uint64_t v104 = UINT64_C(24);
            uint64_t v105_n = v103_n;
            const uint8_t *v105 = v103;
            uint64_t v106 = ((((uint64_t)v105_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v105[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
            f6 = (((((((UINT64_C(2) * v104) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff)) < v106) && (v106 <= ((uint64_t)v103_n))) ? ((f6 + ((uint64_t)(((((uint64_t)((uint64_t)v103[((UINT64_C(2) * v104) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)v103[((((UINT64_C(2) * v104) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))))) & UINT64_C(0xffffffff)) : f6);
            uint64_t v107_n = ((uint64_t)in_b_len);
            const uint8_t *v107 = in_b;
            uint64_t v108 = UINT64_C(25);
            uint64_t v109_n = v107_n;
            const uint8_t *v109 = v107;
            uint64_t v110 = ((((uint64_t)v109_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v109[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
            f6 = (((((((UINT64_C(2) * v108) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff)) < v110) && (v110 <= ((uint64_t)v107_n))) ? ((f6 + ((uint64_t)(((((uint64_t)((uint64_t)v107[((UINT64_C(2) * v108) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)v107[((((UINT64_C(2) * v108) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))))) & UINT64_C(0xffffffff)) : f6);
            uint64_t v111_n = ((uint64_t)in_b_len);
            const uint8_t *v111 = in_b;
            uint64_t v112 = UINT64_C(26);
            uint64_t v113_n = v111_n;
            const uint8_t *v113 = v111;
            uint64_t v114 = ((((uint64_t)v113_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v113[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
            f6 = (((((((UINT64_C(2) * v112) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff)) < v114) && (v114 <= ((uint64_t)v111_n))) ? ((f6 + ((uint64_t)(((((uint64_t)((uint64_t)v111[((UINT64_C(2) * v112) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)v111[((((UINT64_C(2) * v112) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))))) & UINT64_C(0xffffffff)) : f6);
            uint64_t v115_n = ((uint64_t)in_b_len);
            const uint8_t *v115 = in_b;
            uint64_t v116 = UINT64_C(27);
            uint64_t v117_n = v115_n;
            const uint8_t *v117 = v115;
            uint64_t v118 = ((((uint64_t)v117_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v117[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
            f6 = (((((((UINT64_C(2) * v116) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff)) < v118) && (v118 <= ((uint64_t)v115_n))) ? ((f6 + ((uint64_t)(((((uint64_t)((uint64_t)v115[((UINT64_C(2) * v116) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)v115[((((UINT64_C(2) * v116) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))))) & UINT64_C(0xffffffff)) : f6);
            uint64_t v119_n = ((uint64_t)in_b_len);
            const uint8_t *v119 = in_b;
            uint64_t v120 = UINT64_C(28);
            uint64_t v121_n = v119_n;
            const uint8_t *v121 = v119;
            uint64_t v122 = ((((uint64_t)v121_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v121[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
            f6 = (((((((UINT64_C(2) * v120) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff)) < v122) && (v122 <= ((uint64_t)v119_n))) ? ((f6 + ((uint64_t)(((((uint64_t)((uint64_t)v119[((UINT64_C(2) * v120) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)v119[((((UINT64_C(2) * v120) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))))) & UINT64_C(0xffffffff)) : f6);
            uint64_t v123_n = ((uint64_t)in_b_len);
            const uint8_t *v123 = in_b;
            uint64_t v124 = UINT64_C(29);
            uint64_t v125_n = v123_n;
            const uint8_t *v125 = v123;
            uint64_t v126 = ((((uint64_t)v125_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v125[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
            f6 = (((((((UINT64_C(2) * v124) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff)) < v126) && (v126 <= ((uint64_t)v123_n))) ? ((f6 + ((uint64_t)(((((uint64_t)((uint64_t)v123[((UINT64_C(2) * v124) & UINT64_C(0xffff))])) << 8) & UINT64_C(0xffff)) | ((uint64_t)((uint64_t)v123[((((UINT64_C(2) * v124) & UINT64_C(0xffff)) + UINT64_C(1)) & UINT64_C(0xffff))]))))) & UINT64_C(0xffffffff)) : f6);
            uint64_t v127 = f6;
            uint64_t v128 = (((v127 & UINT64_C(0xffff)) + (v127 >> 16)) & UINT64_C(0xffffffff));
            uint64_t v129 = (((v128 & UINT64_C(0xffff)) + (v128 >> 16)) & UINT64_C(0xffffffff));
            int o130_tag;
            uint64_t o130_0 = 0;
            uint64_t o130_1 = 0;
            int o130_2 = 0;
            uint64_t o130_3 = 0;
            if ((v129 != UINT64_C(0xffff))) {
                o130_tag = 0;
                o130_0 = 0;
                o130_1 = 0;
                o130_2 = 0;
                o130_3 = 0;
            } else {
                uint64_t f131 = UINT64_C(20);
                for (int k132 = 0; k132 < 40; k132++) {
                    uint64_t v133_n = ((uint64_t)in_b_len);
                    const uint8_t *v133 = in_b;
                    uint64_t v134_n = v133_n;
                    const uint8_t *v134 = v133;
                    uint64_t v135 = ((((uint64_t)v134_n) < UINT64_C(1)) ? UINT64_C(0) : ((((uint64_t)(((uint64_t)v134[UINT64_C(0)]) & UINT64_C(15))) * UINT64_C(4)) & UINT64_C(0xffff)));
                    uint64_t v136 = (((uint64_t)(f131 & UINT64_C(255))) & UINT64_C(0xffff));
                    if (((((f131 & UINT64_C(0x300)) != UINT64_C(0)) || (v136 >= v135)) || (v135 > ((uint64_t)v133_n)))) break;
                    uint64_t v137 = ((uint64_t)v133[v136]);
                    uint64_t t144;
                    if ((v137 == UINT64_C(0))) {
                        t144 = (f131 | UINT64_C(0x100));
                    } else {
                        uint64_t t143;
                        if ((v137 == UINT64_C(1))) {
                            t143 = (f131 + UINT64_C(1));
                        } else {
                            uint64_t v138 = (f131 | UINT64_C(0x200));
                            uint64_t t142;
                            if ((((v136 + UINT64_C(1)) & UINT64_C(0xffff)) >= v135)) {
                                t142 = v138;
                            } else {
                                uint64_t v139 = ((uint64_t)v133[((v136 + UINT64_C(1)) & UINT64_C(0xffff))]);
                                uint64_t t141;
                                if (((v139 < UINT64_C(2)) || (((v136 + ((uint64_t)v139)) & UINT64_C(0xffff)) > v135))) {
                                    t141 = v138;
                                } else {
                                    uint64_t v140 = (((f131 & UINT64_C(0xffffffffffffff00)) | ((uint64_t)((v136 + ((uint64_t)v139)) & UINT64_C(0xffff)))) + UINT64_C(0x10000));
                                    t141 = (((v137 == UINT64_C(131)) || (v137 == UINT64_C(137))) ? (((v139 < UINT64_C(3)) || ((f131 & UINT64_C(0x400)) != UINT64_C(0))) ? v138 : (v140 | UINT64_C(0x400))) : ((v137 == UINT64_C(148)) ? (((v139 != UINT64_C(4)) || ((f131 & UINT64_C(0x800)) != UINT64_C(0))) ? v138 : (((v140 | UINT64_C(0x800)) | (((uint64_t)((uint64_t)v133[((v136 + UINT64_C(2)) & UINT64_C(0xffff))])) << 40)) | (((uint64_t)((uint64_t)v133[((v136 + UINT64_C(3)) & UINT64_C(0xffff))])) << 32))) : v140));
                                }
                                t142 = t141;
                            }
                            t143 = t142;
                        }
                        t144 = t143;
                    }
                    f131 = t144;
                }
                uint64_t v145 = f131;
                int o146_tag;
                uint64_t o146_0 = 0;
                uint64_t o146_1 = 0;
                int o146_2 = 0;
                uint64_t o146_3 = 0;
                if (((v145 & UINT64_C(0x200)) != UINT64_C(0))) {
                    o146_tag = 0;
                    o146_0 = 0;
                    o146_1 = 0;
                    o146_2 = 0;
                    o146_3 = 0;
                } else {
                    uint64_t v147 = (((v145 & UINT64_C(0x800)) == UINT64_C(0)) ? UINT64_C(0xffff) : (((uint64_t)(v145 >> 32)) & UINT64_C(0xffff)));
                    o146_tag = 1;
                    o146_0 = (((uint64_t)v3) & UINT64_C(255));
                    o146_1 = (((uint64_t)(v145 >> 16)) & UINT64_C(255));
                    o146_2 = ((v145 & UINT64_C(0x400)) != UINT64_C(0));
                    o146_3 = v147;
                }
                o130_tag = o146_tag;
                o130_0 = o146_0;
                o130_1 = o146_1;
                o130_2 = o146_2;
                o130_3 = o146_3;
            }
            o5_tag = o130_tag;
            o5_0 = o130_0;
            o5_1 = o130_1;
            o5_2 = o130_2;
            o5_3 = o130_3;
        }
        o1_tag = o5_tag;
        o1_0 = o5_0;
        o1_1 = o5_1;
        o1_2 = o5_2;
        o1_3 = o5_3;
    }
    if (o1_tag) {
        *out0 = (uint64_t)(o1_0);
        *out1 = (uint64_t)(o1_1);
        *out2 = (uint64_t)(o1_2);
        *out3 = (uint64_t)(o1_3);
    }
    return o1_tag;
}
