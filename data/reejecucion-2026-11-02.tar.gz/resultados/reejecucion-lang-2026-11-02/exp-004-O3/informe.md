# EXP-004: prototipo vertical de EFCH Lang 0.1

Fecha: 2026-11-02T01:51:20Z. gcc: gcc (Ubuntu 15.2.0-16ubuntu1) 15.2.0, `-O3 -march=native -std=c11 -Wall -Wno-unused-variable -Wno-unused-but-set-variable`. CPU: Intel Core Processor (Haswell, no TSX).

| Ejemplo | Equivalencia | Diferencial | ns/op EFCH Lang | ns/op especificación | ns/op C a mano | Líneas EFCH Lang | Líneas C a mano | Ruta ordinaria (s) |
|---|---|---|---|---|---|---|---|---|
| varint | probado (Z3) | 0/5045 fallos | 12.97 | 14.44 | 13.49 | 14 | 15 | 0.14 |
| trama | probado (Z3) | 0/5049 fallos | 20.19 | 18.05 | 19.21 | 18 | 25 | 0.13 |

ns/op: media de las medianas por semilla. Las pruebas diferenciales son evidencia experimental; la equivalencia es formal con los supuestos de cada herramienta.
