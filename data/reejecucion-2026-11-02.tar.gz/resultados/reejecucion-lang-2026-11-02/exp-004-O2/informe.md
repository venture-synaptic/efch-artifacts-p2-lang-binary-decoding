# EXP-004: prototipo vertical de EFCH Lang 0.1

Fecha: 2026-11-02T01:51:07Z. gcc: gcc (Ubuntu 15.2.0-16ubuntu1) 15.2.0, `-O2 -std=c11 -Wall -Wno-unused-variable -Wno-unused-but-set-variable`. CPU: Intel Core Processor (Haswell, no TSX).

| Ejemplo | Equivalencia | Diferencial | ns/op EFCH Lang | ns/op especificación | ns/op C a mano | Líneas EFCH Lang | Líneas C a mano | Ruta ordinaria (s) |
|---|---|---|---|---|---|---|---|---|
| varint | probado (Z3) | 0/5045 fallos | 15.18 | 16.5 | 18.1 | 14 | 15 | 0.21 |
| trama | probado (Z3) | 0/5049 fallos | 19.75 | 20.32 | 19.5 | 18 | 25 | 0.13 |

ns/op: media de las medianas por semilla. Las pruebas diferenciales son evidencia experimental; la equivalencia es formal con los supuestos de cada herramienta.
