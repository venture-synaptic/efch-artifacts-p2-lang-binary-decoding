#include <stddef.h>
#include <stdint.h>
#include <string.h>
typedef unsigned __int128 efch_u128;

/* Operaciones con signo sobre valores de w bits guardados sin signo y enmascarados. Solo usan
   aritmética sin signo: no hay comportamiento indefinido ni dependiente de la implementación. */
#define EFCH_SIGNED_OPS(T, SUF)                                                               \
static inline T efch_mask##SUF(unsigned w) { return w >= 8 * sizeof(T) ? (T)~(T)0 : (((T)1 << w) - 1); } \
static inline int efch_slt##SUF(T x, T y, unsigned w) { T s = (T)1 << (w - 1); return (x ^ s) < (y ^ s); } \
static inline T efch_sext##SUF(T x, unsigned w, unsigned n) {                                 \
    return (x & ((T)1 << (w - 1))) ? (x | (efch_mask##SUF(n) & ~efch_mask##SUF(w))) : x; }    \
static inline T efch_ashr##SUF(T x, T k, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int neg = (x >> (w - 1)) & 1;                                    \
    if (k >= w) return neg ? m : 0;                                                           \
    return (x >> k) | (neg ? (m & ~(m >> k)) : 0); }                                          \
static inline T efch_sdiv##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return nx ? 1 : m;                                                            \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, q = ax / ay;                     \
    return (nx != ny) ? ((T)-q & m) : q; }                                                    \
static inline T efch_srem##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return x;                                                                     \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, r = ax % ay;                     \
    return nx ? ((T)-r & m) : r; }
EFCH_SIGNED_OPS(uint64_t, 64)
EFCH_SIGNED_OPS(efch_u128, 128)

int efch_varint_decode(const uint8_t *in_buf, size_t in_buf_len, uint64_t *out0, uint64_t *out1)
{
    int o1_tag;
    uint64_t o1_0 = 0;
    uint64_t o1_1 = 0;
    if (((UINT64_C(0) < ((uint64_t)((uint64_t)in_buf_len))) && (((uint64_t)in_buf[UINT64_C(0)]) < UINT64_C(128)))) {
        efch_u128 v2 = ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(0))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(0)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(0))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)));
        int o3_tag;
        uint64_t o3_0 = 0;
        uint64_t o3_1 = 0;
        if ((0 && (((uint64_t)in_buf[UINT64_C(0)]) == UINT64_C(0)))) {
            o3_tag = 0;
            o3_0 = 0;
            o3_1 = 0;
        } else {
            int o4_tag;
            uint64_t o4_0 = 0;
            uint64_t o4_1 = 0;
            if ((v2 > (((efch_u128)UINT64_C(0) << 64) | UINT64_C(0xffffffffffffffff)))) {
                o4_tag = 0;
                o4_0 = 0;
                o4_1 = 0;
            } else {
                o4_tag = 1;
                o4_0 = ((uint64_t)v2);
                o4_1 = ((UINT64_C(0) + UINT64_C(1)) & UINT64_C(255));
            }
            o3_tag = o4_tag;
            o3_0 = o4_0;
            o3_1 = o4_1;
        }
        o1_tag = o3_tag;
        o1_0 = o3_0;
        o1_1 = o3_1;
    } else {
        int o5_tag;
        uint64_t o5_0 = 0;
        uint64_t o5_1 = 0;
        if (((UINT64_C(1) < ((uint64_t)((uint64_t)in_buf_len))) && (((uint64_t)in_buf[UINT64_C(1)]) < UINT64_C(128)))) {
            efch_u128 v6 = (((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(0))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(0)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(0))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(1))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(1)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(1))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))));
            int o7_tag;
            uint64_t o7_0 = 0;
            uint64_t o7_1 = 0;
            if ((1 && (((uint64_t)in_buf[UINT64_C(1)]) == UINT64_C(0)))) {
                o7_tag = 0;
                o7_0 = 0;
                o7_1 = 0;
            } else {
                int o8_tag;
                uint64_t o8_0 = 0;
                uint64_t o8_1 = 0;
                if ((v6 > (((efch_u128)UINT64_C(0) << 64) | UINT64_C(0xffffffffffffffff)))) {
                    o8_tag = 0;
                    o8_0 = 0;
                    o8_1 = 0;
                } else {
                    o8_tag = 1;
                    o8_0 = ((uint64_t)v6);
                    o8_1 = ((UINT64_C(1) + UINT64_C(1)) & UINT64_C(255));
                }
                o7_tag = o8_tag;
                o7_0 = o8_0;
                o7_1 = o8_1;
            }
            o5_tag = o7_tag;
            o5_0 = o7_0;
            o5_1 = o7_1;
        } else {
            int o9_tag;
            uint64_t o9_0 = 0;
            uint64_t o9_1 = 0;
            if (((UINT64_C(2) < ((uint64_t)((uint64_t)in_buf_len))) && (((uint64_t)in_buf[UINT64_C(2)]) < UINT64_C(128)))) {
                efch_u128 v10 = ((((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(0))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(0)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(0))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(1))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(1)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(1))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(2))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(2)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(2))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))));
                int o11_tag;
                uint64_t o11_0 = 0;
                uint64_t o11_1 = 0;
                if ((1 && (((uint64_t)in_buf[UINT64_C(2)]) == UINT64_C(0)))) {
                    o11_tag = 0;
                    o11_0 = 0;
                    o11_1 = 0;
                } else {
                    int o12_tag;
                    uint64_t o12_0 = 0;
                    uint64_t o12_1 = 0;
                    if ((v10 > (((efch_u128)UINT64_C(0) << 64) | UINT64_C(0xffffffffffffffff)))) {
                        o12_tag = 0;
                        o12_0 = 0;
                        o12_1 = 0;
                    } else {
                        o12_tag = 1;
                        o12_0 = ((uint64_t)v10);
                        o12_1 = ((UINT64_C(2) + UINT64_C(1)) & UINT64_C(255));
                    }
                    o11_tag = o12_tag;
                    o11_0 = o12_0;
                    o11_1 = o12_1;
                }
                o9_tag = o11_tag;
                o9_0 = o11_0;
                o9_1 = o11_1;
            } else {
                int o13_tag;
                uint64_t o13_0 = 0;
                uint64_t o13_1 = 0;
                if (((UINT64_C(3) < ((uint64_t)((uint64_t)in_buf_len))) && (((uint64_t)in_buf[UINT64_C(3)]) < UINT64_C(128)))) {
                    efch_u128 v14 = (((((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(0))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(0)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(0))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(1))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(1)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(1))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(2))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(2)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(2))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(3))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(3)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(3))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))));
                    int o15_tag;
                    uint64_t o15_0 = 0;
                    uint64_t o15_1 = 0;
                    if ((1 && (((uint64_t)in_buf[UINT64_C(3)]) == UINT64_C(0)))) {
                        o15_tag = 0;
                        o15_0 = 0;
                        o15_1 = 0;
                    } else {
                        int o16_tag;
                        uint64_t o16_0 = 0;
                        uint64_t o16_1 = 0;
                        if ((v14 > (((efch_u128)UINT64_C(0) << 64) | UINT64_C(0xffffffffffffffff)))) {
                            o16_tag = 0;
                            o16_0 = 0;
                            o16_1 = 0;
                        } else {
                            o16_tag = 1;
                            o16_0 = ((uint64_t)v14);
                            o16_1 = ((UINT64_C(3) + UINT64_C(1)) & UINT64_C(255));
                        }
                        o15_tag = o16_tag;
                        o15_0 = o16_0;
                        o15_1 = o16_1;
                    }
                    o13_tag = o15_tag;
                    o13_0 = o15_0;
                    o13_1 = o15_1;
                } else {
                    int o17_tag;
                    uint64_t o17_0 = 0;
                    uint64_t o17_1 = 0;
                    if (((UINT64_C(4) < ((uint64_t)((uint64_t)in_buf_len))) && (((uint64_t)in_buf[UINT64_C(4)]) < UINT64_C(128)))) {
                        efch_u128 v18 = ((((((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(0))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(0)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(0))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(1))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(1)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(1))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(2))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(2)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(2))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(3))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(3)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(3))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(4))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(4)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(4))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))));
                        int o19_tag;
                        uint64_t o19_0 = 0;
                        uint64_t o19_1 = 0;
                        if ((1 && (((uint64_t)in_buf[UINT64_C(4)]) == UINT64_C(0)))) {
                            o19_tag = 0;
                            o19_0 = 0;
                            o19_1 = 0;
                        } else {
                            int o20_tag;
                            uint64_t o20_0 = 0;
                            uint64_t o20_1 = 0;
                            if ((v18 > (((efch_u128)UINT64_C(0) << 64) | UINT64_C(0xffffffffffffffff)))) {
                                o20_tag = 0;
                                o20_0 = 0;
                                o20_1 = 0;
                            } else {
                                o20_tag = 1;
                                o20_0 = ((uint64_t)v18);
                                o20_1 = ((UINT64_C(4) + UINT64_C(1)) & UINT64_C(255));
                            }
                            o19_tag = o20_tag;
                            o19_0 = o20_0;
                            o19_1 = o20_1;
                        }
                        o17_tag = o19_tag;
                        o17_0 = o19_0;
                        o17_1 = o19_1;
                    } else {
                        int o21_tag;
                        uint64_t o21_0 = 0;
                        uint64_t o21_1 = 0;
                        if (((UINT64_C(5) < ((uint64_t)((uint64_t)in_buf_len))) && (((uint64_t)in_buf[UINT64_C(5)]) < UINT64_C(128)))) {
                            efch_u128 v22 = (((((((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(0))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(0)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(0))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(1))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(1)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(1))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(2))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(2)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(2))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(3))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(3)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(3))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(4))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(4)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(4))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(5))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(5)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(5))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))));
                            int o23_tag;
                            uint64_t o23_0 = 0;
                            uint64_t o23_1 = 0;
                            if ((1 && (((uint64_t)in_buf[UINT64_C(5)]) == UINT64_C(0)))) {
                                o23_tag = 0;
                                o23_0 = 0;
                                o23_1 = 0;
                            } else {
                                int o24_tag;
                                uint64_t o24_0 = 0;
                                uint64_t o24_1 = 0;
                                if ((v22 > (((efch_u128)UINT64_C(0) << 64) | UINT64_C(0xffffffffffffffff)))) {
                                    o24_tag = 0;
                                    o24_0 = 0;
                                    o24_1 = 0;
                                } else {
                                    o24_tag = 1;
                                    o24_0 = ((uint64_t)v22);
                                    o24_1 = ((UINT64_C(5) + UINT64_C(1)) & UINT64_C(255));
                                }
                                o23_tag = o24_tag;
                                o23_0 = o24_0;
                                o23_1 = o24_1;
                            }
                            o21_tag = o23_tag;
                            o21_0 = o23_0;
                            o21_1 = o23_1;
                        } else {
                            int o25_tag;
                            uint64_t o25_0 = 0;
                            uint64_t o25_1 = 0;
                            if (((UINT64_C(6) < ((uint64_t)((uint64_t)in_buf_len))) && (((uint64_t)in_buf[UINT64_C(6)]) < UINT64_C(128)))) {
                                efch_u128 v26 = ((((((((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(0))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(0)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(0))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(1))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(1)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(1))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(2))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(2)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(2))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(3))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(3)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(3))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(4))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(4)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(4))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(5))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(5)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(5))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(6))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(6)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(6))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))));
                                int o27_tag;
                                uint64_t o27_0 = 0;
                                uint64_t o27_1 = 0;
                                if ((1 && (((uint64_t)in_buf[UINT64_C(6)]) == UINT64_C(0)))) {
                                    o27_tag = 0;
                                    o27_0 = 0;
                                    o27_1 = 0;
                                } else {
                                    int o28_tag;
                                    uint64_t o28_0 = 0;
                                    uint64_t o28_1 = 0;
                                    if ((v26 > (((efch_u128)UINT64_C(0) << 64) | UINT64_C(0xffffffffffffffff)))) {
                                        o28_tag = 0;
                                        o28_0 = 0;
                                        o28_1 = 0;
                                    } else {
                                        o28_tag = 1;
                                        o28_0 = ((uint64_t)v26);
                                        o28_1 = ((UINT64_C(6) + UINT64_C(1)) & UINT64_C(255));
                                    }
                                    o27_tag = o28_tag;
                                    o27_0 = o28_0;
                                    o27_1 = o28_1;
                                }
                                o25_tag = o27_tag;
                                o25_0 = o27_0;
                                o25_1 = o27_1;
                            } else {
                                int o29_tag;
                                uint64_t o29_0 = 0;
                                uint64_t o29_1 = 0;
                                if (((UINT64_C(7) < ((uint64_t)((uint64_t)in_buf_len))) && (((uint64_t)in_buf[UINT64_C(7)]) < UINT64_C(128)))) {
                                    efch_u128 v30 = (((((((((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(0))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(0)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(0))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(1))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(1)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(1))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(2))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(2)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(2))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(3))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(3)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(3))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(4))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(4)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(4))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(5))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(5)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(5))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(6))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(6)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(6))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(7))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(7)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(7))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))));
                                    int o31_tag;
                                    uint64_t o31_0 = 0;
                                    uint64_t o31_1 = 0;
                                    if ((1 && (((uint64_t)in_buf[UINT64_C(7)]) == UINT64_C(0)))) {
                                        o31_tag = 0;
                                        o31_0 = 0;
                                        o31_1 = 0;
                                    } else {
                                        int o32_tag;
                                        uint64_t o32_0 = 0;
                                        uint64_t o32_1 = 0;
                                        if ((v30 > (((efch_u128)UINT64_C(0) << 64) | UINT64_C(0xffffffffffffffff)))) {
                                            o32_tag = 0;
                                            o32_0 = 0;
                                            o32_1 = 0;
                                        } else {
                                            o32_tag = 1;
                                            o32_0 = ((uint64_t)v30);
                                            o32_1 = ((UINT64_C(7) + UINT64_C(1)) & UINT64_C(255));
                                        }
                                        o31_tag = o32_tag;
                                        o31_0 = o32_0;
                                        o31_1 = o32_1;
                                    }
                                    o29_tag = o31_tag;
                                    o29_0 = o31_0;
                                    o29_1 = o31_1;
                                } else {
                                    int o33_tag;
                                    uint64_t o33_0 = 0;
                                    uint64_t o33_1 = 0;
                                    if (((UINT64_C(8) < ((uint64_t)((uint64_t)in_buf_len))) && (((uint64_t)in_buf[UINT64_C(8)]) < UINT64_C(128)))) {
                                        efch_u128 v34 = ((((((((((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(0))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(0)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(0))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(1))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(1)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(1))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(2))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(2)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(2))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(3))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(3)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(3))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(4))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(4)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(4))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(5))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(5)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(5))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(6))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(6)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(6))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(7))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(7)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(7))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(8))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(8)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(8))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))));
                                        int o35_tag;
                                        uint64_t o35_0 = 0;
                                        uint64_t o35_1 = 0;
                                        if ((1 && (((uint64_t)in_buf[UINT64_C(8)]) == UINT64_C(0)))) {
                                            o35_tag = 0;
                                            o35_0 = 0;
                                            o35_1 = 0;
                                        } else {
                                            int o36_tag;
                                            uint64_t o36_0 = 0;
                                            uint64_t o36_1 = 0;
                                            if ((v34 > (((efch_u128)UINT64_C(0) << 64) | UINT64_C(0xffffffffffffffff)))) {
                                                o36_tag = 0;
                                                o36_0 = 0;
                                                o36_1 = 0;
                                            } else {
                                                o36_tag = 1;
                                                o36_0 = ((uint64_t)v34);
                                                o36_1 = ((UINT64_C(8) + UINT64_C(1)) & UINT64_C(255));
                                            }
                                            o35_tag = o36_tag;
                                            o35_0 = o36_0;
                                            o35_1 = o36_1;
                                        }
                                        o33_tag = o35_tag;
                                        o33_0 = o35_0;
                                        o33_1 = o35_1;
                                    } else {
                                        int o37_tag;
                                        uint64_t o37_0 = 0;
                                        uint64_t o37_1 = 0;
                                        if (((UINT64_C(9) < ((uint64_t)((uint64_t)in_buf_len))) && (((uint64_t)in_buf[UINT64_C(9)]) < UINT64_C(128)))) {
                                            efch_u128 v38 = (((((((((((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(0))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(0)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(0))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(1))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(1)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(1))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(2))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(2)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(2))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(3))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(3)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(3))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(4))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(4)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(4))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(5))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(5)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(5))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(6))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(6)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(6))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(7))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(7)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(7))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(8))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(8)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(8))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff)))) | ((((((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(9))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))) >= 70 ? 0 : ((efch_u128)(((uint64_t)in_buf[UINT64_C(9)]) & UINT64_C(127))) << (((((efch_u128)UINT64_C(0) << 64) | UINT64_C(7)) * (((efch_u128)UINT64_C(0) << 64) | UINT64_C(9))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))))) & (((efch_u128)UINT64_C(63) << 64) | UINT64_C(0xffffffffffffffff))));
                                            int o39_tag;
                                            uint64_t o39_0 = 0;
                                            uint64_t o39_1 = 0;
                                            if ((1 && (((uint64_t)in_buf[UINT64_C(9)]) == UINT64_C(0)))) {
                                                o39_tag = 0;
                                                o39_0 = 0;
                                                o39_1 = 0;
                                            } else {
                                                int o40_tag;
                                                uint64_t o40_0 = 0;
                                                uint64_t o40_1 = 0;
                                                if ((v38 > (((efch_u128)UINT64_C(0) << 64) | UINT64_C(0xffffffffffffffff)))) {
                                                    o40_tag = 0;
                                                    o40_0 = 0;
                                                    o40_1 = 0;
                                                } else {
                                                    o40_tag = 1;
                                                    o40_0 = ((uint64_t)v38);
                                                    o40_1 = ((UINT64_C(9) + UINT64_C(1)) & UINT64_C(255));
                                                }
                                                o39_tag = o40_tag;
                                                o39_0 = o40_0;
                                                o39_1 = o40_1;
                                            }
                                            o37_tag = o39_tag;
                                            o37_0 = o39_0;
                                            o37_1 = o39_1;
                                        } else {
                                            o37_tag = 0;
                                            o37_0 = 0;
                                            o37_1 = 0;
                                        }
                                        o33_tag = o37_tag;
                                        o33_0 = o37_0;
                                        o33_1 = o37_1;
                                    }
                                    o29_tag = o33_tag;
                                    o29_0 = o33_0;
                                    o29_1 = o33_1;
                                }
                                o25_tag = o29_tag;
                                o25_0 = o29_0;
                                o25_1 = o29_1;
                            }
                            o21_tag = o25_tag;
                            o21_0 = o25_0;
                            o21_1 = o25_1;
                        }
                        o17_tag = o21_tag;
                        o17_0 = o21_0;
                        o17_1 = o21_1;
                    }
                    o13_tag = o17_tag;
                    o13_0 = o17_0;
                    o13_1 = o17_1;
                }
                o9_tag = o13_tag;
                o9_0 = o13_0;
                o9_1 = o13_1;
            }
            o5_tag = o9_tag;
            o5_0 = o9_0;
            o5_1 = o9_1;
        }
        o1_tag = o5_tag;
        o1_0 = o5_0;
        o1_1 = o5_1;
    }
    if (o1_tag) {
        *out0 = (uint64_t)(o1_0);
        *out1 = (uint64_t)(o1_1);
    }
    return o1_tag;
}

int efch_varint_decode__lang(const uint8_t *in_buf, size_t in_buf_len, uint64_t *out0, uint64_t *out1)
{
    uint64_t v1 = UINT64_C(0);
    uint64_t v2 = ((((uint64_t)((uint64_t)in_buf_len)) < UINT64_C(10)) ? ((uint64_t)((uint64_t)in_buf_len)) : UINT64_C(10));
    int o3_tag;
    uint64_t o3_0 = 0;
    uint64_t o3_1 = 0;
    if ((UINT64_C(0) < v2)) {
        uint64_t v4 = ((uint64_t)in_buf[UINT64_C(0)]);
        uint64_t v5 = (v1 | (((uint64_t)(v4 & UINT64_C(127))) << 0));
        int o6_tag;
        uint64_t o6_0 = 0;
        uint64_t o6_1 = 0;
        if ((v4 < UINT64_C(128))) {
            int o7_tag;
            uint64_t o7_0 = 0;
            uint64_t o7_1 = 0;
            if (((0 && (v4 == UINT64_C(0))) || (0 && (v4 > UINT64_C(1))))) {
                o7_tag = 0;
                o7_0 = 0;
                o7_1 = 0;
            } else {
                o7_tag = 1;
                o7_0 = v5;
                o7_1 = UINT64_C(1);
            }
            o6_tag = o7_tag;
            o6_0 = o7_0;
            o6_1 = o7_1;
        } else {
            int o8_tag;
            uint64_t o8_0 = 0;
            uint64_t o8_1 = 0;
            if ((UINT64_C(1) < v2)) {
                uint64_t v9 = ((uint64_t)in_buf[UINT64_C(1)]);
                uint64_t v10 = (v5 | (((uint64_t)(v9 & UINT64_C(127))) << 7));
                int o11_tag;
                uint64_t o11_0 = 0;
                uint64_t o11_1 = 0;
                if ((v9 < UINT64_C(128))) {
                    int o12_tag;
                    uint64_t o12_0 = 0;
                    uint64_t o12_1 = 0;
                    if (((1 && (v9 == UINT64_C(0))) || (0 && (v9 > UINT64_C(1))))) {
                        o12_tag = 0;
                        o12_0 = 0;
                        o12_1 = 0;
                    } else {
                        o12_tag = 1;
                        o12_0 = v10;
                        o12_1 = UINT64_C(2);
                    }
                    o11_tag = o12_tag;
                    o11_0 = o12_0;
                    o11_1 = o12_1;
                } else {
                    int o13_tag;
                    uint64_t o13_0 = 0;
                    uint64_t o13_1 = 0;
                    if ((UINT64_C(2) < v2)) {
                        uint64_t v14 = ((uint64_t)in_buf[UINT64_C(2)]);
                        uint64_t v15 = (v10 | (((uint64_t)(v14 & UINT64_C(127))) << 14));
                        int o16_tag;
                        uint64_t o16_0 = 0;
                        uint64_t o16_1 = 0;
                        if ((v14 < UINT64_C(128))) {
                            int o17_tag;
                            uint64_t o17_0 = 0;
                            uint64_t o17_1 = 0;
                            if (((1 && (v14 == UINT64_C(0))) || (0 && (v14 > UINT64_C(1))))) {
                                o17_tag = 0;
                                o17_0 = 0;
                                o17_1 = 0;
                            } else {
                                o17_tag = 1;
                                o17_0 = v15;
                                o17_1 = UINT64_C(3);
                            }
                            o16_tag = o17_tag;
                            o16_0 = o17_0;
                            o16_1 = o17_1;
                        } else {
                            int o18_tag;
                            uint64_t o18_0 = 0;
                            uint64_t o18_1 = 0;
                            if ((UINT64_C(3) < v2)) {
                                uint64_t v19 = ((uint64_t)in_buf[UINT64_C(3)]);
                                uint64_t v20 = (v15 | (((uint64_t)(v19 & UINT64_C(127))) << 21));
                                int o21_tag;
                                uint64_t o21_0 = 0;
                                uint64_t o21_1 = 0;
                                if ((v19 < UINT64_C(128))) {
                                    int o22_tag;
                                    uint64_t o22_0 = 0;
                                    uint64_t o22_1 = 0;
                                    if (((1 && (v19 == UINT64_C(0))) || (0 && (v19 > UINT64_C(1))))) {
                                        o22_tag = 0;
                                        o22_0 = 0;
                                        o22_1 = 0;
                                    } else {
                                        o22_tag = 1;
                                        o22_0 = v20;
                                        o22_1 = UINT64_C(4);
                                    }
                                    o21_tag = o22_tag;
                                    o21_0 = o22_0;
                                    o21_1 = o22_1;
                                } else {
                                    int o23_tag;
                                    uint64_t o23_0 = 0;
                                    uint64_t o23_1 = 0;
                                    if ((UINT64_C(4) < v2)) {
                                        uint64_t v24 = ((uint64_t)in_buf[UINT64_C(4)]);
                                        uint64_t v25 = (v20 | (((uint64_t)(v24 & UINT64_C(127))) << 28));
                                        int o26_tag;
                                        uint64_t o26_0 = 0;
                                        uint64_t o26_1 = 0;
                                        if ((v24 < UINT64_C(128))) {
                                            int o27_tag;
                                            uint64_t o27_0 = 0;
                                            uint64_t o27_1 = 0;
                                            if (((1 && (v24 == UINT64_C(0))) || (0 && (v24 > UINT64_C(1))))) {
                                                o27_tag = 0;
                                                o27_0 = 0;
                                                o27_1 = 0;
                                            } else {
                                                o27_tag = 1;
                                                o27_0 = v25;
                                                o27_1 = UINT64_C(5);
                                            }
                                            o26_tag = o27_tag;
                                            o26_0 = o27_0;
                                            o26_1 = o27_1;
                                        } else {
                                            int o28_tag;
                                            uint64_t o28_0 = 0;
                                            uint64_t o28_1 = 0;
                                            if ((UINT64_C(5) < v2)) {
                                                uint64_t v29 = ((uint64_t)in_buf[UINT64_C(5)]);
                                                uint64_t v30 = (v25 | (((uint64_t)(v29 & UINT64_C(127))) << 35));
                                                int o31_tag;
                                                uint64_t o31_0 = 0;
                                                uint64_t o31_1 = 0;
                                                if ((v29 < UINT64_C(128))) {
                                                    int o32_tag;
                                                    uint64_t o32_0 = 0;
                                                    uint64_t o32_1 = 0;
                                                    if (((1 && (v29 == UINT64_C(0))) || (0 && (v29 > UINT64_C(1))))) {
                                                        o32_tag = 0;
                                                        o32_0 = 0;
                                                        o32_1 = 0;
                                                    } else {
                                                        o32_tag = 1;
                                                        o32_0 = v30;
                                                        o32_1 = UINT64_C(6);
                                                    }
                                                    o31_tag = o32_tag;
                                                    o31_0 = o32_0;
                                                    o31_1 = o32_1;
                                                } else {
                                                    int o33_tag;
                                                    uint64_t o33_0 = 0;
                                                    uint64_t o33_1 = 0;
                                                    if ((UINT64_C(6) < v2)) {
                                                        uint64_t v34 = ((uint64_t)in_buf[UINT64_C(6)]);
                                                        uint64_t v35 = (v30 | (((uint64_t)(v34 & UINT64_C(127))) << 42));
                                                        int o36_tag;
                                                        uint64_t o36_0 = 0;
                                                        uint64_t o36_1 = 0;
                                                        if ((v34 < UINT64_C(128))) {
                                                            int o37_tag;
                                                            uint64_t o37_0 = 0;
                                                            uint64_t o37_1 = 0;
                                                            if (((1 && (v34 == UINT64_C(0))) || (0 && (v34 > UINT64_C(1))))) {
                                                                o37_tag = 0;
                                                                o37_0 = 0;
                                                                o37_1 = 0;
                                                            } else {
                                                                o37_tag = 1;
                                                                o37_0 = v35;
                                                                o37_1 = UINT64_C(7);
                                                            }
                                                            o36_tag = o37_tag;
                                                            o36_0 = o37_0;
                                                            o36_1 = o37_1;
                                                        } else {
                                                            int o38_tag;
                                                            uint64_t o38_0 = 0;
                                                            uint64_t o38_1 = 0;
                                                            if ((UINT64_C(7) < v2)) {
                                                                uint64_t v39 = ((uint64_t)in_buf[UINT64_C(7)]);
                                                                uint64_t v40 = (v35 | (((uint64_t)(v39 & UINT64_C(127))) << 49));
                                                                int o41_tag;
                                                                uint64_t o41_0 = 0;
                                                                uint64_t o41_1 = 0;
                                                                if ((v39 < UINT64_C(128))) {
                                                                    int o42_tag;
                                                                    uint64_t o42_0 = 0;
                                                                    uint64_t o42_1 = 0;
                                                                    if (((1 && (v39 == UINT64_C(0))) || (0 && (v39 > UINT64_C(1))))) {
                                                                        o42_tag = 0;
                                                                        o42_0 = 0;
                                                                        o42_1 = 0;
                                                                    } else {
                                                                        o42_tag = 1;
                                                                        o42_0 = v40;
                                                                        o42_1 = UINT64_C(8);
                                                                    }
                                                                    o41_tag = o42_tag;
                                                                    o41_0 = o42_0;
                                                                    o41_1 = o42_1;
                                                                } else {
                                                                    int o43_tag;
                                                                    uint64_t o43_0 = 0;
                                                                    uint64_t o43_1 = 0;
                                                                    if ((UINT64_C(8) < v2)) {
                                                                        uint64_t v44 = ((uint64_t)in_buf[UINT64_C(8)]);
                                                                        uint64_t v45 = (v40 | (((uint64_t)(v44 & UINT64_C(127))) << 56));
                                                                        int o46_tag;
                                                                        uint64_t o46_0 = 0;
                                                                        uint64_t o46_1 = 0;
                                                                        if ((v44 < UINT64_C(128))) {
                                                                            int o47_tag;
                                                                            uint64_t o47_0 = 0;
                                                                            uint64_t o47_1 = 0;
                                                                            if (((1 && (v44 == UINT64_C(0))) || (0 && (v44 > UINT64_C(1))))) {
                                                                                o47_tag = 0;
                                                                                o47_0 = 0;
                                                                                o47_1 = 0;
                                                                            } else {
                                                                                o47_tag = 1;
                                                                                o47_0 = v45;
                                                                                o47_1 = UINT64_C(9);
                                                                            }
                                                                            o46_tag = o47_tag;
                                                                            o46_0 = o47_0;
                                                                            o46_1 = o47_1;
                                                                        } else {
                                                                            int o48_tag;
                                                                            uint64_t o48_0 = 0;
                                                                            uint64_t o48_1 = 0;
                                                                            if ((UINT64_C(9) < v2)) {
                                                                                uint64_t v49 = ((uint64_t)in_buf[UINT64_C(9)]);
                                                                                uint64_t v50 = (v45 | (((uint64_t)(v49 & UINT64_C(127))) << 63));
                                                                                int o51_tag;
                                                                                uint64_t o51_0 = 0;
                                                                                uint64_t o51_1 = 0;
                                                                                if ((v49 < UINT64_C(128))) {
                                                                                    int o52_tag;
                                                                                    uint64_t o52_0 = 0;
                                                                                    uint64_t o52_1 = 0;
                                                                                    if (((1 && (v49 == UINT64_C(0))) || (1 && (v49 > UINT64_C(1))))) {
                                                                                        o52_tag = 0;
                                                                                        o52_0 = 0;
                                                                                        o52_1 = 0;
                                                                                    } else {
                                                                                        o52_tag = 1;
                                                                                        o52_0 = v50;
                                                                                        o52_1 = UINT64_C(10);
                                                                                    }
                                                                                    o51_tag = o52_tag;
                                                                                    o51_0 = o52_0;
                                                                                    o51_1 = o52_1;
                                                                                } else {
                                                                                    o51_tag = 0;
                                                                                    o51_0 = 0;
                                                                                    o51_1 = 0;
                                                                                }
                                                                                o48_tag = o51_tag;
                                                                                o48_0 = o51_0;
                                                                                o48_1 = o51_1;
                                                                            } else {
                                                                                o48_tag = 0;
                                                                                o48_0 = 0;
                                                                                o48_1 = 0;
                                                                            }
                                                                            o46_tag = o48_tag;
                                                                            o46_0 = o48_0;
                                                                            o46_1 = o48_1;
                                                                        }
                                                                        o43_tag = o46_tag;
                                                                        o43_0 = o46_0;
                                                                        o43_1 = o46_1;
                                                                    } else {
                                                                        o43_tag = 0;
                                                                        o43_0 = 0;
                                                                        o43_1 = 0;
                                                                    }
                                                                    o41_tag = o43_tag;
                                                                    o41_0 = o43_0;
                                                                    o41_1 = o43_1;
                                                                }
                                                                o38_tag = o41_tag;
                                                                o38_0 = o41_0;
                                                                o38_1 = o41_1;
                                                            } else {
                                                                o38_tag = 0;
                                                                o38_0 = 0;
                                                                o38_1 = 0;
                                                            }
                                                            o36_tag = o38_tag;
                                                            o36_0 = o38_0;
                                                            o36_1 = o38_1;
                                                        }
                                                        o33_tag = o36_tag;
                                                        o33_0 = o36_0;
                                                        o33_1 = o36_1;
                                                    } else {
                                                        o33_tag = 0;
                                                        o33_0 = 0;
                                                        o33_1 = 0;
                                                    }
                                                    o31_tag = o33_tag;
                                                    o31_0 = o33_0;
                                                    o31_1 = o33_1;
                                                }
                                                o28_tag = o31_tag;
                                                o28_0 = o31_0;
                                                o28_1 = o31_1;
                                            } else {
                                                o28_tag = 0;
                                                o28_0 = 0;
                                                o28_1 = 0;
                                            }
                                            o26_tag = o28_tag;
                                            o26_0 = o28_0;
                                            o26_1 = o28_1;
                                        }
                                        o23_tag = o26_tag;
                                        o23_0 = o26_0;
                                        o23_1 = o26_1;
                                    } else {
                                        o23_tag = 0;
                                        o23_0 = 0;
                                        o23_1 = 0;
                                    }
                                    o21_tag = o23_tag;
                                    o21_0 = o23_0;
                                    o21_1 = o23_1;
                                }
                                o18_tag = o21_tag;
                                o18_0 = o21_0;
                                o18_1 = o21_1;
                            } else {
                                o18_tag = 0;
                                o18_0 = 0;
                                o18_1 = 0;
                            }
                            o16_tag = o18_tag;
                            o16_0 = o18_0;
                            o16_1 = o18_1;
                        }
                        o13_tag = o16_tag;
                        o13_0 = o16_0;
                        o13_1 = o16_1;
                    } else {
                        o13_tag = 0;
                        o13_0 = 0;
                        o13_1 = 0;
                    }
                    o11_tag = o13_tag;
                    o11_0 = o13_0;
                    o11_1 = o13_1;
                }
                o8_tag = o11_tag;
                o8_0 = o11_0;
                o8_1 = o11_1;
            } else {
                o8_tag = 0;
                o8_0 = 0;
                o8_1 = 0;
            }
            o6_tag = o8_tag;
            o6_0 = o8_0;
            o6_1 = o8_1;
        }
        o3_tag = o6_tag;
        o3_0 = o6_0;
        o3_1 = o6_1;
    } else {
        o3_tag = 0;
        o3_0 = 0;
        o3_1 = 0;
    }
    if (o3_tag) {
        *out0 = (uint64_t)(o3_0);
        *out1 = (uint64_t)(o3_1);
    }
    return o3_tag;
}
