#include <stddef.h>
#include <stdint.h>
#include <string.h>
typedef unsigned __int128 efch_u128;

/* Operaciones con signo sobre valores de w bits guardados sin signo y enmascarados. Solo usan
   aritmética sin signo: no hay comportamiento indefinido ni dependiente de la implementación. */
#define EFCH_SIGNED_OPS(T, SUF)                                                               \
static inline T efch_mask##SUF(unsigned w) { return w >= 8 * sizeof(T) ? (T)~(T)0 : (((T)1 << w) - 1); } \
static inline int efch_slt##SUF(T x, T y, unsigned w) { T s = (T)1 << (w - 1); return (x ^ s) < (y ^ s); } \
static inline T efch_sext##SUF(T x, unsigned w, unsigned n) {                                 \
    return (x & ((T)1 << (w - 1))) ? (x | (efch_mask##SUF(n) & ~efch_mask##SUF(w))) : x; }    \
static inline T efch_ashr##SUF(T x, T k, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int neg = (x >> (w - 1)) & 1;                                    \
    if (k >= w) return neg ? m : 0;                                                           \
    return (x >> k) | (neg ? (m & ~(m >> k)) : 0); }                                          \
static inline T efch_sdiv##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return nx ? 1 : m;                                                            \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, q = ax / ay;                     \
    return (nx != ny) ? ((T)-q & m) : q; }                                                    \
static inline T efch_srem##SUF(T x, T y, unsigned w) {                                        \
    T m = efch_mask##SUF(w); int nx = (x >> (w - 1)) & 1, ny = (y >> (w - 1)) & 1;            \
    if (y == 0) return x;                                                                     \
    T ax = nx ? ((T)-x & m) : x, ay = ny ? ((T)-y & m) : y, r = ax % ay;                     \
    return nx ? ((T)-r & m) : r; }
EFCH_SIGNED_OPS(uint64_t, 64)
EFCH_SIGNED_OPS(efch_u128, 128)

int efch_trama_decode__lang(const uint8_t *in_buf, size_t in_buf_len, uint64_t *out0, uint64_t *out1, uint64_t *out2)
{
    int o1_tag;
    uint64_t o1_0 = 0;
    uint64_t o1_1 = 0;
    uint64_t o1_2 = 0;
    if ((((uint64_t)((uint64_t)in_buf_len)) < UINT64_C(2))) {
        o1_tag = 0;
        o1_0 = 0;
        o1_1 = 0;
        o1_2 = 0;
    } else {
        uint64_t v2 = ((uint64_t)in_buf[UINT64_C(0)]);
        uint64_t v3 = ((v2 >> 3) & UINT64_C(7));
        uint64_t v4 = (v2 & UINT64_C(7));
        int o5_tag;
        uint64_t o5_0 = 0;
        uint64_t o5_1 = 0;
        uint64_t o5_2 = 0;
        if (((((v2 >> 6) != UINT64_C(1)) || (v3 == UINT64_C(6))) || (((uint64_t)((uint64_t)in_buf_len)) < ((uint64_t)((v4 + UINT64_C(2)) & UINT64_C(255)))))) {
            o5_tag = 0;
            o5_0 = 0;
            o5_1 = 0;
            o5_2 = 0;
        } else {
            uint64_t v6 = ((v3 == UINT64_C(7)) ? UINT64_C(90) : UINT64_C(0));
            uint64_t v7 = ((uint64_t)v2);
            uint64_t v8 = UINT64_C(0);
            int v9 = (UINT64_C(1) <= v4);
            uint64_t v10 = (v9 ? ((v7 + ((uint64_t)((uint64_t)in_buf[UINT64_C(1)]))) & UINT64_C(0xffff)) : v7);
            uint64_t v11 = (v9 ? (v8 | (((uint64_t)(((uint64_t)in_buf[UINT64_C(1)]) ^ v6)) << 0)) : v8);
            int v12 = (UINT64_C(2) <= v4);
            uint64_t v13 = (v12 ? ((v10 + ((uint64_t)((uint64_t)in_buf[UINT64_C(2)]))) & UINT64_C(0xffff)) : v10);
            uint64_t v14 = (v12 ? (v11 | (((uint64_t)(((uint64_t)in_buf[UINT64_C(2)]) ^ v6)) << 8)) : v11);
            int v15 = (UINT64_C(3) <= v4);
            uint64_t v16 = (v15 ? ((v13 + ((uint64_t)((uint64_t)in_buf[UINT64_C(3)]))) & UINT64_C(0xffff)) : v13);
            uint64_t v17 = (v15 ? (v14 | (((uint64_t)(((uint64_t)in_buf[UINT64_C(3)]) ^ v6)) << 16)) : v14);
            int v18 = (UINT64_C(4) <= v4);
            uint64_t v19 = (v18 ? ((v16 + ((uint64_t)((uint64_t)in_buf[UINT64_C(4)]))) & UINT64_C(0xffff)) : v16);
            uint64_t v20 = (v18 ? (v17 | (((uint64_t)(((uint64_t)in_buf[UINT64_C(4)]) ^ v6)) << 24)) : v17);
            int v21 = (UINT64_C(5) <= v4);
            uint64_t v22 = (v21 ? ((v19 + ((uint64_t)((uint64_t)in_buf[UINT64_C(5)]))) & UINT64_C(0xffff)) : v19);
            uint64_t v23 = (v21 ? (v20 | (((uint64_t)(((uint64_t)in_buf[UINT64_C(5)]) ^ v6)) << 32)) : v20);
            int v24 = (UINT64_C(6) <= v4);
            uint64_t v25 = (v24 ? ((v22 + ((uint64_t)((uint64_t)in_buf[UINT64_C(6)]))) & UINT64_C(0xffff)) : v22);
            uint64_t v26 = (v24 ? (v23 | (((uint64_t)(((uint64_t)in_buf[UINT64_C(6)]) ^ v6)) << 40)) : v23);
            int v27 = (UINT64_C(7) <= v4);
            uint64_t v28 = (v27 ? ((v25 + ((uint64_t)((uint64_t)in_buf[UINT64_C(7)]))) & UINT64_C(0xffff)) : v25);
            uint64_t v29 = (v27 ? (v26 | (((uint64_t)(((uint64_t)in_buf[UINT64_C(7)]) ^ v6)) << 48)) : v26);
            int o30_tag;
            uint64_t o30_0 = 0;
            uint64_t o30_1 = 0;
            uint64_t o30_2 = 0;
            if ((((uint64_t)((uint64_t)in_buf[((uint64_t)((v4 + UINT64_C(1)) & UINT64_C(255)))])) != (UINT64_C(251) == 0 ? v28 : v28 % UINT64_C(251)))) {
                o30_tag = 0;
                o30_0 = 0;
                o30_1 = 0;
                o30_2 = 0;
            } else {
                int o31_tag;
                uint64_t o31_0 = 0;
                uint64_t o31_1 = 0;
                uint64_t o31_2 = 0;
                if (((v4 > UINT64_C(0)) && ((((uint64_t)in_buf[((uint64_t)v4)]) ^ v6) == UINT64_C(0)))) {
                    o31_tag = 0;
                    o31_0 = 0;
                    o31_1 = 0;
                    o31_2 = 0;
                } else {
                    int o32_tag;
                    uint64_t o32_0 = 0;
                    uint64_t o32_1 = 0;
                    uint64_t o32_2 = 0;
                    if (((v3 == UINT64_C(0)) && (v29 >= UINT64_C(0x3e8)))) {
                        o32_tag = 0;
                        o32_0 = 0;
                        o32_1 = 0;
                        o32_2 = 0;
                    } else {
                        o32_tag = 1;
                        o32_0 = v29;
                        o32_1 = v3;
                        o32_2 = ((v4 + UINT64_C(2)) & UINT64_C(255));
                    }
                    o31_tag = o32_tag;
                    o31_0 = o32_0;
                    o31_1 = o32_1;
                    o31_2 = o32_2;
                }
                o30_tag = o31_tag;
                o30_0 = o31_0;
                o30_1 = o31_1;
                o30_2 = o31_2;
            }
            o5_tag = o30_tag;
            o5_0 = o30_0;
            o5_1 = o30_1;
            o5_2 = o30_2;
        }
        o1_tag = o5_tag;
        o1_0 = o5_0;
        o1_1 = o5_1;
        o1_2 = o5_2;
    }
    if (o1_tag) {
        *out0 = (uint64_t)(o1_0);
        *out1 = (uint64_t)(o1_1);
        *out2 = (uint64_t)(o1_2);
    }
    return o1_tag;
}
