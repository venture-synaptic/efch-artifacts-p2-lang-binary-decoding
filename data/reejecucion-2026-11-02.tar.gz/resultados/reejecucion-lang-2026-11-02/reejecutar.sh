#!/bin/bash
# Re-ejecución de EXP-004 y EXP-015 con el código de main 26315176 (02/11/2026).
set -u
cd /home/ubuntu/efch-rerun-lang
O=resultados/reejecucion-lang-2026-11-02
mkdir -p $O
{
echo "inicio $(date -u +%FT%TZ) commit $(git rev-parse HEAD)"
python3 experimentos/lang01.py --salida $O/exp-004-O2
python3 experimentos/lang01.py --salida $O/exp-004-O3 --cflags="-O3 -march=native"
for o in cargas d0 d2 fuentes; do echo "== exp015 $o"; python3 experimentos/exp015.py $o --salida $O/exp-015 || echo "FALLO $o"; done
echo "== cargas idénticas a las archivadas?"
for f in ipv4 varint; do for s in 1 2 20261024; do a=$(find $O/exp-015 -path "*$f*" -name "carga-$s.bin" | head -1); b=$(find resultados/exp-015 -path "*$f*" -name "carga-$s.bin" | head -1); echo "$f $s $(sha256sum $a | cut -c1-16) $(sha256sum $b | cut -c1-16)"; done; done
for f in ipv4 varint; do
  case $f in ipv4) fn=efch_ipv4_header__lang; bl=baseline_ipv4_header;; varint) fn=efch_varint_u64__lang; bl=baseline_varint_u64;; esac
  c=$(dirname $(find resultados/exp-015 -path "*$f*" -name "carga-1.bin" | head -1))
  echo "== M9 $f"
  python3 experimentos/maquina.py medir reejecucion-$f -- python3 experimentos/m9.py \
    --a $O/exp-015/fuentes/$f-lang.c:$fn --b ejemplos/corpus-g4/$f/baseline.c:$bl \
    --carga $c/carga-*.bin --salida $O/exp-015/d3-$f
done
echo "fin $(date -u +%FT%TZ)"
} > $O/reejecucion.log 2>&1
